"""Bit-exact fused dot product for a parameterized binary floating format.

All products and the accumulation are performed exactly (integer arithmetic
on significands scaled by powers of two); only the final sum is rounded.
"""
import json
import sys


def solve(req):
    ebits = int(req["ebits"])
    fbits = int(req["fbits"])
    mode = str(req["mode"]).upper()
    pairs = req.get("pairs") or []

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                 # F = 2**fbits
    Eall = (1 << ebits) - 1        # all-ones exponent
    width = 1 + ebits + fbits
    wmask = (1 << width) - 1
    fmask = F - 1
    topbit = F >> 1                # top fraction bit (quiet/signal marker)
    emin = 1 - bias
    emax = Eall - 1 - bias
    eshift = ebits + fbits

    def decode(h):
        # Hex pattern of any sufficient length (case/leading zeros immaterial).
        v = h if type(h) is int else int(str(h).strip(), 16)
        if v > wmask:
            v &= wmask
        return (v >> eshift) & 1, (v >> fbits) & Eall, v & fmask

    # ---- inspect every operand -------------------------------------------
    invalid = False
    any_nan = False
    inf_pos = False
    inf_neg = False
    prods = []                     # (sign, significand, exponent)

    for pair in pairs:
        sa, ea, fa = decode(pair[0])
        sb, eb, fb = decode(pair[1])

        nana = ea == Eall and fa != 0
        nanb = eb == Eall and fb != 0
        if nana:
            any_nan = True
            if not (fa & topbit):          # signaling NaN
                invalid = True
        if nanb:
            any_nan = True
            if not (fb & topbit):
                invalid = True
        if nana or nanb:
            continue                       # NaN pair contributes nothing

        infa = ea == Eall
        infb = eb == Eall
        zeroa = ea == 0 and fa == 0
        zerob = eb == 0 and fb == 0
        if (infa and zerob) or (zeroa and infb):
            invalid = True                 # zero times infinity
            continue
        if infa or infb:                   # infinite product
            if sa ^ sb:
                inf_neg = True
            else:
                inf_pos = True
            continue

        if ea == 0:
            siga, expa = fa, 1 - bias - fbits
        else:
            siga, expa = F + fa, ea - bias - fbits
        if eb == 0:
            sigb, expb = fb, 1 - bias - fbits
        else:
            sigb, expb = F + fb, eb - bias - fbits
        prods.append((sa ^ sb, siga * sigb, expa + expb))

    if inf_pos and inf_neg:
        invalid = True                      # +inf and -inf products

    # ---- NaN results -----------------------------------------------------
    if invalid or any_nan:
        bits = (Eall << fbits) | topbit     # canonical NaN
        return {"bits": format(bits, "x"),
                "flags": ["invalid"] if invalid else []}

    sbit = 1 if inf_neg else 0
    if inf_pos or inf_neg:                  # infinite result, no flags
        return {"bits": format((sbit << eshift) | (Eall << fbits), "x"),
                "flags": []}

    # ---- exact finite sum: S * 2**Emin ----------------------------------
    if prods:
        Emin = min(p[2] for p in prods)
        S = 0
        for sgn, sig, exp in prods:
            t = sig << (exp - Emin)
            S = S - t if sgn else S + t
    else:
        Emin = 0
        S = 0

    if S == 0:
        # Exact zero: negative only if every product is a negative signed
        # zero (with at least one product), or the mode is RDN.
        negz = mode == "RDN" or (bool(prods) and
                                 all(sgn == 1 and sig == 0
                                     for sgn, sig, _ in prods))
        return {"bits": format((1 if negz else 0) << eshift, "x"),
                "flags": []}

    neg = S < 0
    A = -S if neg else S                     # exact magnitude = A * 2**Emin
    L = A.bit_length() - 1 + Emin            # floor(log2(x))
    k = emin - fbits
    if L - fbits > k:
        k = L - fbits                        # quantum q = 2**k
    d = k - Emin

    if d <= 0:
        n = A << (-d)                        # exact: no rounding needed
        inexact = False
    else:
        base = 1 << d
        quot, rem = divmod(A, base)
        if rem == 0:
            n = quot
            inexact = False
        else:
            twice = rem << 1
            if mode == "RNE":
                if twice > base:
                    n = quot + 1
                elif twice < base:
                    n = quot
                else:                        # tie -> even significand
                    n = quot + 1 if (quot & 1) else quot
            elif mode == "RNA":
                n = quot + 1 if twice >= base else quot
            elif mode == "RTZ":
                n = quot
            elif mode == "RUP":
                n = quot + 1 if not neg else quot
            elif mode == "RDN":
                n = quot + 1 if neg else quot
            else:
                n = quot
            inexact = True                   # n*2**d != A

    # ---- overflow: rounded magnitude y = n*2**k >= 2**(emax+1) ----------
    if n == 0:
        overflow = False
    else:
        diff = k - (emax + 1)
        overflow = True if diff >= 0 else n >= (1 << (-diff))

    sbit = 1 if neg else 0
    if overflow:
        nearest = mode in ("RNE", "RNA")
        away = (mode == "RUP" and not neg) or (mode == "RDN" and neg)
        if nearest or away:
            bits = (sbit << eshift) | (Eall << fbits)
        else:
            bits = (sbit << eshift) | ((Eall - 1) << fbits) | fmask
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
        if n == 0:
            tiny = True
        else:
            dd = emin - k
            tiny = dd > 0 and n < (1 << dd)
        if tiny:
            flags.append("underflow")

    # ---- encode the rounded magnitude y = n * 2**k ----------------------
    if n == 0:
        e, f = 0, 0                          # keeps the exact sign
    elif n < F:
        e, f = 0, n                           # subnormal (k == emin-fbits)
    else:
        sh = n.bit_length() - (fbits + 1)
        M = n >> sh                          # F <= M < 2F
        e = (k + sh) + bias + fbits
        f = M - F
    bits = (sbit << eshift) | (e << fbits) | f
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")


if __name__ == "__main__":
    main()
