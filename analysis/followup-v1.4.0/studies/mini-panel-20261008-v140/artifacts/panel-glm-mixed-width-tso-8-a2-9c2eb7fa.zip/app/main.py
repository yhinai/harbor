#!/usr/bin/env python3
"""Mixed-width buffered machine.

Enumerate every distinct terminal observable outcome of a small TSO-like
teaching model with per-thread FIFO store buffers, per-byte store
forwarding, fences and atomic (read-modify-write) exchanges.

State exploration is an explicit DFS over the transition system.  Every
transition advances ``sum(pc) + sum(drained)`` by exactly one, so the
transition graph is a DAG and the future behaviour of a state is fully
determined by the state itself (past observations are irrelevant for the
future).  Therefore ``dfs`` may memoise, per state, the set of *suffix*
outcomes (per-thread future observations plus final memory), which keeps the
search finite and complete while still enumerating all interleavings.

State representation:
  pcs : tuple of program counters                       (buffer heads are
  ds  : tuple of drained-store counts                    implied: thread t's
  mem : shared memory packed into one int (little endian)  buffer holds its
                                                         stores[ds:exec])
"""

import json
import sys

_STORE = "store"
_LOAD = "load"
_FENCE = "fence"
_XCHG = "xchg"


def _pack_memory(mem_list):
    m = 0
    shift = 0
    for b in mem_list:
        m |= (int(b) & 0xFF) << shift
        shift += 8
    return m


def _compile(request):
    """Normalise a request into compact per-thread tables."""
    mem_list = request["memory"]
    n = len(mem_list)
    programs = [[tuple(ins) for ins in prog] for prog in request["threads"]]
    nthreads = len(programs)

    lens = []
    exec_count = []   # exec_count[t][pc] = stores issued among instrs[:pc]
    store_ops = []    # store_ops[t][i] = (notmask, payload) for draining
    actions = []      # actions[t][pc] = normalised action descriptor

    for prog in programs:
        lt = len(prog)
        lens.append(lt)
        counts = [0] * (lt + 1)
        sts = []
        cov = [[] for _ in range(n)]   # cov[j] = [(store idx, byte), ...] in program order
        acts = []
        for pc, ins in enumerate(prog):
            op = ins[0]
            if op == _STORE:
                addr = int(ins[1])
                width = int(ins[2])
                value = int(ins[3]) & ((1 << (8 * width)) - 1)
                shift = 8 * addr
                mask = ((1 << (8 * width)) - 1) << shift
                idx = len(sts)
                sts.append((~mask, value << shift))
                for k in range(width):
                    cov[addr + k].append((idx, (value >> (8 * k)) & 0xFF))
                acts.append((_STORE,))
            elif op == _LOAD:
                addr = int(ins[1])
                width = int(ins[2])
                # (memory shift of the byte, covering stores youngest first,
                #  shift of the byte inside the loaded value)
                fields = tuple(
                    (8 * (addr + k), tuple(reversed(cov[addr + k])), 8 * k)
                    for k in range(width)
                )
                acts.append((_LOAD, fields))
            elif op == _FENCE:
                acts.append((_FENCE,))
            elif op == _XCHG:
                addr = int(ins[1])
                width = int(ins[2])
                value = int(ins[3]) & ((1 << (8 * width)) - 1)
                shift = 8 * addr
                mask = ((1 << (8 * width)) - 1) << shift
                acts.append((_XCHG, shift, (1 << (8 * width)) - 1, ~mask, value << shift))
            else:
                raise ValueError("unknown instruction %r" % (op,))
            counts[pc + 1] = len(sts)
        exec_count.append(counts)
        store_ops.append(sts)
        actions.append(acts)

    return n, nthreads, lens, exec_count, store_ops, actions, _pack_memory(mem_list)


def solve(request):
    n, nthreads, lens, exec_count, store_ops, actions, mem0 = _compile(request)

    memo = {}
    empty_reads = ((),) * nthreads
    nrange = range(nthreads)

    def dfs(pcs, ds, mem):
        """Return the set of suffix outcomes reachable from this state.

        An outcome is (reads, memory) where ``reads`` is a tuple with one
        tuple of observations per thread (only observations still to come).
        """
        key = (pcs, ds, mem)
        got = memo.get(key)
        if got is not None:
            return got

        outs = set()
        enabled = False
        for t in nrange:
            pc = pcs[t]
            lt = lens[t]
            issued = exec_count[t][pc]     # stores executed by thread t
            drained = ds[t]
            # --- 1. execute the next instruction of thread t -----------------
            if pc < lt:
                act = actions[t][pc]
                kind = act[0]
                if kind == _STORE:
                    # append to buffer (implied by pc), memory untouched
                    npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                    outs.update(dfs(npcs, ds, mem))
                    enabled = True
                elif kind == _LOAD:
                    # youngest own buffered store covering each byte wins
                    val = 0
                    for memshift, covd, resshift in act[1]:
                        byte = -1
                        for idx, bval in covd:
                            if idx < issued:
                                if idx >= drained:   # still in the buffer
                                    byte = bval
                                break                 # youngest covering store
                        if byte < 0:
                            byte = (mem >> memshift) & 0xFF
                        val |= byte << resshift
                    npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                    for reads, m in dfs(npcs, ds, mem):
                        nr = reads[:t] + ((val,) + reads[t],) + reads[t + 1:]
                        outs.add((nr, m))
                    enabled = True
                elif kind == _FENCE:
                    if drained == issued:             # buffer must be empty
                        npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                        outs.update(dfs(npcs, ds, mem))
                        enabled = True
                else:                                 # xchg
                    _, shift, valmask, notmask, payload = act
                    if drained == issued:             # buffer must be empty
                        val = (mem >> shift) & valmask
                        nmem = (mem & notmask) | payload
                        npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                        for reads, m in dfs(npcs, ds, nmem):
                            nr = reads[:t] + ((val,) + reads[t],) + reads[t + 1:]
                            outs.add((nr, m))
                        enabled = True
            # --- 2. drain the oldest buffered store of thread t --------------
            if drained < issued:
                notmask, payload = store_ops[t][drained]
                nmem = (mem & notmask) | payload
                nds = ds[:t] + (drained + 1,) + ds[t + 1:]
                outs.update(dfs(pcs, nds, nmem))
                enabled = True

        if not enabled:
            # every thread finished and every buffer is empty
            outs.add((empty_reads, mem))
        memo[key] = outs
        return outs

    result = dfs(tuple(0 for _ in nrange), tuple(0 for _ in nrange), mem0)
    outcomes = [
        {
            "reads": [list(r) for r in reads],
            "memory": [(m >> (8 * i)) & 0xFF for i in range(n)],
        }
        for reads, m in result
    ]
    return {"outcomes": outcomes}


def main():
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
