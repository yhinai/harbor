"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin and writes one JSON response
per request on stdout. See the task contract for the binary record format.
"""
import json
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_SIZE = 13  # payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
CRC_SIZE = 4

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _u32(buf):
    return int.from_bytes(buf, "little")


def recover(pages, checkpoint, log):
    """Replay the structurally valid prefix of ``log`` over ``pages``.

    ``pages`` is a list of bytearrays (mutated in place). Returns
    ``(valid_bytes, last_seq)``.
    """
    n = len(log)
    pos = 0
    prev_seq = 0
    last_seq = 0
    valid_bytes = 0
    active = {}  # transaction id -> list of staged (payload, page_index, offset, data)

    while True:
        if n - pos < HEADER_SIZE:
            break  # incomplete / torn header
        header = log[pos:pos + HEADER_SIZE]
        payload_length = _u32(header[0:4])
        sequence = _u32(header[4:8])
        kind = header[8]
        txid = _u32(header[9:13])

        # Header validation: bounded payload, positive and strictly
        # increasing sequence (previous starts at 0), known kind,
        # positive transaction id.
        if payload_length > MAX_PAYLOAD:
            break
        if sequence <= prev_seq:
            break
        if not KIND_BEGIN <= kind <= KIND_ABORT:
            break
        if txid == 0:
            break

        record_end = pos + HEADER_SIZE + payload_length + CRC_SIZE
        if record_end > n:
            break  # incomplete / torn record
        payload_end = pos + HEADER_SIZE + payload_length
        payload = log[pos + HEADER_SIZE:payload_end]
        stored_crc = _u32(log[payload_end:record_end])
        if zlib.crc32(log[pos:payload_end]) != stored_crc:
            break  # CRC mismatch

        # Payload shape and bounds validation.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_length != 0:
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        else:  # KIND_PATCH
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            if page_index >= len(pages):
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break

        # The record is structurally valid: it extends the prefix and only
        # now may have a semantic effect.
        prev_seq = sequence
        last_seq = sequence
        valid_bytes = record_end
        pos = record_end

        if kind == KIND_BEGIN:
            # Fresh incarnation; any unfinished one is discarded.
            active[txid] = []
        elif kind == KIND_PATCH:
            staged = active.get(txid)
            if staged is not None:
                staged.append((payload, page_index, byte_offset, bytes(payload[6:])))
        elif kind == KIND_ABORT:
            active.pop(txid, None)
        else:  # KIND_COMMIT always closes its active incarnation, if any.
            staged = active.pop(txid, None)
            if staged is not None and sequence > checkpoint:
                patch_count = _u32(payload[0:4])
                digest = _u32(payload[4:8])
                if patch_count == len(staged):
                    crc = 0
                    for entry in staged:
                        crc = zlib.crc32(entry[0], crc)
                    if crc == digest:
                        # Seals match and the commit is newer than the
                        # checkpoint: apply staged patches atomically, in
                        # patch (log) order.
                        for _, page_index, byte_offset, data in staged:
                            page = pages[page_index]
                            page[byte_offset:byte_offset + len(data)] = data
            # A seal mismatch (or a commit at/below the checkpoint) simply
            # closes the incarnation without applying; the prefix stands.

    return valid_bytes, last_seq


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    checkpoint = int(request["checkpoint"])
    log = bytes.fromhex(request["log"])
    valid_bytes, last_seq = recover(pages, checkpoint, log)
    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
