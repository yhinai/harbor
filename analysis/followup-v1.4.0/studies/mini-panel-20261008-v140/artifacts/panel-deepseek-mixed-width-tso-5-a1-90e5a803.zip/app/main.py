"""Exhaustive terminal outcomes for a mixed-width buffered (TSO-like) machine.

Machine state
-------------
A state consists of

  * one program counter per thread,
  * one FIFO store buffer per thread (a sequence of (address, width, value)
    stores that have been issued but not yet drained),
  * the shared memory (one byte per address).

Observations do not influence which transitions are enabled, so states that
share a machine state but differ only in their observation lists can be
processed together.  For every reachable machine state we keep the set of
observation prefixes that reach it, and its outgoing transitions are computed
only once.  Every terminal machine state then yields one outcome per
observation prefix (all with that state's final memory).
"""

import json
import sys


def _parse(request):
    memory = tuple(int(b) & 0xFF for b in request["memory"])
    progs = []
    for prog in request["threads"]:
        ins = []
        for x in prog:
            op = x[0]
            if op == "store":
                ins.append(("store", int(x[1]), int(x[2]), int(x[3])))
            elif op == "load":
                ins.append(("load", int(x[1]), int(x[2])))
            elif op == "fence":
                ins.append(("fence",))
            elif op == "xchg":
                ins.append(("xchg", int(x[1]), int(x[2]), int(x[3])))
            else:
                raise ValueError("unknown instruction")
        progs.append(tuple(ins))
    return memory, tuple(progs)


def _successors(state, progs, lens, nt):
    """All transitions out of ``state``.

    Each transition is ``(new_state, thread, value)`` where ``value`` is the
    observation appended to ``thread``, or None when nothing is observed.
    """
    pcs, bufs, mem = state
    succs = []

    # 1. Execute the next instruction of any thread.
    for t in range(nt):
        pc = pcs[t]
        if pc >= lens[t]:
            continue
        ins = progs[t][pc]
        op = ins[0]

        if op == "store":
            _, a, w, v = ins
            nb = bufs[:t] + (bufs[t] + ((a, w, v),),) + bufs[t + 1:]
            npc = pcs[:t] + (pc + 1,) + pcs[t + 1:]
            succs.append(((npc, nb, mem), None, None))

        elif op == "load":
            _, a, w = ins
            bt = bufs[t]
            val = 0
            for k in range(w):
                addr = a + k
                bv = mem[addr]
                # youngest buffered store covering this byte wins
                for e in range(len(bt) - 1, -1, -1):
                    sa, sw, sv = bt[e]
                    if sa <= addr < sa + sw:
                        bv = (sv >> (8 * (addr - sa))) & 0xFF
                        break
                val |= bv << (8 * k)
            npc = pcs[:t] + (pc + 1,) + pcs[t + 1:]
            succs.append(((npc, bufs, mem), t, val))

        elif op == "fence":
            if not bufs[t]:
                npc = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                succs.append(((npc, bufs, mem), None, None))

        else:  # xchg
            _, a, w, v = ins
            if not bufs[t]:
                val = 0
                for k in range(w):
                    val |= mem[a + k] << (8 * k)
                nm = mem[:a] + tuple(
                    (v >> (8 * k)) & 0xFF for k in range(w)
                ) + mem[a + w:]
                npc = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                succs.append(((npc, bufs, nm), t, val))

    # 2. Drain the oldest store of any nonempty buffer.
    for t in range(nt):
        bt = bufs[t]
        if bt:
            a, w, v = bt[0]
            nb = bufs[:t] + (bt[1:],) + bufs[t + 1:]
            nm = mem[:a] + tuple(
                (v >> (8 * k)) & 0xFF for k in range(w)
            ) + mem[a + w:]
            succs.append(((pcs, nb, nm), None, None))

    return succs


def solve(request):
    mem0, progs = _parse(request)
    nt = len(progs)
    lens = tuple(len(p) for p in progs)

    start = (tuple([0] * nt), tuple([()] * nt), mem0)
    start_obs = tuple([()] * nt)

    # machine state -> set of observation prefixes reaching it
    obs_sets = {start: {start_obs}}
    succ_cache = {}
    stack = [(start, start_obs)]

    while stack:
        state, obs = stack.pop()
        succs = succ_cache.get(state)
        if succs is None:
            succs = _successors(state, progs, lens, nt)
            succ_cache[state] = succs
        for new_state, t, val in succs:
            if val is None:
                obs2 = obs
            else:
                ot = obs[t]
                obs2 = obs[:t] + (ot + (val,),) + obs[t + 1:]
            seen = obs_sets.get(new_state)
            if seen is None:
                obs_sets[new_state] = {obs2}
                stack.append((new_state, obs2))
            elif obs2 not in seen:
                seen.add(obs2)
                stack.append((new_state, obs2))

    outcomes = set()
    for state, obss in obs_sets.items():
        pcs, bufs, mem = state
        if all(pcs[t] == lens[t] for t in range(nt)) and all(not b for b in bufs):
            for obs in obss:
                outcomes.add((obs, mem))

    return {
        "outcomes": [
            {"reads": [list(o) for o in obs], "memory": list(mem)}
            for obs, mem in outcomes
        ]
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line)), separators=(",", ":")))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
