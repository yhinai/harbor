"""Linearizability checker for histories of atomic range transactions.

A whole transaction is one atomic operation: the operations inside it may not
interleave with other transactions.  We must decide whether the completed
history admits a serial witness, i.e. an order of all transactions such that

  * real time is respected (A.end <= B.start  =>  A occurs before B), and
  * replaying the transactions in that order, starting from `initial`, matches
    every expected observation of every operation and ends exactly at `final`.

Algorithm
---------
Depth first search over topological orders, carrying the map produced by the
already scheduled prefix.  Two ideas keep it tiny for histories of this size
(at most 10 transactions, 6 keys):

* Memoisation of failures on (scheduled-set, map).  Everything the future can
  depend on is exactly that pair, so a failed pair is never retried.

* A repair prune: a key whose current value differs from its required final
  value must still be repairable, so some not yet scheduled transaction has to
  be able to write that required value (otherwise the final map is already
  unreachable).  A companion test at the root additionally refuses schedules in
  which real time forces an unconditional writer after every such repairer.

The search is exhaustive, so `order: null` is a proof that no witness exists.
"""

import json
import sys

# ------------------------------------------------------------------ op codes
GET, PUT, DEL, CAS, SCAN = 0, 1, 2, 3, 4


def run(prog, state):
    """Replay one transaction against `state`; return the new tuple, or None
    if an expected observation does not match."""
    st = list(state)
    for ins in prog:
        c = ins[0]
        if c == PUT:
            st[ins[1]] = ins[2]
        elif c == GET:
            if st[ins[1]] != ins[2]:
                return None
        elif c == DEL:
            st[ins[1]] = None
        elif c == CAS:
            i = ins[1]
            ok = st[i] == ins[2]
            if ok is not ins[4]:
                return None
            if ok:
                st[i] = ins[3]
        else:  # SCAN
            obs = []
            for i in ins[1]:
                v = st[i]
                if v is not None:
                    obs.append((i, v))
            if obs != ins[2]:
                return None
    return tuple(st)


def compile_tx(ops, kidx, keylist):
    """Compile JSON operations into tuples of ints/tuples (fast to execute)."""
    prog = []
    for op in ops:
        kind = op[0]
        if kind == 'get':
            prog.append((GET, kidx[op[1]], op[2]))
        elif kind == 'put':
            prog.append((PUT, kidx[op[1]], op[2]))
        elif kind == 'del':
            prog.append((DEL, kidx[op[1]]))
        elif kind == 'cas':
            prog.append((CAS, kidx[op[1]], op[2], op[3], op[4]))
        elif kind == 'scan':
            low = op[1]
            high = op[2]
            rng = [i for i, k in enumerate(keylist) if low <= k < high]
            exp = [(kidx.get(k, -1), v) for k, v in op[3]]
            if any(e[0] < 0 for e in exp):
                # expects a key nothing can ever create: never satisfiable
                exp = [(-1, None)]
            prog.append((SCAN, rng, exp))
        else:
            return None
    return prog


def solve(req):
    if not isinstance(req, dict):
        return {"order": None}
    initial = req.get('initial') or {}
    final = req.get('final') or {}
    txs = list(req.get('transactions') or [])
    if not isinstance(initial, dict) or not isinstance(final, dict):
        return {"order": None}

    keys = set(initial)
    keys.update(final)
    for t in txs:
        for op in t['ops']:
            if op[0] in ('get', 'put', 'del', 'cas'):
                keys.add(op[1])
    keylist = sorted(keys)
    nk = len(keylist)
    kidx = {k: i for i, k in enumerate(keylist)}

    init_state = tuple(initial.get(k) for k in keylist)
    fs = tuple(final.get(k) for k in keylist)

    n = len(txs)
    if n == 0:
        return {"order": [] if init_state == fs else None}

    progs = []
    for t in txs:
        prog = compile_tx(t['ops'], kidx, keylist)
        if prog is None:
            return {"order": None}
        progs.append(prog)

    bits = [1 << i for i in range(n)]
    full = (1 << n) - 1

    # real time: predecessors that have to be scheduled first
    prec = [0] * n
    for i, a in enumerate(txs):
        pi = 0
        for j, b in enumerate(txs):
            if b['end'] <= a['start']:
                pi |= bits[j]
        prec[i] = pi

    # good[j]: transactions able to write key j to its required final value.
    # wu[j]:   transactions that unconditionally write key j (put or del).
    good = [0] * nk
    wu = [0] * nk
    for i, prog in enumerate(progs):
        for ins in prog:
            c = ins[0]
            if c == PUT:
                wu[ins[1]] |= bits[i]
                if ins[2] == fs[ins[1]]:
                    good[ins[1]] |= bits[i]
            elif c == DEL:
                wu[ins[1]] |= bits[i]
                if fs[ins[1]] is None:
                    good[ins[1]] |= bits[i]
            elif c == CAS:
                if ins[3] == fs[ins[1]]:
                    good[ins[1]] |= bits[i]

    # for each key, is the required final value reachable at all?  The last
    # transaction that actually writes key j must write the required value, and
    # no unconditional writer of j may be forced after it by real time.
    for j in range(nk):
        if init_state[j] != fs[j]:
            if not good[j]:
                return {"order": None}
            gm = good[j]
            feas = False
            for g in range(n):
                if (gm >> g) & 1:
                    blocked = False
                    for w in range(n):
                        if w != g and (wu[j] >> w) & 1 and txs[g]['end'] <= txs[w]['start']:
                            blocked = True
                            break
                    if not blocked:
                        feas = True
                        break
            if not feas:
                return {"order": None}

    checks = [(j, fs[j], good[j]) for j in range(nk)]

    order = []
    fails = [set() for _ in range(1 << n)]

    def dfs(mask, state):
        if mask == full:
            return state == fs
        f = fails[mask]
        if state in f:
            return False
        rem = full ^ mask
        for i in range(n):
            b = bits[i]
            if not (rem & b) or (prec[i] & rem):
                continue
            new = run(progs[i], state)
            if new is None:
                continue
            nrem = rem ^ b
            dead = False
            for j, want, gm in checks:
                if new[j] != want and not (gm & nrem):
                    dead = True
                    break
            if dead:
                continue
            order.append(i)
            if dfs(mask | b, new):
                return True
            order.pop()
        f.add(state)
        return False

    if dfs(0, init_state):
        return {"order": [txs[i]['id'] for i in order]}
    return {"order": None}


def main():
    out = []
    for line in sys.stdin.read().splitlines():
        if not line.strip():
            continue
        try:
            res = solve(json.loads(line))
        except Exception as exc:  # pragma: no cover - defensive
            print('solver error: %r' % (exc,), file=sys.stderr)
            res = {"order": None}
        out.append(json.dumps(res))
    if out:
        sys.stdout.write("\n".join(out) + "\n")


if __name__ == '__main__':
    main()
