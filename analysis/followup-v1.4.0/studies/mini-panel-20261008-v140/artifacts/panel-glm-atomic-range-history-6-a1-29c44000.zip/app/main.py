#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation, so a witness is a linear extension
of the interval precedence order (A.end <= B.start  =>  A before B) whose
execution from `initial` reproduces every observation and ends exactly at
`final`.

Useful structural fact: every expected result is part of the input, so the
effect a transaction has on the store is a *fixed* partial map -- a `put`
assigns a constant, a `del` removes, and a `cas` assigns its new value exactly
when its expected success flag is true.  Therefore the store after a prefix is
"for each key, the value written by the last transaction that writes it".

Two complementary complete searches exploit that:

* forward: extend a prefix one transaction at a time, carrying the concrete
  store, memoising (placed set, store);
* backward: build the order from the end, carrying for every key the set of
  values the store may hold at the current cut, memoising (chosen set, domains).

Both collapse the enormous number of interleavings into a few reachable
abstract states.  Either search alone is a decision procedure; running the
other one as a fallback keeps pathological instances cheap.
"""

import json
import sys
from bisect import bisect_left

sys.setrecursionlimit(100000)

# Marker for "key absent" (a key holding zero is different from an absent key).
ABSENT = object()
# Marker used only for dict lookups with a default.
_MISS = object()


class Budget(Exception):
    """Raised when a search exceeds its node allowance."""


class Inst(object):
    __slots__ = (
        'n', 'ids', 'K', 'keylist', 'init_state', 'final_state', 'cops',
        'preds', 'succs', 'netw', 'wrplans', 'has_reads', 'writes_mask',
        'fixers', 'lastok', 'valbit', 'fullmask', 'full_dv', 'final_dv',
        'init_bits',
    )


# --------------------------------------------------------------------------
# compilation
# --------------------------------------------------------------------------

def compile_instance(req):
    """Turn a request into integer-indexed tables.  Never fails on valid input."""
    inst = Inst()
    txs = req.get('transactions') or []
    n = inst.n = len(txs)
    inst.ids = [t['id'] for t in txs]
    initial = req.get('initial') or {}
    final = req.get('final') or {}

    # Key universe: every key that can be mentioned anywhere.
    keys = set(initial)
    keys.update(final)
    for t in txs:
        for op in t['ops']:
            tag = op[0]
            if tag == 'scan':
                keys.add(op[1])
                keys.add(op[2])
                for pair in op[3]:
                    keys.add(pair[0])
            else:
                keys.add(op[1])
    keylist = inst.keylist = sorted(keys)
    K = inst.K = len(keylist)
    kidx = {k: i for i, k in enumerate(keylist)}
    inst.init_state = tuple(initial.get(k, ABSENT) for k in keylist)
    inst.final_state = tuple(final.get(k, ABSENT) for k in keylist)

    # Compile ops: keys become indices, scan ranges become index tuples.
    cops = []       # per transaction: tuple of op tuples
    netws = []      # per transaction: {key index: value or ABSENT} (net effect)
    has_reads = []  # per transaction: does it observe anything?
    for t in txs:
        cops_t = []
        netw = {}
        reads = False
        for op in t['ops']:
            tag = op[0]
            if tag == 'get':
                cops_t.append(('G', kidx[op[1]], op[2]))
                reads = True
            elif tag == 'put':
                i = kidx[op[1]]
                cops_t.append(('P', i, op[2]))
                netw[i] = op[2]
            elif tag == 'del':
                i = kidx[op[1]]
                cops_t.append(('D', i))
                netw[i] = ABSENT
            elif tag == 'cas':
                i = kidx[op[1]]
                want = bool(op[4])
                cops_t.append(('C', i, op[2], op[3], want))
                reads = True
                if want:
                    netw[i] = ABSENT if op[3] is None else op[3]
            else:  # scan
                low, high, pairs = op[1], op[2], op[3]
                ridx = tuple(range(bisect_left(keylist, low),
                                   bisect_left(keylist, high)))
                emap = {}
                prev = None
                valid = True
                for pair in pairs:
                    k = pair[0]
                    if not (low <= k < high) or (prev is not None and k <= prev):
                        # expected pairs must be sorted, unique, inside range
                        valid = False
                        break
                    prev = k
                    emap[kidx[k]] = pair[1]
                cops_t.append(('S', ridx, emap, valid))
                reads = True
        cops.append(tuple(cops_t))
        netws.append(netw)
        has_reads.append(reads)
    inst.cops = cops
    inst.netw = netws
    inst.has_reads = has_reads
    inst.wrplans = [tuple(sorted(nw.items())) for nw in netws]

    # Interval precedence (an interval order, hence acyclic).
    preds = [0] * n
    succs = [0] * n
    for a in range(n):
        ea, sa = txs[a]['end'], txs[a]['start']
        for b in range(n):
            if a != b and ea <= txs[b]['start']:
                succs[a] |= 1 << b
                preds[b] |= 1 << a
    inst.preds = preds
    inst.succs = succs

    # Static write bookkeeping.
    writes_mask = [0] * K
    fixers = [0] * K          # transactions whose write to a key equals final
    lastok = 0                # transactions that may legally be the last one
    for t in range(n):
        bit = 1 << t
        nw = netws[t]
        ok = True
        for i, v in nw.items():
            writes_mask[i] |= bit
            if v == inst.final_state[i]:
                fixers[i] |= bit
            else:
                ok = False
        if ok:
            lastok |= bit
    inst.writes_mask = writes_mask
    inst.fixers = fixers
    inst.lastok = lastok

    # Per key: the values that key can ever hold (used by the backward search).
    poss = []
    for i in range(K):
        s = {ABSENT}
        v = inst.init_state[i]
        if v is not ABSENT:
            s.add(v)
        poss.append(s)
    for cops_t in cops:
        for op in cops_t:
            tag = op[0]
            if tag == 'P':
                poss[op[1]].add(op[2])
            elif tag == 'C' and op[4]:
                poss[op[1]].add(ABSENT if op[3] is None else op[3])
    valbit = []
    fullmask = []
    for i in range(K):
        vs = list(poss[i])
        valbit.append({v: 1 << j for j, v in enumerate(vs)})
        fullmask.append((1 << len(vs)) - 1)
    inst.valbit = valbit
    inst.fullmask = fullmask
    inst.full_dv = tuple(fullmask)
    inst.final_dv = tuple(valbit[i].get(inst.final_state[i], 0)
                          for i in range(K))
    inst.init_bits = [valbit[i].get(inst.init_state[i], 0) for i in range(K)]
    return inst


# --------------------------------------------------------------------------
# forward engine: concrete store
# --------------------------------------------------------------------------

def apply_fwd(ops, state):
    """Execute one transaction on a concrete store.  None => observation fails."""
    st = list(state)
    for op in ops:
        tag = op[0]
        if tag == 'P':
            st[op[1]] = op[2]
        elif tag == 'G':
            v = st[op[1]]
            if (None if v is ABSENT else v) != op[2]:
                return None
        elif tag == 'D':
            st[op[1]] = ABSENT
        elif tag == 'C':
            i = op[1]
            v = st[i]
            if ((None if v is ABSENT else v) == op[2]) != op[4]:
                return None
            if op[4]:
                st[i] = ABSENT if op[3] is None else op[3]
        else:  # scan
            if op[3] is False:
                return None
            emap = op[2]
            for i in op[1]:
                v = st[i]
                if v is ABSENT:
                    if i in emap:
                        return None
                elif emap.get(i, _MISS) != v:
                    return None
    return tuple(st)


def forward_search(inst, budget):
    """Return ('found', order) | ('none', None) | ('budget', None)."""
    n = inst.n
    full = (1 << n) - 1
    final_state = inst.final_state
    if n == 0:
        return ('found', []) if inst.init_state == final_state else ('none', None)
    preds = inst.preds
    cops = inst.cops
    has_reads = inst.has_reads
    wrplans = inst.wrplans
    fixers = inst.fixers
    lastok = inst.lastok
    K = inst.K
    krange = tuple(range(K))
    memo = set()
    path = []
    nodes = [0]

    def dfs(mask, state):
        nodes[0] += 1
        if budget is not None and nodes[0] > budget:
            raise Budget()
        if mask == full:
            return state == final_state
        for t in range(n):
            bit = 1 << t
            if mask & bit:
                continue
            if preds[t] & ~mask:
                continue       # an unplaced transaction must still come first
            if has_reads[t]:
                ns = apply_fwd(cops[t], state)
                if ns is None:
                    continue
            else:
                st = list(state)
                for i, v in wrplans[t]:
                    st[i] = v
                ns = tuple(st)
            nm = mask | bit
            # Pruning: the eventual last transaction must still be unplaced,
            # and every key that is not yet final must have a remaining fixer.
            if nm != full:
                rem = ~nm
                if not (lastok & rem):
                    continue
                bad = False
                for i in krange:
                    if ns[i] != final_state[i] and not (fixers[i] & rem):
                        bad = True
                        break
                if bad:
                    continue
            if (nm, ns) in memo:
                continue
            if dfs(nm, ns):
                path.append(t)
                return True
        memo.add((mask, state))
        return False

    try:
        found = dfs(0, inst.init_state)
    except Budget:
        return ('budget', None)
    if found:
        return ('found', [inst.ids[t] for t in reversed(path)])
    return ('none', None)


# --------------------------------------------------------------------------
# backward engine: per-key value domains
# --------------------------------------------------------------------------

def _req_mask(vb, exp):
    """Bitmask of store values whose *observed* value equals exp.

    Reading an absent key yields null, so an expectation of null accepts both
    an absent key and (defensively) a key explicitly holding null.
    """
    if exp is None:
        m = vb.get(ABSENT, 0)
        if None in vb:
            m |= vb[None]
        return m
    return vb.get(exp, 0)

def apply_bwd(ops, dv, valbit, fullmask, K):
    """Requirement on the store *before* a transaction.

    dv is the requirement on the store *after* it (per key, a bitmask of the
    allowed values).  Returns a new domain tuple, or None when no store can
    satisfy the transaction together with the suffix requirement.
    """
    val = list(fullmask)
    pre = list(fullmask)
    written = [False] * K
    for op in ops:
        tag = op[0]
        if tag == 'P':
            i = op[1]
            vb = valbit[i]
            m = vb.get(op[2], 0)
            if not m:
                return None
            if not written[i]:
                pre[i] = val[i]
                written[i] = True
            val[i] = m
        elif tag == 'G':
            i = op[1]
            val[i] &= _req_mask(valbit[i], op[2])
            if not val[i]:
                return None
            if not written[i]:
                pre[i] = val[i]
        elif tag == 'D':
            i = op[1]
            m = valbit[i][ABSENT]
            if not written[i]:
                pre[i] = val[i]
                written[i] = True
            val[i] = m
        elif tag == 'C':
            i = op[1]
            vb = valbit[i]
            m = _req_mask(vb, op[2])
            if op[4]:
                val[i] &= m          # must compare equal, then it writes
                if not val[i]:
                    return None
                if not written[i]:
                    pre[i] = val[i]
                wm = vb.get(ABSENT if op[3] is None else op[3], 0)
                if not wm:
                    return None
                if not written[i]:
                    pre[i] = val[i]
                    written[i] = True
                val[i] = wm
            else:
                val[i] &= fullmask[i] & ~m   # must compare unequal, no write
                if not val[i]:
                    return None
                if not written[i]:
                    pre[i] = val[i]
        else:  # scan
            if op[3] is False:
                return None
            emap = op[2]
            for i in op[1]:
                vb = valbit[i]
                m = vb.get(emap[i], 0) if i in emap else vb[ABSENT]
                val[i] &= m
                if not val[i]:
                    return None
                if not written[i]:
                    pre[i] = val[i]
    out = []
    for i in range(K):
        if written[i]:
            if not (val[i] & dv[i]):
                return None
            out.append(pre[i])
        else:
            m = val[i] & dv[i]
            if not m:
                return None
            out.append(m)
    return tuple(out)


def backward_search(inst, budget):
    """Return ('found', order) | ('none', None) | ('budget', None)."""
    n = inst.n
    full = (1 << n) - 1
    if n == 0:
        return ('found', []) if inst.init_state == inst.final_state else ('none', None)
    succs = inst.succs
    cops = inst.cops
    valbit = inst.valbit
    fullmask = inst.fullmask
    K = inst.K
    init_bits = inst.init_bits
    memo = set()
    path = []
    nodes = [0]

    def dfs(cmask, dv):
        nodes[0] += 1
        if budget is not None and nodes[0] > budget:
            raise Budget()
        if cmask == full:
            for i in range(K):
                if not (dv[i] & init_bits[i]):
                    return False
            return True
        for t in range(n):
            bit = 1 << t
            if cmask & bit:
                continue
            if succs[t] & ~cmask:
                continue    # a successor of t is not yet scheduled after t
            ndv = apply_bwd(cops[t], dv, valbit, fullmask, K)
            if ndv is None:
                continue
            nm = cmask | bit
            if (nm, ndv) in memo:
                continue
            if dfs(nm, ndv):
                path.append(t)
                return True
        memo.add((cmask, dv))
        return False

    try:
        found = dfs(0, inst.final_dv)
    except Budget:
        return ('budget', None)
    if found:
        return ('found', [inst.ids[t] for t in path])
    return ('none', None)


# --------------------------------------------------------------------------
# independent re-verification (mirrors the published semantics exactly)
# --------------------------------------------------------------------------

def verify(req, order):
    tx = {t['id']: t for t in req['transactions']}
    if not isinstance(order, list) or len(order) != len(tx):
        return False
    if any(not isinstance(x, str) for x in order) or set(order) != set(tx):
        return False
    ranks = {x: i for i, x in enumerate(order)}
    for a in tx.values():
        for b in tx.values():
            if a['end'] <= b['start'] and ranks[a['id']] >= ranks[b['id']]:
                return False
    d = dict(req.get('initial') or {})
    for name in order:
        for op in tx[name]['ops']:
            tag = op[0]
            if tag == 'get':
                if d.get(op[1]) != op[2]:
                    return False
            elif tag == 'put':
                d[op[1]] = op[2]
            elif tag == 'del':
                d.pop(op[1], None)
            elif tag == 'cas':
                _, key, old, new, want = op
                ok = d.get(key) == old
                if ok != want:
                    return False
                if ok:
                    if new is None:
                        d.pop(key, None)
                    else:
                        d[key] = new
            else:
                if sorted([[k, v] for k, v in d.items()
                           if op[1] <= k < op[2]]) != op[3]:
                    return False
    return d == (req.get('final') or {})


# --------------------------------------------------------------------------
# driver
# --------------------------------------------------------------------------

BUDGET = 400000


def solve(req):
    """Return {'order': [...]} for a witness, {'order': None} if there is none."""
    try:
        return {'order': _solve(req)}
    except Exception as exc:  # pragma: no cover - defensive
        print('solver failure: %r' % (exc,), file=sys.stderr)
        return {'order': None}


def _solve(req):
    inst = compile_instance(req)
    n = inst.n
    if n == 0:
        return [] if inst.init_state == inst.final_state else None

    # A transaction whose own operations contradict each other (or whose scan
    # expectations are malformed) can never be placed, and every transaction
    # has to be placed exactly once.
    full_dv = inst.full_dv
    valbit, fullmask, K = inst.valbit, inst.fullmask, inst.K
    for t in range(n):
        if apply_bwd(inst.cops[t], full_dv, valbit, fullmask, K) is None:
            return None

    # Keys nobody writes keep their initial value for the whole history.
    for i in range(K):
        if not inst.writes_mask[i] and inst.init_state[i] != inst.final_state[i]:
            return None
    # The last transaction of the witness decides every key it writes.
    if not inst.lastok:
        return None

    for engine in (backward_search, forward_search):
        status, order = engine(inst, BUDGET)
        if status == 'found':
            if verify(req, order):
                return order
        elif status == 'none':
            return None
    # Both budgeted out: retry without an allowance.  The searches are
    # complete, so this still yields a definite answer.
    for engine in (backward_search, forward_search):
        status, order = engine(inst, None)
        if status == 'found':
            if verify(req, order):
                return order
        elif status == 'none':
            return None
    return None


def main():
    out = []
    for line in sys.stdin:
        if not line.strip():
            continue
        req = json.loads(line)
        out.append(json.dumps(solve(req)))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))


if __name__ == '__main__':
    main()
