"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin, writes one JSON response per
line on stdout.  See instruction.md for the format contract.
"""

import json
import struct
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER = 13          # payload_length + sequence + kind + transaction_id
TRAILER = 4          # crc
KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _unhex(text):
    """Decode a hex string, tolerating an odd trailing nibble (torn byte)."""
    if len(text) & 1:
        text = text[:-1]
    return bytes.fromhex(text)


def solve(request):
    pages = [bytearray(_unhex(p)) for p in request["pages"]]
    checkpoint = int(request["checkpoint"])
    log = _unhex(request["log"])

    page_count = len(pages)
    n = len(log)
    pos = 0
    valid_bytes = 0
    last_seq = 0

    # txid -> [list of (page_index, byte_offset, data), patch_count, concat bytes]
    active = {}

    while pos + HEADER + TRAILER <= n:
        payload_len = int.from_bytes(log[pos:pos + 4], "little")
        if payload_len > MAX_PAYLOAD:
            break
        end = pos + HEADER + payload_len + TRAILER
        if end > n:
            break  # incomplete/torn record
        seq = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")
        payload = log[pos + HEADER:pos + HEADER + payload_len]
        crc = int.from_bytes(log[pos + HEADER + payload_len:end], "little")

        if zlib.crc32(log[pos:pos + HEADER + payload_len]) & 0xFFFFFFFF != crc:
            break
        if seq == 0 or seq <= last_seq:
            break
        if txid == 0:
            break

        # Structural validation of the payload shape.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_len != 0:
                break
        elif kind == KIND_PATCH:
            if payload_len < 6:
                break
            page_index, byte_offset, byte_count = struct.unpack_from("<HHH", payload, 0)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= page_count:
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break
        elif kind == KIND_COMMIT:
            if payload_len != 8:
                break
        else:
            break

        # The record is structurally valid: commit it to the prefix.
        valid_bytes = end
        last_seq = seq

        if kind == KIND_BEGIN:
            active[txid] = [[], 0, bytearray()]
        elif kind == KIND_PATCH:
            inc = active.get(txid)
            if inc is not None:
                page_index, byte_offset, byte_count = struct.unpack_from("<HHH", payload, 0)
                inc[0].append((page_index, byte_offset, payload[6:]))
                inc[1] += 1
                inc[2] += payload
        elif kind == KIND_COMMIT:
            inc = active.pop(txid, None)
            if inc is not None:
                patch_count, digest = struct.unpack_from("<II", payload, 0)
                if inc[1] == patch_count and (zlib.crc32(inc[2]) & 0xFFFFFFFF) == digest:
                    if seq > checkpoint:
                        for page_index, byte_offset, data in inc[0]:
                            pages[page_index][byte_offset:byte_offset + len(data)] = data
        else:  # KIND_ABORT
            active.pop(txid, None)

        pos = end

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))) + "\n")
        out.flush()


if __name__ == "__main__":
    main()
