#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Requests are newline-delimited JSON objects on stdin; one JSON response is
written per input line, in order:

    request  := {"pages": [hex, ...], "checkpoint": int, "log": hex}
    response := {"pages": [hex, ...], "valid_bytes": int, "last_seq": int}

`pages` is the authoritative durable checkpoint image, `checkpoint` a sequence
watermark, and `log` the journal to replay.

Record layout (all integers unsigned little-endian, no implicit padding):

    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32

The fixed header is 13 bytes and crc covers header + payload.

Kinds: 1 BEGIN (empty payload), 2 PATCH (page_index:u16 | byte_offset:u16 |
byte_count:u16 | data), 3 COMMIT (patch_count:u32 | digest:u32),
4 ABORT (empty payload).

Recovery replays only the structurally valid prefix of the log and applies only
complete, correctly sealed transactions whose COMMIT is newer than the
checkpoint; the durable image is never re-derived from journal records.
"""

import json
import sys
import zlib

HEADER_SIZE = 13   # payload_length:u32 + sequence:u32 + kind:u8 + transaction_id:u32
CRC_SIZE = 4       # trailing crc:u32
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _u16(buf, off):
    """Unsigned 16-bit little-endian integer at *off*."""
    return buf[off] | (buf[off + 1] << 8)


def _u32(buf, off):
    """Unsigned 32-bit little-endian integer at *off*."""
    return (buf[off]
            | (buf[off + 1] << 8)
            | (buf[off + 2] << 16)
            | (buf[off + 3] << 24))


def recover(pages_hex, checkpoint, log_hex):
    """Replay journal *log_hex* over *pages_hex* beyond *checkpoint*.

    Returns the recovered pages, the byte length of the log's valid prefix, and
    the sequence number of the last valid record (0 for an empty prefix).
    """
    pages = [bytearray.fromhex(p) for p in pages_hex]
    num_pages = len(pages)
    log = bytes.fromhex(log_hex)
    log_len = len(log)

    # Active incarnations: transaction_id -> [(patch payload, page, offset, count)]
    active = {}

    last_seq = 0       # sequence of the previous valid record (watermark)
    valid_bytes = 0    # byte length of the valid prefix
    off = 0

    while off < log_len:
        # Enough bytes for the fixed header?
        if log_len - off < HEADER_SIZE:
            break                                    # torn header

        payload_len = _u32(log, off)
        seq = _u32(log, off + 4)
        kind = log[off + 8]
        txid = _u32(log, off + 9)

        # Enough bytes for the payload and its trailing crc, and a sane length?
        end = off + HEADER_SIZE + payload_len + CRC_SIZE
        if payload_len > MAX_PAYLOAD or end > log_len:
            break                                    # bad length / incomplete record

        payload = log[off + HEADER_SIZE:off + HEADER_SIZE + payload_len]
        stored_crc = _u32(log, off + HEADER_SIZE + payload_len)

        # Checksum.
        if zlib.crc32(log[off:off + HEADER_SIZE + payload_len]) != stored_crc:
            break                                    # corrupt record

        # Sequence: positive and strictly increasing.
        if seq <= last_seq:
            break

        # Transaction id: positive.
        if txid == 0:
            break

        # Kind, payload shape and bounds. Structural validity is a precondition
        # for any semantic effect, so it is checked for every record, including
        # those that concern an inactive transaction.
        patch = None                                 # (page, offset, count)
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_len != 0:
                break
        elif kind == KIND_PATCH:
            if payload_len < 7:                      # 6 header bytes + >= 1 data byte
                break
            page_index = _u16(payload, 0)
            byte_offset = _u16(payload, 2)
            byte_count = _u16(payload, 4)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= num_pages:
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break                                # must fit an existing page
            patch = (page_index, byte_offset, byte_count)
        elif kind == KIND_COMMIT:
            if payload_len != 8:
                break
        else:
            break                                    # unknown kind

        # Structurally valid: the record extends the valid prefix and may now
        # take part in transaction state processing.
        if kind == KIND_BEGIN:
            active[txid] = []                         # fresh incarnation
        elif kind == KIND_PATCH:
            staged = active.get(txid)
            if staged is not None:                    # otherwise: ignored
                staged.append((payload, patch))
        elif kind == KIND_ABORT:
            active.pop(txid, None)                   # discard, if any
        else:                                         # KIND_COMMIT
            staged = active.pop(txid, None)          # always closes, if any
            if staged is not None:                   # orphan commits do nothing
                patch_count = _u32(payload, 0)
                digest = _u32(payload, 4)
                concat = b"".join(item[0] for item in staged)
                if (patch_count == len(staged)
                        and digest == zlib.crc32(concat)
                        and seq > checkpoint):
                    # Sealed, complete, newer than the checkpoint: replay.
                    for payload, (page, offset, count) in staged:
                        pages[page][offset:offset + count] = payload[6:6 + count]

        last_seq = seq
        valid_bytes = end
        off = end

    return {
        "pages": [bytes(page).hex() for page in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def solve(request):
    """Handle one request object."""
    return recover(request["pages"], request["checkpoint"], request["log"])


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            response = solve(json.loads(line))
        except Exception as exc:          # pragma: no cover - spec-conforming
            print("recovery failed: %r" % (exc,), file=sys.stderr)
            response = {"pages": [], "valid_bytes": 0, "last_seq": 0}
        out.write(json.dumps(response))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
