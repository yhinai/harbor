"""Entry point: newline-delimited JSON requests on stdin -> one JSON object per
output line, in input order.  The recovery rules live in journal.py.
"""

import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

from journal import solve


def respond(line):
    """Solve one request, falling back to a conservative answer on surprises.

    Inputs are specified to be well formed, so the fallback only guards against
    one stray line taking the whole batch down.
    """
    try:
        return solve(json.loads(line))
    except Exception as exc:  # pragma: no cover - defensive
        print("journal: ignoring malformed request: %r" % (exc,), file=sys.stderr)
        try:
            pages = json.loads(line).get("pages", [])
        except Exception:
            pages = []
        return {"pages": pages, "valid_bytes": 0, "last_seq": 0}


def main():
    for line in sys.stdin:
        if not line.strip():
            continue
        print(json.dumps(respond(line)))


if __name__ == "__main__":
    main()
