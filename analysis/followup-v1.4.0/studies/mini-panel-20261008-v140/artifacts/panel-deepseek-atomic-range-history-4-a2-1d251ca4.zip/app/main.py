import json, sys

ABSENT = 19          # encoded value for missing key
FULL = (1 << 20) - 1 # all encodings allowed


def enc(v):
    return ABSENT if v is None else v + 9


def solve(request):
    txs = request.get("transactions", [])
    n = len(txs)
    initial = request.get("initial", {})
    final = request.get("final", {})

    # ---- collect universe of keys ------------------------------------
    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            k = op[0]
            if k in ("get", "put", "del", "cas"):
                keys.add(op[1])
            elif k == "scan":
                for pair in op[3]:
                    keys.add(pair[0])
    universe = sorted(keys)
    m = len(universe)
    kidx = {k: i for i, k in enumerate(universe)}

    init_state = 0
    final_state = 0
    for i, k in enumerate(universe):
        init_state |= enc(initial.get(k)) << (5 * i)
        final_state |= enc(final.get(k)) << (5 * i)

    # ---- symbolic analysis of each transaction -----------------------
    A = []   # A[t][key] allowed start values (bitmask)
    C = []   # C[t][key] constant written, or -1 for "unchanged"
    bad = False
    for t in txs:
        a = [FULL] * m
        c = [-1] * m
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                i = kidx[op[1]]
                e = enc(op[2])
                if c[i] >= 0:
                    if c[i] != e:
                        bad = True
                        break
                else:
                    a[i] &= (1 << e)
                    if a[i] == 0:
                        bad = True
                        break
            elif kind == "put":
                i = kidx[op[1]]
                c[i] = enc(op[2])
            elif kind == "del":
                i = kidx[op[1]]
                c[i] = ABSENT
            elif kind == "cas":
                i = kidx[op[1]]
                eo = enc(op[2])
                en = enc(op[3])
                want = op[4]
                if c[i] >= 0:
                    cond = (c[i] == eo)
                    if cond != want:
                        bad = True
                        break
                    if want:
                        c[i] = en
                else:
                    if want:
                        a[i] &= (1 << eo)
                        if a[i] == 0:
                            bad = True
                            break
                        c[i] = en
                    else:
                        a[i] &= ~(1 << eo)
                        if a[i] == 0:
                            bad = True
                            break
            elif kind == "scan":
                low, high = op[1], op[2]
                expd = {}
                for pair in op[3]:
                    expd[pair[0]] = enc(pair[1])
                for i, k in enumerate(universe):
                    if low <= k < high:
                        if c[i] >= 0:
                            if c[i] != expd.get(k, ABSENT):
                                bad = True
                                break
                        else:
                            e = expd.get(k, ABSENT)
                            a[i] &= (1 << e)
                            if a[i] == 0:
                                bad = True
                                break
                if bad:
                    break
        if bad:
            break
        A.append(a)
        C.append(c)

    if bad:
        return {"order": None}

    if n == 0:
        return {"order": []} if init_state == final_state else {"order": None}

    full = (1 << n) - 1

    # ---- precedence ---------------------------------------------------
    pred = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and txs[i]["end"] <= txs[j]["start"]:
                pred[j] |= (1 << i)
    # transitive closure (must_before)
    must_before = pred[:]
    for _ in range(n):
        changed = False
        for j in range(n):
            nb = must_before[j]
            x = nb
            while x:
                b = x & -x
                u = b.bit_length() - 1
                x ^= b
                nb |= must_before[u]
            if nb != must_before[j]:
                must_before[j] = nb
                changed = True
        if not changed:
            break

    # ---- packed per-transaction data ---------------------------------
    keep_mask = [0] * n
    const_bits = [0] * n
    checks = [None] * n
    for t in range(n):
        km = 0
        cb = 0
        ck = []
        for i in range(m):
            sh = 5 * i
            if C[t][i] >= 0:
                cb |= C[t][i] << sh
            else:
                km |= 31 << sh
            if A[t][i] != FULL:
                ck.append((sh, A[t][i]))
        keep_mask[t] = km
        const_bits[t] = cb
        checks[t] = ck

    # ---- pruning tables ----------------------------------------------
    writers_mask = [0] * m          # t writes key i
    final_writers_mask = [0] * m    # t writes key i with final value
    for i in range(m):
        fv = (final_state >> (5 * i)) & 31
        wm = 0
        fm = 0
        for t in range(n):
            if C[t][i] >= 0:
                wm |= (1 << t)
                if C[t][i] == fv:
                    fm |= (1 << t)
        writers_mask[i] = wm
        final_writers_mask[i] = fm

    # allow[k][e] = bitmask over t of (e in A[t][k])
    allow_flat = [[0] * 20 for _ in range(m)]
    for i in range(m):
        row = allow_flat[i]
        for t in range(n):
            am = A[t][i]
            if am == FULL:
                for e in range(20):
                    row[e] |= (1 << t)
            else:
                x = am
                while x:
                    b = x & -x
                    e = b.bit_length() - 1
                    x ^= b
                    row[e] |= (1 << t)

    # helper[t][i] = bitmask over w != t that can set key i to a value allowed by t
    help = [[0] * m for _ in range(n)]
    can_precede = [0] * n
    for t in range(n):
        cp = 0
        for w in range(n):
            # w may execute before t unless t is forced to execute before w
            if w != t and not (must_before[w] >> t) & 1:
                cp |= (1 << w)
        can_precede[t] = cp
        for i in range(m):
            am = A[t][i]
            h = 0
            for w in range(n):
                if w != t and C[w][i] >= 0 and ((am >> C[w][i]) & 1):
                    h |= (1 << w)
            help[t][i] = h

    full_keep = 0
    for i in range(m):
        full_keep |= 31 << (5 * i)

    # ---- canonicalisation cache (per mask) ---------------------------
    canon_cache = {}
    allow_row = allow_flat  # local
    fstate = final_state
    fbit = 1 << n

    def get_canon(mask):
        cm = canon_cache.get(mask)
        if cm is not None:
            return cm
        R = full ^ mask
        cm = []
        for i in range(m):
            groups = {}
            row = allow_row[i]
            fv = (fstate >> (5 * i)) & 31
            for e in range(20):
                sig = (fbit if e == fv else 0) | (row[e] & R)
                g = groups.get(sig)
                if g is None:
                    groups[sig] = [e]
                else:
                    g.append(e)
            rep = [0] * 20
            for vals in groups.values():
                r = min(vals)
                for e in vals:
                    rep[e] = r
            cm.append(tuple(rep))
        canon_cache[mask] = cm
        return cm

    # ---- DFS ----------------------------------------------------------
    failed = set()
    shifts = [5 * i for i in range(m)]
    all_checks = checks
    keep = keep_mask
    cbits = const_bits
    fvals = [(fstate >> (5 * i)) & 31 for i in range(m)]
    wm = writers_mask
    fwm = final_writers_mask
    hlp = help
    cpre = can_precede

    sys.setrecursionlimit(10000)

    def dfs(mask, state):
        # canonicalise
        cm = get_canon(mask)
        cs = 0
        for i in range(m):
            cs |= cm[i][(state >> shifts[i]) & 31] << shifts[i]
        state = cs
        key = (mask << 30) | state
        if key in failed:
            return None
        if mask == full:
            for i in range(m):
                if ((state >> shifts[i]) & 31) != fvals[i]:
                    failed.add(key)
                    return None
            return []
        remaining = full ^ mask

        # prune A: final value still reachable for every key
        for i in range(m):
            if (wm[i] & remaining) == 0:
                if ((state >> shifts[i]) & 31) != fvals[i]:
                    failed.add(key)
                    return None
            elif (fwm[i] & remaining) == 0:
                failed.add(key)
                return None

        # prune B: every remaining transaction must stay satisfiable
        x = remaining
        while x:
            b = x & -x
            t = b.bit_length() - 1
            x ^= b
            for (sh, am) in all_checks[t]:
                e = (state >> sh) & 31
                if (am >> e) & 1:
                    continue
                if (hlp[t][sh // 5] & remaining & ~b & cpre[t]) == 0:
                    failed.add(key)
                    return None

        # candidates
        cands = []
        x = remaining
        while x:
            b = x & -x
            t = b.bit_length() - 1
            x ^= b
            if pred[t] & remaining:
                continue
            ok = True
            for (sh, am) in all_checks[t]:
                if not ((am >> ((state >> sh) & 31)) & 1):
                    ok = False
                    break
            if not ok:
                continue
            if keep[t] == full_keep:
                # read-only transaction, valid right now: safe to run it first
                res = dfs(mask | b, state)
                if res is not None:
                    res.insert(0, t)
                    return res
                failed.add(key)
                return None
            # score: how many mismatching keys does it fix
            ns = (state & keep[t]) | cbits[t]
            sc = 0
            for i in range(m):
                if ((state >> shifts[i]) & 31) != fvals[i] and ((ns >> shifts[i]) & 31) == fvals[i]:
                    sc += 1
            cands.append((sc, t, ns))
        cands.sort(key=lambda z: (-z[0], z[1]))

        for _sc, t, ns in cands:
            res = dfs(mask | (1 << t), ns)
            if res is not None:
                res.insert(0, t)
                return res

        failed.add(key)
        return None

    res = dfs(0, init_state)
    if res is None:
        return {"order": None}
    return {"order": [txs[t]["id"] for t in res]}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        try:
            ans = solve(req)
        except Exception as e:  # pragma: no cover
            print("error: %r" % (e,), file=sys.stderr)
            ans = {"order": None}
        out.write(json.dumps(ans))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
