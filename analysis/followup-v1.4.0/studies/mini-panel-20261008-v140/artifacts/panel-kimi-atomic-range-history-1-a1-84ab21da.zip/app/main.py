"""Linearizability witness checker for atomic range transactions.

Given a completed concurrent history (transactions with real-time intervals
and fully observed operations), find a serial execution order witnessing all
observations and the required final map, or prove that none exists.

Algorithm: depth-first search over topological orders of the real-time
precedence DAG (A.end <= B.start forces A before B), with
  * immediate simulation of each candidate transaction (observation pruning),
  * memoization of failed (executed-set, state) search nodes,
  * a forward necessary-condition check against the required final map.

Bounds are tiny (<= 10 transactions, <= 5 ops each, <= 6 keys), so this is
easily fast enough while remaining exact.
"""

import json
import sys


def _simulate(d, ops):
    """Apply a transaction's ops to map d (mutated).

    Returns d on success, or None as soon as any observed return value
    mismatches.  Mirrors the reference semantics exactly.
    """
    for op in ops:
        kind = op[0]
        if kind == 'get':
            if d.get(op[1]) != op[2]:
                return None
        elif kind == 'put':
            d[op[1]] = op[2]
        elif kind == 'del':
            d.pop(op[1], None)
        elif kind == 'cas':
            ok = d.get(op[1]) == op[2]
            if ok is not op[4]:
                return None
            if ok:
                if op[3] is None:
                    d.pop(op[1], None)
                else:
                    d[op[1]] = op[3]
        else:  # scan
            low = op[1]
            high = op[2]
            pairs = sorted([[k, v] for k, v in d.items() if low <= k < high])
            if pairs != op[3]:
                return None
    return d


def solve(request):
    txs = request.get('transactions') or []
    initial = request.get('initial') or {}
    final = request.get('final') or {}
    n = len(txs)

    if n == 0:
        return {'order': [] if initial == final else None}

    full = (1 << n) - 1
    ids = [t['id'] for t in txs]
    t_ops = [t.get('ops') or [] for t in txs]
    starts = [t['start'] for t in txs]
    ends = [t['end'] for t in txs]

    # Real-time precedence: A.end <= B.start  =>  A strictly before B.
    # (start < end per transaction makes this relation acyclic.)
    pred = [0] * n
    for i in range(n):
        ei = ends[i]
        for j in range(n):
            if i != j and ei <= starts[j]:
                pred[j] |= 1 << i

    # can_produce[i][k]: superset of the values transaction i may leave stored
    # at key k if it executes (None represents absence).  Only used to build a
    # sound *necessary* condition for reaching the final map.
    can_produce = []
    for ops in t_ops:
        cp = {}
        for op in ops:
            kind = op[0]
            if kind == 'put':
                cp.setdefault(op[1], set()).add(op[2])
            elif kind == 'del':
                cp.setdefault(op[1], set()).add(None)
            elif kind == 'cas':
                cp.setdefault(op[1], set()).add(op[3])
        can_produce.append(cp)

    def feasible(d, mask):
        # For every key whose current value differs from the required final
        # value, some remaining transaction must be able to produce the final
        # value for that key (the last remaining writer of a key fixes its
        # final value).  Sound over-approximation: prunes only dead ends.
        rem = full & ~mask
        keys = set(d)
        keys.update(final)
        for k in keys:
            if d.get(k) == final.get(k):
                continue
            want = final.get(k)
            m = rem
            while m:
                b = m & -m
                i = b.bit_length() - 1
                s = can_produce[i].get(k)
                if s is not None and want in s:
                    break
                m ^= b
            else:
                return False
        return True

    # Static candidate preference: earliest deadline first (deterministic).
    pref = sorted(range(n), key=lambda i: (ends[i], starts[i], i))

    failed = set()
    order = []

    def dfs(mask, d):
        key = (mask, tuple(sorted(d.items())))
        if key in failed:
            return False
        if not feasible(d, mask):
            failed.add(key)
            return False
        for i in pref:
            bi = 1 << i
            if mask & bi or pred[i] & ~mask:
                continue
            nd = _simulate(dict(d), t_ops[i])
            if nd is None:
                continue
            order.append(i)
            if mask | bi == full:
                if nd == final:
                    return True
            elif dfs(mask | bi, nd):
                return True
            order.pop()
        failed.add(key)
        return False

    if dfs(0, dict(initial)):
        return {'order': [ids[i] for i in order]}
    return {'order': None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            result = solve(json.loads(line))
        except Exception:  # keep the protocol intact; report on stderr
            import traceback
            traceback.print_exc(file=sys.stderr)
            result = {'order': None}
        out.write(json.dumps(result))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
