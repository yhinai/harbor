import sys
import json
from bisect import bisect_left

STATS = {}


def solve(req):
    initial = req.get('initial') or {}
    final = req.get('final') or {}
    txs = req.get('transactions') or []
    n = len(txs)

    # Universe of keys that can ever be present in a state.
    keys = set(initial) | set(final)
    for t in txs:
        for op in t['ops']:
            if op[0] == 'scan':
                for p in op[3]:
                    keys.add(p[0])
            else:
                keys.add(op[1])
    keys = sorted(keys)
    kidx = {k: i for i, k in enumerate(keys)}
    K = len(keys)
    SH = [5 * i for i in range(K)]
    CLR = [~(31 << (5 * i)) for i in range(K)]
    OTHER = 20          # canonical "irrelevant" code (real codes are 0..19)

    def vc(v):
        # absent -> 0, integer value v -> v+10 (1..19)
        return 0 if v is None else v + 10

    # Normalize operations.  op codes:
    #   0 get(key_index, code)
    #   1 put(key_index, code)
    #   2 del(key_index)
    #   3 cas(key_index, old_code, new_code, want_success)
    #   4 scan(lo_index, hi_index, expected_tuple)
    txops = []
    wmask = []
    final_codes0 = [vc(final[k]) if k in final else 0 for k in keys]
    final_wmask = []
    tx_write_codes = []
    tx_req_eq = []
    tx_req_ne = []
    written = [set() for _ in range(K)]
    uncond = [False] * K
    obs_masks = []
    for t in txs:
        ops = []
        wm = 0
        fwm = 0
        wcodes = [0] * K
        req_eq = []
        req_ne = []
        obs = [0] * K
        for op in t['ops']:
            nm = op[0]
            if nm == 'get':
                i = kidx[op[1]]
                c = vc(op[2])
                obs[i] |= 1 << c
                req_eq.append((i, c))
                ops.append((0, i, c))
            elif nm == 'put':
                i = kidx[op[1]]
                c = vc(op[2])
                wm |= 1 << i
                written[i].add(c)
                uncond[i] = True
                if c == final_codes0[i]:
                    fwm |= 1 << i
                wcodes[i] |= 1 << c
                ops.append((1, i, c))
            elif nm == 'del':
                i = kidx[op[1]]
                wm |= 1 << i
                written[i].add(0)
                uncond[i] = True
                if final_codes0[i] == 0:
                    fwm |= 1 << i
                wcodes[i] |= 1
                ops.append((2, i))
            elif nm == 'cas':
                i = kidx[op[1]]
                old = vc(op[2])
                new = vc(op[3])
                wm |= 1 << i
                written[i].add(new)
                if new == final_codes0[i]:
                    fwm |= 1 << i
                wcodes[i] |= 1 << new
                if op[4]:
                    req_eq.append((i, old))
                else:
                    req_ne.append((i, old))
                obs[i] |= 1 << old
                ops.append((3, i, old, new, bool(op[4])))
            else:  # scan
                lo = bisect_left(keys, op[1])
                hi = bisect_left(keys, op[2])
                exp = tuple(sorted((kidx[k], vc(v)) for k, v in op[3]))
                expd = {}
                for k, v in op[3]:
                    expd[kidx[k]] = vc(v)
                for i in range(lo, hi):
                    c0 = expd.get(i, 0)
                    obs[i] |= 1 << c0
                    req_eq.append((i, c0))
                ops.append((4, lo, hi, exp))
        txops.append(ops)
        wmask.append(wm)
        final_wmask.append(fwm)
        tx_write_codes.append(wcodes)
        tx_req_eq.append(tuple(req_eq))
        tx_req_ne.append(tuple(req_ne))
        obs_masks.append(obs)

    init_state = 0
    for k, v in initial.items():
        init_state |= vc(v) << SH[kidx[k]]
    final_state = 0
    for k, v in final.items():
        final_state |= vc(v) << SH[kidx[k]]

    full = (1 << n) - 1

    # Cheap global filter: the value a key ends with must be writable
    # (or the initial value if every writer is conditional).
    for i in range(K):
        fc = (final_state >> SH[i]) & 31
        ic = (init_state >> SH[i]) & 31
        if uncond[i]:
            if fc not in written[i]:
                return {"order": None}
        else:
            if fc != ic and fc not in written[i]:
                return {"order": None}

    if n == 0:
        return {"order": [] if init_state == final_state else None}

    # Real-time predecessor masks.
    pred = [0] * n
    for i in range(n):
        si = txs[i]['start']
        p = 0
        for j in range(n):
            if i != j and txs[j]['end'] <= si:
                p |= 1 << j
        pred[i] = p

    # Successor heuristic: try the most observation-heavy transactions first.
    obs_count = []
    for t in txs:
        c = 0
        for op in t['ops']:
            if op[0] in ('get', 'cas', 'scan'):
                c += 1
        obs_count.append(c)
    hint = sorted(range(n), key=lambda i: (-obs_count[i], -len(txops[i]), i))

    # Keys writable by each set of transactions.
    writable = [0] * (1 << n)
    can_final = [0] * (1 << n)
    for mask in range(1, 1 << n):
        lb = mask & -mask
        j = lb.bit_length() - 1
        writable[mask] = writable[mask ^ lb] | wmask[j]
        can_final[mask] = can_final[mask ^ lb] | final_wmask[j]

    shift = 5 * K

    final_bits = tuple(1 << ((final_state >> SH[i]) & 31) for i in range(K))
    D_cache = {}
    cmap_cache = {}
    ready_cache = {}
    wcodes_cache = {}
    rem_cache = {}

    def get_D(mask):
        # codes observable by the transactions still to run, plus final code
        d = D_cache.get(mask)
        if d is None:
            cur = list(final_bits)
            r = full ^ mask
            while r:
                lb = r & -r
                r ^= lb
                om = obs_masks[lb.bit_length() - 1]
                for i in range(K):
                    cur[i] |= om[i]
            d = tuple(cur)
            D_cache[mask] = d
        return d

    def get_cmap(mask):
        cm = cmap_cache.get(mask)
        if cm is None:
            d = get_D(mask)
            cm = tuple(
                tuple(c if (d[i] >> c) & 1 else OTHER for c in range(20))
                for i in range(K)
            )
            cmap_cache[mask] = cm
        return cm

    def get_wcodes(mask):
        wc = wcodes_cache.get(mask)
        if wc is None:
            cur = [0] * K
            r = full ^ mask
            while r:
                lb = r & -r
                r ^= lb
                tw = tx_write_codes[lb.bit_length() - 1]
                for i in range(K):
                    cur[i] |= tw[i]
            wc = tuple(cur)
            wcodes_cache[mask] = wc
        return wc

    def get_rem(mask):
        rl = rem_cache.get(mask)
        if rl is None:
            rl = []
            r = full ^ mask
            while r:
                lb = r & -r
                r ^= lb
                rl.append(lb.bit_length() - 1)
            rl = tuple(rl)
            rem_cache[mask] = rl
        return rl

    def get_ready(mask):
        r = ready_cache.get(mask)
        if r is None:
            free = full ^ mask
            r = tuple(i for i in hint if (free >> i) & 1 and (pred[i] & free) == 0)
            ready_cache[mask] = r
        return r

    def apply_ops(ops, s):
        for op in ops:
            c = op[0]
            if c == 1:                      # put
                i = op[1]
                s = (s & CLR[i]) | (op[2] << SH[i])
            elif c == 0:                    # get
                if ((s >> SH[op[1]]) & 31) != op[2]:
                    return -1
            elif c == 2:                    # del
                s &= CLR[op[1]]
            elif c == 3:                    # cas
                i = op[1]
                if ((s >> SH[i]) & 31) == op[2]:
                    if not op[4]:
                        return -1
                    s = (s & CLR[i]) | (op[3] << SH[i])
                elif op[4]:
                    return -1
            else:                           # scan
                lo = op[1]
                hi = op[2]
                found = []
                ap = found.append
                for i in range(lo, hi):
                    cv = (s >> SH[i]) & 31
                    if cv:
                        ap((i, cv))
                if tuple(found) != op[3]:
                    return -1
        return s

    memo = set()
    order = []
    nodes = [0]

    def dfs(mask, s):
        nodes[0] += 1
        # Canonicalize: codes that no remaining transaction can distinguish
        # (and that are not the required final code) collapse to OTHER.
        cm = get_cmap(mask)
        cs = 0
        for i in range(K):
            c = (s >> SH[i]) & 31
            if c > 19:
                c = OTHER
            else:
                c = cm[i][c]
            cs |= c << SH[i]
        s = cs
        if mask == full:
            return s == final_state
        mk = (mask << shift) | s
        if mk in memo:
            return False
        rem = full ^ mask
        ss = s ^ final_state
        if ss:
            cf = can_final[rem]
            for i in range(K):
                if ((ss >> SH[i]) & 31) and not ((cf >> i) & 1):
                    memo.add(mk)
                    return False
        # necessary-condition pruning for still-pending transactions
        rem_list = get_rem(mask)
        wc = None
        wr = None
        for t in rem_list:
            rq = tx_req_eq[t]
            if rq:
                if wc is None:
                    wc = get_wcodes(mask)
                for i, c in rq:
                    if ((s >> SH[i]) & 31) != c and not ((wc[i] >> c) & 1):
                        memo.add(mk)
                        return False
            rn = tx_req_ne[t]
            if rn:
                if wr is None:
                    wr = writable[rem]
                for i, c in rn:
                    if ((s >> SH[i]) & 31) == c and not ((wr >> i) & 1):
                        memo.add(mk)
                        return False
        for t in get_ready(mask):
            s2 = apply_ops(txops[t], s)
            if s2 >= 0:
                order.append(t)
                if dfs(mask | (1 << t), s2):
                    return True
                order.pop()
        memo.add(mk)
        return False

    ok = dfs(0, init_state)
    STATS['nodes'] = nodes[0]
    STATS['memo'] = len(memo)
    if ok:
        return {"order": [txs[t]['id'] for t in order]}
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin.buffer:
        if not line.strip():
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req)))
        out.write('\n')
        out.flush()


if __name__ == '__main__':
    main()
