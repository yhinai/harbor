"""Exhaustive terminal-outcome enumerator for a mixed-width buffered (TSO-like) machine.

Model summary (all transitions atomic):
  * store: append (addr,width,value) to the issuing thread's FIFO buffer; no memory change.
  * load:  per byte, youngest same-thread buffered store covering that byte wins,
           else shared memory; little-endian assembly; never blocked by a nonempty buffer.
  * fence: enabled only when the thread's buffer is empty.
  * xchg:  enabled only when the thread's buffer is empty; atomically reads shared
           memory (observed), then writes the supplied value.
  * drain: move the oldest buffered store of any thread into shared memory
           (all of its bytes at once), even after the thread finished.
Terminal: every thread finished AND every buffer empty.

Key facts used for memoization:
  * A thread's buffer contents are fully determined by (pc, drained_count):
    stores are appended in program order and drained oldest-first.
  * Past observations never influence future transitions, so the set of
    (future observations, final memory) reachable from a state depends only on
    (memory, program counters, drain counts).
"""

import json
import sys


def solve(request):
    mem0 = tuple(request["memory"])
    threads = request["threads"]
    n = len(threads)

    progs = []         # per thread: tuple of parsed instructions
    store_seq = []     # per thread: tuple of (addr, (byte0, byte1, ...)) for stores, program order
    stores_before = []  # per thread: stores_before[pc] = # store instructions in prog[:pc]
    for prog_in in threads:
        prog = []
        seq = []
        for ins in prog_in:
            op = ins[0]
            if op == "store":
                _, addr, width, value = ins
                seq.append((addr, tuple((value >> (8 * i)) & 0xFF for i in range(width))))
                prog.append(("store",))
            elif op == "load":
                prog.append(("load", ins[1], ins[2]))
            elif op == "fence":
                prog.append(("fence",))
            elif op == "xchg":
                prog.append(("xchg", ins[1], ins[2], ins[3]))
            else:
                raise ValueError("unknown instruction: %r" % (ins,))
        prog = tuple(prog)
        progs.append(prog)
        store_seq.append(tuple(seq))
        sb = [0]
        for ins in prog:
            sb.append(sb[-1] + (1 if ins[0] == "store" else 0))
        stores_before.append(tuple(sb))

    def load_value(mem, buf, addr, width):
        v = 0
        for i in range(width):
            a = addr + i
            b = None
            # youngest buffered store covering byte a wins
            for saddr, sbytes in reversed(buf):
                if saddr <= a < saddr + len(sbytes):
                    b = sbytes[a - saddr]
                    break
            if b is None:
                b = mem[a]
            v |= b << (8 * i)
        return v

    memo = {}

    def rec(mem, pcs, drained):
        """Return the set of (future_reads, final_mem) terminal outcomes reachable
        from this core state. future_reads is a tuple of n tuples of observed values."""
        key = (mem, pcs, drained)
        got = memo.get(key)
        if got is not None:
            return got
        results = set()
        live = False  # at least one enabled transition
        for t in range(n):
            prog = progs[t]
            pc = pcs[t]
            sb = stores_before[t][pc]
            d = drained[t]
            if pc < len(prog):
                live = True
                ins = prog[pc]
                op = ins[0]
                npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                if op == "store":
                    # append to buffer: implicitly stores_before[t][pc+1] == sb+1
                    for reads, m in rec(mem, npcs, drained):
                        results.add((reads, m))
                elif op == "load":
                    buf = store_seq[t][d:sb]
                    val = load_value(mem, buf, ins[1], ins[2])
                    for reads, m in rec(mem, npcs, drained):
                        results.add((reads[:t] + ((val,) + reads[t],) + reads[t + 1:], m))
                elif op == "fence":
                    if d == sb:  # buffer empty
                        for reads, m in rec(mem, npcs, drained):
                            results.add((reads, m))
                else:  # xchg, buffer must be empty
                    if d == sb:
                        addr, width, value = ins[1], ins[2], ins[3]
                        val = 0
                        for i in range(width):
                            val |= mem[addr + i] << (8 * i)
                        ml = list(mem)
                        for i in range(width):
                            ml[addr + i] = (value >> (8 * i)) & 0xFF
                        for reads, m in rec(tuple(ml), npcs, drained):
                            results.add((reads[:t] + ((val,) + reads[t],) + reads[t + 1:], m))
            if d < sb:
                # drain oldest buffered store of thread t to shared memory
                live = True
                saddr, sbytes = store_seq[t][d]
                ml = list(mem)
                ml[saddr:saddr + len(sbytes)] = sbytes
                nd = drained[:t] + (d + 1,) + drained[t + 1:]
                for reads, m in rec(tuple(ml), pcs, nd):
                    results.add((reads, m))
        if not live:
            # terminal: all threads finished and all buffers empty
            results.add((((),) * n, mem))
        memo[key] = results
        return results

    final = rec(mem0, (0,) * n, (0,) * n)
    outcomes = [
        {"reads": [list(r) for r in reads], "memory": list(m)}
        for reads, m in final
    ]
    return {"outcomes": outcomes}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
