"""Linearizability checker for histories of atomic range transactions.

Each input request describes an initial map, a final map and a set of
transactions (each transaction is one atomic operation with observed return
values).  A witness is a total order of the transactions that respects the
real-time partial order (A.end <= B.start  =>  A before B), makes every
observed return value match, and ends in the requested final map.  If no such
order exists the answer is ``{"order": null}``.

The search is a DFS over linear extensions of the real-time order with
memoisation of failed (remaining-set, state) pairs plus two necessary-condition
prunes that are recomputed at every node:

* per key, while writers remain, one of them must still be able to be the last
  writer (it has to write the final value and have no remaining writer of that
  key ordered after it), and
* when a key has exactly one possible last writer, every other remaining writer
  of that key must precede it.  Those derived precedences are folded into the
  reachability closure and can expose cycles immediately.
"""

import sys
import json
import heapq


def normalize_transaction(ops, kidx, keys, FULL, vbit, vidx):
    """Compress one transaction into (possible, reqs, effs).

    ``reqs`` constrains the state at the moment the transaction starts (only
    for keys that are read before any definite write in the transaction).
    ``effs`` gives the keys the transaction definitely writes together with the
    values written; every other key keeps its value.  If ``possible`` is False
    the transaction can never validate against any start state.
    """
    cur = {}
    sd = {}
    effect = {}
    possible = True
    for op in ops:
        kind = op[0]
        if kind == "get":
            j = kidx[op[1]]
            v = op[2]
            dm = cur.get(j, FULL) & vbit(v)
            cur[j] = dm
            if j not in effect:
                sd[j] = sd.get(j, FULL) & vbit(v)
            if not dm or (j in sd and not sd[j]):
                possible = False
        elif kind == "put":
            j = kidx[op[1]]
            v = op[2]
            cur[j] = vbit(v)
            effect[j] = v
        elif kind == "del":
            j = kidx[op[1]]
            cur[j] = vbit(None)
            effect[j] = None
        elif kind == "cas":
            j = kidx[op[1]]
            old = op[2]
            new = op[3]
            want = op[4]
            if want:
                dm = cur.get(j, FULL) & vbit(old)
                if j not in effect:
                    sd[j] = sd.get(j, FULL) & vbit(old)
                if not dm or (j in sd and not sd[j]):
                    possible = False
                cur[j] = vbit(new)
                effect[j] = new
            else:
                dm = cur.get(j, FULL) & ~vbit(old)
                cur[j] = dm
                if j not in effect:
                    sd[j] = sd.get(j, FULL) & ~vbit(old)
                if not dm or (j in sd and not sd[j]):
                    possible = False
        elif kind == "scan":
            low = op[1]
            high = op[2]
            pairs = op[3]
            exp = {}
            for p in pairs:
                exp[kidx[p[0]]] = p[1]
            for j, k in enumerate(keys):
                if low <= k < high:
                    want = vbit(exp[j]) if j in exp else vbit(None)
                    dm = cur.get(j, FULL) & want
                    cur[j] = dm
                    if j not in effect:
                        sd[j] = sd.get(j, FULL) & want
                    if not dm or (j in sd and not sd[j]):
                        possible = False
        else:
            possible = False
    reqs = tuple((j, dm) for j, dm in sd.items() if dm != FULL)
    effs = tuple((j, vidx(v)) for j, v in effect.items())
    return possible, reqs, effs


def writeonly_solve(state, R, K, writers, wval, fin, before, n):
    """Exact completion search when every remaining transaction is write-only.

    For each key the last remaining writer has to write the final value, and all
    other remaining writers of the key have to precede it.  Choices are made per
    key with backtracking; if an acyclic combination exists a topological order
    is returned, otherwise None.
    """
    Ws = [0] * K
    keys_with = []
    for j in range(K):
        W = writers[j] & R
        Ws[j] = W
        if not W:
            if state[j] != fin[j]:
                return None
        else:
            keys_with.append(j)
    cands = {}
    for j in keys_with:
        W = Ws[j]
        c = 0
        wv = wval[j]
        while W:
            b = W & -W
            i = b.bit_length() - 1
            W ^= b
            if wv[i] == fin[j]:
                c |= b
        if not c:
            return None
        cands[j] = c
    keys_with.sort(key=lambda j: cands[j].bit_count())
    base = [before[i] & R for i in range(n)]
    chosen = {}

    def rec(idx, edges):
        if idx == len(keys_with):
            return True
        j = keys_with[idx]
        W = Ws[j]
        cand = cands[j]
        while cand:
            b = cand & -cand
            t = b.bit_length() - 1
            cand ^= b
            ne = edges[:]
            o = W & ~b
            ok = True
            while o:
                bb = o & -o
                w = bb.bit_length() - 1
                o ^= bb
                if (ne[w] >> t) & 1:
                    continue
                if (ne[t] >> w) & 1:
                    ok = False
                    break
                add = b | ne[t]
                for p in range(n):
                    if p == w or ((ne[p] >> w) & 1):
                        ne[p] |= add
            if not ok:
                continue
            chosen[j] = t
            if rec(idx + 1, ne):
                return True
            del chosen[j]
        return False

    if not rec(0, base):
        return None

    edges = base
    for j in keys_with:
        t = chosen[j]
        o = Ws[j] & ~(1 << t)
        while o:
            b = o & -o
            w = b.bit_length() - 1
            o ^= b
            if (edges[w] >> t) & 1:
                continue
            add = (1 << t) | edges[t]
            for p in range(n):
                if p == w or ((edges[p] >> w) & 1):
                    edges[p] |= add
    indeg = [0] * n
    for p in range(n):
        if (R >> p) & 1:
            succ = edges[p] & R
            while succ:
                b = succ & -succ
                q = b.bit_length() - 1
                succ ^= b
                indeg[q] += 1
    avail = [i for i in range(n) if (R >> i) & 1 and indeg[i] == 0]
    heapq.heapify(avail)
    out = []
    while avail:
        i = heapq.heappop(avail)
        out.append(i)
        succ = edges[i] & R
        while succ:
            b = succ & -succ
            q = b.bit_length() - 1
            succ ^= b
            indeg[q] -= 1
            if indeg[q] == 0:
                heapq.heappush(avail, q)
    if len(out) != R.bit_count():
        return None
    return out


def solve(req):
    txs = req.get("transactions", []) or []
    initial = req.get("initial", {}) or {}
    final = req.get("final", {}) or {}
    n = len(txs)

    # ---- key universe: every string that can influence the state ----
    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind in ("get", "put", "del", "cas"):
                keys.add(op[1])
            elif kind == "scan":
                keys.add(op[1])
                keys.add(op[2])
                for p in op[3]:
                    keys.add(p[0])
    keys = sorted(keys)
    K = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    FULL = (1 << 20) - 1

    def vbit(v):
        return 1 if v is None else (1 << (v + 10))

    def vidx(v):
        return 0 if v is None else v + 10

    init = tuple(vidx(initial.get(k)) for k in keys)
    fin = tuple(vidx(final.get(k)) for k in keys)

    if n == 0:
        return {"order": [] if init == fin else None}

    # ---- normalise transactions ----
    reqs = []
    effs = []
    ids = []
    sigs = []
    for t in txs:
        ids.append(t["id"])
        possible, rq, ef = normalize_transaction(
            t["ops"], kidx, keys, FULL, vbit, vidx)
        if not possible:
            return {"order": None}
        reqs.append(rq)
        effs.append(ef)
        sigs.append((t["start"], t["end"], rq, ef))

    # ---- real-time partial order, transitively closed ----
    before = [0] * n
    for i in range(n):
        ei = txs[i]["end"]
        for j in range(n):
            if i != j and ei <= txs[j]["start"]:
                before[i] |= 1 << j
    for k in range(n):
        bk = before[k]
        if bk:
            for i in range(n):
                if (before[i] >> k) & 1:
                    before[i] |= bk
    preds = [0] * n
    for i in range(n):
        m = before[i]
        while m:
            b = m & -m
            j = b.bit_length() - 1
            m ^= b
            preds[j] |= 1 << i

    # ---- writers per key ----
    writers = [0] * K
    wval = [[-1] * n for _ in range(K)]
    for i in range(n):
        for j, v in effs[i]:
            writers[j] |= 1 << i
            wval[j][i] = v

    full = (1 << n) - 1
    POW = [20 ** j for j in range(K)]
    STATE_SPACE = 20 ** K
    CSP_MIN = 5
    no_dpre = [0] * n
    read_mask = 0
    for i in range(n):
        if reqs[i]:
            read_mask |= 1 << i
    csp_cache = {}
    dead = set()
    path = []

    def analyze(mask, state):
        """Necessary-condition check.  Returns (ok, derived_predecessors)."""
        singleton = False
        for j in range(K):
            W = writers[j] & ~mask
            if not W:
                if state[j] != fin[j]:
                    return False, None
                continue
            cand = 0
            w = W
            wv = wval[j]
            while w:
                b = w & -w
                i = b.bit_length() - 1
                w ^= b
                if wv[i] == fin[j] and not (before[i] & W):
                    cand |= b
            if not cand:
                return False, None
            if cand & (cand - 1) == 0:
                singleton = True
        if not singleton:
            return True, None
        # There is at least one forced last writer: derive precedences to a
        # fixpoint and look for cycles.
        edges = before[:]
        while True:
            changed = False
            for j in range(K):
                W = writers[j] & ~mask
                if not W:
                    if state[j] != fin[j]:
                        return False, None
                    continue
                cand = 0
                w = W
                wv = wval[j]
                while w:
                    b = w & -w
                    i = b.bit_length() - 1
                    w ^= b
                    if wv[i] == fin[j] and not (edges[i] & W):
                        cand |= b
                if not cand:
                    return False, None
                if cand & (cand - 1) == 0:
                    t = cand.bit_length() - 1
                    o = W & ~cand
                    while o:
                        b = o & -o
                        i = b.bit_length() - 1
                        o ^= b
                        if not ((edges[i] >> t) & 1):
                            if (edges[t] >> i) & 1:
                                return False, None
                            add = cand | edges[t]
                            for p in range(n):
                                if p == i or ((edges[p] >> i) & 1):
                                    edges[p] |= add
                            changed = True
            if not changed:
                break
        dpre = [0] * n
        for i in range(n):
            m = 0
            for p in range(n):
                if (edges[p] >> i) & 1:
                    m |= 1 << p
            dpre[i] = m
        return True, dpre

    def dfs(mask, state, scode):
        if mask == full:
            return state == fin
        key = mask * STATE_SPACE + scode
        if key in dead:
            return False
        rem = full & ~mask
        if not (rem & read_mask) and rem.bit_count() >= CSP_MIN:
            # Only write-only transactions remain: solve exactly.
            ok_state = True
            for j in range(K):
                if not (writers[j] & rem) and state[j] != fin[j]:
                    ok_state = False
                    break
            if not ok_state:
                dead.add(key)
                return False
            if rem in csp_cache:
                order = csp_cache[rem]
            else:
                order = writeonly_solve(state, rem, K, writers, wval, fin,
                                        before, n)
                csp_cache[rem] = order
            if order is not None:
                path.extend(order)
                return True
            dead.add(key)
            return False
        ok, dpre = analyze(mask, state)
        if not ok:
            dead.add(key)
            return False
        if dpre is None:
            dpre = no_dpre
        avail = full & ~mask
        seen_sigs = set()
        w = avail
        while w:
            b = w & -w
            i = b.bit_length() - 1
            w ^= b
            if (preds[i] | dpre[i]) & ~mask:
                continue
            s = sigs[i]
            if s in seen_sigs:
                continue
            seen_sigs.add(s)
            good = True
            for j, dm in reqs[i]:
                if not ((dm >> state[j]) & 1):
                    good = False
                    break
            if not good:
                continue
            ns = list(state)
            nsc = scode
            for j, v in effs[i]:
                nsc += (v - state[j]) * POW[j]
                ns[j] = v
            path.append(i)
            if dfs(mask | b, tuple(ns), nsc):
                return True
            path.pop()
        dead.add(key)
        return False

    if dfs(0, init, sum(init[j] * POW[j] for j in range(K))):
        return {"order": [ids[i] for i in path]}
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            res = solve(req)
        except Exception as exc:  # pragma: no cover - defensive
            sys.stderr.write("error: %r\n" % (exc,))
            res = {"order": None}
        out.write(json.dumps(res))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
