#!/usr/bin/env python3
"""Exhaustive enumeration of terminal observable outcomes of the
mixed-width buffered (TSO-like) machine described in the task.

Requests are newline-delimited JSON objects on stdin; one JSON response
object per request line is written to stdout, in order.

Machine summary (every transition is atomic, including multi-byte ones):

  * state: per-thread program counter, per-thread FIFO store buffer,
    shared memory, per-thread list of observed load/xchg values.
  * execute (per thread, program order):
      store  -> append (addr,width,value) to own FIFO, pc+1 (memory untouched)
      load   -> byte-wise: youngest own buffered store covering the byte wins,
                otherwise shared memory; assembled little-endian into an
                unsigned value, appended to own observations, pc+1 (non blocking)
      fence  -> enabled only with an empty own buffer, pc+1
      xchg   -> enabled only with an empty own buffer; atomically read the
                shared-memory value, append it to own observations, write the
                supplied value to those bytes, pc+1
  * drain: the oldest store of any non-empty buffer becomes globally visible
    (all of its bytes at once) and is removed from the buffer.  Draining stays
    enabled after the issuing thread has finished.
  * terminal: all programs finished and all buffers empty.  No fairness
    assumption: the set of finite terminal executions is what is enumerated.
"""

import json
import sys

sys.setrecursionlimit(1000000)

STORE, LOAD, FENCE, XCHG = "store", "load", "fence", "xchg"


def solve(request):
    """Return {'outcomes': [{'reads': [[..], ..], 'memory': [..]}, ..]}."""

    mem0 = tuple(int(b) & 0xFF for b in request["memory"])
    progs = [[tuple(ins) for ins in thread] for thread in request["threads"]]
    n = len(progs)
    lens = tuple(len(p) for p in progs)
    start_pcs = tuple(0 for _ in range(n))
    start_bufs = tuple(() for _ in range(n))
    empty_reads = tuple(() for _ in range(n))

    # ---------------- helpers ----------------
    def load_value(buf, mem, addr, width):
        """Byte-wise load: youngest own buffered store covering the byte wins,
        otherwise shared memory; assembled little-endian."""
        val = 0
        for i in range(width):
            a = addr + i
            b = -1
            for j in range(len(buf) - 1, -1, -1):   # youngest first
                sa, sw, sv = buf[j]
                if sa <= a < sa + sw:
                    b = (sv >> (8 * (a - sa))) & 0xFF
                    break
            if b < 0:
                b = mem[a]
            val |= b << (8 * i)
        return val

    def read_mem(mem, addr, width):
        val = 0
        for i in range(width):
            val |= mem[addr + i] << (8 * i)
        return val

    def write_mem(mem, addr, width, value):
        if width == 1:
            v = value & 0xFF
            return mem if mem[addr] == v else mem[:addr] + (v,) + mem[addr + 1:]
        lst = list(mem)
        for i in range(width):
            lst[addr + i] = (value >> (8 * i)) & 0xFF
        return tuple(lst)

    # ---------------------------------------------------------------
    # f(core) -> set of (reads_suffix, final_memory) pairs, where core is
    # (pcs, bufs, mem).  The core determines every enabled transition and
    # therefore every continuation; observations accumulated so far are only
    # a prefix prepended to the continuation's own observations, so they are
    # kept out of the memoisation key.  Final memory is reported alongside the
    # reads because it can differ between continuations.
    # ---------------------------------------------------------------
    memo = {}

    def f(pcs, bufs, mem):
        key = (pcs, bufs, mem)
        cached = memo.get(key)
        if cached is not None:
            return cached

        results = set()
        terminal = True

        for t in range(n):
            pc = pcs[t]
            buf = bufs[t]

            # ---- transition 1: execute thread t's next instruction ----
            if pc < lens[t]:
                terminal = False
                ins = progs[t][pc]
                op = ins[0]
                npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]

                if op == STORE:
                    _, a, w, v = ins
                    nb = buf + ((a, w, int(v)),)
                    nbufs = bufs[:t] + (nb,) + bufs[t + 1:]
                    results.update(f(npcs, nbufs, mem))

                elif op == LOAD:
                    _, a, w = ins
                    val = load_value(buf, mem, a, w)
                    for reads, fmem in f(npcs, bufs, mem):
                        results.add(
                            (reads[:t] + ((val,) + reads[t],) + reads[t + 1:], fmem)
                        )

                elif op == FENCE:
                    if not buf:
                        results.update(f(npcs, bufs, mem))

                elif op == XCHG:
                    if not buf:
                        _, a, w, v = ins
                        old = read_mem(mem, a, w)
                        nmem = write_mem(mem, a, w, v)
                        for reads, fmem in f(npcs, bufs, nmem):
                            results.add(
                                (reads[:t] + ((old,) + reads[t],) + reads[t + 1:], fmem)
                            )
                else:
                    # Unknown opcode: tolerated as a no-op advance.
                    results.update(f(npcs, bufs, mem))

            # ---- transition 2: drain thread t's oldest store ----
            if buf:
                terminal = False
                a, w, v = buf[0]
                nbufs = bufs[:t] + (buf[1:],) + bufs[t + 1:]
                results.update(f(pcs, nbufs, write_mem(mem, a, w, v)))

        if terminal:
            results.add((empty_reads, mem))

        memo[key] = results
        return results

    pairs = f(start_pcs, start_bufs, mem0)

    return {
        "outcomes": [
            {"reads": [list(r) for r in reads], "memory": list(fmem)}
            for reads, fmem in pairs
        ]
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        response = solve(json.loads(line))
        out.write(json.dumps(response))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
