"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line to stdout.
"""

import json
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_SIZE = 13  # payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
CRC_SIZE = 4

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])

    num_pages = len(pages)
    page_len = len(pages[0])
    log_len = len(log)

    pos = 0          # start of the next record; also the valid prefix length
    last_seq = 0     # sequence of the last structurally valid record
    active = {}      # txid -> [patches list, patch count, payload crc]

    while True:
        remaining = log_len - pos
        if remaining < HEADER_SIZE:
            break  # incomplete header
        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")

        if payload_length > MAX_PAYLOAD:
            break
        total = HEADER_SIZE + payload_length + CRC_SIZE
        if remaining < total:
            break  # incomplete payload/crc (torn tail)

        payload = log[pos + HEADER_SIZE:pos + HEADER_SIZE + payload_length]
        crc_stored = int.from_bytes(
            log[pos + HEADER_SIZE + payload_length:pos + total], "little")
        if zlib.crc32(log[pos:pos + HEADER_SIZE + payload_length]) != crc_stored:
            break  # invalid CRC (zlib.crc32 is already unsigned in py3)
        if sequence == 0 or sequence <= last_seq:
            break  # invalid sequence
        if txid == 0:
            break  # invalid transaction id

        # Kind/payload-shape validation. These are structural checks: they
        # truncate the log even when the transaction is inactive.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            if page_index >= num_pages or byte_offset + byte_count > page_len:
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        else:
            break  # unknown kind

        # The record is structurally valid; apply its semantics.
        if kind == KIND_BEGIN:
            # Fresh incarnation; any unfinished one is discarded.
            active[txid] = [[], 0, 0]
        elif kind == KIND_PATCH:
            state = active.get(txid)
            if state is not None:
                state[0].append((page_index, byte_offset, bytes(payload[6:])))
                state[1] += 1
                state[2] = zlib.crc32(payload, state[2])
        elif kind == KIND_COMMIT:
            state = active.pop(txid, None)  # always closes the incarnation
            if state is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (patch_count == state[1] and digest == state[2]
                        and sequence > checkpoint):
                    for pi, off, data in state[0]:
                        pages[pi][off:off + len(data)] = data
        else:  # KIND_ABORT
            active.pop(txid, None)

        last_seq = sequence
        pos += total

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        response = solve(json.loads(line))
        write(json.dumps(response))
        write("\n")


if __name__ == "__main__":
    main()
