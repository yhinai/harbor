"""Checker for linearizability of atomic range transactions.

A whole transaction is one atomic operation, so a history is linearizable iff
there is a total order of the transactions that
  * respects the real-time constraints (A.end <= B.start  =>  A before B),
  * makes every observation (get / cas / scan) come true when replayed from
    ``initial``, and
  * leaves exactly the map ``final``.

The main solver searches the order backwards.  The state kept there is, for
every key, the exact *set* of values that the state may hold at the current
cut of the order.  Because every observation and every write of a transaction
constrains one key independently, that set is always a product of per-key
value sets, which keeps the search small and gives excellent pruning for
transactions without observations.

As a hard safety net a bounded meet-in-the-middle check is used whenever the
backward search grows too large: it splits the witness into an ideal prefix of
size n//2 and its complement, enumerating all reachable concrete prefix states
and all possible suffix pre-state products.
"""

import json
import sys


class _SearchLimit(Exception):
    pass


def _build(request):
    initial = request.get("initial") or {}
    final = request.get("final") or {}
    txs = request.get("transactions") or []
    n = len(txs)

    # ---- keys that can ever matter -------------------------------------
    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "scan":
                keys.add(op[1])
                keys.add(op[2])
                for pair in op[3]:
                    keys.add(pair[0])
            else:
                keys.add(op[1])
    keys = sorted(keys)
    kidx = {k: i for i, k in enumerate(keys)}
    K = len(keys)

    # ---- values that can ever appear (None = absent) -------------------
    vals = {None}
    vals.update(initial.values())
    vals.update(final.values())
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                vals.add(op[2])
            elif kind == "put":
                vals.add(op[2])
            elif kind == "cas":
                vals.add(op[2])
                vals.add(op[3])
            elif kind == "scan":
                for pair in op[3]:
                    vals.add(pair[1])
    ordered = [None] + sorted(v for v in vals if v is not None)
    vidx = {v: i for i, v in enumerate(ordered)}
    FULL = (1 << len(ordered)) - 1

    init_state = tuple(vidx[initial.get(k, None)] for k in keys)
    fin_masks = tuple(1 << vidx[final.get(k, None)] for k in keys)

    # ---- operations in a form cheap to replay / to invert --------------
    fops = []
    for t in txs:
        ops = []
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                ops.append((0, kidx[op[1]], vidx[op[2]]))
            elif kind == "put":
                ops.append((1, kidx[op[1]], vidx[op[2]]))
            elif kind == "del":
                ops.append((2, kidx[op[1]]))
            elif kind == "cas":
                ops.append((3, kidx[op[1]], vidx[op[2]], vidx[op[3]],
                            1 if op[4] else 0))
            else:  # scan
                lo, hi = op[1], op[2]
                pairs = {p[0]: p[1] for p in op[3]}
                idxs = tuple((kidx[k], vidx[pairs.get(k, None)])
                             for k in keys if lo <= k < hi)
                ops.append((4, idxs))
        fops.append(ops)

    # ---- real-time precedence ------------------------------------------
    starts = [t["start"] for t in txs]
    ends = [t["end"] for t in txs]
    after = [0] * n          # after[i]: transactions that must follow i
    pred = [0] * n           # pred[i]:  transactions that must precede i
    for i in range(n):
        for j in range(n):
            if i != j:
                if ends[i] <= starts[j]:
                    after[i] |= 1 << j
                if ends[j] <= starts[i]:
                    pred[i] |= 1 << j

    return {
        "n": n,
        "K": K,
        "FULL": FULL,
        "init_state": init_state,
        "fin_masks": fin_masks,
        "fops": fops,
        "after": after,
        "pred": pred,
        "ids": [t["id"] for t in txs],
    }


def _execute(state, ops):
    """Replay one transaction; return the resulting state or None."""
    s = list(state)
    for op in ops:
        kind = op[0]
        if kind == 0:                     # get
            if s[op[1]] != op[2]:
                return None
        elif kind == 1:                   # put
            s[op[1]] = op[2]
        elif kind == 2:                   # del
            s[op[1]] = 0                  # 0 is the bit index of None
        elif kind == 3:                   # cas
            _, ki, old, new, want = op
            ok = s[ki] == old
            if ok != want:
                return None
            if ok:
                s[ki] = new
        else:                             # scan
            for ki, val in op[1]:
                if s[ki] != val:
                    return None
    return tuple(s)


def _preimage(B, ops, FULL):
    """Exact set of states before ``ops`` that end up inside the product set B.

    The result is again a product set (tuple of bitmasks), or None if empty.
    """
    B = list(B)
    for op in reversed(ops):
        kind = op[0]
        if kind == 0:                     # get key == expected
            nb = B[op[1]] & (1 << op[2])
            if not nb:
                return None
            B[op[1]] = nb
        elif kind == 1:                   # put value
            if not (B[op[1]] & (1 << op[2])):
                return None
            B[op[1]] = FULL
        elif kind == 2:                   # del
            if not (B[op[1]] & 1):
                return None
            B[op[1]] = FULL
        elif kind == 3:                   # cas
            _, ki, old, new, want = op
            if want:
                if not (B[ki] & (1 << new)):
                    return None
                nb = 1 << old
            else:
                nb = B[ki] & ~(1 << old)
            if not nb:
                return None
            B[ki] = nb
        else:                             # scan
            for ki, val in op[1]:
                nb = B[ki] & (1 << val)
                if not nb:
                    return None
                B[ki] = nb
    return tuple(B)


def _search(prep, node_limit):
    """Backward search; raises _SearchLimit when it grows too large."""
    n = prep["n"]
    K = prep["K"]
    FULL = prep["FULL"]
    fops = prep["fops"]
    after = prep["after"]
    init_state = prep["init_state"]
    fin_masks = prep["fin_masks"]

    memo = set()
    order_rev = []
    nodes = 0

    def dfs(R, B):
        nonlocal nodes
        nodes += 1
        if nodes > node_limit:
            raise _SearchLimit()
        if R == 0:
            for ki in range(K):
                if not (B[ki] & (1 << init_state[ki])):
                    return False
            return True
        state = (R, B)
        if state in memo:
            return False
        cands = []
        for i in range(n):
            if (R >> i) & 1 and not (after[i] & R):
                B2 = _preimage(B, fops[i], FULL)
                if B2 is not None:
                    cands.append((i, B2))
        cands.sort(key=lambda ib: sum(x.bit_count() for x in ib[1]))
        for i, B2 in cands:
            order_rev.append(i)
            if dfs(R ^ (1 << i), B2):
                return True
            order_rev.pop()
        memo.add(state)
        return False

    if dfs((1 << n) - 1, fin_masks):
        return list(reversed(order_rev))
    return None


def _mitm(prep):
    """Bounded meet-in-the-middle decision + reconstruction."""
    n = prep["n"]
    K = prep["K"]
    FULL = prep["FULL"]
    fops = prep["fops"]
    after = prep["after"]
    pred = prep["pred"]
    init_state = prep["init_state"]
    fin_masks = prep["fin_masks"]
    full = (1 << n) - 1
    k = n // 2

    # ---- concrete states reachable by an ideal prefix of size <= k -----
    F = {0: {init_state}}
    Fpar = {}
    for S in range(1 << n):
        pc = S.bit_count()
        if pc == 0 or pc > k:
            continue
        st = set()
        for i in range(n):
            if not (S >> i) & 1:
                continue
            Si = S ^ (1 << i)
            if after[i] & Si:            # i cannot be last in S
                continue
            prev = F.get(Si)
            if not prev:
                continue
            for s in prev:
                s2 = _execute(s, fops[i])
                if s2 is not None and s2 not in st:
                    st.add(s2)
                    Fpar[(S, s2)] = (i, s)
        if st:
            F[S] = st

    # ---- pre-state products of an up-set suffix of size <= n-k ---------
    B = {0: {fin_masks}}
    Bpar = {}
    for T in range(1 << n):
        pc = T.bit_count()
        if pc == 0 or pc > n - k:
            continue
        prods = set()
        for i in range(n):
            if not (T >> i) & 1:
                continue
            Ti = T ^ (1 << i)
            if pred[i] & Ti:             # i cannot be first in T
                continue
            prev = B.get(Ti)
            if not prev:
                continue
            for P in prev:
                P2 = _preimage(P, fops[i], FULL)
                if P2 is not None and P2 not in prods:
                    prods.add(P2)
                    Bpar[(T, P2)] = (i, P)
        if prods:
            B[T] = prods

    # ---- join prefixes (ideals of size k) with suffixes ----------------
    for S in range(1 << n):
        if S.bit_count() != k:
            continue
        ok = True
        for i in range(n):
            if (S >> i) & 1 and (pred[i] & ~S):
                ok = False
                break
        if not ok:
            continue
        C = full ^ S
        fs = F.get(S)
        bs = B.get(C)
        if not fs or not bs:
            continue
        bs_list = list(bs)
        sb_list = [(s, tuple(1 << x for x in s)) for s in fs]
        if len(bs_list) >= 4 and len(sb_list) >= 4:
            # index the products by the most selective key
            best_key = min(range(K), key=lambda ki: sum(P[ki].bit_count()
                                                       for P in bs_list))
            groups = {}
            for idx, P in enumerate(bs_list):
                m = P[best_key]
                while m:
                    b = m & -m
                    groups.setdefault(b.bit_length() - 1, []).append(idx)
                    m ^= b
            for s, sb in sb_list:
                for idx in groups.get(s[best_key], ()):
                    P = bs_list[idx]
                    ok = True
                    for ki in range(K):
                        if ki != best_key and not (P[ki] & sb[ki]):
                            ok = False
                            break
                    if ok:
                        return _rebuild(Fpar, Bpar, S, s, C, P)
        else:
            for s, sb in sb_list:
                for P in bs_list:
                    if all(P[ki] & sb[ki] for ki in range(K)):
                        return _rebuild(Fpar, Bpar, S, s, C, P)
    return None


def _rebuild(Fpar, Bpar, S, s, C, P):
    fwd = []
    cs, cS = s, S
    while cS:
        i, ps = Fpar[(cS, cs)]
        fwd.append(i)
        cS ^= 1 << i
        cs = ps
    fwd.reverse()
    bwd = []
    cT, cP = C, P
    while cT:
        i, pP = Bpar[(cT, cP)]
        bwd.append(i)
        cT ^= 1 << i
        cP = pP
    return fwd + bwd


_NODE_LIMIT = 5000


def _replay_ok(prep, order):
    """Independent straight replay used as a final sanity check."""
    state = prep["init_state"]
    n = prep["n"]
    if len(order) != n or sorted(order) != list(range(n)):
        return False
    for i in order:
        state = _execute(state, prep["fops"][i])
        if state is None:
            return False
    for ki in range(prep["K"]):
        if not (prep["fin_masks"][ki] & (1 << state[ki])):
            return False
    return True


def solve(request):
    prep = _build(request)
    try:
        order = _search(prep, _NODE_LIMIT)
    except _SearchLimit:
        order = _mitm(prep)
    if order is not None and not _replay_ok(prep, order):
        order = _mitm(prep)
        if order is not None and not _replay_ok(prep, order):
            order = None
    if order is None:
        return {"order": None}
    ids = prep["ids"]
    return {"order": [ids[i] for i in order]}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request)))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
