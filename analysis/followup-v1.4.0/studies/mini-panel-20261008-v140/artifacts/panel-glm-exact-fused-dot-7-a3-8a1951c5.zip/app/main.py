#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating-point format.

All multiplication and accumulation are performed exactly (integer
arithmetic); only the final sum is rounded to the destination format.

Each request line is a JSON object:
    {"ebits": E, "fbits": F, "mode": M, "pairs": [[hex, hex], ...]}
and produces one JSON object:
    {"bits": "<hex>", "flags": [...]}
"""

import json
import sys

# operand classes
K_FIN = 0     # finite (including signed zero)
K_INF = 1     # infinity
K_QNAN = 2    # quiet NaN
K_SNAN = 3    # signaling NaN

_MODES = ('RNE', 'RNA', 'RTZ', 'RUP', 'RDN')


def _fmt(bits, width):
    """Format a bit pattern as lowercase hex, padded to whole nibbles."""
    return format(bits, '0{}x'.format((width + 3) // 4))


def _ge_pow2(n, qe, t):
    """Test (n * 2**qe) >= 2**t for integer n >= 0 and integer exponents."""
    d = t - qe
    if d >= 0:
        return n >= (1 << d)
    # 2**t is below the quantum unit, so any nonzero n clears the bar
    return n >= 1


def solve(request):
    ebits = int(request['ebits'])
    fbits = int(request['fbits'])
    mode = str(request.get('mode', 'RNE')).strip().upper()
    if mode not in _MODES:
        mode = 'RNE'
    pairs = request.get('pairs')
    if not pairs:
        pairs = []

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                    # 2**fbits
    Eall = (1 << ebits) - 1
    width = 1 + ebits + fbits
    vmask = (1 << width) - 1
    fmask = F - 1
    topbit = 1 << (fbits - 1)         # top fraction bit (quiet NaN marker)
    emin = 1 - bias
    emax = Eall - 1 - bias
    esh = fbits                       # exponent field shift
    ssh = ebits + fbits               # sign field shift

    def decode(v):
        """-> (kind, sign, significand, exponent) with value sign*sig*2**exp."""
        s = (v >> ssh) & 1
        e = (v >> esh) & Eall
        if e == Eall:
            f = v & fmask
            if f == 0:
                return (K_INF, s, 0, 0)
            if f & topbit:
                return (K_QNAN, s, 0, 0)
            return (K_SNAN, s, 0, 0)
        if e == 0:
            return (K_FIN, s, v & fmask, 1 - bias - fbits)
        return (K_FIN, s, F + (v & fmask), e - bias - fbits)

    def operand(tok):
        # bit pattern from a hex string (any sufficient length); ints accepted too
        if isinstance(tok, int):
            return tok & vmask
        t = str(tok).strip().lower()
        if t.startswith('0x'):
            t = t[2:]
        return int(t or '0', 16) & vmask

    # ---- inspect every operand; gather exceptions and exact products ----
    invalid = False
    saw_nan = False
    pos_inf = False
    neg_inf = False
    prods = []                        # (sign, significand, exponent) of products

    for pair in pairs:
        a = decode(operand(pair[0]))
        b = decode(operand(pair[1]))
        ak, bk = a[0], b[0]
        if ak >= K_QNAN or bk >= K_QNAN:
            # A pair with a NaN operand contributes no infinite product and
            # cannot itself count as zero times infinity.
            saw_nan = True
            if ak == K_SNAN or bk == K_SNAN:
                invalid = True
            continue
        if ak == K_INF or bk == K_INF:
            if (ak == K_FIN and a[2] == 0) or (bk == K_FIN and b[2] == 0):
                invalid = True       # zero times infinity (either order)
                continue
            if a[1] ^ b[1]:
                neg_inf = True
            else:
                pos_inf = True
            continue
        prods.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    # ---- NaN / invalid ----
    if pos_inf and neg_inf:
        invalid = True          # both positive and negative infinite products
    if saw_nan or invalid:
        # canonical NaN: sign 0, exponent Eall, only the top fraction bit set
        bits = (Eall << esh) | topbit
        flags = ['invalid'] if invalid else []
        return _fmt(bits, width), flags

    # ---- infinite result ----
    if pos_inf or neg_inf:
        bits = ((1 if neg_inf else 0) << ssh) | (Eall << esh)
        return _fmt(bits, width), []

    # ---- exact accumulation of finite products ----
    if not prods:
        bits = (1 if mode == 'RDN' else 0) << ssh
        return _fmt(bits, width), []

    kmin = min(pd[2] for pd in prods)
    total = 0
    for sgn, m, k in prods:
        term = m << (k - kmin)
        total = total - term if sgn else total + term

    if total == 0:
        # Exact zero: negative iff every product is a negative signed zero
        # (and there is at least one), or the mode is RDN.
        neg = (mode == 'RDN') or all(pd[0] == 1 and pd[1] == 0 for pd in prods)
        bits = (1 if neg else 0) << ssh
        return _fmt(bits, width), []

    sign = 1 if total < 0 else 0
    mag = -total if total < 0 else total          # exact nonzero magnitude x

    # quantum: q = 2**max(emin - fbits, L - fbits), L = floor(log2(x))
    L = mag.bit_length() - 1 + kmin
    qe = emin - fbits
    if L - fbits > qe:
        qe = L - fbits

    # y = n * 2**qe with n = round(x / q) using the mode and the original sign
    d = kmin - qe
    if d >= 0:
        n = mag << d
        inexact = False
    else:
        sh = -d
        n0 = mag >> sh
        rem = mag & ((1 << sh) - 1)
        if rem == 0:
            n = n0
            inexact = False
        else:
            inexact = True
            if mode == 'RNE':
                half = 1 << (sh - 1)
                if rem > half:
                    n = n0 + 1
                elif rem < half:
                    n = n0
                else:
                    n = n0 + (n0 & 1)          # ties to an even significand
            elif mode == 'RNA':
                n = n0 + 1 if (rem << 1) >= (1 << sh) else n0
            elif mode == 'RTZ':
                n = n0
            elif mode == 'RUP':
                n = n0 + 1 if sign == 0 else n0
            else:                              # RDN
                n = n0 + 1 if sign == 1 else n0

    # ---- overflow ----
    if _ge_pow2(n, qe, emax + 1):
        away = (mode in ('RNE', 'RNA')
                or (mode == 'RUP' and sign == 0)
                or (mode == 'RDN' and sign == 1))
        if away:
            bits = (sign << ssh) | (Eall << esh)
        else:
            bits = (sign << ssh) | ((Eall - 1) << esh) | fmask
        return _fmt(bits, width), ['overflow', 'inexact']

    flags = []
    if inexact:
        flags.append('inexact')
        if not _ge_pow2(n, qe, emin):        # rounded magnitude below 2**emin
            flags.append('underflow')

    # ---- encode ----
    if n == 0:
        # nonzero result rounded to zero retains its exact sign
        bits = sign << ssh
        return _fmt(bits, width), flags

    if _ge_pow2(n, qe, emin):
        # normal: exponent from floor(log2(y)), fraction from the significand
        bl = n.bit_length() - 1
        e = bl + qe + bias
        sh = fbits - bl
        sig = (n << sh) if sh >= 0 else (n >> (-sh))
        bits = (sign << ssh) | (e << esh) | (sig - F)
    else:
        # subnormal: q is the 2**(emin - fbits) quantum, so n is the fraction
        sh = qe - (emin - fbits)
        frac = (n << sh) if sh >= 0 else (n >> (-sh))
        bits = (sign << ssh) | frac
    return _fmt(bits, width), flags


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except ValueError as exc:
            print('bad input line: %s' % exc, file=sys.stderr)
            continue
        try:
            bits, flags = solve(request)
        except Exception as exc:                       # pragma: no cover
            print('error handling request: %r' % (exc,), file=sys.stderr)
            continue
        out.write(json.dumps({'bits': bits, 'flags': flags}))
        out.write('\n')


if __name__ == '__main__':
    main()
