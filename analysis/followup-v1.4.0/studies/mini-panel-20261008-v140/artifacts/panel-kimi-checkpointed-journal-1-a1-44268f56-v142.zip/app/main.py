"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin and writes one JSON response
per line.  See the task specification for the binary record format and the
transaction/checkpoint replay rules.
"""

import json
import sys
import zlib

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4

HEADER_SIZE = 13          # payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
CRC_SIZE = 4              # trailing crc:u32
MAX_PAYLOAD = 4096


def solve(request):
    pages = [bytearray.fromhex(p) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])

    n_pages = len(pages)
    page_len = len(pages[0])
    n = len(log)

    # Active transaction incarnations: txid -> staged patches / running digest
    # of the concatenated PATCH payloads (in log order).
    staged = {}
    digests = {}

    pos = 0        # bytes consumed by the valid prefix
    last_seq = 0   # sequence of the last valid record (0 for empty prefix)

    while True:
        # --- structural validation (any failure ends the valid prefix) ---
        if n - pos < HEADER_SIZE:
            break  # incomplete header
        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")

        if payload_length > MAX_PAYLOAD:
            break
        end = pos + HEADER_SIZE + payload_length
        if n - end < CRC_SIZE:
            break  # incomplete payload or missing CRC
        if zlib.crc32(log[pos:end]) != int.from_bytes(log[end:end + CRC_SIZE], "little"):
            break  # CRC mismatch
        if sequence <= last_seq:
            break  # must be positive and strictly increasing (last_seq starts at 0)
        if txid == 0:
            break  # transaction ID must be positive

        payload = log[pos + HEADER_SIZE:end]

        if kind == KIND_BEGIN:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if (byte_count == 0
                    or payload_length != 6 + byte_count
                    or page_index >= n_pages
                    or byte_offset + byte_count > page_len):
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        elif kind == KIND_ABORT:
            if payload_length != 0:
                break
        else:
            break  # unknown kind

        # --- semantic effects (record is now known to be valid) ---
        if kind == KIND_BEGIN:
            # Fresh incarnation; any unfinished incarnation is discarded.
            staged[txid] = []
            digests[txid] = 0
        elif kind == KIND_PATCH:
            if txid in staged:
                staged[txid].append((page_index, byte_offset, payload[6:]))
                digests[txid] = zlib.crc32(payload, digests[txid])
            # else: inactive transaction -> ignored
        elif kind == KIND_ABORT:
            staged.pop(txid, None)
            digests.pop(txid, None)
        else:  # KIND_COMMIT: always closes the active incarnation, if any.
            if txid in staged:
                count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                tx_patches = staged.pop(txid)
                tx_digest = digests.pop(txid)
                if (count == len(tx_patches) and digest == tx_digest
                        and sequence > checkpoint):
                    for page_index, byte_offset, data in tx_patches:
                        page = pages[page_index]
                        page[byte_offset:byte_offset + len(data)] = data
            # Orphan COMMIT: no effect.  Seal mismatch: closed, not applied.

        last_seq = sequence
        pos = end + CRC_SIZE

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
