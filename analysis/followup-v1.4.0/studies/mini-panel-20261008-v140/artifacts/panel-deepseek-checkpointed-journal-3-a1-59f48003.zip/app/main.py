"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line to stdout.

Record layout (little-endian, no padding):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
    | payload | crc:u32
where crc = zlib.crc32(header + payload) & 0xffffffff.

Kinds:
    1 BEGIN  : empty payload
    2 PATCH  : page_index:u16 | byte_offset:u16 | byte_count:u16 | data
    3 COMMIT : patch_count:u32 | digest:u32
    4 ABORT  : empty payload
"""
import json
import struct
import sys
import zlib

HEADER_LEN = 13
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4

_HEADER = struct.Struct("<IIBI")   # payload_length, sequence, kind, transaction_id
_U16_3 = struct.Struct("<HHH")     # page_index, byte_offset, byte_count
_U32_2 = struct.Struct("<II")      # patch_count, digest
_U32_1 = struct.Struct("<I")       # crc


def solve(request):
    pages = [bytearray.fromhex(h) for h in request["pages"]]
    page_count = len(pages)
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])
    view = memoryview(log)
    n = len(log)

    pos = 0          # start of the next record; also the valid prefix length
    last_seq = 0
    active = {}      # transaction id -> list of staged PATCH payloads

    crc32 = zlib.crc32

    while n - pos >= HEADER_LEN:
        payload_len, seq, kind, txid = _HEADER.unpack_from(view, pos)
        if payload_len > MAX_PAYLOAD:
            break
        end = pos + HEADER_LEN + payload_len + 4
        if end > n:
            break  # torn / incomplete record

        if seq == 0 or seq <= last_seq or txid == 0 or not (KIND_BEGIN <= kind <= KIND_ABORT):
            break

        payload_start = pos + HEADER_LEN
        payload = view[payload_start:payload_start + payload_len]

        # Payload shape / bounds must hold before the record has any effect.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_len != 0:
                break
        elif kind == KIND_PATCH:
            if payload_len < 6:
                break
            page_index, byte_offset, byte_count = _U16_3.unpack_from(view, payload_start)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= page_count or byte_offset + byte_count > len(pages[page_index]):
                break
        else:  # KIND_COMMIT
            if payload_len != 8:
                break

        # CRC over header + payload, computed incrementally to avoid a copy.
        if crc32(payload, crc32(view[pos:payload_start])) != _U32_1.unpack_from(view, payload_start + payload_len)[0]:
            break

        # Structurally valid record: it joins the prefix and acts on state.
        if kind == KIND_BEGIN:
            active[txid] = []
        elif kind == KIND_PATCH:
            staged = active.get(txid)
            if staged is not None:
                staged.append(payload)
        elif kind == KIND_COMMIT:
            staged = active.pop(txid, None)
            if staged is not None:
                patch_count, digest = _U32_2.unpack_from(view, payload_start)
                if patch_count == len(staged) and seq > checkpoint:
                    running = 0
                    for p in staged:
                        running = crc32(p, running)
                    if running & 0xFFFFFFFF == digest:
                        for p in staged:
                            page_index, byte_offset, byte_count = _U16_3.unpack_from(p, 0)
                            pages[page_index][byte_offset:byte_offset + byte_count] = p[6:6 + byte_count]
                # Seal mismatch / commit at or below checkpoint: incarnation is
                # closed either way, patches are not applied.
        else:  # KIND_ABORT
            active.pop(txid, None)

        last_seq = seq
        pos = end

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        if not line.strip():
            continue
        write(json.dumps(solve(json.loads(line))))
        write("\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
