"""Exhaustive outcome enumeration for a small TSO-like buffered machine.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line to stdout.  See the task statement for the machine definition.

State representation used for the exhaustive search:

  * ``pcs``      -- program counter of every thread
  * ``drained``  -- how many stores of every thread have already been drained
  * ``mem``      -- shared memory packed little-endian into one integer
  * ``reads``    -- tuple of observation tuples, one per thread

A thread's FIFO store buffer is exactly the suffix of its already-executed
stores that has not been drained yet, so (pc, drained) fully describes it.
Observations do not influence enabledness, but they must stay part of the
search key because different histories reaching the same configuration can
have different observations and hence different terminal outcomes.
"""

import json
import sys
from collections import deque


def solve(request):
    nbytes = len(request["memory"])
    mem0 = 0
    for i, b in enumerate(request["memory"]):
        mem0 |= (int(b) & 0xFF) << (8 * i)

    progs = []
    for th in request["threads"]:
        p = []
        for ins in th:
            kind = ins[0]
            if kind == "store":
                p.append(("store", int(ins[1]), int(ins[2]), int(ins[3])))
            elif kind == "load":
                p.append(("load", int(ins[1]), int(ins[2])))
            elif kind == "fence":
                p.append(("fence",))
            elif kind == "xchg":
                p.append(("xchg", int(ins[1]), int(ins[2]), int(ins[3])))
            else:
                raise ValueError("unknown instruction: %r" % (kind,))
        progs.append(tuple(p))

    T = len(progs)

    # stores[i]: store instructions of thread i in program order.
    # cnts[i][pc]: number of store instructions at positions < pc.
    stores = []
    cnts = []
    ends = []
    for p in progs:
        st = []
        c = [0]
        for ins in p:
            if ins[0] == "store":
                st.append(ins)
            c.append(len(st))
        stores.append(tuple(st))
        cnts.append(tuple(c))
        ends.append(len(p))

    start = ((0,) * T, (0,) * T, mem0, ((),) * T)
    visited = {(start[0], start[1], start[2]): {start[3]}}
    queue = deque([start])
    outcomes = set()

    while queue:
        pcs, drained, mem, reads = queue.popleft()

        if all(pcs[i] == ends[i] and drained[i] == cnts[i][ends[i]]
               for i in range(T)):
            outcomes.add((reads, mem))
            continue

        # ---- execute the next instruction of one thread ----
        for i in range(T):
            pc = pcs[i]
            if pc >= ends[i]:
                continue
            ins = progs[i][pc]
            kind = ins[0]

            if kind == "store":
                # Buffer the whole store; pc advances, drained count unchanged.
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                nreads = reads
                nmem = mem

            elif kind == "load":
                addr, width = ins[1], ins[2]
                buf = stores[i][drained[i]:cnts[i][pc]]
                value = 0
                if buf:
                    # Resolve every byte: youngest covering buffered store wins,
                    # otherwise the shared memory byte is used.
                    for j in range(width):
                        b = addr + j
                        byte = (mem >> (8 * b)) & 0xFF
                        for st in reversed(buf):
                            saddr = st[1]
                            if saddr <= b < saddr + st[2]:
                                byte = (st[3] >> (8 * (b - saddr))) & 0xFF
                                break
                        value |= byte << (8 * j)
                else:
                    value = (mem >> (8 * addr)) & ((1 << (8 * width)) - 1)
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                nreads = reads[:i] + (reads[i] + (value,),) + reads[i + 1:]
                nmem = mem

            elif kind == "fence":
                if drained[i] != cnts[i][pc]:
                    continue  # disabled: this thread's buffer is not empty
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                nreads = reads
                nmem = mem

            else:  # xchg
                if drained[i] != cnts[i][pc]:
                    continue  # disabled: this thread's buffer is not empty
                addr, width, value = ins[1], ins[2], ins[3]
                old = (mem >> (8 * addr)) & ((1 << (8 * width)) - 1)
                mask = ((1 << (8 * width)) - 1) << (8 * addr)
                nmem = (mem & ~mask) | (value << (8 * addr))
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                nreads = reads[:i] + (reads[i] + (old,),) + reads[i + 1:]

            key = (npcs, drained, nmem)
            seen = visited.get(key)
            if seen is None:
                visited[key] = {nreads}
                queue.append((npcs, drained, nmem, nreads))
            elif nreads not in seen:
                seen.add(nreads)
                queue.append((npcs, drained, nmem, nreads))

        # ---- drain the oldest buffered store of one thread ----
        for i in range(T):
            nexec = cnts[i][pcs[i]]
            if drained[i] >= nexec:
                continue
            st = stores[i][drained[i]]
            addr, width, value = st[1], st[2], st[3]
            mask = ((1 << (8 * width)) - 1) << (8 * addr)
            nmem = (mem & ~mask) | (value << (8 * addr))
            ndrained = drained[:i] + (drained[i] + 1,) + drained[i + 1:]
            key = (pcs, ndrained, nmem)
            seen = visited.get(key)
            if seen is None:
                visited[key] = {reads}
                queue.append((pcs, ndrained, nmem, reads))
            elif reads not in seen:
                seen.add(reads)
                queue.append((pcs, ndrained, nmem, reads))

    result = []
    for reads, mem in outcomes:
        result.append({
            "reads": [list(obs) for obs in reads],
            "memory": [(mem >> (8 * i)) & 0xFF for i in range(nbytes)],
        })
    return {"outcomes": result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request)))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
