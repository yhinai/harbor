#!/usr/bin/env python3
"""Mixed-width buffered machine: enumerate every terminal observable outcome.

Model (see instruction.md):
  * each thread has a program counter, a FIFO store buffer and an
    observation list; shared memory is a byte array,
  * `store`  : append the complete store to the thread's buffer (memory
    unchanged),
  * `load`   : every byte is resolved independently -- the youngest store
    still sitting in *this* thread's buffer that covers the byte wins,
    otherwise the byte comes from shared memory; the assembled unsigned
    little-endian value is appended to the thread's observations,
  * `fence`  : enabled only with an empty buffer,
  * `xchg`   : enabled only with an empty buffer; atomically reads shared
    memory, records the value and writes the supplied value,
  * `drain`  : the oldest store of any non-empty buffer becomes globally
    visible, all of its bytes at once.

Every transition either advances a program counter or removes a buffered
store, so all executions are finite and the transition graph is acyclic.
We therefore enumerate the reachable states exhaustively (deduplicating on
the whole state, which determines everything that can still happen and
everything already observed) and report the states that have no enabled
transition left, i.e. all threads finished and all buffers empty.
"""

import json
import sys

STORE, LOAD, FENCE, XCHG = 0, 1, 2, 3


def compile_threads(threads):
    """Compile instructions into compact (kind, addr, width, bytes) tuples."""
    progs = []
    for thr in threads:
        prog = []
        for ins in thr:
            kind = ins[0]
            if kind == 'store':
                a, w, v = int(ins[1]), int(ins[2]), int(ins[3])
                nb = (v & ((1 << (8 * w)) - 1)).to_bytes(w, 'little')
                prog.append((STORE, a, w, nb))
            elif kind == 'load':
                prog.append((LOAD, int(ins[1]), int(ins[2]), b''))
            elif kind == 'fence':
                prog.append((FENCE, 0, 0, b''))
            elif kind == 'xchg':
                a, w, v = int(ins[1]), int(ins[2]), int(ins[3])
                nb = (v & ((1 << (8 * w)) - 1)).to_bytes(w, 'little')
                prog.append((XCHG, a, w, nb))
            else:
                raise ValueError('unknown instruction %r' % (kind,))
        progs.append(tuple(prog))
    return progs


def explore(mem0, progs):
    """Return {(per-thread observations, final memory)} of terminal states.

    A state is (memory, pcs, buffers, observations); buffers and
    observations are tuples of per-thread tuples, hence immutable, and the
    complete tuple is used as the deduplication key.
    """
    n = len(progs)
    lens = tuple(len(p) for p in progs)
    nrange = range(n)
    start = (mem0, (0,) * n, ((),) * n, ((),) * n)
    visited = {start}
    stack = [start]
    outcomes = set()

    while stack:
        state = stack.pop()
        mem, pcs, bufs, obs = state
        moved = False

        # ---- 1. execute the next instruction of any thread --------------
        for t in nrange:
            pc = pcs[t]
            if pc == lens[t]:
                continue
            kind, a, w, nb = progs[t][pc]
            buf = bufs[t]
            if kind == STORE:
                # buffer the complete store; memory is untouched
                st = (mem, pcs[:t] + (pc + 1,) + pcs[t + 1:],
                      bufs[:t] + (buf + ((a, nb),),) + bufs[t + 1:], obs)
            elif kind == LOAD:
                # per-byte store forwarding from the youngest own store
                val = 0
                shift = 0
                for i in range(w):
                    addr = a + i
                    b = None
                    for ent in reversed(buf):        # youngest first
                        sa, snb = ent
                        if sa <= addr < sa + len(snb):
                            b = snb[addr - sa]
                            break
                    if b is None:
                        b = mem[addr]
                    val |= b << shift
                    shift += 8
                st = (mem, pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs,
                      obs[:t] + (obs[t] + (val,),) + obs[t + 1:])
            elif kind == FENCE:
                if buf:
                    continue                          # not enabled
                st = (mem, pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs, obs)
            else:                                     # XCHG
                if buf:
                    continue                          # not enabled
                val = int.from_bytes(mem[a:a + w], 'little')
                st = (mem[:a] + nb + mem[a + w:],
                      pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs,
                      obs[:t] + (obs[t] + (val,),) + obs[t + 1:])
            moved = True
            if st not in visited:
                visited.add(st)
                stack.append(st)

        # ---- 2. drain the oldest store of any non-empty buffer ---------
        for t in nrange:
            buf = bufs[t]
            if buf:
                a, nb = buf[0]
                st = (mem[:a] + nb + mem[a + len(nb):], pcs,
                      bufs[:t] + (buf[1:],) + bufs[t + 1:], obs)
                moved = True
                if st not in visited:
                    visited.add(st)
                    stack.append(st)

        if not moved:
            # no enabled transition <=> all threads finished and every
            # buffer empty: this is a terminal state
            outcomes.add((obs, mem))

    return outcomes


def solve(request):
    mem0 = bytes([int(x) & 0xFF for x in request['memory']])
    progs = compile_threads(request['threads'])
    outcomes = explore(mem0, progs)
    result = [{'reads': [list(o) for o in obs], 'memory': list(mem)}
              for obs, mem in outcomes]
    result.sort(key=lambda o: (o['memory'], o['reads']))
    return {'outcomes': result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            response = solve(json.loads(line))
        except Exception as exc:  # keep the batch alive on bad input
            sys.stderr.write('request failed: %r\n' % (exc,))
            response = {'outcomes': []}
        out.write(json.dumps(response))
        out.write('\n')
        out.flush()


if __name__ == '__main__':
    main()
