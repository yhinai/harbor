"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line to stdout.  See instruction.md for the format description.
"""

import json
import sys
import zlib

HEADER_LEN = 13          # payload_length u32 | sequence u32 | kind u8 | tx_id u32
CRC_LEN = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _u32(data, off):
    return int.from_bytes(data[off:off + 4], "little")


def _u16(data, off):
    return int.from_bytes(data[off:off + 2], "little")


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    checkpoint = request["checkpoint"]

    log_hex = request["log"].strip()
    if len(log_hex) & 1:
        # A dangling nibble cannot form a byte; treat it as a torn tail.
        log_hex = log_hex[:-1]
    log = bytes.fromhex(log_hex)
    total_len = len(log)
    page_count = len(pages)

    # Active incarnations: tx_id -> (list_of_patches, running_crc32_of_patch_payloads)
    active = {}

    pos = 0
    valid_bytes = 0
    last_seq = 0
    prev_seq = 0

    # Minimum record size is HEADER_LEN + CRC_LEN (empty payload).
    while pos + HEADER_LEN + CRC_LEN <= total_len:
        payload_len = _u32(log, pos)
        if payload_len > MAX_PAYLOAD:
            break
        rec_end = pos + HEADER_LEN + payload_len + CRC_LEN
        if rec_end > total_len:
            break  # torn / incomplete record

        seq = _u32(log, pos + 4)
        kind = log[pos + 8]
        tx_id = _u32(log, pos + 9)

        header = log[pos:pos + HEADER_LEN]
        payload = log[pos + HEADER_LEN:pos + HEADER_LEN + payload_len]
        stored_crc = _u32(log, pos + HEADER_LEN + payload_len)

        if (zlib.crc32(header + payload) & 0xFFFFFFFF) != stored_crc:
            break
        if seq <= prev_seq or tx_id == 0 or kind < KIND_BEGIN or kind > KIND_ABORT:
            break

        patch = None
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_len != 0:
                break
        elif kind == KIND_PATCH:
            if payload_len < 6:
                break
            page_index = _u16(payload, 0)
            byte_offset = _u16(payload, 2)
            byte_count = _u16(payload, 4)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= page_count:
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break
            patch = (page_index, byte_offset, payload[6:6 + byte_count])
        else:  # KIND_COMMIT
            if payload_len != 8:
                break

        # Structurally valid: apply its semantic effect.
        if kind == KIND_BEGIN:
            active[tx_id] = [[], 0]
        elif kind == KIND_PATCH:
            state = active.get(tx_id)
            if state is not None:
                state[0].append(patch)
                state[1] = zlib.crc32(payload, state[1])
        elif kind == KIND_ABORT:
            active.pop(tx_id, None)
        else:  # COMMIT closes the active incarnation, if any
            state = active.pop(tx_id, None)
            if state is not None:
                patches, digest = state
                patch_count = _u32(payload, 0)
                want_digest = _u32(payload, 4)
                if (patch_count == len(patches)
                        and want_digest == digest
                        and seq > checkpoint):
                    for page_index, byte_offset, data in patches:
                        pages[page_index][byte_offset:byte_offset + len(data)] = data

        pos = rec_end
        valid_bytes = pos
        last_seq = seq
        prev_seq = seq

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
