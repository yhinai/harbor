"""Bit-exact fused dot product for a parameterized binary float format.

Reads newline-delimited JSON requests from stdin and writes one JSON response
object per line to stdout.  All products and their sum are computed exactly as
integers scaled by powers of two; only the final sum is rounded.
"""

import json
import sys


def _decode(hexstr, width, ebits, fbits, Eall, F, fmask, bias):
    """Decode one operand bit pattern into a tuple describing it."""
    v = int(hexstr, 16) & ((1 << width) - 1)
    s = (v >> (ebits + fbits)) & 1
    e = (v >> fbits) & Eall
    f = v & fmask
    if e == Eall:
        if f == 0:
            return (2, s, 0, 0)          # infinity
        # NaN: signalling iff top fraction bit is 0
        if (f >> (fbits - 1)) & 1:
            return (3, s, 0, 0)          # quiet NaN
        return (4, s, 0, 0)              # signalling NaN
    if e == 0:
        if f == 0:
            return (0, s, 0, 0)          # signed zero
        return (1, s, f, 1 - bias - fbits)   # subnormal
    return (1, s, F + f, e - bias - fbits)   # normal


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    width = 1 + ebits + fbits
    F = 1 << fbits
    fmask = F - 1
    Eall = (1 << ebits) - 1
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias

    any_nan = False
    signalling_nan = False
    invalid = False
    inf_signs = set()
    finite = []  # (sign, mantissa, exponent); mantissa 0 means signed zero

    for pair in pairs:
        a = _decode(pair[0], width, ebits, fbits, Eall, F, fmask, bias)
        b = _decode(pair[1], width, ebits, fbits, Eall, F, fmask, bias)
        ka, kb = a[0], b[0]
        if ka >= 3 or kb >= 3:
            any_nan = True
            if ka == 4 or kb == 4:
                signalling_nan = True
            continue  # a NaN operand contributes no product
        if (ka == 2 and kb == 0) or (ka == 0 and kb == 2):
            invalid = True  # zero times infinity
            continue
        if ka == 2 or kb == 2:
            inf_signs.add(a[1] ^ b[1])
            continue
        # both finite (normal, subnormal or zero)
        finite.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    invalid_raised = signalling_nan or invalid or len(inf_signs) > 1

    if any_nan or invalid_raised:
        # canonical NaN: sign 0, exponent Eall, only top fraction bit set
        bits = (Eall << fbits) | (1 << (fbits - 1))
        return bits, (["invalid"] if invalid_raised else [])

    if inf_signs:
        s = next(iter(inf_signs))
        return (s << (ebits + fbits)) | (Eall << fbits), []

    # ---- exact finite dot product ----
    nonzero = [p for p in finite if p[1] != 0]
    if not nonzero:
        # exact zero: negative iff all products are negative signed zeros
        # (with at least one product), or mode is RDN.
        if mode == "RDN":
            zs = 1
        elif finite and all(p[0] == 1 for p in finite):
            zs = 1
        else:
            zs = 0
        return zs << (ebits + fbits), []

    min_exp = min(p[2] for p in nonzero)
    total = 0
    for s, m, ex in nonzero:
        term = m << (ex - min_exp)
        total += -term if s else term

    if total == 0:
        # cancellation of nonzero products
        zs = 1 if mode == "RDN" else 0
        return zs << (ebits + fbits), []

    sign = 1 if total < 0 else 0
    mag = -total if sign else total

    L = mag.bit_length() - 1 + min_exp
    Q = max(emin - fbits, L - fbits)
    shift = min_exp - Q
    if shift >= 0:
        y_int = mag << shift
        rem = 0
    else:
        den = 1 << (-shift)
        y_int, rem = divmod(mag, den)

    if rem:
        twice = rem << 1
        up = False
        if mode == "RNE" or mode == "RNA":
            if twice > den:
                up = True
            elif twice == den:
                if mode == "RNA":
                    up = True
                else:
                    up = bool(y_int & 1)
        elif mode == "RUP":
            up = (sign == 0)
        elif mode == "RDN":
            up = (sign == 1)
        # RTZ: never round magnitude up
        if up:
            y_int += 1

    inexact = rem != 0

    if (emax + 1 - Q <= 0) or (y_int >= (1 << (emax + 1 - Q))):
        # overflow
        if (mode in ("RNE", "RNA")
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1)):
            bits = (sign << (ebits + fbits)) | (Eall << fbits)
        else:
            bits = ((sign << (ebits + fbits))
                    | ((Eall - 1) << fbits) | fmask)
        return bits, ["overflow", "inexact"]

    if y_int == 0:
        below_emin = True
    elif emin - Q > 0:
        below_emin = y_int < (1 << (emin - Q))
    else:
        below_emin = False

    flags = []
    if inexact:
        flags.append("inexact")
    if inexact and below_emin:
        flags.append("underflow")

    if y_int == 0:
        # nonzero exact result rounded to zero keeps its exact sign
        return sign << (ebits + fbits), flags

    if below_emin:
        # subnormal (here Q == emin - fbits)
        f = y_int << (Q - emin + fbits)
        return (sign << (ebits + fbits)) | f, flags

    bl = y_int.bit_length()
    e = (bl - 1 + Q) + bias
    sh = fbits - (bl - 1)
    m = (y_int << sh) if sh >= 0 else (y_int >> (-sh))
    f = m - F
    bits = (sign << (ebits + fbits)) | (e << fbits) | f
    return bits, flags


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        bits, flags = solve(req)
        out.write(json.dumps({"bits": format(bits, "x"), "flags": flags}))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
