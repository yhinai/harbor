#!/usr/bin/env python3
"""Linearizability / serial-witness checker for atomic range transactions.

Input : newline delimited JSON requests on stdin.
Output: one JSON object per request line on stdout,
        {"order": [txn ids ...]} for a valid serial witness,
        {"order": null} when no witness exists.

A whole transaction is a single atomic operation.  A witness is a permutation
of the transactions such that
  * whenever A.end <= B.start, A appears before B (real time order), and
  * executing the transactions in that order starting from `initial`
    reproduces every observed return value and ends exactly at `final`.

Algorithm: depth first search over the linear extensions of the real time
precedence relation, memoised on (set of already placed transactions, state).
The search is pruned with
  * per-transaction caches of the (deterministic) state transition,
  * necessary "last writer" conditions on the set of remaining transactions,
  * a relaxed last-writer search which is exact (and therefore a direct
    construction) when every remaining transaction is observation free.
"""

import sys
import json

ABSENT = object()          # sentinel: the key is not present
_MISS = object()           # sentinel: cache miss
_NFIX = object()           # sentinel: key value not provably constant


class _BudgetExceeded(Exception):
    """The relaxed last-writer search ran out of its step budget."""


# Step budget (candidate evaluations) shared by all relaxed searches of one
# request.  A single full search over 10 transactions costs at most ~10k
# evaluations, so this allows plenty of searches while bounding worst cases.
_CSP_BUDGET = 400000


def solve_request(req):
    initial = req.get("initial") or {}
    final = req.get("final") or {}
    txns = req.get("transactions") or []
    n = len(txns)

    # ------------------------------------------------------------------
    # universe of keys (state is a tuple over this fixed sorted universe)
    # ------------------------------------------------------------------
    keyset = set()
    for k in initial:
        if isinstance(k, str):
            keyset.add(k)
    for k in final:
        if isinstance(k, str):
            keyset.add(k)
    for t in txns:
        for op in t.get("ops") or []:
            if not op or not isinstance(op[0], str):
                continue
            kind = op[0]
            if kind == "scan":
                if len(op) > 1 and isinstance(op[1], str):
                    keyset.add(op[1])
                if len(op) > 2 and isinstance(op[2], str):
                    keyset.add(op[2])
            elif len(op) > 1 and isinstance(op[1], str):
                keyset.add(op[1])
    U = sorted(keyset)
    K = len(U)
    kidx = {}
    for i, k in enumerate(U):
        kidx[k] = i

    init_state = tuple(initial.get(k, ABSENT) for k in U)
    final_state = tuple(final.get(k, ABSENT) for k in U)

    starts = [t.get("start", 0) for t in txns]
    ends = [t.get("end", 0) for t in txns]
    ids = [t.get("id") for t in txns]

    # ------------------------------------------------------------------
    # compile every transaction into a fast op list
    #   (0, keyidx, value)            put / del
    #   (1, keyidx, expected)         get
    #   (2, keyidx, old, new, want)   cas
    #   (3, keyidxs, expected_pairs)  scan
    #   (4,)                          can never succeed
    # ------------------------------------------------------------------
    cops_list = []
    twrite = []        # bitmask of key indices written by the transaction
    teff = []          # dict key index -> value written (ABSENT means delete)
    for t in txns:
        cops = []
        writes = {}
        for op in t.get("ops") or []:
            if not op or not isinstance(op[0], str):
                continue
            kind = op[0]
            if kind == "put" and len(op) > 2:
                i = kidx.get(op[1])
                if i is None:
                    continue
                cops.append((0, i, op[2]))
                writes[i] = op[2]
            elif kind == "del" and len(op) > 1:
                i = kidx.get(op[1])
                if i is None:
                    continue
                cops.append((0, i, ABSENT))
                writes[i] = ABSENT
            elif kind == "get" and len(op) > 2:
                i = kidx.get(op[1])
                if i is None:
                    cops.append((4,))
                    continue
                cops.append((1, i, op[2]))
            elif kind == "cas" and len(op) > 4:
                i = kidx.get(op[1])
                if i is None:
                    cops.append((4,))
                    continue
                want = op[4]
                if not isinstance(want, bool):
                    # the observed flag is not a boolean: comparison of
                    # "actual is expected" can never hold.
                    cops.append((4,))
                    continue
                cops.append((2, i, op[2], op[3], want))
                if want:
                    writes[i] = ABSENT if op[3] is None else op[3]
            elif kind == "scan" and len(op) > 3:
                lo = op[1]
                hi = op[2]
                try:
                    exp = tuple((p[0], p[1]) for p in (op[3] or []))
                except Exception:
                    cops.append((4,))
                    continue
                if not isinstance(lo, str) or not isinstance(hi, str):
                    cops.append((4,))
                    continue
                inds = tuple(j for j, k in enumerate(U) if lo <= k < hi)
                cops.append((3, inds, exp))
        cops_list.append(cops)
        wmask = 0
        for i in writes:
            wmask |= 1 << i
        twrite.append(wmask)
        teff.append(writes)

    written_any = 0
    for w in twrite:
        written_any |= w

    # ------------------------------------------------------------------
    # static classification of every transaction
    #   * "dead"   : it can never succeed -> the request has no witness
    #   * "always" : it always succeeds, with a fixed net effect.  A read is
    #                only treated as fixed when its observed value provably
    #                cannot depend on the execution order:
    #                  - the transaction itself wrote the key earlier, or
    #                  - every writer of the key writes the same value that
    #                    the key already holds initially (constant key).
    # ------------------------------------------------------------------
    # keys whose committed value is provably the same in every execution
    fixed_value = []
    for k in range(K):
        v = init_state[k]
        isfixed = True
        for i in range(n):
            if (twrite[i] >> k) & 1 and teff[i].get(k) != v:
                isfixed = False
                break
        fixed_value.append(v if isfixed else _NFIX)

    always_bits = 0
    for ti in range(n):
        pure = True
        dead = False
        known = {}                       # keys written earlier in this txn
        for op in cops_list[ti]:
            code = op[0]
            if code == 0:                 # put / del
                known[op[1]] = op[2]
                continue
            if code == 4:                 # can never succeed
                dead = True
                break
            if code == 1:                 # get
                i = op[1]
                cur = known[i] if i in known else fixed_value[i]
                if cur is _NFIX:
                    pure = False
                elif (None if cur is ABSENT else cur) != op[2]:
                    dead = True
                    break
            elif code == 2:               # cas
                i = op[1]
                cur = known[i] if i in known else fixed_value[i]
                if cur is _NFIX:
                    pure = False
                elif ((None if cur is ABSENT else cur) == op[2]) is not op[4]:
                    dead = True
                    break
                if op[4]:
                    known[i] = ABSENT if op[3] is None else op[3]
            else:                         # scan
                dyn = False
                fixed_pairs = []
                for j in op[1]:
                    v = known[j] if j in known else fixed_value[j]
                    if v is _NFIX:
                        dyn = True
                        break
                    if v is not ABSENT:
                        fixed_pairs.append((U[j], v))
                if dyn:
                    pure = False
                elif tuple(fixed_pairs) != op[2]:
                    dead = True
                    break
        if dead:
            return None
        if pure:
            always_bits |= 1 << ti

    full = (1 << n) - 1

    # ------------------------------------------------------------------
    # real time precedence
    # ------------------------------------------------------------------
    pred = [0] * n     # pred[i]: transactions that must be placed before i
    succ = [0] * n     # succ[i]: transactions that must be placed after i
    for i in range(n):
        for j in range(n):
            if i != j and ends[j] <= starts[i]:
                pred[i] |= 1 << j
                succ[j] |= 1 << i

    cand_order = sorted(range(n), key=lambda i: (starts[i], i))

    _eligible = {}

    def eligible(mask):
        """Transactions that may be placed next (all predecessors placed)."""
        r = _eligible.get(mask)
        if r is None:
            rem = full & ~mask
            r = tuple(i for i in cand_order
                     if (rem >> i) & 1 and not (pred[i] & rem))
            _eligible[mask] = r
        return r

    # ------------------------------------------------------------------
    # deterministic transaction application, memoised per transaction
    # ------------------------------------------------------------------
    apply_cache = [dict() for _ in range(n)]

    def apply_tx(i, state):
        c = apply_cache[i]
        r = c.get(state, _MISS)
        if r is not _MISS:
            return r
        s = list(state)
        for op in cops_list[i]:
            code = op[0]
            if code == 0:
                s[op[1]] = op[2]
            elif code == 1:
                v = s[op[1]]
                if (None if v is ABSENT else v) != op[2]:
                    c[state] = None
                    return None
            elif code == 2:
                v = s[op[1]]
                if (None if v is ABSENT else v) == op[2]:
                    if op[4] is False:
                        c[state] = None
                        return None
                    s[op[1]] = ABSENT if op[3] is None else op[3]
                else:
                    if op[4] is True:
                        c[state] = None
                        return None
            elif code == 3:
                exp = op[2]
                got = tuple((U[j], s[j]) for j in op[1]
                            if s[j] is not ABSENT)
                if got != exp:
                    c[state] = None
                    return None
            else:
                c[state] = None
                return None
        res = tuple(s)
        c[state] = res
        return res

    # ------------------------------------------------------------------
    # necessary conditions on the set of remaining transactions
    # ------------------------------------------------------------------
    _mi = {}

    def mask_info(mask):
        r = _mi.get(mask)
        if r is not None:
            return r
        rem = full & ~mask
        rem_list = [i for i in range(n) if (rem >> i) & 1]
        nowriter = []
        infeasible = False
        if rem_list:
            # mand[x]: transactions that must be placed before x
            mand = [pred[i] & rem for i in range(n)]
            for k in range(K):
                wr = [i for i in rem_list if (twrite[i] >> k) & 1]
                if not wr:
                    # nobody else touches k: it must already hold final value
                    nowriter.append(k)
                    continue
                fk = final_state[k]
                cands = [i for i in wr if teff[i].get(k) == fk]
                if not cands:
                    infeasible = True      # no possible last writer for k
                    break
                if len(cands) == 1:
                    L = cands[0]
                    mb = mand[L]
                    for W in wr:
                        if W != L:
                            mb |= 1 << W
                    mand[L] = mb
            if not infeasible:
                # cycle check (Kahn) over real time + forced last-writer edges
                indeg = {}
                for i in rem_list:
                    indeg[i] = bin(mand[i]).count("1")
                queue = [i for i in rem_list if indeg[i] == 0]
                qi = 0
                seen = 0
                while qi < len(queue):
                    x = queue[qi]
                    qi += 1
                    seen += 1
                    xb = 1 << x
                    for y in rem_list:
                        if mand[y] & xb:
                            indeg[y] -= 1
                            if indeg[y] == 0:
                                queue.append(y)
                if seen != len(rem_list):
                    infeasible = True
        r = (infeasible, tuple(nowriter))
        _mi[mask] = r
        return r

    # ------------------------------------------------------------------
    # relaxed last-writer search.
    # Ignores read feasibility, i.e. asks: is there a linear extension of the
    # remaining transactions whose pure write effects produce `final`?
    # Infeasible  -> no witness can exist (sound prune).
    # Feasible    -> returns such an order; when every remaining transaction
    #                always succeeds (always_bits) this order *is* a valid
    #                completion, so the search is exact in that case.
    # ------------------------------------------------------------------
    _csp = {}
    budget = [_CSP_BUDGET]

    def csp(mask):
        r = _csp.get(mask, _MISS)
        if r is not _MISS:
            return r
        if budget[0] <= 0:
            r = (None, None)
            _csp[mask] = r
            return r
        R0 = full & ~mask
        memoR = {}
        try:
            order = _csp_search(R0, 0, memoR)
        except _BudgetExceeded:
            r = (None, None)
            _csp[mask] = r
            return r
        if order is False:
            r = (False, None)
        else:
            r = (True, order)
        _csp[mask] = r
        return r

    def _csp_search(R, settled, memoR):
        # `settled` is a function of R (keys written by already removed
        # transactions), so memoising on R alone is sound.
        if R == 0:
            return []
        got = memoR.get(R, _MISS)
        if got is not _MISS:
            return got
        res = False
        for i in range(n):
            b = 1 << i
            if not (R & b):
                continue
            if succ[i] & R:
                continue          # something must come after i: i is not last
            budget[0] -= 1
            if budget[0] < 0:
                raise _BudgetExceeded()
            wm = twrite[i]
            m = wm & ~settled
            ok = True
            if m:
                eff = teff[i]
                fk = final_state
                kk = m
                while kk:
                    lb = kk & (-kk)
                    k = lb.bit_length() - 1
                    kk ^= lb
                    if eff.get(k) != fk[k]:
                        ok = False
                        break
            if not ok:
                continue
            sub = _csp_search(R & ~b, settled | wm, memoR)
            if sub is not False:
                res = sub + [i]
                break
        memoR[R] = res
        return res

    # ------------------------------------------------------------------
    # main search
    # ------------------------------------------------------------------
    memo = {}

    def dfs(mask, state):
        if mask == full:
            return state == final_state
        key = (mask, state)
        r = memo.get(key)
        if r is not None:
            return r
        infeasible, nowriter = mask_info(mask)
        if infeasible:
            memo[key] = False
            return False
        fstate = final_state
        for k in nowriter:
            if state[k] != fstate[k]:
                memo[key] = False
                return False
        cst, cord = csp(mask)
        if cst is False:
            memo[key] = False
            return False
        rem = full & ~mask
        if cst is True and (rem & always_bits) == rem:
            # every remaining transaction always succeeds with a fixed
            # effect: the relaxed order is an exact completion.
            memo[key] = True
            return True
        cands = eligible(mask)
        if cord and cst is True:
            f = cord[0]
            if f in cands and f != cands[0]:
                cands = (f,) + tuple(i for i in cands if i != f)
        for i in cands:
            s2 = apply_tx(i, state)
            if s2 is None:
                continue
            if dfs(mask | (1 << i), s2):
                memo[key] = True
                return True
        memo[key] = False
        return False

    if not dfs(0, init_state):
        return None

    # ------------------------------------------------------------------
    # reconstruct a concrete witness (all lookups hit the memo)
    # ------------------------------------------------------------------
    order = []
    mask = 0
    state = init_state
    while mask != full:
        rem = full & ~mask
        if (rem & always_bits) == rem:
            cst, cord = csp(mask)
            if cst is True:
                order.extend(cord)
                break
        advanced = False
        for i in eligible(mask):
            s2 = apply_tx(i, state)
            if s2 is None:
                continue
            if dfs(mask | (1 << i), s2):
                order.append(i)
                mask |= 1 << i
                state = s2
                advanced = True
                break
        if not advanced:
            return None        # unreachable, defensive
    return [ids[i] for i in order]


def main():
    out = []
    data = sys.stdin.buffer.read().decode("utf-8", "replace")
    for line in data.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except Exception:
            out.append({"order": None})
            continue
        try:
            order = solve_request(req)
        except Exception:
            import traceback
            traceback.print_exc(file=sys.stderr)
            order = None
        out.append({"order": order})
    if out:
        sys.stdout.write("\n".join(json.dumps(o) for o in out) + "\n")


if __name__ == "__main__":
    main()
