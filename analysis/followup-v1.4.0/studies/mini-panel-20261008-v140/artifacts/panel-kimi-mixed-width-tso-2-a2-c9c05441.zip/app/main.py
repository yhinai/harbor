import json
import sys


def enumerate_outcomes(request):
    initial_memory = tuple(request["memory"])
    programs = [tuple(tuple(ins) for ins in thread) for thread in request["threads"]]
    n = len(programs)

    # State: (shared memory bytes, program counters, per-thread FIFO store
    # buffers of (address, width, value), per-thread observation lists).
    start = (initial_memory, (0,) * n, ((),) * n, ((),) * n)

    outcomes = set()
    seen = {start}
    stack = [start]

    while stack:
        memory, pcs, buffers, observations = stack.pop()

        if all(pcs[t] == len(programs[t]) and not buffers[t] for t in range(n)):
            outcomes.add((observations, memory))
            continue

        for t in range(n):
            # Transition 1: execute the thread's next instruction.
            if pcs[t] < len(programs[t]):
                ins = programs[t][pcs[t]]
                op = ins[0]
                next_pcs = pcs[:t] + (pcs[t] + 1,) + pcs[t + 1:]

                if op == "store":
                    _, addr, width, value = ins
                    entry = (addr, width, value)
                    next_buffers = buffers[:t] + (buffers[t] + (entry,),) + buffers[t + 1:]
                    nxt = (memory, next_pcs, next_buffers, observations)
                    if nxt not in seen:
                        seen.add(nxt)
                        stack.append(nxt)

                elif op == "load":
                    _, addr, width = ins
                    value = 0
                    for i in range(width):
                        b = addr + i
                        byte = memory[b]
                        # Youngest buffered store of this thread covering the byte wins.
                        for saddr, swidth, svalue in reversed(buffers[t]):
                            if saddr <= b < saddr + swidth:
                                byte = (svalue >> (8 * (b - saddr))) & 0xFF
                                break
                        value |= byte << (8 * i)
                    next_obs = observations[:t] + (observations[t] + (value,),) + observations[t + 1:]
                    nxt = (memory, next_pcs, buffers, next_obs)
                    if nxt not in seen:
                        seen.add(nxt)
                        stack.append(nxt)

                elif op == "fence":
                    if not buffers[t]:
                        nxt = (memory, next_pcs, buffers, observations)
                        if nxt not in seen:
                            seen.add(nxt)
                            stack.append(nxt)

                elif op == "xchg":
                    _, addr, width, value = ins
                    if not buffers[t]:
                        old = 0
                        new_memory = list(memory)
                        for i in range(width):
                            old |= memory[addr + i] << (8 * i)
                            new_memory[addr + i] = (value >> (8 * i)) & 0xFF
                        next_obs = observations[:t] + (observations[t] + (old,),) + observations[t + 1:]
                        nxt = (tuple(new_memory), next_pcs, buffers, next_obs)
                        if nxt not in seen:
                            seen.add(nxt)
                            stack.append(nxt)

            # Transition 2: drain the oldest buffered store of this thread.
            if buffers[t]:
                saddr, swidth, svalue = buffers[t][0]
                new_memory = list(memory)
                for i in range(swidth):
                    new_memory[saddr + i] = (svalue >> (8 * i)) & 0xFF
                next_buffers = buffers[:t] + (buffers[t][1:],) + buffers[t + 1:]
                nxt = (tuple(new_memory), pcs, next_buffers, observations)
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)

    return {
        "outcomes": [
            {"reads": [list(o) for o in obs], "memory": list(mem)}
            for obs, mem in outcomes
        ]
    }


def main():
    results = []
    for line in sys.stdin:
        line = line.strip()
        if line:
            results.append(json.dumps(enumerate_outcomes(json.loads(line))))
    if results:
        sys.stdout.write("\n".join(results) + "\n")


if __name__ == "__main__":
    main()
