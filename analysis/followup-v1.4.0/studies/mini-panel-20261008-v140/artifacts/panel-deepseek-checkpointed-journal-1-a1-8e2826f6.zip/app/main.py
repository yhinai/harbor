#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin, writes one JSON response per
request to stdout.  See instruction.md for the format description.
"""

import json
import struct
import sys
import zlib

MAX_PAYLOAD = 4096

HEADER = struct.Struct("<IIBI")   # payload_length, sequence, kind, transaction_id
CRC = struct.Struct("<I")
PATCH_HEADER = struct.Struct("<HHH")  # page_index, byte_offset, byte_count

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def recover(pages_hex, checkpoint, log_hex):
    """Return the recovered image, valid prefix length and last valid sequence."""
    pages = [bytearray.fromhex(h) for h in pages_hex]
    page_sizes = [len(p) for p in pages]
    n_pages = len(pages)

    # A torn final nibble cannot form a byte; ignore it defensively.
    if len(log_hex) & 1:
        log_hex = log_hex[:-1]
    log = bytes.fromhex(log_hex)
    size = len(log)

    # Active incarnations: transaction id -> list of raw PATCH payloads, in
    # the order their (structurally valid) records appeared in the log.
    active = {}

    pos = 0                 # start of the next unvalidated record
    valid_bytes = 0         # end of the last structurally valid record
    last_seq = 0            # sequence of the last structurally valid record

    while size - pos >= HEADER.size:
        plen, seq, kind, txid = HEADER.unpack_from(log, pos)

        # Header / kind / transaction-id / sequence validity.  A record must
        # be structurally valid before it can have any semantic effect.
        if plen > MAX_PAYLOAD or kind < KIND_BEGIN or kind > KIND_ABORT:
            break
        if txid == 0 or seq <= last_seq:
            break

        payload_start = pos + HEADER.size
        record_end = payload_start + plen
        if record_end + CRC.size > size:       # incomplete / torn record
            break

        payload = log[payload_start:record_end]
        stored_crc = CRC.unpack_from(log, record_end)[0]
        if zlib.crc32(log[pos:record_end]) & 0xFFFFFFFF != stored_crc:
            break

        # Payload shape / bounds validity for the record's kind.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if plen != 0:
                break
        elif kind == KIND_PATCH:
            if plen < 7:                       # needs 6 header bytes + >=1 data
                break
            page_index, byte_offset, byte_count = PATCH_HEADER.unpack_from(payload, 0)
            if byte_count == 0 or plen != 6 + byte_count:
                break
            if page_index >= n_pages or byte_offset + byte_count > page_sizes[page_index]:
                break
        else:  # KIND_COMMIT
            if plen != 8:
                break

        # The record is structurally valid: extend the valid prefix.
        pos = record_end + CRC.size
        valid_bytes = pos
        last_seq = seq

        # Semantic effect (the same for records at/below the checkpoint).
        if kind == KIND_BEGIN:
            # Fresh incarnation, discarding any unfinished one.
            active[txid] = []
        elif kind == KIND_PATCH:
            staged = active.get(txid)
            if staged is not None:
                staged.append(payload)
        elif kind == KIND_COMMIT:
            staged = active.pop(txid, None)
            if staged is not None:
                patch_count, digest = struct.unpack("<II", payload)
                if (patch_count == len(staged)
                        and digest == zlib.crc32(b"".join(staged)) & 0xFFFFFFFF):
                    if seq > checkpoint:
                        for raw in staged:
                            page_index, byte_offset, byte_count = PATCH_HEADER.unpack_from(raw, 0)
                            pages[page_index][byte_offset:byte_offset + byte_count] = \
                                raw[6:6 + byte_count]
        else:  # KIND_ABORT
            active.pop(txid, None)

    return {
        "pages": [bytes(page).hex() for page in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def solve(request):
    """Process one request object and return one response object."""
    return recover(request["pages"], request["checkpoint"], request["log"])


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        result = solve(json.loads(line))
        out.write(json.dumps(result, separators=(",", ":")))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
