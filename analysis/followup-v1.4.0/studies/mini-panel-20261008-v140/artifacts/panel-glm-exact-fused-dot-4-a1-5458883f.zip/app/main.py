"""Exact fused dot product for a parameterized binary floating format.

Every multiplication and every accumulation is exact (integer arithmetic on
power-of-two scaled mantissas); only the final sum is rounded.
"""
import sys, json

_MODES = {'RNE': 0, 'RNA': 1, 'RTZ': 2, 'RUP': 3, 'RDN': 4}

# operand kinds
_NUM = 0      # finite nonzero: (-1)**sign * mantissa * 2**scale
_ZERO = 1     # signed zero
_INF = 2      # signed infinity
_QNAN = 3     # quiet NaN
_SNAN = 4     # signaling NaN

# decoded-operand caches, keyed by (ebits, fbits): hex pattern -> operand tuple
_caches = {}


def _decode(ebits, fbits, Eall, F, bias, pat):
    """Decode one hexadecimal bit pattern into (kind, sign, mantissa, scale)."""
    v = int(pat, 16)
    width = 1 + ebits + fbits
    if v >> width:                     # tolerate redundant leading digits
        v &= (1 << width) - 1
    e = (v >> fbits) & Eall
    s = (v >> (ebits + fbits)) & 1
    f = v & (F - 1)
    if e == Eall:
        if f == 0:
            return (_INF, s, 0, 0)
        if f >> (fbits - 1):           # top fraction bit set: quiet NaN
            return (_QNAN, s, 0, 0)
        return (_SNAN, s, 0, 0)
    if e:
        return (_NUM, s, F + f, e - bias - fbits)     # normal
    if f == 0:
        return (_ZERO, s, 0, 0)
    return (_NUM, s, f, 1 - bias - fbits)             # subnormal


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = _MODES[req['mode']]
    pairs = req['pairs']

    F = 1 << fbits
    Eall = (1 << ebits) - 1
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    w = ebits + fbits

    key = (ebits, fbits)
    cache = _caches.get(key)
    if cache is None:
        cache = _caches[key] = {}
    elif len(cache) > 100000:          # keep the cache bounded
        cache.clear()

    has_nan = False
    invalid = False
    pos_inf = False
    neg_inf = False

    mags = []                          # nonzero product mantissas
    exps = []                          # their power-of-two scales
    sgns = []                          # their signs
    nprod = 0                          # number of finite products
    all_neg_zero = True                # every product is a negative signed zero

    for pa, pb in pairs:
        A = cache.get(pa)
        if A is None:
            A = cache[pa] = _decode(ebits, fbits, Eall, F, bias, pa)
        B = cache.get(pb)
        if B is None:
            B = cache[pb] = _decode(ebits, fbits, Eall, F, bias, pb)
        ka, sa, ma, ea = A
        kb, sb, mb, eb = B

        if ka >= _QNAN or kb >= _QNAN:      # NaN operand: contributes nothing
            has_nan = True
            if ka == _SNAN or kb == _SNAN:
                invalid = True
            continue
        if ka == _INF or kb == _INF:        # infinity times finite or infinity
            if (ka == _INF and kb == _ZERO) or (kb == _INF and ka == _ZERO):
                invalid = True              # zero times infinity
            elif sa ^ sb:                   # infinite product
                neg_inf = True
            else:
                pos_inf = True
            continue

        # exact finite product
        nprod += 1
        sg = sa ^ sb                        # product zero sign: sign XOR
        mag = ma * mb
        if mag:
            mags.append(mag)
            exps.append(ea + eb)
            sgns.append(sg)
            all_neg_zero = False
        elif not sg:
            all_neg_zero = False

    # --- exceptional results ---------------------------------------------
    if pos_inf and neg_inf:             # both signs of infinite products
        invalid = True
    if has_nan or invalid:
        bits = (Eall << fbits) | (1 << (fbits - 1))       # canonical NaN
        return {'bits': format(bits, 'x'),
                'flags': ['invalid'] if invalid else []}
    if pos_inf or neg_inf:
        sign = 1 if neg_inf else 0
        bits = (sign << w) | (Eall << fbits)
        return {'bits': format(bits, 'x'), 'flags': []}

    # --- exact accumulation ----------------------------------------------
    if mags:
        E = min(exps)
        S = 0
        for i, mag in enumerate(mags):
            d = exps[i] - E
            m = mag << d if d else mag
            S = S - m if sgns[i] else S + m
    else:
        E = 0
        S = 0

    if S == 0:                       # exact zero
        # negative iff all products are negative signed zeros (and there is
        # at least one), or the rounding mode is RDN
        neg = (mode == 4) or (nprod > 0 and all_neg_zero)
        bits = (neg << w) if neg else 0
        return {'bits': format(bits, 'x'), 'flags': []}

    neg = 1 if S < 0 else 0
    A = -S if neg else S              # exact magnitude is A * 2**E

    # --- rounding of the final sum ----------------------------------------
    L = A.bit_length() - 1 + E        # floor(log2(x))
    qe = emin - fbits                 # quantum exponent
    lq = L - fbits
    if lq > qe:
        qe = lq
    shift = qe - E                    # x/q = A / 2**shift
    if shift <= 0:
        r = A << (-shift)             # exact multiple of the quantum
        inexact = False
    else:
        base = A >> shift
        rem = A - (base << shift)
        if rem:
            if mode == 0:             # RNE: ties to even significand
                half = 1 << (shift - 1)
                if rem > half or (rem == half and (base & 1)):
                    base += 1
            elif mode == 1:           # RNA: ties away from zero
                if rem << 1 >= (1 << shift):
                    base += 1
            elif mode == 2:           # RTZ: toward zero
                pass
            elif mode == 3:           # RUP: toward +inf
                if not neg:
                    base += 1
            else:                     # RDN: toward -inf
                if neg:
                    base += 1
            inexact = True
        else:
            inexact = False
        r = base

    # rounded magnitude, in units of 2**(emin-fbits)
    m = r << (qe - (emin - fbits))

    # --- overflow ---------------------------------------------------------
    if m >= (1 << (emax + bias + fbits)):     # magnitude >= 2**(emax+1)
        if (mode <= 1 or (mode == 3 and not neg) or (mode == 4 and neg)):
            bits = (neg << w) | (Eall << fbits)          # signed infinity
        else:
            bits = ((neg << w) | ((Eall - 1) << fbits) | (F - 1))  # max finite
        return {'bits': format(bits, 'x'), 'flags': ['overflow', 'inexact']}

    flags = []
    if inexact:
        flags.append('inexact')
        if m < F:                    # tininess after rounding
            flags.append('underflow')

    # --- encode -----------------------------------------------------------
    if m == 0:
        e = 0
        f = 0
    elif m < F:                      # subnormal (or zero) range
        e = 0
        f = m
    else:
        e = m.bit_length() - fbits
        f = (m >> (e - 1)) - F
    bits = (neg << w) | (e << fbits) | f
    return {'bits': format(bits, 'x'), 'flags': flags}


def main():
    out = []
    write = sys.stdout.write
    loads = json.loads
    for line in sys.stdin:
        if not line.strip():
            continue
        out.append(json.dumps(solve(loads(line))))
        if len(out) >= 512:
            write('\n'.join(out) + '\n')
            out.clear()
    if out:
        write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
