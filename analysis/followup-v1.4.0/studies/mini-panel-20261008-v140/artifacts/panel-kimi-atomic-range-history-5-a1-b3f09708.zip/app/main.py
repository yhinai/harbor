import json
import sys


def solve(request):
    """Return {"order": [...]} witness, {"order": []} for an empty valid
    history, or {"order": None} when no serial witness exists."""
    initial = request['initial']
    final = request['final']
    txs = request['transactions']
    n = len(txs)
    if n == 0:
        return {"order": [] if initial == final else None}

    # Real-time precedence: a.end <= b.start  =>  a must precede b.
    pred_mask = [0] * n
    for i in range(n):
        si = txs[i]['start']
        m = 0
        for j in range(n):
            if i != j and txs[j]['end'] <= si:
                m |= 1 << j
        pred_mask[i] = m

    ops_list = [t['ops'] for t in txs]

    def run(i, d):
        """Simulate transaction i on state d (a dict).  Return the new state
        dict, or None if some observation fails."""
        d = dict(d)
        get = d.get
        for op in ops_list[i]:
            tag = op[0]
            if tag == 'get':
                if get(op[1]) != op[2]:
                    return None
            elif tag == 'put':
                d[op[1]] = op[2]
            elif tag == 'del':
                d.pop(op[1], None)
            elif tag == 'cas':
                if get(op[1]) == op[2]:
                    if not op[4]:
                        return None
                    if op[3] is None:
                        d.pop(op[1], None)
                    else:
                        d[op[1]] = op[3]
                elif op[4]:
                    return None
            else:  # scan: [low, high) sorted [key, value] pairs
                low, high, want = op[1], op[2], op[3]
                if sorted([k, v] for k, v in d.items() if low <= k < high) != want:
                    return None
        return d

    full = (1 << n) - 1
    dead = set()          # (placed_mask, state) nodes fully explored w/o success
    order = []
    # Try earlier-starting transactions first to find witnesses quickly.
    cand = sorted(range(n), key=lambda i: (txs[i]['start'], txs[i]['end']))

    def dfs(mask, d):
        if mask == full:
            return d == final
        key = (mask, tuple(sorted(d.items())))
        if key in dead:
            return False
        for i in cand:
            bit = 1 << i
            if mask & bit or pred_mask[i] & ~mask:
                continue
            nd = run(i, d)
            if nd is None:
                continue
            order.append(i)
            if dfs(mask | bit, nd):
                return True
            order.pop()
        dead.add(key)
        return False

    if dfs(0, initial):
        ids = [t['id'] for t in txs]
        return {"order": [ids[i] for i in order]}
    return {"order": None}


if __name__ == '__main__':
    write = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if line:
            write(json.dumps(solve(json.loads(line))) + '\n')
    sys.stdout.flush()
