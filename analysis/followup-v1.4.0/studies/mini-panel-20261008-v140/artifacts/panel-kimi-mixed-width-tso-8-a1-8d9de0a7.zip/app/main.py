import json
import sys


def solve(request):
    mem0 = tuple(request["memory"])
    progs = [tuple(tuple(ins) for ins in prog) for prog in request["threads"]]
    n = len(progs)

    # State: (memory tuple, per-thread tuple of (pc, buffer tuple, observations tuple))
    init = (mem0, tuple((0, (), ()) for _ in range(n)))
    visited = {init}
    stack = [init]
    outcomes = set()

    while stack:
        mem, ts = stack.pop()
        terminal = True
        for i in range(n):
            pc, buf, obs = ts[i]
            prog = progs[i]

            # Transition 2: drain the oldest store of this thread's buffer.
            if buf:
                terminal = False
                sa, sw, sv = buf[0]
                m = list(mem)
                for k in range(sw):
                    m[sa + k] = (sv >> (8 * k)) & 0xFF
                ns = (tuple(m), ts[:i] + ((pc, buf[1:], obs),) + ts[i + 1:])
                if ns not in visited:
                    visited.add(ns)
                    stack.append(ns)

            # Transition 1: execute the next instruction of this thread.
            if pc < len(prog):
                terminal = False
                ins = prog[pc]
                op = ins[0]
                if op == "store":
                    nbuf = buf + ((ins[1], ins[2], ins[3]),)
                    ns = (mem, ts[:i] + ((pc + 1, nbuf, obs),) + ts[i + 1:])
                elif op == "load":
                    a, w = ins[1], ins[2]
                    val = 0
                    for k in range(w):
                        b = mem[a + k]
                        for sa, sw, sv in reversed(buf):
                            if sa <= a + k < sa + sw:
                                b = (sv >> (8 * (a + k - sa))) & 0xFF
                                break
                        val |= b << (8 * k)
                    ns = (mem, ts[:i] + ((pc + 1, buf, obs + (val,)),) + ts[i + 1:])
                elif op == "fence":
                    if buf:
                        continue
                    ns = (mem, ts[:i] + ((pc + 1, buf, obs),) + ts[i + 1:])
                else:  # xchg
                    if buf:
                        continue
                    a, w, v = ins[1], ins[2], ins[3]
                    old = 0
                    m = list(mem)
                    for k in range(w):
                        old |= m[a + k] << (8 * k)
                        m[a + k] = (v >> (8 * k)) & 0xFF
                    ns = (tuple(m), ts[:i] + ((pc + 1, buf, obs + (old,)),) + ts[i + 1:])
                if ns not in visited:
                    visited.add(ns)
                    stack.append(ns)

        if terminal:
            outcomes.add((tuple(t[2] for t in ts), mem))

    result = [
        {"reads": [list(o) for o in robs], "memory": list(m)}
        for (robs, m) in outcomes
    ]
    result.sort(key=lambda o: json.dumps(o, sort_keys=True))
    return {"outcomes": result}


if __name__ == "__main__":
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))) + "\n")
