#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

The journal is a sequence of records:
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32
with all integers unsigned little-endian and crc = zlib.crc32(header + payload).

Recovery replays only the structurally valid prefix of the log and applies only
complete, correctly sealed transactions whose COMMIT sequence is newer than the
supplied checkpoint.  Requests are newline-delimited JSON objects on stdin; one
JSON response is written per request line.
"""

import json
import struct
import sys
import zlib

HEADER_SIZE = 13
CRC_SIZE = 4
MAX_PAYLOAD = 4096
TAIL_SIZE = CRC_SIZE          # bytes following the payload

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4
KINDS = frozenset((KIND_BEGIN, KIND_PATCH, KIND_COMMIT, KIND_ABORT))

_HEADER = struct.Struct('<IIBI')      # payload_length, sequence, kind, transaction_id
_PATCH_HEAD = struct.Struct('<HHH')   # page_index, byte_offset, byte_count
_SEAL = struct.Struct('<II')          # patch_count, digest
unpack_header = _HEADER.unpack_from
unpack_patch = _PATCH_HEAD.unpack_from
unpack_seal = _SEAL.unpack_from
unpack_u32 = struct.Struct('<I').unpack_from
crc32 = zlib.crc32


def hex_to_bytes(text):
    """Decode a hex string into bytes; undecodable input yields b''."""
    if isinstance(text, (bytes, bytearray, memoryview)):
        return bytes(text)
    if not isinstance(text, str):
        return b''
    try:
        return bytes.fromhex(text)
    except ValueError:
        try:
            return bytes.fromhex(''.join(text.split()))
        except ValueError:
            return b''


def recover(pages, checkpoint, data):
    """Replay `data` onto `pages` (list of bytearrays); returns (valid_bytes, last_seq)."""
    total = len(data)
    npages = len(pages)
    view = memoryview(data)
    active = {}                      # transaction id -> [patch_count, digest, patches]
    pos = 0
    last_seq = 0

    while pos + HEADER_SIZE <= total:
        payload_len, seq, kind, txid = unpack_header(data, pos)

        # ---- header validation -------------------------------------------
        if payload_len > MAX_PAYLOAD:
            break
        if seq <= last_seq:            # sequences must be positive & increasing
            break
        if txid == 0:
            break
        if kind not in KINDS:
            break

        # ---- completeness and CRC ----------------------------------------
        body_start = pos + HEADER_SIZE
        end = body_start + payload_len + TAIL_SIZE
        if end > total:
            break                     # torn / truncated record
        # crc covers the contiguous 13-byte header followed by the payload
        stored_crc = unpack_u32(data, end - CRC_SIZE)[0]
        if crc32(view[pos:end - CRC_SIZE]) & 0xffffffff != stored_crc:
            break

        payload = data[body_start:end - CRC_SIZE]

        # ---- kind-specific payload shape / bounds ------------------------
        if kind == KIND_PATCH:
            if payload_len < 6:
                break
            page_index, byte_offset, byte_count = unpack_patch(payload, 0)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= npages:
                break
            page_len = len(pages[page_index])
            if byte_offset > page_len or byte_count > page_len - byte_offset:
                break
        elif kind == KIND_COMMIT:
            if payload_len != 8:
                break
        elif payload_len != 0:        # BEGIN / ABORT carry an empty payload
            break

        # ---- structurally valid: extend the prefix, then apply semantics --
        if kind == KIND_BEGIN:
            active[txid] = [0, 0, []]
        elif kind == KIND_PATCH:
            state = active.get(txid)
            if state is not None:
                state[0] += 1
                state[1] = crc32(payload, state[1]) & 0xffffffff
                state[2].append(payload)
        elif kind == KIND_COMMIT:
            state = active.pop(txid, None)
            if state is not None:
                patch_count, digest = unpack_seal(payload, 0)
                if (patch_count == state[0] and digest == state[1]
                        and seq > checkpoint):
                    for patch in state[2]:
                        page_index, byte_offset, byte_count = unpack_patch(patch, 0)
                        page = pages[page_index]
                        page[byte_offset:byte_offset + byte_count] = \
                            patch[6:6 + byte_count]
                # a mismatching seal (or a checkpointed COMMIT) still closes
                # the incarnation, dropping its staged patches
        else:                          # KIND_ABORT
            active.pop(txid, None)

        last_seq = seq
        pos = end

    return pos, last_seq


def solve(request):
    """Recover one request; returns the response object."""
    raw_pages = request.get('pages') or []
    pages = [bytearray(hex_to_bytes(page)) for page in raw_pages]

    checkpoint = request.get('checkpoint')
    if isinstance(checkpoint, bool) or not isinstance(checkpoint, (int, float)):
        checkpoint = 0

    data = hex_to_bytes(request.get('log'))
    valid_bytes, last_seq = recover(pages, checkpoint, data)

    return {
        'pages': [bytes(page).hex() for page in pages],
        'valid_bytes': valid_bytes,
        'last_seq': last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
