#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Request  : {"pages": [hex, ...], "checkpoint": int, "log": hex}
Response : {"pages": [hex, ...], "valid_bytes": int, "last_seq": int}

Record layout (all integers unsigned little-endian, no implicit padding):

    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32

with ``crc == zlib.crc32(header + payload) & 0xffffffff``.  Kinds:

    1 BEGIN  empty payload
    2 PATCH  page_index:u16 | byte_offset:u16 | byte_count:u16 | data[byte_count]
    3 COMMIT patch_count:u32 | digest:u32
    4 ABORT  empty payload

Recovery replays the longest structurally valid prefix of the log, maintaining
transaction state across the whole prefix (records at or below the checkpoint
included), and re-applies the staged patches of every transaction that was
closed by a correctly sealed COMMIT whose sequence is newer than the durable
checkpoint watermark.
"""

import json
import struct
import sys
import zlib

# Record header: payload_length, sequence, kind, transaction_id (13 bytes).
_HEADER = struct.Struct("<IIBI")
# Trailing CRC field.
_CRC = struct.Struct("<I")
# PATCH payload prefix: page_index, byte_offset, byte_count.
_PATCH = struct.Struct("<HHH")
# COMMIT payload: patch_count, digest.
_COMMIT = struct.Struct("<II")

_HEADER_SIZE = _HEADER.size      # 13
_CRC_SIZE = _CRC.size            # 4
_MAX_PAYLOAD = 4096

_BEGIN = 1
_PATCH_KIND = 2
_COMMIT_KIND = 3
_ABORT = 4


def _decode_pages(pages):
    """Authoritative durable checkpoint image, as mutable bytearrays."""
    decoded = []
    if isinstance(pages, (list, tuple)):
        for page in pages:
            if isinstance(page, str):
                text = page.strip()
                if text[:2].lower() == "0x":   # defensive; never sent
                    text = text[2:]
                decoded.append(bytearray(bytes.fromhex(text)))
            elif isinstance(page, (bytes, bytearray)):
                decoded.append(bytearray(page))
            else:
                decoded.append(bytearray())
    return decoded


def _decode_log(log):
    """Raw log bytes; hex case is immaterial."""
    if not log:
        return b""
    if isinstance(log, str):
        text = log.strip()
        if not text:
            return b""
        return bytes.fromhex(text)
    if isinstance(log, (bytes, bytearray, memoryview)):
        return bytes(log)
    return b""


def solve(request):
    """Replay one journal request and return the recovered state."""
    if not isinstance(request, dict):
        raise TypeError("request must be an object")

    pages = _decode_pages(request.get("pages"))
    page_sizes = [len(page) for page in pages]
    n_pages = len(pages)
    log = _decode_log(request.get("log"))

    checkpoint = request.get("checkpoint", 0)
    if type(checkpoint) is not int:          # bool/float/str: never sent
        checkpoint = int(checkpoint)

    total = len(log)
    view = memoryview(log)

    unpack_header = _HEADER.unpack_from
    unpack_crc = _CRC.unpack_from
    unpack_patch = _PATCH.unpack_from
    unpack_commit = _COMMIT.unpack_from
    crc32 = zlib.crc32

    # Active incarnations: transaction_id -> staged PATCH payloads (log order).
    staged = {}

    pos = 0        # Start of the record currently being validated.
    last_seq = 0   # Sequence of the last valid record (0 for an empty prefix).

    while pos + _HEADER_SIZE <= total:
        payload_len, seq, kind, txid = unpack_header(log, pos)

        # An oversized payload declaration is an invalid header; a record whose
        # payload or CRC is cut short is incomplete.  Both end the valid prefix
        # right here.
        if payload_len > _MAX_PAYLOAD:
            break
        body_end = pos + _HEADER_SIZE + payload_len
        end = body_end + _CRC_SIZE
        if end > total:
            break

        # The seal covers the fixed header plus the payload.
        if crc32(view[pos:body_end]) != unpack_crc(log, body_end)[0]:
            break
        # Sequence must be positive and strictly increasing (initial watermark
        # 0 therefore also rejects a zero sequence); the id must be positive.
        if seq <= last_seq or txid == 0 or kind < _BEGIN or kind > _ABORT:
            break

        # Payload shape validation -- structural, independent of activity.
        if kind == _PATCH_KIND:
            if payload_len < 7:                      # 6 fixed bytes + data
                break
            page_index, byte_offset, byte_count = unpack_patch(log, pos + _HEADER_SIZE)
            if byte_count == 0 or 6 + byte_count != payload_len:
                break
            if page_index >= n_pages:
                break
            if byte_offset + byte_count > page_sizes[page_index]:
                break
            incarnation = staged.get(txid)
            if incarnation is not None:              # inactive ids are ignored
                incarnation.append(log[pos + _HEADER_SIZE:body_end])
        elif kind == _COMMIT_KIND:
            if payload_len != 8:
                break
            # COMMIT always closes the active incarnation, if any.
            incarnation = staged.pop(txid, None)
            if incarnation is not None:
                patch_count, digest = unpack_commit(log, pos + _HEADER_SIZE)
                if patch_count == len(incarnation):
                    # Digest covers this incarnation's PATCH payloads in log
                    # order; the empty concatenation has CRC zero.
                    if crc32(b"".join(incarnation)) == digest and seq > checkpoint:
                        # Atomic application, in patch order.  A seal mismatch
                        # or an already-checkpointed COMMIT merely drops the
                        # incarnation and leaves the valid prefix intact.
                        for patch_payload in incarnation:
                            page_index, byte_offset, byte_count = unpack_patch(patch_payload, 0)
                            pages[page_index][
                                byte_offset:byte_offset + byte_count
                            ] = patch_payload[6:6 + byte_count]
        else:  # BEGIN or ABORT
            if payload_len != 0:
                break
            if kind == _BEGIN:
                # A fresh incarnation discards any unfinished one.
                staged[txid] = []
            else:
                staged.pop(txid, None)

        # The record was structurally valid and has been accounted for.
        last_seq = seq
        pos = end

    return {
        "pages": [bytes(page).hex() for page in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def _fallback(request):
    """Best-effort reply if an unforeseen input shape slips through."""
    try:
        pages = list(request.get("pages", []))
    except Exception:
        pages = []
    return {"pages": pages, "valid_bytes": 0, "last_seq": 0}


def main(stream=None, out=None):
    out = sys.stdout if out is None else out
    stream = sys.stdin if stream is None else stream
    for line in stream:
        if not line.strip():
            continue
        try:
            request = json.loads(line)
        except ValueError as exc:
            print("bad request line: %r" % (exc,), file=sys.stderr)
            request = {}
        try:
            response = solve(request)
        except Exception as exc:  # pragma: no cover - defensive only
            print("recovery error: %r" % (exc,), file=sys.stderr)
            response = _fallback(request)
        out.write(json.dumps(response))
        out.write("\n")
    try:
        out.flush()
    except Exception:
        pass


if __name__ == "__main__":
    main()
