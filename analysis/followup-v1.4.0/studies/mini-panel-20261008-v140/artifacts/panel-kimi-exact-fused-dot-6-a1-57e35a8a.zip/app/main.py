import json
import sys


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = req['mode']
    pairs = req['pairs']

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                # 2**fbits
    Eall = (1 << ebits) - 1       # all-ones exponent
    emin = 1 - bias
    emax = Eall - 1 - bias
    fmask = F - 1
    spos = ebits + fbits          # index of sign bit
    topf = F >> 1                 # top fraction bit (quiet bit)

    CANON_NAN = (Eall << fbits) | topf
    MAX_FIN = ((Eall - 1) << fbits) | fmask

    invalid = False
    any_nan = False
    inf_pos = False               # a positive infinite product exists
    inf_neg = False               # a negative infinite product exists

    prods = []                    # nonzero finite products: (sign, mantissa, exp2)
    any_product = False           # at least one finite (non-NaN, non-inf) pair
    all_neg_zero = True           # every product so far is a negative signed zero

    for pair in pairs:
        va = int(pair[0], 16)
        vb = int(pair[1], 16)
        sa = (va >> spos) & 1
        ea = (va >> fbits) & Eall
        fa = va & fmask
        sb = (vb >> spos) & 1
        eb = (vb >> fbits) & Eall
        fb = vb & fmask

        a_nan = ea == Eall and fa != 0
        b_nan = eb == Eall and fb != 0
        # signaling NaN: exponent all ones, nonzero fraction, top fraction bit 0
        if (a_nan and not (fa & topf)) or (b_nan and not (fb & topf)):
            invalid = True
        if a_nan or b_nan:
            any_nan = True
            continue

        a_inf = ea == Eall
        b_inf = eb == Eall
        a_zero = ea == 0 and fa == 0
        b_zero = eb == 0 and fb == 0

        if (a_inf and b_zero) or (b_inf and a_zero):
            invalid = True
            continue

        ps = sa ^ sb
        if a_inf or b_inf:
            if ps:
                inf_neg = True
            else:
                inf_pos = True
            continue

        # finite x finite
        any_product = True
        if ea == 0:
            Ma, Ea = fa, emin - fbits
        else:
            Ma, Ea = F + fa, ea - bias - fbits
        if eb == 0:
            Mb, Eb = fb, emin - fbits
        else:
            Mb, Eb = F + fb, eb - bias - fbits
        M = Ma * Mb
        if M == 0:
            if ps == 0:
                all_neg_zero = False
        else:
            all_neg_zero = False
            prods.append((ps, M, Ea + Eb))

    if inf_pos and inf_neg:
        invalid = True

    if any_nan or invalid:
        return {'bits': format(CANON_NAN, 'x'),
                'flags': ['invalid'] if invalid else []}

    if inf_pos or inf_neg:
        s = 1 if inf_neg else 0
        return {'bits': format((s << spos) | (Eall << fbits), 'x'), 'flags': []}

    # ---- exact finite sum ----
    total = 0
    cur_exp = 0
    for ps, M, E in prods:
        if E < cur_exp:
            total <<= (cur_exp - E)
            cur_exp = E
        term = M << (E - cur_exp)
        total = total - term if ps else total + term
    # exact sum == total * 2**cur_exp

    if total == 0:
        neg = (any_product and all_neg_zero) or mode == 'RDN'
        bits = (1 << spos) if neg else 0
        return {'bits': format(bits, 'x'), 'flags': []}

    s = 1 if total < 0 else 0
    num = -total if total < 0 else total     # x = num * 2**cur_exp, magnitude
    L = num.bit_length() - 1 + cur_exp       # floor(log2(x))
    q_exp = emin - fbits
    t = L - fbits
    if t > q_exp:
        q_exp = t                            # q = 2**q_exp
    shift = q_exp - cur_exp
    if shift >= 0:
        den = 1 << shift
        quo, rem = divmod(num, den)
    else:
        den = 1
        quo = num << (-shift)
        rem = 0

    inexact = rem != 0
    if rem:
        if mode == 'RNE':
            twice = rem << 1
            if twice > den or (twice == den and (quo & 1)):
                quo += 1
        elif mode == 'RNA':
            if (rem << 1) >= den:
                quo += 1
        elif mode == 'RUP':
            if s == 0:
                quo += 1
        elif mode == 'RDN':
            if s == 1:
                quo += 1
        # RTZ: truncate
    n = quo                                  # rounded magnitude y = n * 2**q_exp

    if n == 0:
        # nonzero x rounded to zero: keep exact sign; y=0 < 2**emin and inexact
        return {'bits': format(s << spos, 'x'),
                'flags': ['underflow', 'inexact']}

    Ly = n.bit_length() - 1 + q_exp          # floor(log2(y))

    if Ly >= emax + 1:
        # overflow: y >= 2**(emax+1)
        if mode in ('RNE', 'RNA') or (mode == 'RUP' and s == 0) or \
           (mode == 'RDN' and s == 1):
            bits = (s << spos) | (Eall << fbits)      # signed infinity
        else:
            bits = (s << spos) | MAX_FIN              # signed max finite
        return {'bits': format(bits, 'x'), 'flags': ['overflow', 'inexact']}

    if Ly >= emin:
        e = Ly + bias
        sig = n >> (n.bit_length() - 1 - fbits)       # exact; in [F, 2F]
        bits = (s << spos) | (e << fbits) | (sig - F)
    else:
        frac = n << (q_exp - (emin - fbits))          # exact; < F
        bits = (s << spos) | frac

    flags = []
    if inexact:
        if Ly < emin:
            flags.append('underflow')
        flags.append('inexact')
    return {'bits': format(bits, 'x'), 'flags': flags}


if __name__ == '__main__':
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write('\n')
