import json
import sys

sys.setrecursionlimit(100000)


def solve(request):
    initial = request['initial']
    final = request['final']
    txns = request['transactions']
    n = len(txns)
    if n == 0:
        return {"order": [] if initial == final else None}

    ids = [t['id'] for t in txns]
    ops_list = [t['ops'] for t in txns]

    # Precedence: if a.end <= b.start then a must precede b.
    # (Always acyclic: a.end <= b.start and b.end <= a.start would give
    #  a.start < a.end <= b.start < b.end <= a.start, a contradiction.)
    pred = [0] * n
    for i in range(n):
        si = txns[i]['start']
        m = 0
        for j in range(n):
            if txns[j]['end'] <= si:
                m |= 1 << j
        pred[i] = m

    full = (1 << n) - 1
    final_items = tuple(sorted(final.items()))

    def run(ops, st):
        # Execute one transaction atomically; return new state or None if an
        # observation fails.  Fully deterministic given the input state.
        d = dict(st)
        for op in ops:
            tag = op[0]
            if tag == 'get':
                if d.get(op[1]) != op[2]:
                    return None
            elif tag == 'put':
                d[op[1]] = op[2]
            elif tag == 'del':
                d.pop(op[1], None)
            elif tag == 'cas':
                ok = d.get(op[1]) == op[2]
                if ok != op[4]:
                    return None
                if ok:
                    nv = op[3]
                    if nv is None:
                        d.pop(op[1], None)
                    else:
                        d[op[1]] = nv
            else:  # scan
                lo = op[1]
                hi = op[2]
                got = sorted([[k, v] for k, v in d.items() if lo <= k < hi])
                if got != op[3]:
                    return None
        return d

    dead = set()
    order = []

    def search(mask, st):
        if mask == full:
            return tuple(sorted(st.items())) == final_items
        key = (mask, tuple(sorted(st.items())))
        if key in dead:
            return False
        for i in range(n):
            bit = 1 << i
            if mask & bit:
                continue
            if pred[i] & ~mask:
                continue  # an interval-predecessor is not yet placed
            ns = run(ops_list[i], st)
            if ns is None:
                continue
            order.append(i)
            if search(mask | bit, ns):
                return True
            order.pop()
        dead.add(key)
        return False

    if search(0, dict(initial)):
        return {"order": [ids[i] for i in order]}
    return {"order": None}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    if out:
        sys.stdout.write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
