#!/usr/bin/env python3
"""Enumerate all terminal observable outcomes of the mixed-width buffered machine.

State exploration over the full machine state (program counters, per-thread
FIFO store buffers, shared memory bytes, per-thread observation lists).
Every transition (instruction issue or buffer drain) is an explicit edge, so
the collected terminal states are exactly the finite complete executions.
"""
import json
import sys

sys.setrecursionlimit(10000)


def _bytes_of(value, width):
    """Little-endian byte list for an unsigned value of the given width."""
    return [(value >> (8 * i)) & 0xFF for i in range(width)]


def solve(request):
    mem0 = tuple(request['memory'])
    progs = [[tuple(ins) for ins in thread] for thread in request['threads']]
    nthreads = len(progs)
    lens = [len(p) for p in progs]
    done_pcs = tuple(lens)

    # state = (pcs, buffers, memory, observations)
    start = ((0,) * nthreads, ((),) * nthreads, mem0, ((),) * nthreads)
    seen = set()
    outcomes = set()
    stack = [start]

    while stack:
        state = stack.pop()
        if state in seen:
            continue
        seen.add(state)
        pcs, bufs, mem, obs = state

        terminal = True

        # --- transition 1: issue the next instruction of a thread ---
        for t in range(nthreads):
            pc = pcs[t]
            buf = bufs[t]
            if pc >= lens[t]:
                continue
            terminal = False
            ins = progs[t][pc]
            op = ins[0]

            if op == 'store':
                _, addr, width, value = ins
                nbuf = buf + ((addr, width, value),)
                nbufs = bufs[:t] + (nbuf,) + bufs[t + 1:]
                nstate = (pcs[:t] + (pc + 1,) + pcs[t + 1:], nbufs, mem, obs)
                if nstate not in seen:
                    stack.append(nstate)

            elif op == 'load':
                _, addr, width = ins
                val = 0
                for i in range(width):
                    a = addr + i
                    b = None
                    # youngest buffered store of this thread covering the byte
                    for s in reversed(buf):
                        if s[0] <= a < s[0] + s[1]:
                            b = (s[2] >> (8 * (a - s[0]))) & 0xFF
                            break
                    if b is None:
                        b = mem[a]
                    val |= b << (8 * i)
                nobs = obs[:t] + (obs[t] + (val,),) + obs[t + 1:]
                nstate = (pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs, mem, nobs)
                if nstate not in seen:
                    stack.append(nstate)

            elif op == 'fence':
                if buf:
                    continue  # not enabled while the buffer is non-empty
                nstate = (pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs, mem, obs)
                if nstate not in seen:
                    stack.append(nstate)

            elif op == 'xchg':
                if buf:
                    continue  # not enabled while the buffer is non-empty
                _, addr, width, value = ins
                old = 0
                for i in range(width):
                    old |= mem[addr + i] << (8 * i)
                nm = list(mem)
                vb = _bytes_of(value, width)
                for i in range(width):
                    nm[addr + i] = vb[i]
                nobs = obs[:t] + (obs[t] + (old,),) + obs[t + 1:]
                nstate = (pcs[:t] + (pc + 1,) + pcs[t + 1:], bufs,
                          tuple(nm), nobs)
                if nstate not in seen:
                    stack.append(nstate)
            else:
                raise ValueError('unknown instruction: %r' % (op,))

        # --- transition 2: drain the oldest store of a thread buffer ---
        for t in range(nthreads):
            buf = bufs[t]
            if not buf:
                continue
            addr, width, value = buf[0]
            nm = list(mem)
            vb = _bytes_of(value, width)
            for i in range(width):
                nm[addr + i] = vb[i]
            nbufs = bufs[:t] + (buf[1:],) + bufs[t + 1:]
            nstate = (pcs, nbufs, tuple(nm), obs)
            if nstate not in seen:
                stack.append(nstate)

        if terminal and pcs == done_pcs and all(not b for b in bufs):
            outcomes.add((obs, mem))

    result = []
    for obs, mem in outcomes:
        result.append({
            'reads': [list(o) for o in obs],
            'memory': list(mem),
        })
    return {'outcomes': result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
            response = solve(request)
        except Exception as exc:  # keep the batch alive on a bad request
            print('request failed: %r' % (exc,), file=sys.stderr)
            response = {'outcomes': []}
        out.write(json.dumps(response))
        out.write('\n')
        out.flush()


if __name__ == '__main__':
    main()
