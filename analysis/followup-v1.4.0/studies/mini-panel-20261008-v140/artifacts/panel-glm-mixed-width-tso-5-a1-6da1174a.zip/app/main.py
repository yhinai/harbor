#!/usr/bin/env python3
"""Exhaustively enumerate the terminal observable outcomes of a small
mixed-width buffered (TSO-like) teaching machine.

Model (all transitions atomic):
  * each thread has a program counter, a FIFO store buffer and an observation list
  * "store" appends the complete (addr, width, value) store to the issuing
    thread's buffer (memory unchanged)
  * "load" reads byte-wise: youngest buffered store of the *same* thread that
    covers the byte wins, otherwise shared memory; the assembled little-endian
    unsigned value is appended to that thread's observations
  * "fence" is enabled only with an empty own buffer
  * "xchg" is enabled only with an empty own buffer; it atomically reads the
    shared-memory value (appending it to the observations) and replaces those
    bytes with the supplied value
  * the oldest store of any non-empty buffer may drain to shared memory,
    all bytes becoming visible together

A state is terminal when every thread finished its instructions and every
buffer is empty.  We enumerate the set of distinct terminal observations.

Search: the transition graph is a DAG (every transition either advances a
program counter or removes a buffered store).  Buffers are fully determined by
(pc, #drained), so a "core" state is (memory, per-thread (pc, drained)).
Observation lists are write-only output, therefore the set of possible
*suffix* observations from a core state is independent of the past, and can be
memoised on the core state alone.
"""

import json
import sys


def _mask(value, width):
    """Value as an unsigned little-endian integer of the given byte width."""
    return int(value) & ((1 << (8 * width)) - 1)


def solve(request):
    mem0 = bytes(int(b) & 0xFF for b in request["memory"])
    programs = request["threads"]
    n = len(programs)

    # ---- per-thread precomputation -------------------------------------
    progs = []
    for prog in programs:
        ops = [tuple(op) for op in prog]
        length = len(ops)
        issued = [0] * (length + 1)      # stores among ops[:pc]
        count = 0
        for i, op in enumerate(ops):
            if op[0] == "store":
                count += 1
            issued[i + 1] = count
        stores = [(op[1], op[2], _mask(op[3], op[2]))
                  for op in ops if op[0] == "store"]
        payloads = [v.to_bytes(w, "little") for a, w, v in stores]
        progs.append((ops, issued, stores, payloads, length))

    nstores = [len(p[2]) for p in progs]
    empty_suffix = ((),) * n
    memo = {}

    def dfs(mem, ts):
        """ts: tuple of (pc, drained) per thread.

        Returns frozenset of (per-thread observation suffix, final memory).
        """
        key = (mem, ts)
        cached = memo.get(key)
        if cached is not None:
            return cached

        # terminal test: everybody finished, every buffer empty
        terminal = True
        for t in range(n):
            pc, dr = ts[t]
            if pc != progs[t][4] or dr != nstores[t]:
                terminal = False
                break
        if terminal:
            res = frozenset(((empty_suffix, mem),))
            memo[key] = res
            return res

        res = set()
        for t in range(n):
            pc, dr = ts[t]
            ops, issued, stores, payloads, length = progs[t]

            if pc < length:
                op = ops[pc]
                kind = op[0]
                nts = ts[:t] + ((pc + 1, dr),) + ts[t + 1:]
                if kind == "store":
                    res.update(dfs(mem, nts))
                elif kind == "load":
                    addr, width = op[1], op[2]
                    hi = issued[pc]           # stores currently buffered
                    val = 0
                    for i in range(width):
                        a = addr + i
                        b = None
                        # youngest (last appended) covering store wins
                        for j in range(hi - 1, dr - 1, -1):
                            sa, sw, sv = stores[j]
                            if sa <= a < sa + sw:
                                b = (sv >> (8 * (a - sa))) & 0xFF
                                break
                        if b is None:
                            b = mem[a]
                        val |= b << (8 * i)
                    for suf, fmem in dfs(mem, nts):
                        ns = list(suf)
                        ns[t] = (val,) + suf[t]
                        res.add((tuple(ns), fmem))
                elif kind == "fence":
                    if dr == issued[pc]:      # own buffer empty
                        res.update(dfs(mem, nts))
                elif kind == "xchg":
                    if dr == issued[pc]:      # own buffer empty
                        addr = op[1]
                        width = op[2]
                        val = _mask(op[3], width)
                        old = int.from_bytes(mem[addr:addr + width], "little")
                        new_bytes = val.to_bytes(width, "little")
                        nmem = mem[:addr] + new_bytes + mem[addr + width:]
                        for suf, fmem in dfs(nmem, nts):
                            ns = list(suf)
                            ns[t] = (old,) + suf[t]
                            res.add((tuple(ns), fmem))
                else:  # unknown opcode: ignore defensively
                    pass

            # drain the oldest store of this thread's buffer
            if dr < issued[pc]:
                sa, sw, _sv = stores[dr]
                nmem = mem[:sa] + payloads[dr] + mem[sa + sw:]
                res.update(dfs(nmem, ts[:t] + ((pc, dr + 1),) + ts[t + 1:]))

        res = frozenset(res)
        memo[key] = res
        return res

    root = dfs(mem0, tuple((0, 0) for _ in range(n)))
    outcomes = []
    for reads, fmem in root:
        outcomes.append({
            "reads": [list(r) for r in reads],
            "memory": list(fmem),
        })
    return {"outcomes": outcomes}


def main():
    sys.setrecursionlimit(100000)
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        sys.stdout.write(json.dumps(solve(request)) + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
