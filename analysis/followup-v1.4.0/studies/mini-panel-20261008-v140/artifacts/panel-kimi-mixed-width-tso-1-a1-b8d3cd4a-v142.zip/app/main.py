import json
import sys
from functools import lru_cache


def solve(request):
    mem0 = tuple(request["memory"])
    threads = request["threads"]
    n = len(threads)
    instrs = [tuple(tuple(ins) for ins in t) for t in threads]
    lens = tuple(len(t) for t in instrs)
    empty_obs = tuple(() for _ in range(n))
    pcs0 = tuple(0 for _ in range(n))
    bufs0 = tuple(() for _ in range(n))

    @lru_cache(maxsize=None)
    def rec(mem, pcs, bufs):
        """Return frozenset of (obs_suffix, final_mem) reachable from this state.

        obs_suffix is a tuple with one tuple of observed values per thread,
        covering only instructions executed from this state onward.
        """
        done = True
        for t in range(n):
            if pcs[t] < lens[t] or bufs[t]:
                done = False
                break
        if done:
            return frozenset({(empty_obs, mem)})

        results = set()
        for t in range(n):
            pc = pcs[t]
            buf = bufs[t]
            if pc < lens[t]:
                ins = instrs[t][pc]
                op = ins[0]
                npc = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                if op == "store":
                    nb = bufs[:t] + (buf + ((ins[1], ins[2], ins[3]),),) + bufs[t + 1:]
                    results.update(rec(mem, npc, nb))
                elif op == "load":
                    addr, width = ins[1], ins[2]
                    val = 0
                    for j in range(width):
                        a = addr + j
                        b = mem[a]
                        for sa, sw, sv in reversed(buf):
                            if sa <= a < sa + sw:
                                b = (sv >> (8 * (a - sa))) & 0xFF
                                break
                        val |= b << (8 * j)
                    for obs, m2 in rec(mem, npc, bufs):
                        results.add((obs[:t] + ((val,) + obs[t],) + obs[t + 1:], m2))
                elif op == "fence":
                    if not buf:
                        results.update(rec(mem, npc, bufs))
                elif op == "xchg":
                    if not buf:
                        addr, width, value = ins[1], ins[2], ins[3]
                        old = 0
                        nm = list(mem)
                        for j in range(width):
                            old |= mem[addr + j] << (8 * j)
                            nm[addr + j] = (value >> (8 * j)) & 0xFF
                        for obs, m2 in rec(tuple(nm), npc, bufs):
                            results.add((obs[:t] + ((old,) + obs[t],) + obs[t + 1:], m2))
            if buf:
                # Drain oldest store of thread t (possible even if t finished).
                sa, sw, sv = buf[0]
                nm = list(mem)
                for j in range(sw):
                    nm[sa + j] = (sv >> (8 * j)) & 0xFF
                nb = bufs[:t] + (buf[1:],) + bufs[t + 1:]
                results.update(rec(tuple(nm), pcs, nb))
        return frozenset(results)

    out = rec(mem0, pcs0, bufs0)
    return {
        "outcomes": [
            {"reads": [list(o) for o in obs], "memory": list(m)} for obs, m in out
        ]
    }


if __name__ == "__main__":
    for line in sys.stdin:
        line = line.strip()
        if line:
            print(json.dumps(solve(json.loads(line))))
