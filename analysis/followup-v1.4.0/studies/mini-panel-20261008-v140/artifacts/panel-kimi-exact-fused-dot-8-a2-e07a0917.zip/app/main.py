import json
import sys


def solve(request):
    ebits = request["ebits"]
    fbits = request["fbits"]
    mode = request["mode"]
    pairs = request["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    fmask = F - 1
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    smask = 1 << (ebits + fbits)
    mask = (smask << 1) - 1

    # Operand kinds
    ZERO, FIN, INF, NAN = 0, 1, 2, 3

    def decode(h):
        # returns (kind, sign, significand, exponent, is_snan)
        v = int(h, 16) & mask
        s = v >> (ebits + fbits)
        e = (v >> fbits) & Eall
        f = v & fmask
        if e == Eall:
            if f == 0:
                return (INF, s, 0, 0, False)
            # NaN: top fraction bit 1 -> quiet, 0 -> signaling
            return (NAN, s, 0, 0, (f >> (fbits - 1)) == 0)
        if e == 0:
            if f == 0:
                return (ZERO, s, 0, 0, False)
            return (FIN, s, f, emin - fbits, False)
        return (FIN, s, F + f, e - bias - fbits, False)

    any_nan = False
    any_snan = False
    zero_inf = False
    inf_signs = 0  # bit 0: positive infinite product seen; bit 1: negative
    products = []  # (sign, magnitude_int, exponent) for finite products; m == 0 for zero products

    for pair in pairs:
        a = decode(pair[0])
        b = decode(pair[1])
        for o in (a, b):
            if o[0] == NAN:
                any_nan = True
                if o[4]:
                    any_snan = True
        if a[0] == NAN or b[0] == NAN:
            # contributes nothing
            continue
        if a[0] == INF or b[0] == INF:
            if a[0] == ZERO or b[0] == ZERO:
                zero_inf = True
            else:
                inf_signs |= 1 << (a[1] ^ b[1])
            continue
        products.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    invalid = any_snan or zero_inf or (inf_signs == 3)
    if any_nan or invalid:
        bits = (Eall << fbits) | (1 << (fbits - 1))  # canonical NaN
        return {"bits": format(bits, "x"), "flags": ["invalid"] if invalid else []}

    if inf_signs:
        s = 1 if inf_signs == 2 else 0
        bits = (s << (ebits + fbits)) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # Exact sum of finite products: total * 2**E0
    nonzero = [(sgn, m, t) for (sgn, m, t) in products if m]
    if nonzero:
        E0 = min(t for _, _, t in nonzero)
        total = 0
        for sgn, m, t in nonzero:
            total += (-m if sgn else m) << (t - E0)
    else:
        E0 = 0
        total = 0

    if total == 0:
        neg = mode == "RDN" or (
            len(products) >= 1
            and all(m == 0 and sgn == 1 for sgn, m, t in products)
        )
        bits = (1 if neg else 0) << (ebits + fbits)
        return {"bits": format(bits, "x"), "flags": []}

    sign = 1 if total < 0 else 0
    a = -total if total < 0 else total
    L = a.bit_length() - 1 + E0
    k = emin - fbits
    if L - fbits > k:
        k = L - fbits
    sh = k - E0
    if sh <= 0:
        n = a << (-sh)
        rem = 0
    else:
        n = a >> sh
        rem = a & ((1 << sh) - 1)
        if rem:
            half = 1 << (sh - 1)
            if mode == "RNE":
                if rem > half or (rem == half and (n & 1)):
                    n += 1
            elif mode == "RNA":
                if rem >= half:
                    n += 1
            elif mode == "RUP":
                if sign == 0:
                    n += 1
            elif mode == "RDN":
                if sign == 1:
                    n += 1
            # RTZ: truncate
    inexact = rem != 0
    # y = n * 2**k

    if n and n.bit_length() - 1 + k > emax:
        # overflow
        away = (
            mode == "RNE"
            or mode == "RNA"
            or (mode == "RUP" and sign == 0)
            or (mode == "RDN" and sign == 1)
        )
        if away:
            bits = (sign << (ebits + fbits)) | (Eall << fbits)
        else:
            bits = (sign << (ebits + fbits)) | ((Eall - 1) << fbits) | fmask
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
        if n == 0 or n.bit_length() - 1 + k < emin:
            flags.append("underflow")
    if n == 0:
        bits = sign << (ebits + fbits)
    else:
        Ly = n.bit_length() - 1 + k
        if Ly < emin:
            bits = (sign << (ebits + fbits)) | n  # subnormal, e = 0, f = n
        else:
            e_field = Ly + bias
            f_field = (n >> (Ly - fbits - k)) - F
            bits = (sign << (ebits + fbits)) | (e_field << fbits) | f_field
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write("".join(s + "\n" for s in out))


if __name__ == "__main__":
    main()
