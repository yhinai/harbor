"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin, writes one JSON response
per input line to stdout.  See instruction.md for the format contract.
"""
import json
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_LEN = 13


def _crc32(data):
    return zlib.crc32(data) & 0xFFFFFFFF


def solve(request):
    pages = [bytearray.fromhex(p) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])
    n = len(log)

    # Active incarnation per transaction id: list of (page_index, byte_offset, payload).
    active = {}
    prev_seq = 0
    last_seq = 0
    valid_bytes = 0
    off = 0

    while off + HEADER_LEN <= n:
        start = off
        payload_length = int.from_bytes(log[off:off + 4], "little")
        seq = int.from_bytes(log[off + 4:off + 8], "little")
        kind = log[off + 8]
        txid = int.from_bytes(log[off + 9:off + 13], "little")

        # Structural validity of the fixed header.
        if payload_length > MAX_PAYLOAD:
            break
        end = start + HEADER_LEN + payload_length + 4
        if end > n:
            break  # torn/incomplete record
        payload = log[start + HEADER_LEN:start + HEADER_LEN + payload_length]
        stored_crc = int.from_bytes(log[start + HEADER_LEN + payload_length:end], "little")
        if _crc32(log[start:start + HEADER_LEN + payload_length]) != stored_crc:
            break
        if seq == 0 or seq <= prev_seq or txid == 0 or kind not in (1, 2, 3, 4):
            break

        # Structural validity of the payload shape / bounds.
        patch = None
        if kind == 1 or kind == 4:  # BEGIN / ABORT: empty payload
            if payload_length != 0:
                break
        elif kind == 2:  # PATCH
            if payload_length < 7:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            if page_index >= len(pages) or byte_offset + byte_count > len(pages[page_index]):
                break
            patch = (page_index, byte_offset, payload)
        else:  # COMMIT
            if payload_length != 8:
                break

        # The record is part of the valid prefix.
        off = end
        prev_seq = seq
        valid_bytes = off
        last_seq = seq

        # Semantic processing.
        if kind == 1:
            active[txid] = []
        elif kind == 2:
            if txid in active:
                active[txid].append(patch)
        elif kind == 3:
            patches = active.pop(txid, None)
            if patches is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                sealed = (patch_count == len(patches)
                          and digest == _crc32(b"".join(p[2] for p in patches)))
                if sealed and seq > checkpoint:
                    for page_index, byte_offset, p in patches:
                        data = p[6:]
                        pages[page_index][byte_offset:byte_offset + len(data)] = data
        else:  # ABORT
            active.pop(txid, None)

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        try:
            response = solve(request)
        except Exception:  # keep the process alive; malformed input is undefined
            try:
                fallback_pages = list(request.get("pages", []))
            except Exception:
                fallback_pages = []
            response = {"pages": fallback_pages, "valid_bytes": 0, "last_seq": 0}
        out.write(json.dumps(response))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
