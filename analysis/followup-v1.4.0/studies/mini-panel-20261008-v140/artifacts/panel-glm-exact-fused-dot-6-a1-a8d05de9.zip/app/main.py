"""Exact fused dot product for a parameterized binary floating-point format.

Every product and the whole accumulation are performed exactly with big
integers; only the final sum is rounded once, in the requested mode.

Bit layout (most to least significant): sign | exponent (ebits) | fraction
(fbits).
"""

import json
import sys

NEAREST = ('RNE', 'RNA')


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = str(req['mode']).upper()
    pairs = req['pairs']

    eall = (1 << ebits) - 1                 # all-ones exponent field
    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                          # 2**fbits
    sign_shift = ebits + fbits              # width of exponent+fraction
    mask = (1 << (sign_shift + 1)) - 1     # format bit width mask
    emin = 1 - bias                         # minimum normal exponent
    emax = eall - 1 - bias                  # maximum normal exponent
    top_frac = 1 << (fbits - 1)             # quiet bit inside the fraction

    # ------------------------------------------------------------ decode
    decoded = []
    for pair in pairs:
        va = int(pair[0], 16) & mask
        vb = int(pair[1], 16) & mask
        decoded.append((
            (va >> sign_shift) & 1, (va >> fbits) & eall, va & (F - 1),
            (vb >> sign_shift) & 1, (vb >> fbits) & eall, vb & (F - 1),
        ))

    # ---------------------------------------- inspect every operand
    has_nan = False
    invalid = False
    inf_sign = None            # sign of the (unique) infinite product, if any
    finite_pairs = []

    for sa, ea, fa, sb, eb, fb in decoded:
        nan_a = (ea == eall and fa != 0)
        nan_b = (eb == eall and fb != 0)
        if nan_a or nan_b:
            # a NaN operand: this pair yields no product at all
            has_nan = True
            if (nan_a and not (fa & top_frac)) or \
               (nan_b and not (fb & top_frac)):
                invalid = True              # signaling NaN
            continue
        if ea == eall or eb == eall:
            # infinity times zero, in either order
            if (ea == eall and eb == 0 and fb == 0) or \
               (eb == eall and ea == 0 and fa == 0):
                invalid = True
                continue
            s = sa ^ sb
            if inf_sign is None:
                inf_sign = s
            elif inf_sign != s:
                invalid = True              # +inf and -inf products
            continue
        finite_pairs.append((sa, ea, fa, sb, eb, fb))

    if has_nan or invalid:
        bits = (eall << fbits) | top_frac   # canonical NaN
        return {'bits': format(bits, 'x'),
                'flags': ['invalid'] if invalid else []}

    if inf_sign is not None:
        bits = (inf_sign << sign_shift) | (eall << fbits)
        return {'bits': format(bits, 'x'), 'flags': []}

    # ---------------------------------------- exact products, exact sum
    # a finite operand equals  m * 2**x  with m a non-negative integer
    coeffs = []                              # (sign, mantissa, exponent)
    all_zero_neg = True     # every product so far is a negative signed zero
    for sa, ea, fa, sb, eb, fb in finite_pairs:
        if ea == 0:
            ma, xa = fa, emin - fbits       # subnormal (or zero)
        else:
            ma, xa = F + fa, ea - bias - fbits
        if eb == 0:
            mb, xb = fb, emin - fbits
        else:
            mb, xb = F + fb, eb - bias - fbits

        s = sa ^ sb                         # sign of the product
        m = ma * mb
        if m:
            all_zero_neg = False
            coeffs.append((s, m, xa + xb))
        elif s == 0:
            all_zero_neg = False

    if not coeffs:                          # every product is (signed) zero
        neg = (len(pairs) > 0 and all_zero_neg) or mode == 'RDN'
        return {'bits': format(neg << sign_shift, 'x'), 'flags': []}

    min_e = min(c[2] for c in coeffs)
    total = 0
    for s, m, x in coeffs:
        v = m << (x - min_e)
        total = total - v if s else total + v

    if total == 0:                          # cancellation of non-zero terms
        return {'bits': format((mode == 'RDN') << sign_shift, 'x'), 'flags': []}

    sign = 1 if total < 0 else 0
    xmag = -total if total < 0 else total
    L = xmag.bit_length() - 1 + min_e       # floor(log2(exact magnitude))

    Q = emin - fbits                        # quantum exponent
    if L - fbits > Q:
        Q = L - fbits

    d = Q - min_e
    if d <= 0:                              # already an integral multiple
        n = xmag if d == 0 else xmag << (-d)
        rem = 0
    else:
        n = n0 = xmag >> d
        rem = xmag & ((1 << d) - 1)
        if rem:                             # not an exact multiple: round
            half = 1 << (d - 1)
            if mode == 'RNE':
                up = rem > half or (rem == half and (n0 & 1))
            elif mode == 'RNA':
                up = rem >= half
            elif mode == 'RTZ':
                up = False
            elif mode == 'RUP':
                up = (sign == 0)            # toward +inf
            elif mode == 'RDN':
                up = (sign == 1)            # toward -inf
            else:
                up = rem > half             # unknown mode: act like RNE
            if up:
                n = n0 + 1

    inexact = rem != 0

    def ge_pow2(k, qe, e):                  # k * 2**qe >= 2**e
        if k == 0:
            return False
        p = e - qe
        return k >= (1 << p) if p >= 0 else True

    if ge_pow2(n, Q, emax + 1):             # overflow
        away = (mode in NEAREST or
                (mode == 'RUP' and sign == 0) or
                (mode == 'RDN' and sign == 1))
        if away:
            bits = (sign << sign_shift) | (eall << fbits)
        else:
            bits = (sign << sign_shift) | ((eall - 1) << fbits) | (F - 1)
        return {'bits': format(bits, 'x'), 'flags': ['overflow', 'inexact']}

    flags = []
    if inexact:
        flags.append('inexact')
        if not ge_pow2(n, Q, emin):         # rounded magnitude below 2**emin
            flags.append('underflow')

    # ------------------------------------------------------ encode result
    if n == 0:
        e_field, frac = 0, 0
    elif ge_pow2(n, Q, emin):               # normal
        bl = n.bit_length()
        sh = fbits - bl + 1
        M = (n << sh) if sh > 0 else (n >> (-sh))   # significand in [F, 2F)
        frac = M - F
        e_field = bl - 1 + Q + bias
    else:                                   # subnormal: Q == emin - fbits
        e_field, frac = 0, n

    bits = (sign << sign_shift) | (e_field << fbits) | frac
    return {'bits': format(bits, 'x'), 'flags': flags}


def main():
    out = []
    for line in sys.stdin:
        if not line.strip():
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write(''.join(x + '\n' for x in out))


if __name__ == '__main__':
    main()
