#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Reads newline-delimited JSON requests on stdin and writes one JSON object per
line on stdout.  Each request describes an initial state, a final state and a
set of transactions (a transaction is one atomic operation).  We search for a
serial order of the transactions that respects the real-time precedence
(A.end <= B.start  =>  A before B), reproduces every observation and ends in
the final state, or report that none exists.
"""

import sys
import json
import operator
from bisect import bisect_left

DEBUG = False
STATS = {"nodes": 0, "states": 0, "relax_steps": 0}


def solve(req):
    initial = req.get("initial") or {}
    final = req.get("final") or {}
    txns = req.get("transactions") or []
    n = len(txns)

    # ---- key universe (lexicographically sorted) -------------------------
    keyset = set(initial) | set(final)
    for t in txns:
        for op in t["ops"]:
            if op[0] == "scan":
                keyset.add(op[1])
                keyset.add(op[2])
                for pair in op[3]:
                    keyset.add(pair[0])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    nk = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    def encode(d):
        return tuple(d.get(k) for k in keys)

    init_state = encode(initial)
    final_state = encode(final)

    if n == 0:
        return {"order": [] if init_state == final_state else None}

    # ---- parse operations into compact form ------------------------------
    # 0 get(j,exp) | 1 put(j,val) | 2 del(j)
    # 3 cas(j,old,new,exp_success) | 4 scan(lo,hi,pairs,expkeymask)
    txn_ops = []
    read_mask = [0] * n
    write_mask = [0] * n
    for i, t in enumerate(txns):
        ops = []
        rm = 0
        wm = 0
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                j = kidx[op[1]]
                ops.append((0, j, op[2]))
                rm |= 1 << j
            elif kind == "put":
                j = kidx[op[1]]
                ops.append((1, j, op[2]))
                wm |= 1 << j
            elif kind == "del":
                j = kidx[op[1]]
                ops.append((2, j))
                wm |= 1 << j
            elif kind == "cas":
                j = kidx[op[1]]
                ops.append((3, j, op[2], op[3], bool(op[4])))
                rm |= 1 << j
                wm |= 1 << j
            else:  # scan
                lo = bisect_left(keys, op[1])
                hi = bisect_left(keys, op[2])
                pairs = tuple((kidx[k], v) for k, v in op[3])
                em = 0
                for k, v in op[3]:
                    em |= 1 << kidx[k]
                ops.append((4, lo, hi, pairs, em))
                for j in range(lo, hi):
                    rm |= 1 << j
        txn_ops.append(ops)
        read_mask[i] = rm
        write_mask[i] = wm

    # ---- real-time precedence -------------------------------------------
    starts = [t["start"] for t in txns]
    ends = [t["end"] for t in txns]
    pred = [0] * n
    pred_succ = [0] * n
    for b in range(n):
        pm = 0
        for a in range(n):
            if a != b and ends[a] <= starts[b]:
                pm |= 1 << a
        pred[b] = pm
    for a in range(n):
        sm = 0
        for b in range(n):
            if a != b and ends[a] <= starts[b]:
                sm |= 1 << b
        pred_succ[a] = sm

    full = (1 << n) - 1
    full_key_mask = (1 << nk) - 1

    keymask = [0] * (1 << n)
    for R in range(1, 1 << n):
        lb = R & (-R)
        i = lb.bit_length() - 1
        keymask[R] = keymask[R ^ lb] | read_mask[i] | write_mask[i]

    # projection getters for memoisation keys
    proj_getter = []
    for R in range(1 << n):
        lst = [j for j in range(nk) if (keymask[R] >> j) & 1]
        if not lst:
            proj_getter.append(lambda st: ())
        elif len(lst) == 1:
            j = lst[0]
            proj_getter.append(lambda st, j=j: (st[j],))
        else:
            proj_getter.append(operator.itemgetter(*lst))

    # ---- write capabilities ---------------------------------------------
    writer_value = [dict() for _ in range(nk)]  # key -> value -> txn mask
    def_writer_mask = [0] * nk
    writes_by_key = [[] for _ in range(nk)]
    for i in range(n):
        bit = 1 << i
        for op in txn_ops[i]:
            c = op[0]
            if c == 1:
                j, v = op[1], op[2]
                writer_value[j][v] = writer_value[j].get(v, 0) | bit
                def_writer_mask[j] |= bit
                writes_by_key[j].append((i, v))
            elif c == 2:
                j = op[1]
                writer_value[j][None] = writer_value[j].get(None, 0) | bit
                def_writer_mask[j] |= bit
                writes_by_key[j].append((i, None))
            elif c == 3:
                j, v = op[1], op[3]
                writer_value[j][v] = writer_value[j].get(v, 0) | bit
                writes_by_key[j].append((i, v))

    # providers[j][v][t] = mask of writers w != t of value v to key j that
    # are not forced after t (t.end > w.start or overlapping)
    providers = [dict() for _ in range(nk)]
    for j in range(nk):
        d = providers[j]
        for (w, v) in writes_by_key[j]:
            arr = d.get(v)
            if arr is None:
                arr = [0] * n
                d[v] = arr
            for t in range(n):
                if t != w and not (ends[t] <= starts[w]):
                    arr[t] |= 1 << w

    valset = {None}
    for t in txns:
        for op in t["ops"]:
            if op[0] in ("get", "put"):
                valset.add(op[2])
            elif op[0] == "cas":
                valset.add(op[2])
                valset.add(op[3])
            elif op[0] == "scan":
                for pair in op[3]:
                    valset.add(pair[1])
    valset |= set(initial.values())
    valset |= set(final.values())
    code_of = {}
    for _i, _v in enumerate(sorted(v for v in valset if v is not None)):
        code_of[_v] = _i
    code_of[None] = len(code_of)

    def vcode(v):
        return code_of[v]

    # own_masks[t][p][j] = bitmask of values written by t before op p on key j
    own_masks = []
    for i in range(n):
        ops = txn_ops[i]
        per_pos = []
        cur = [0] * nk
        for p, op in enumerate(ops):
            per_pos.append(tuple(cur))
            c = op[0]
            if c == 1:
                cur[op[1]] |= 1 << vcode(op[2])
            elif c == 2:
                cur[op[1]] |= 1 << vcode(None)
            elif c == 3:
                cur[op[1]] |= 1 << vcode(op[3])
        own_masks.append(per_pos)

    # compact requirement lists used by txn_ok
    #  (0, j, exp, code, p) get
    #  (1, j, old, code, p) cas expecting success
    #  (2, j, old, code, p) cas expecting failure
    #  (3, pair_codes, absent_idx, p) scan
    txn_reqs = []
    for i in range(n):
        reqs = []
        for p, op in enumerate(txn_ops[i]):
            c = op[0]
            if c == 0:
                reqs.append((0, op[1], op[2], vcode(op[2]), p))
            elif c == 3:
                reqs.append(((1 if op[4] else 2), op[1], op[2], vcode(op[2]), p))
            elif c == 4:
                lo, hi, pairs, em = op[1], op[2], op[3], op[4]
                pc = tuple((k, v, vcode(v)) for (k, v) in pairs)
                absent = tuple(j for j in range(lo, hi) if not ((em >> j) & 1))
                reqs.append((3, pc, absent, p))
        txn_reqs.append(reqs)

    # positions of unconditional writes, for relaxed last-writer reasoning
    def_positions = [[] for _ in range(nk)]
    for i in range(n):
        for pos, op in enumerate(txn_ops[i]):
            if op[0] == 1 or op[0] == 2:
                def_positions[op[1]].append((i, pos))
    last_def_pos = []
    for j in range(nk):
        d = {}
        for (u, pos) in def_positions[j]:
            if pos > d.get(u, -1):
                d[u] = pos
        last_def_pos.append(d)

    # ops that can produce the final value of a key
    candidates = [[] for _ in range(nk)]
    for i in range(n):
        for pos, op in enumerate(txn_ops[i]):
            c = op[0]
            if c == 1:
                j = op[1]
                if op[2] == final_state[j]:
                    candidates[j].append((i, pos))
            elif c == 2:
                j = op[1]
                if final_state[j] is None:
                    candidates[j].append((i, pos))
            elif c == 3:
                j = op[1]
                if op[3] == final_state[j]:
                    candidates[j].append((i, pos))
    for j in range(nk):
        ld = last_def_pos[j]
        candidates[j] = [(u, pos) for (u, pos) in candidates[j]
                         if ld.get(u, -1) <= pos]

    providers_neq = [dict() for _ in range(nk)]

    def get_neq(j, old):
        d = providers_neq[j]
        arr = d.get(old)
        if arr is None:
            arr = [0] * n
            for v, src in providers[j].items():
                if v != old:
                    for t in range(n):
                        arr[t] |= src[t]
            d[old] = arr
        return arr

    relaxed_cache = {}

    def relaxed_ok(R, A):
        """Necessary condition: can the remaining transactions R still produce
        the final map if we ignore all reads and let CAS operations succeed or
        fail freely?  A is the bitmask of keys whose current value already
        equals the final value.  The chosen last writer of each key must come
        after every unconditional writer of that key; acyclicity of the
        resulting constraint graph is checked by backtracking."""
        ck = (R, A)
        v = relaxed_cache.get(ck)
        if v is not None:
            return v
        opts_by_key = []
        for j in range(nk):
            opts = []
            if ((A >> j) & 1) and (def_writer_mask[j] & R) == 0:
                opts.append(None)          # keep the current value
            for (u, pos) in candidates[j]:
                if (R >> u) & 1:
                    edges = 0
                    for (w, pw) in def_positions[j]:
                        if w != u and ((R >> w) & 1):
                            edges |= 1 << w
                    opts.append((u, edges))
            if not opts:
                relaxed_cache[ck] = False
                return False
            opts_by_key.append(opts)

        order = sorted(range(nk), key=lambda j: len(opts_by_key[j]))
        base_adj = [pred_succ[u] & R for u in range(n)]
        # transitive closure with reflexive bits
        reach = [(1 << u) | base_adj[u] for u in range(n)]
        for k in range(n):
            rk = reach[k]
            for u in range(n):
                if (reach[u] >> k) & 1:
                    reach[u] |= rk

        def bt(k):
            if DEBUG:
                STATS["relax_steps"] += 1
            if k == nk:
                return True
            j = order[k]
            for opt in opts_by_key[j]:
                if opt is None:
                    if bt(k + 1):
                        return True
                else:
                    u, edges = opt
                    if reach[u] & edges:
                        continue
                    saved = reach[:]
                    ru = reach[u]
                    for x in range(n):
                        if reach[x] & edges:
                            reach[x] |= ru
                    if bt(k + 1):
                        return True
                    reach[:] = saved
            return False

        ans = bt(0)
        relaxed_cache[ck] = ans
        return ans

    # ---- transaction execution ------------------------------------------
    def exec_txn(state, ops):
        s = list(state)
        for op in ops:
            c = op[0]
            if c == 0:
                if s[op[1]] != op[2]:
                    return None
            elif c == 1:
                s[op[1]] = op[2]
            elif c == 2:
                s[op[1]] = None
            elif c == 3:
                j = op[1]
                succ = (s[j] == op[2])
                if succ != op[4]:
                    return None
                if succ:
                    s[j] = op[3]
            else:
                lo, hi, pairs = op[1], op[2], op[3]
                pi = 0
                lp = len(pairs)
                for j in range(lo, hi):
                    v = s[j]
                    if v is not None:
                        if pi >= lp or pairs[pi][0] != j or pairs[pi][1] != v:
                            return None
                        pi += 1
                if pi != lp:
                    return None
        return tuple(s)

    # Necessary conditions for the remaining transactions R:
    #  * every read must be achievable at all (some remaining writer, not
    #    forced after t, can produce the needed value; or t itself can write it
    #    earlier inside its own operation sequence);
    #  * whenever a read has exactly one possible provider, that provider must
    #    precede t; if these forced precedences contain a cycle, no completion
    #    exists.
    def checks_ok(state, R):
        adj = [0] * n
        x = R
        while x:
            lb = x & -x
            t = lb.bit_length() - 1
            x ^= lb
            own = own_masks[t]
            for req in txn_reqs[t]:
                kind = req[0]
                if kind == 0:
                    _, j, exp, code, p = req
                    if state[j] != exp and not ((own[p][j] >> code) & 1):
                        arr = providers[j].get(exp)
                        P = 0 if arr is None else (arr[t] & R)
                        if not P:
                            return False
                        if not (P & (P - 1)):
                            adj[P.bit_length() - 1] |= 1 << t
                elif kind == 1:
                    _, j, old, code, p = req
                    if state[j] != old and not ((own[p][j] >> code) & 1):
                        arr = providers[j].get(old)
                        P = 0 if arr is None else (arr[t] & R)
                        if not P:
                            return False
                        if not (P & (P - 1)):
                            adj[P.bit_length() - 1] |= 1 << t
                elif kind == 2:
                    _, j, old, code, p = req
                    if state[j] == old and not (own[p][j] & ~(1 << code)):
                        P = get_neq(j, old)[t] & R
                        if not P:
                            return False
                        if not (P & (P - 1)):
                            adj[P.bit_length() - 1] |= 1 << t
                else:
                    _, pc, absent, p = req
                    for (k, v, code) in pc:
                        if state[k] != v and not ((own[p][k] >> code) & 1):
                            arr = providers[k].get(v)
                            P = 0 if arr is None else (arr[t] & R)
                            if not P:
                                return False
                            if not (P & (P - 1)):
                                adj[P.bit_length() - 1] |= 1 << t
                    for j in absent:
                        if state[j] is not None and not ((own[p][j] >> vcode(None)) & 1):
                            arr = providers[j].get(None)
                            P = 0 if arr is None else (arr[t] & R)
                            if not P:
                                return False
                            if not (P & (P - 1)):
                                adj[P.bit_length() - 1] |= 1 << t

        # cycle detection on the forced-precedence graph restricted to R
        indeg = [0] * n
        y = R
        while y:
            lb = y & -y
            u = lb.bit_length() - 1
            y ^= lb
            a = adj[u] & R
            while a:
                lb2 = a & -a
                v = lb2.bit_length() - 1
                a ^= lb2
                indeg[v] += 1
        stack = []
        y = R
        while y:
            lb = y & -y
            u = lb.bit_length() - 1
            y ^= lb
            if indeg[u] == 0:
                stack.append(u)
        cnt = 0
        while stack:
            u = stack.pop()
            cnt += 1
            a = adj[u] & R
            while a:
                lb2 = a & -a
                v = lb2.bit_length() - 1
                a ^= lb2
                indeg[v] -= 1
                if indeg[v] == 0:
                    stack.append(v)
        if cnt != bin(R).count("1"):
            return False
        return True

    # ---- depth-first search over serial orders ---------------------------
    failed = set()
    heur = sorted(range(n), key=lambda t: (starts[t], ends[t], t))

    def dfs(S, state):
        if DEBUG:
            STATS["nodes"] += 1
        R = full & ~S
        if R == 0:
            return [] if state == final_state else None
        km = keymask[R]

        key = (S, proj_getter[R](state))
        if key in failed:
            return None

        bad = 0
        for j in range(nk):
            if state[j] != final_state[j]:
                bad |= 1 << j
        if bad & (full_key_mask & ~km):
            return None
        b = bad & km
        while b:
            lb = b & -b
            j = lb.bit_length() - 1
            b ^= lb
            if not (writer_value[j].get(final_state[j], 0) & R):
                return None

        if not checks_ok(state, R):
            return None

        if not relaxed_ok(R, full_key_mask & ~bad):
            return None

        for t in heur:
            if ((R >> t) & 1) and (pred[t] & R) == 0:
                ns = exec_txn(state, txn_ops[t])
                if ns is None:
                    continue
                res = dfs(S | (1 << t), ns)
                if res is not None:
                    return [t] + res

        if DEBUG:
            STATS["states"] += 1
        failed.add(key)
        return None

    order = dfs(0, init_state)
    if order is None:
        return {"order": None}
    return {"order": [txns[i]["id"] for i in order]}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        try:
            res = solve(req)
        except Exception as exc:  # pragma: no cover - safety net
            print("error: %r" % (exc,), file=sys.stderr)
            res = {"order": None}
        out.write(json.dumps(res))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
