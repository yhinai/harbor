import json
import sys


def _hexstr(bits, width):
    ndigits = (width + 3) // 4
    return format(bits, '0{}x'.format(ndigits))


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"].upper()
    pairs = req["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    width = 1 + ebits + fbits
    sign_shift = ebits + fbits
    emin = 1 - bias
    emax = Eall - 1 - bias
    fmask = F - 1
    top_frac = 1 << (fbits - 1)
    canonical_nan_bits = (Eall << fbits) | top_frac

    invalid = False
    any_nan = False
    inf_signs = set()
    terms = []      # (mantissa, binary exponent, sign) with value = (-1)^sign * mant * 2^exp
    products = []   # (is_zero, sign) for every finite product

    for pair in pairs:
        v1 = int(pair[0], 16)
        v2 = int(pair[1], 16)
        s1 = (v1 >> sign_shift) & 1
        e1 = (v1 >> fbits) & Eall
        f1 = v1 & fmask
        s2 = (v2 >> sign_shift) & 1
        e2 = (v2 >> fbits) & Eall
        f2 = v2 & fmask

        nan1 = (e1 == Eall and f1 != 0)
        nan2 = (e2 == Eall and f2 != 0)
        if nan1 and ((f1 >> (fbits - 1)) & 1) == 0:
            invalid = True
        if nan2 and ((f2 >> (fbits - 1)) & 1) == 0:
            invalid = True
        if nan1 or nan2:
            any_nan = True
            continue

        inf1 = (e1 == Eall)
        inf2 = (e2 == Eall)
        zero1 = (e1 == 0 and f1 == 0)
        zero2 = (e2 == 0 and f2 == 0)
        sign = s1 ^ s2

        if (zero1 and inf2) or (inf1 and zero2):
            invalid = True
            continue

        if inf1 or inf2:
            inf_signs.add(sign)
            continue

        if zero1 or zero2:
            products.append((True, sign))
            continue

        if e1 == 0:
            m1 = f1
            k1 = emin - fbits
        else:
            m1 = F + f1
            k1 = e1 - bias - fbits
        if e2 == 0:
            m2 = f2
            k2 = emin - fbits
        else:
            m2 = F + f2
            k2 = e2 - bias - fbits
        products.append((False, sign))
        terms.append((m1 * m2, k1 + k2, sign))

    if len(inf_signs) > 1:
        invalid = True

    if any_nan or invalid:
        return {"bits": _hexstr(canonical_nan_bits, width),
                "flags": ["invalid"] if invalid else []}

    if inf_signs:
        s = 1 if 1 in inf_signs else 0
        bits = (s << sign_shift) | (Eall << fbits)
        return {"bits": _hexstr(bits, width), "flags": []}

    # Exact sum of all finite products: acc_m * 2**acc_k.
    acc_m = 0
    acc_k = 0
    for (m, k, sg) in terms:
        val = m if sg == 0 else -m
        if acc_m == 0:
            acc_m = val
            acc_k = k
        elif k == acc_k:
            acc_m += val
        elif k < acc_k:
            acc_m = (acc_m << (acc_k - k)) + val
            acc_k = k
        else:
            acc_m += val << (k - acc_k)

    if acc_m == 0:
        neg = (mode == "RDN") or (len(products) > 0 and
                                  all(z and sg == 1 for (z, sg) in products))
        bits = (1 << sign_shift) if neg else 0
        return {"bits": _hexstr(bits, width), "flags": []}

    sign = 1 if acc_m < 0 else 0
    A = -acc_m if acc_m < 0 else acc_m
    E = acc_k
    L = (A.bit_length() - 1) + E
    qe = max(emin, L) - fbits
    shift = E - qe

    exact = True
    if shift >= 0:
        n = A << shift
    else:
        d = -shift
        qq, rr = divmod(A, 1 << d)
        if rr == 0:
            n = qq
        else:
            exact = False
            twice = rr << 1
            den = 1 << d
            if mode == "RNE":
                if twice > den or (twice == den and (qq & 1) == 1):
                    n = qq + 1
                else:
                    n = qq
            elif mode == "RNA":
                n = qq + 1 if twice >= den else qq
            elif mode == "RTZ":
                n = qq
            elif mode == "RUP":
                n = qq if sign else qq + 1
            elif mode == "RDN":
                n = qq + 1 if sign else qq
            else:
                raise ValueError("unknown rounding mode: " + str(mode))

    K = emax + 1
    if qe >= K:
        overflow = n > 0
    else:
        overflow = n >= (1 << (K - qe))

    if overflow:
        away = (mode in ("RNE", "RNA")
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1))
        if away:
            bits = (sign << sign_shift) | (Eall << fbits)
        else:
            bits = (sign << sign_shift) | ((Eall - 1) << fbits) | fmask
        return {"bits": _hexstr(bits, width), "flags": ["overflow", "inexact"]}

    flags = []
    if not exact:
        flags.append("inexact")
    below = False
    if qe < emin:
        below = n < (1 << (emin - qe))
    if below and not exact:
        flags.append("underflow")

    if n == 0:
        bits = sign << sign_shift
    elif below:
        # y < 2**emin, so qe == emin - fbits and 0 < n < F
        bits = (sign << sign_shift) | n
    else:
        sig_shift = fbits - (n.bit_length() - 1)
        if sig_shift >= 0:
            f_int = n << sig_shift
        else:
            f_int = n >> (-sig_shift)
        Ey = (n.bit_length() - 1) + qe
        e_stored = Ey + bias
        bits = (sign << sign_shift) | (e_stored << fbits) | (f_int - F)
    return {"bits": _hexstr(bits, width), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req), separators=(",", ":")))
        out.write("\n")
        out.flush()
    out.flush()


if __name__ == "__main__":
    main()
