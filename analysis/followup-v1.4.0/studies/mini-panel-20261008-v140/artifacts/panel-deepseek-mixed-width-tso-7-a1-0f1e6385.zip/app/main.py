import json
import sys
from collections import defaultdict


def _load_value(mem, buf, addr, width):
    """Value observed by a load: per byte, the youngest buffered store wins."""
    v = (mem >> (8 * addr)) & ((1 << (8 * width)) - 1)
    for sa, sw, sv in buf:  # oldest first; younger stores overwrite
        lo = sa if sa > addr else addr
        hi = sa + sw
        end = addr + width
        if hi > end:
            hi = end
        if lo < hi:
            for b in range(lo, hi):
                shift = 8 * (b - addr)
                byte = (sv >> (8 * (b - sa))) & 0xFF
                v = (v & ~(0xFF << shift)) | (byte << shift)
    return v


def _write_value(mem, addr, width, value):
    mask = ((1 << (8 * width)) - 1) << (8 * addr)
    return (mem & ~mask) | ((value & ((1 << (8 * width)) - 1)) << (8 * addr))


def solve(request):
    raw_mem = request["memory"]
    nbytes = len(raw_mem)
    init_mem = 0
    for i, b in enumerate(raw_mem):
        init_mem |= (b & 0xFF) << (8 * i)

    instrs = tuple(tuple(tuple(ins) for ins in th) for th in request["threads"])
    nthreads = len(instrs)

    # rem_instr[i][pc]: instructions left from pc on
    # rem_store[i][pc]: stores among those
    rem_instr = []
    rem_store = []
    for th in instrs:
        L = len(th)
        ri = [0] * (L + 1)
        rs = [0] * (L + 1)
        for pc in range(L - 1, -1, -1):
            ri[pc] = ri[pc + 1] + 1
            rs[pc] = rs[pc + 1] + (1 if th[pc][0] == "store" else 0)
        rem_instr.append(ri)
        rem_store.append(rs)

    def potential(ts):
        s = 0
        for i in range(nthreads):
            pc, buf = ts[i]
            s += rem_instr[i][pc] + rem_store[i][pc] + len(buf)
        return s

    def successors(mem, ts):
        res = []
        for i in range(nthreads):
            pc, buf = ts[i]
            th = instrs[i]
            if pc < len(th):
                ins = th[pc]
                op = ins[0]
                if op == "store":
                    nb = buf + ((ins[1], ins[2], ins[3]),)
                    res.append((mem, ts[:i] + ((pc + 1, nb),) + ts[i + 1:], None))
                elif op == "load":
                    val = _load_value(mem, buf, ins[1], ins[2])
                    res.append((mem, ts[:i] + ((pc + 1, buf),) + ts[i + 1:], (i, val)))
                elif op == "fence":
                    if not buf:
                        res.append((mem, ts[:i] + ((pc + 1, buf),) + ts[i + 1:], None))
                elif op == "xchg":
                    if not buf:
                        addr, width, value = ins[1], ins[2], ins[3]
                        old = (mem >> (8 * addr)) & ((1 << (8 * width)) - 1)
                        nm = _write_value(mem, addr, width, value)
                        res.append((nm, ts[:i] + ((pc + 1, buf),) + ts[i + 1:], (i, old)))
            if buf:
                sa, sw, sv = buf[0]
                nm = _write_value(mem, sa, sw, sv)
                res.append((nm, ts[:i] + ((pc, buf[1:]),) + ts[i + 1:], None))
        return res

    # A "core" is a machine state without the per-thread observation lists.
    # Transitions never depend on observations, so a core can be reached
    # with several observation prefixes; track all of them.  The potential
    # (remaining instructions + remaining stores + buffered stores) drops by
    # exactly one on every transition, so descending potential is a
    # topological order and no memo table of terminal outcomes is needed:
    # at potential zero a core is terminal and its prefix is a final outcome.
    start_ts = tuple((0, ()) for _ in range(nthreads))
    p0 = potential(start_ts)

    buckets = defaultdict(list)
    buckets[p0].append((init_mem, start_ts))
    registered = {(init_mem, start_ts)}
    empty_prefix = tuple(() for _ in range(nthreads))
    reach = {(init_mem, start_ts): {empty_prefix}}

    for p in range(p0, 0, -1):
        for core in buckets[p]:
            prefixes = reach.pop(core, None)
            if not prefixes:
                continue
            mem, ts = core
            for nm, nts, delta in successors(mem, ts):
                succ = (nm, nts)
                if succ not in registered:
                    registered.add(succ)
                    buckets[p - 1].append(succ)
                r = reach.get(succ)
                if r is None:
                    r = set()
                    reach[succ] = r
                if delta is None:
                    r.update(prefixes)
                else:
                    i, val = delta
                    for pref in prefixes:
                        r.add(pref[:i] + (pref[i] + (val,),) + pref[i + 1:])

    out = []
    for core in buckets[0]:
        mem = core[0]
        for reads in reach[core]:
            out.append({
                "reads": [list(r) for r in reads],
                "memory": [(mem >> (8 * i)) & 0xFF for i in range(nbytes)],
            })
    return {"outcomes": out}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))), flush=True)


if __name__ == "__main__":
    main()
