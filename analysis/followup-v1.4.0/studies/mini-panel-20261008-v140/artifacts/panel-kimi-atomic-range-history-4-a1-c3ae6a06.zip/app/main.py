import json
import sys


def _simulate(ops, state):
    """Apply one transaction atomically to `state` (dict key->int).

    Returns the new state dict, or None if any observation fails."""
    st = dict(state)
    for op in ops:
        kind = op[0]
        if kind == "get":
            if st.get(op[1]) != op[2]:
                return None
        elif kind == "put":
            st[op[1]] = op[2]
        elif kind == "del":
            st.pop(op[1], None)
        elif kind == "cas":
            ok = st.get(op[1]) == op[2]
            if ok is not op[4]:
                return None
            if ok:
                new = op[3]
                if new is None:
                    st.pop(op[1], None)
                else:
                    st[op[1]] = new
        elif kind == "scan":
            pairs = sorted([[k, v] for k, v in st.items() if op[1] <= k < op[2]])
            if pairs != [list(p) for p in op[3]]:
                return None
        else:
            return None
    return st


def _enc(state):
    return tuple(sorted(state.items()))


def solve(request):
    initial = request.get("initial") or {}
    final = request.get("final") or {}
    txns = request.get("transactions") or []
    n = len(txns)
    ids = [t["id"] for t in txns]

    # pred[i]: bitmask of transactions that must precede i (j.end <= i.start)
    pred = [0] * n
    for i in range(n):
        si = txns[i]["start"]
        m = 0
        for j in range(n):
            if i != j and txns[j]["end"] <= si:
                m |= 1 << j
        pred[i] = m

    ops_list = [t["ops"] for t in txns]

    sim_cache = {}

    def apply(i, enc_state):
        key = (i, enc_state)
        if key not in sim_cache:
            res = _simulate(ops_list[i], dict(enc_state))
            sim_cache[key] = None if res is None else _enc(res)
        return sim_cache[key]

    final_enc = _enc(final)
    full = (1 << n) - 1
    failed = set()
    order = []

    def dfs(mask, state_enc):
        if mask == full:
            return state_enc == final_enc
        for i in range(n):
            bit = 1 << i
            if mask & bit:
                continue
            if pred[i] & ~mask:
                continue
            ns = apply(i, state_enc)
            if ns is None:
                continue
            nm = mask | bit
            if (nm, ns) in failed:
                continue
            order.append(i)
            if dfs(nm, ns):
                return True
            order.pop()
            failed.add((nm, ns))
        return False

    if dfs(0, _enc(initial)):
        return {"order": [ids[i] for i in order]}
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            res = solve(json.loads(line))
        except Exception:
            res = {"order": None}
        out.write(json.dumps(res) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
