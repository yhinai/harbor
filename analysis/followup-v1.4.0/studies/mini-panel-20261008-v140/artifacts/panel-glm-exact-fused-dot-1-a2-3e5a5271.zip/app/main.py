#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating-point format.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per input line to stdout.  Every multiplication and the accumulation are
performed exactly (integer arithmetic); only the final sum is rounded.
"""

import json
import sys


def solve(req):
    ebits = int(req["ebits"])
    fbits = int(req["fbits"])
    mode = str(req["mode"]).strip().upper()
    pairs = req.get("pairs") or []

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                 # significand scale (2**fbits)
    Eall = (1 << ebits) - 1        # all-ones exponent field
    emin = 1 - bias
    emax = Eall - 1 - bias
    width = 1 + ebits + fbits
    mask = (1 << width) - 1
    fmask = F - 1                  # fraction field mask
    ftop = 1 << (fbits - 1)        # top fraction bit (quiet/sNaN selector)
    fshift = ebits + fbits         # exponent-field shift

    def encode(sign, efield, frac):
        return (sign << fshift) | (efield << fbits) | frac

    def as_hex(bits):
        digits = (width + 3) // 4
        return format(bits, "0{}x".format(digits)) if digits > 1 else format(bits, "x")

    # ---- decode every operand and classify each pair -------------------
    has_nan = False        # some operand is a NaN (quiet or signaling)
    invalid = False        # sNaN, 0*inf, or +/- infinite products
    inf_signs = set()      # signs of infinite products (NaN-free pairs)
    terms = []             # nonzero finite products: (neg, mantissa, exponent)
    zero_prods = []        # signs of zero products

    for pair in pairs:
        a = int(pair[0], 16) & mask
        b = int(pair[1], 16) & mask

        sa = (a >> fshift) & 1
        ea = (a >> fbits) & Eall
        fa = a & fmask
        sb = (b >> fshift) & 1
        eb = (b >> fbits) & Eall
        fb = b & fmask

        nan_a = (ea == Eall and fa != 0)
        nan_b = (eb == Eall and fb != 0)

        if nan_a or nan_b:
            # A NaN operand disables this pair for 0*inf / infinite products.
            has_nan = True
            if nan_a and not (fa & ftop):
                invalid = True
            if nan_b and not (fb & ftop):
                invalid = True
            continue

        inf_a = (ea == Eall)
        inf_b = (eb == Eall)
        zero_a = (ea == 0 and fa == 0)
        zero_b = (eb == 0 and fb == 0)
        sign = sa ^ sb

        if inf_a or inf_b:
            if (inf_a and zero_b) or (zero_a and inf_b):
                invalid = True          # zero times infinity, either order
                continue
            inf_signs.add(sign)        # infinite product
            continue

        # both operands finite (possibly signed zero)
        if zero_a or zero_b:
            zero_prods.append(sign)
            continue
        if ea == 0:
            ma, xa = fa, 1 - bias - fbits
        else:
            ma, xa = F + fa, ea - bias - fbits
        if eb == 0:
            mb, xb = fb, 1 - bias - fbits
        else:
            mb, xb = F + fb, eb - bias - fbits
        terms.append((bool(sign), ma * mb, xa + xb))

    if 0 in inf_signs and 1 in inf_signs:
        invalid = True                 # +inf and -inf products

    # ---- exceptional results -------------------------------------------
    if has_nan or invalid:
        flags = ["invalid"] if invalid else []
        return {"bits": as_hex(encode(0, Eall, ftop)), "flags": flags}

    if inf_signs:
        return {"bits": as_hex(encode(inf_signs.pop(), Eall, 0)), "flags": []}

    # ---- exact accumulation of finite products -------------------------
    if not terms:
        # exact zero: negative only for all-negative-zero products, or RDN
        neg = (mode == "RDN") or (bool(zero_prods) and all(s == 1 for s in zero_prods))
        return {"bits": as_hex(encode(1 if neg else 0, 0, 0)), "flags": []}

    exp_min = min(t[2] for t in terms)
    total = 0
    for neg, mant, exp in terms:
        v = mant << (exp - exp_min)
        total = total - v if neg else total + v

    if total == 0:
        # cancellation involving nonzero products: +0 (except RDN)
        neg = (mode == "RDN")
        return {"bits": as_hex(encode(1 if neg else 0, 0, 0)), "flags": []}

    neg = total < 0
    mag = -total if neg else total     # exact magnitude = mag * 2**exp_min

    # ---- rounding of the exact magnitude -------------------------------
    L = exp_min + (mag.bit_length() - 1)          # floor(log2(x))
    qexp = emin - fbits
    if L - fbits > qexp:
        qexp = L - fbits                          # quantum exponent
    d = qexp - exp_min                            # x/q = mag / 2**d

    if d <= 0:
        y = mag << (-d)                           # already on the grid
    else:
        lo = mag >> d
        rem = mag - (lo << d)
        half = 1 << (d - 1)
        if mode == "RNE":
            if rem > half:
                y = lo + 1
            elif rem < half:
                y = lo
            else:
                y = lo if (lo & 1) == 0 else lo + 1
        elif mode == "RNA":
            y = lo + 1 if rem >= half else lo
        elif mode == "RTZ":
            y = lo
        elif mode == "RUP":
            y = lo + 1 if (not neg and rem) else lo
        elif mode == "RDN":
            y = lo + 1 if (neg and rem) else lo
        else:
            raise ValueError("unknown rounding mode: %r" % (req.get("mode"),))

    inexact = (mag != (y << d)) if d > 0 else False

    if y == 0:
        # nonzero exact magnitude rounded to zero keeps its exact sign
        flags = ["inexact", "underflow"] if inexact else []
        return {"bits": as_hex(encode(1 if neg else 0, 0, 0)), "flags": flags}

    bl = y.bit_length() - 1
    eval_ = qexp + bl                              # floor(log2(rounded value))

    if eval_ >= emax + 1:                          # rounded magnitude >= 2**(emax+1)
        away = (mode in ("RNE", "RNA")
                or (mode == "RUP" and not neg)
                or (mode == "RDN" and neg))
        if away:
            bits = encode(1 if neg else 0, Eall, 0)             # infinity
        else:
            bits = encode(1 if neg else 0, Eall - 1, fmask)     # max finite
        return {"bits": as_hex(bits), "flags": ["overflow", "inexact"]}

    # ---- encode the rounded finite magnitude ---------------------------
    if eval_ < emin:
        efield = 0
        frac = y << (qexp - (emin - fbits))        # subnormal
    else:
        efield = eval_ + bias
        frac = ((y >> (bl - fbits)) if bl >= fbits else (y << (fbits - bl))) - F

    flags = []
    if inexact:
        flags.append("inexact")
        if eval_ < emin:                           # tininess after rounding
            flags.append("underflow")
    return {"bits": as_hex(encode(1 if neg else 0, efield, frac)), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            res = solve(json.loads(line))
        except Exception as exc:  # keep one response per input line
            print("error: %s" % exc, file=sys.stderr)
            res = {"bits": "0", "flags": []}
        out.write(json.dumps(res))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
