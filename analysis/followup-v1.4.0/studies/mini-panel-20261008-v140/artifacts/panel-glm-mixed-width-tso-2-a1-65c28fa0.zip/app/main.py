#!/usr/bin/env python3
"""Exhaustive enumeration of terminal observable outcomes for a small
mixed-width store-buffering (TSO-like) machine.

Machine summary
---------------
State:
  * shared memory: tuple of byte values
  * per thread: program counter, FIFO store buffer, observation list

Transitions (one per step, all atomic):
  1. execute the next instruction of any thread:
       store  -> append (addr,width,value) to that thread's buffer, advance pc
       load   -> per byte: youngest store in *that thread's* buffer covering
                 the byte wins, else shared memory; assemble little-endian,
                 append to observations, advance pc (never blocks)
       fence  -> enabled only when that thread's buffer is empty; advance pc
       xchg   -> enabled only when that thread's buffer is empty; atomically
                 read shared memory into observations and write the new value
  2. drain the oldest store of any nonempty buffer to shared memory
     (all bytes become visible together)

A state is terminal iff every thread finished its instructions and every
buffer is empty.  Every maximal execution is finite and ends terminal.

Enumeration strategy
--------------------
The buffer of a thread is always the sub-list store_list[drained:issued] of
that thread's program stores, hence a state is fully described by
    key = (memory, pcs, drained_counts)
and the future of a state depends only on its key.  Every transition strictly
increases the lexicographic measure (sum of pcs, -(total buffered stores)),
so the reachable state graph is a DAG.  We therefore expand keys in
increasing measure order (heap), merging the partial observation lists that
reach the same key; a key is expanded only after all of its predecessors have
been processed, which makes the merge exact and the enumeration complete.
"""

import heapq
import json
import sys


def _bytes_of(value, width):
    return (value & ((1 << (8 * width)) - 1)).to_bytes(width, "little")


def solve(request):
    memory0 = bytes(request["memory"])
    progs = []
    store_lists = []   # per thread: (addr, width, little-endian bytes) in program order
    store_cnt = []     # per thread: store_cnt[pc] = number of stores in prog[:pc]
    for program in request["threads"]:
        prog = [tuple(op) for op in program]
        progs.append(prog)
        stores = []
        cnt = [0] * (len(prog) + 1)
        issued = 0
        for k, op in enumerate(prog):
            cnt[k] = issued
            if op[0] == "store":
                stores.append((int(op[1]), int(op[2]), _bytes_of(int(op[3]), int(op[2]))))
                issued += 1
        cnt[len(prog)] = issued
        store_lists.append(stores)
        store_cnt.append(cnt)
    nthreads = len(progs)
    lengths = [len(p) for p in progs]

    def measure(key):
        _, pcs, ds = key
        buffered = 0
        for i in range(nthreads):
            buffered += store_cnt[i][pcs[i]] - ds[i]
        return (sum(pcs), -buffered)

    start = (memory0, (0,) * nthreads, (0,) * nthreads)
    prefixes = {start: {((),) * nthreads}}   # key -> set of partial observation tuples
    seen = {start}
    heap = [(measure(start), start)]
    processed = set()
    outcomes = set()

    while heap:
        _, key = heapq.heappop(heap)
        if key in processed:
            continue
        processed.add(key)
        mem, pcs, ds = key
        partials = prefixes.pop(key)
        trans = []   # (child_key, (thread, value) or None)
        finished = True
        for i in range(nthreads):
            pc = pcs[i]
            drained = ds[i]
            issued = store_cnt[i][pc]
            if issued > drained:                       # pending store -> drain
                finished = False
                addr, width, sbytes = store_lists[i][drained]
                nmem = mem[:addr] + sbytes + mem[addr + width:]
                trans.append(((nmem, pcs, ds[:i] + (drained + 1,) + ds[i + 1:]), None))
            if pc < lengths[i]:                        # pending instruction
                finished = False
                op = progs[i][pc]
                kind = op[0]
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                if kind == "store":
                    trans.append(((mem, npcs, ds), None))
                elif kind == "load":
                    addr = int(op[1])
                    width = int(op[2])
                    buf = store_lists[i][drained:issued]
                    nbuf = len(buf)
                    out = bytearray(width)
                    for off in range(width):
                        idx = addr + off
                        byte = mem[idx]
                        for j in range(nbuf - 1, -1, -1):   # youngest covering store wins
                            saddr, swidth, sbytes = buf[j]
                            if saddr <= idx < saddr + swidth:
                                byte = sbytes[idx - saddr]
                                break
                        out[off] = byte
                    trans.append(((mem, npcs, ds),
                                  (i, int.from_bytes(bytes(out), "little"))))
                elif kind == "fence":
                    if drained == issued:              # only with an empty buffer
                        trans.append(((mem, npcs, ds), None))
                elif kind == "xchg":
                    if drained == issued:              # only with an empty buffer
                        addr = int(op[1])
                        width = int(op[2])
                        current = int.from_bytes(mem[addr:addr + width], "little")
                        nmem = (mem[:addr] + _bytes_of(int(op[3]), width)
                                + mem[addr + width:])
                        trans.append(((nmem, npcs, ds), (i, current)))
                else:
                    raise ValueError("unknown instruction %r" % (kind,))

        if finished:                                   # all pcs done, all buffers empty
            for partial in partials:
                outcomes.add((partial, mem))
            continue

        for child, addition in trans:
            if child not in seen:
                seen.add(child)
                heapq.heappush(heap, (measure(child), child))
            target = prefixes.get(child)
            if target is None:
                target = set()
                prefixes[child] = target
            if addition is None:
                target.update(partials)
            else:
                i, value = addition
                for partial in partials:
                    target.add(partial[:i] + (partial[i] + (value,),) + partial[i + 1:])

    return {
        "outcomes": [
            {"reads": [list(t) for t in obs], "memory": list(mem)}
            for obs, mem in outcomes
        ]
    }


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        sys.stdout.write(json.dumps(solve(request)) + "\n")


if __name__ == "__main__":
    main()
