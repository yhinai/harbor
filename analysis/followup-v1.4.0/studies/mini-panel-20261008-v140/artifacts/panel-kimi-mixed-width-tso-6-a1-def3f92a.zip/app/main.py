import json
import sys
from functools import lru_cache

sys.setrecursionlimit(100000)


def solve(request):
    mem0 = tuple(request["memory"])
    progs = [tuple(tuple(ins) for ins in t) for t in request["threads"]]
    n = len(progs)

    # Abstract state: (memory tuple, program counters tuple, buffers tuple).
    # Each buffer is a tuple of (address, width, value) stores, FIFO.
    # go() returns the frozenset of (obs, final_memory) where obs is a tuple
    # of per-thread tuples of values observed from this state onward.
    @lru_cache(maxsize=None)
    def go(mem, pcs, bufs):
        results = set()
        terminal = True
        for t in range(n):
            pc = pcs[t]
            buf = bufs[t]
            prog = progs[t]
            if pc < len(prog):
                terminal = False
                ins = prog[pc]
                op = ins[0]
                npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                if op == "store":
                    nbufs = bufs[:t] + (buf + ((ins[1], ins[2], ins[3]),),) + bufs[t + 1:]
                    results.update(go(mem, npcs, nbufs))
                elif op == "load":
                    addr, width = ins[1], ins[2]
                    val = 0
                    for i in range(width):
                        a = addr + i
                        b = mem[a]
                        for sa, sw, sv in reversed(buf):
                            if sa <= a < sa + sw:
                                b = (sv >> (8 * (a - sa))) & 0xFF
                                break
                        val |= b << (8 * i)
                    for obs, m in go(mem, npcs, bufs):
                        results.add((obs[:t] + ((val,) + obs[t],) + obs[t + 1:], m))
                elif op == "fence":
                    if not buf:
                        results.update(go(mem, npcs, bufs))
                else:  # xchg
                    if not buf:
                        addr, width, sv = ins[1], ins[2], ins[3]
                        val = 0
                        for i in range(width):
                            val |= mem[addr + i] << (8 * i)
                        lst = list(mem)
                        for i in range(width):
                            lst[addr + i] = (sv >> (8 * i)) & 0xFF
                        for obs, m in go(tuple(lst), npcs, bufs):
                            results.add((obs[:t] + ((val,) + obs[t],) + obs[t + 1:], m))
            if buf:
                terminal = False
                sa, sw, sv = buf[0]
                lst = list(mem)
                for i in range(sw):
                    lst[sa + i] = (sv >> (8 * i)) & 0xFF
                nbufs = bufs[:t] + (buf[1:],) + bufs[t + 1:]
                results.update(go(tuple(lst), pcs, nbufs))
        if terminal:
            results.add((tuple(() for _ in range(n)), mem))
        return frozenset(results)

    init_pcs = tuple(0 for _ in range(n))
    init_bufs = tuple(() for _ in range(n))
    outcomes = [
        {"reads": [list(o) for o in obs], "memory": list(m)}
        for obs, m in go(mem0, init_pcs, init_bufs)
    ]
    return {"outcomes": outcomes}


if __name__ == "__main__":
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if line:
            out.write(json.dumps(solve(json.loads(line))))
            out.write("\n")
            out.flush()
