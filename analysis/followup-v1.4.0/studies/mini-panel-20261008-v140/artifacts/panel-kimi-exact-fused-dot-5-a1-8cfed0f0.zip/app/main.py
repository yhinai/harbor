import sys
import json

# kind codes
ZERO, FIN, INF, NAN = 0, 1, 2, 3
FLAG_ORDER = ("invalid", "overflow", "underflow", "inexact")


class Ctx:
    __slots__ = ("ebits", "fbits", "bias", "Eall", "emin", "emax",
                 "tbits", "fmask", "emask", "ftop", "F", "vmask", "sbit")

    def __init__(self, ebits, fbits):
        self.ebits = ebits
        self.fbits = fbits
        self.bias = (1 << (ebits - 1)) - 1
        self.Eall = (1 << ebits) - 1
        self.emin = 1 - self.bias
        self.emax = self.Eall - 1 - self.bias
        self.tbits = 1 + ebits + fbits
        self.fmask = (1 << fbits) - 1
        self.emask = (1 << ebits) - 1
        self.ftop = 1 << (fbits - 1)
        self.F = 1 << fbits
        self.vmask = (1 << self.tbits) - 1
        self.sbit = 1 << (ebits + fbits)


def decode(ctx, v):
    f = v & ctx.fmask
    e = (v >> ctx.fbits) & ctx.emask
    s = 1 if (v & ctx.sbit) else 0
    if e == ctx.Eall:
        if f == 0:
            return (INF, s)
        return (NAN, s, (f & ctx.ftop) == 0)
    if e == 0:
        if f == 0:
            return (ZERO, s, 0, 0)
        return (FIN, s, f, ctx.emin - ctx.fbits)  # subnormal: f * 2^(1-bias-fbits)
    return (FIN, s, ctx.F | f, e - ctx.bias - ctx.fbits)


def cmp_pow2(n, q_exp, p):
    # compare n * 2**q_exp  vs  2**p ; n >= 0 integer
    if n == 0:
        return -1
    k = p - q_exp
    if k >= 0:
        t = 1 << k
        if n < t:
            return -1
        if n > t:
            return 1
        return 0
    return 1


def solve(req):
    ctx = Ctx(req["ebits"], req["fbits"])
    mode = req["mode"]

    any_nan = False
    invalid = False
    inf_signs = 0  # bit0: a +inf product seen, bit1: a -inf product seen
    prods = []     # (sign, m, E) for finite pairs; m == 0 means zero product

    for pair in req["pairs"]:
        A = decode(ctx, int(pair[0], 16) & ctx.vmask)
        B = decode(ctx, int(pair[1], 16) & ctx.vmask)
        ka, kb = A[0], B[0]
        if ka == NAN or kb == NAN:
            any_nan = True
            if (ka == NAN and A[2]) or (kb == NAN and B[2]):
                invalid = True
            continue
        if ka == INF or kb == INF:
            other = B if ka == INF else A
            if other[0] == ZERO:
                invalid = True
            else:
                inf_signs |= (2 if (A[1] ^ B[1]) else 1)
            continue
        prods.append((A[1] ^ B[1], A[2] * B[2], A[3] + B[3]))

    if inf_signs == 3:
        invalid = True

    if any_nan or invalid:
        bits = (ctx.Eall << ctx.fbits) | ctx.ftop  # canonical NaN
        return {"bits": format(bits, "x"),
                "flags": ["invalid"] if invalid else []}

    if inf_signs:
        s = 1 if inf_signs == 2 else 0
        bits = (s << (ctx.ebits + ctx.fbits)) | (ctx.Eall << ctx.fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # ---- finite exact sum ----
    minE = None
    for s, m, E in prods:
        if m and (minE is None or E < minE):
            minE = E
    S = 0
    if minE is not None:
        for s, m, E in prods:
            if m:
                t = m << (E - minE)
                S = S - t if s else S + t

    if S == 0:
        neg = (mode == "RDN")
        if not neg and prods:
            neg = all(m == 0 and s == 1 for s, m, _ in prods)
        bits = ctx.sbit if neg else 0
        return {"bits": format(bits, "x"), "flags": []}

    sign = 1 if S < 0 else 0
    Sa = -S if S < 0 else S

    # ---- round ----
    L = Sa.bit_length() - 1 + minE
    q_exp = ctx.emin - ctx.fbits
    if L - ctx.fbits > q_exp:
        q_exp = L - ctx.fbits
    d = q_exp - minE
    inexact = False
    if d <= 0:
        n = Sa << (-d)
    else:
        n = Sa >> d
        rem = Sa - (n << d)
        if rem:
            inexact = True
            if mode == "RNE":
                half = 1 << (d - 1)
                up = rem > half or (rem == half and (n & 1))
            elif mode == "RNA":
                up = rem >= (1 << (d - 1))
            elif mode == "RTZ":
                up = False
            elif mode == "RUP":
                up = (sign == 0)
            else:  # RDN
                up = (sign == 1)
            if up:
                n += 1

    flags = set()
    # overflow check: y = n * 2^q_exp >= 2^(emax+1) ?
    if cmp_pow2(n, q_exp, ctx.emax + 1) >= 0:
        if (mode == "RNE" or mode == "RNA"
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1)):
            bits = (sign << (ctx.ebits + ctx.fbits)) | (ctx.Eall << ctx.fbits)
        else:
            bits = ((sign << (ctx.ebits + ctx.fbits))
                    | ((ctx.Eall - 1) << ctx.fbits) | ctx.fmask)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    # encode finite
    if n == 0:
        bits = sign << (ctx.ebits + ctx.fbits)
    else:
        Ly = n.bit_length() - 1 + q_exp
        if Ly >= ctx.emin:
            e = Ly + ctx.bias
            shift = n.bit_length() - 1 - ctx.fbits
            m = (n >> shift) if shift > 0 else (n << (-shift))
            bits = ((sign << (ctx.ebits + ctx.fbits)) | (e << ctx.fbits)
                    | (m - ctx.F))
        else:
            bits = ((sign << (ctx.ebits + ctx.fbits))
                    | (n << (q_exp - ctx.emin + ctx.fbits)))

    if inexact:
        flags.add("inexact")
        if cmp_pow2(n, q_exp, ctx.emin) < 0:
            flags.add("underflow")
    return {"bits": format(bits, "x"),
            "flags": [f for f in FLAG_ORDER if f in flags]}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write("\n".join(out))
    if out:
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
