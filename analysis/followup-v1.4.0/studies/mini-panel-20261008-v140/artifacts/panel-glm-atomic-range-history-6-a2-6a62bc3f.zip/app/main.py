#!/usr/bin/env python3
"""Linearizability checker for histories of atomic range transactions.

A witness is an order in which the finished transactions can be replayed as
single atomic steps: it must extend the real-time partial order
(``A.end <= B.start`` implies A before B), every recorded observation must
match, and the map left behind must equal ``final``.

Strategy
--------
The search builds the witness *backwards*, from the last transaction to the
first.  While walking backwards it keeps, for every key, the set of values that
the state in front of the already placed suffix is still allowed to hold.
That summary is exact rather than an over-approximation, because every
operation observes and mutates one key at a time -- a get pins one key, a cas
pins one key, and a scan pins each key inside its range independently.  Hence
the set of workable states in front of a suffix is always a product of per-key
sets, and merging states into sets loses nothing while pruning whole families
of dead branches at once (a key whose allowed set empties out kills the branch).

Real-time order is respected by only prepending a transaction once every
transaction that must follow it is already placed.  Failures are memoised on
(remaining transactions, constraint vector), so the search is complete.

Any order that comes out is re-checked with a literal replay of the request
(the same semantics the reference checker uses), and anything outside the
documented input shape falls back to a plain forward search that replays
operations literally.
"""

import json
import sys
import time

ABSENT = None      # the value a key "holds" when it is not present
BAD = object()     # marker for "this observation can never happen"

EXP, SET, CAS = 0, 1, 2   # per-key action kinds: observe / assign / compare-and-set

PROCESS_START = time.monotonic()
TOTAL_BUDGET = 45.0       # seconds this process may spend searching in total


class WeirdError(Exception):
    """Input outside the documented shape: use the literal forward search."""


class UnsatError(Exception):
    """An observation that no state whatsoever could produce."""


class OutOfTime(Exception):
    """A search gave up because its time slice ran out."""


def _is_int(x):
    return type(x) is int


def _deadline(seconds):
    """A per-request slice, never reaching past the whole-process budget."""
    return min(time.monotonic() + seconds, PROCESS_START + TOTAL_BUDGET)


# --------------------------------------------------------------- parsing ----

def _parse_op(op):
    if not isinstance(op, list) or not op:
        raise WeirdError
    kind = op[0]
    if kind == 'get':
        if len(op) != 3 or not isinstance(op[1], str):
            raise WeirdError
        if op[2] is not None and not _is_int(op[2]):
            raise WeirdError
        return ('get', op[1], op[2])
    if kind == 'put':
        if len(op) != 3 or not isinstance(op[1], str) or not _is_int(op[2]):
            raise WeirdError
        return ('put', op[1], op[2])
    if kind == 'del':
        if len(op) != 2 or not isinstance(op[1], str):
            raise WeirdError
        return ('del', op[1])
    if kind == 'cas':
        if len(op) != 5 or not isinstance(op[1], str) or not isinstance(op[4], bool):
            raise WeirdError
        if op[2] is not None and not _is_int(op[2]):
            raise WeirdError
        if op[3] is not None and not _is_int(op[3]):
            raise WeirdError
        return ('cas', op[1], op[2], op[3], op[4])
    # Anything else is read as a scan, exactly like the reference checker does.
    if len(op) != 4 or not isinstance(op[1], str) or not isinstance(op[2], str):
        raise WeirdError
    low, high, pairs = op[1], op[2], op[3]
    if not isinstance(pairs, list):
        raise UnsatError
    seen = {}
    prev = None
    for p in pairs:
        if not isinstance(p, list) or len(p) != 2 or not isinstance(p[0], str):
            raise WeirdError                 # let the literal replay decide
        if not _is_int(p[1]):
            raise WeirdError                 # a value unlike anything it can store
        key = p[0]
        # a replayed scan is always sorted, duplicate free and inside its range
        if not (low <= key < high) or (prev is not None and key <= prev):
            raise UnsatError                 # no state can ever produce this
        seen[key] = p[1]
        prev = key
    return ('scan', low, high, seen)


def parse_request(req):
    """Structural check.  Returns (transactions, initial, final) in normal form."""
    if not isinstance(req, dict):
        raise WeirdError
    txs = req.get('transactions')
    initial = req.get('initial')
    final = req.get('final')
    if not isinstance(txs, list) or not isinstance(initial, dict) or not isinstance(final, dict):
        raise WeirdError
    for m in (initial, final):
        for k, v in m.items():
            if not isinstance(k, str) or not _is_int(v):
                raise WeirdError
    seen = set()
    out = []
    for t in txs:
        if not isinstance(t, dict):
            raise WeirdError
        tid = t.get('id')
        start = t.get('start')
        end = t.get('end')
        ops = t.get('ops')
        if (not isinstance(tid, str) or tid in seen
                or not _is_int(start) or not _is_int(end)
                or not isinstance(ops, list)):
            raise WeirdError
        seen.add(tid)
        out.append((tid, start, end, [_parse_op(op) for op in ops]))
    return out, dict(initial), dict(final)


# ------------------------------------------------- backward set search ------

def _sim(actions, value):
    """Replay one transaction's actions that touch a single key.

    Returns the value the key holds afterwards, or BAD when an observation
    cannot match.  Other keys are irrelevant, so this is a faithful projection.
    """
    cur = value
    for a in actions:
        tag = a[0]
        if tag == EXP:
            if cur != a[1]:
                return BAD
        elif tag == SET:
            cur = a[1]
        else:                                   # compare and set
            if (cur == a[1]) != a[3]:
                return BAD
            if cur == a[1]:
                cur = a[2]
    return cur


def backward_search(txs, initial, final, deadline):
    """Search the witness from the last transaction backwards.

    Returns (order_or_None, complete).  ``complete`` is False only when the
    search was cut short by its time slice, in which case the answer is unknown.
    """
    n = len(txs)

    # Keys that can ever be present, plus keys any scan claims to have seen.
    keys = set(initial) | set(final)
    for _, _, _, ops in txs:
        for op in ops:
            if op[0] == 'scan':
                keys.update(op[3])
            else:
                keys.add(op[1])
    keys = sorted(keys)
    nkeys = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    # Project every transaction onto one ordered action list per key.
    acts = []
    for _, _, _, ops in txs:
        per = [[] for _ in range(nkeys)]
        for op in ops:
            tag = op[0]
            if tag == 'get':
                per[kidx[op[1]]].append((EXP, op[2]))
            elif tag == 'put':
                per[kidx[op[1]]].append((SET, op[2]))
            elif tag == 'del':
                per[kidx[op[1]]].append((SET, ABSENT))
            elif tag == 'cas':
                _, key, old, new, want = op
                per[kidx[key]].append((CAS, old, ABSENT if new is None else new, want))
            else:
                low, high, pmap = op[1], op[2], op[3]
                for i, k in enumerate(keys):      # keys in range, absent or not
                    if low <= k < high:
                        per[i].append((EXP, pmap.get(k, ABSENT)))
        acts.append(per)

    # Per key: every value that key can ever hold, as a bit position.
    dom = []
    for i, k in enumerate(keys):
        vals = {ABSENT, initial.get(k, ABSENT)}
        for per in acts:
            for a in per[i]:
                if a[0] == SET:
                    vals.add(a[1])
                elif a[0] == CAS and a[3]:
                    vals.add(a[2])
        dom.append(tuple(vals))
    bitof = [{v: b for b, v in enumerate(d)} for d in dom]

    # inv[t][key]: resulting value (bit) -> bitmask of workable previous values.
    inv = []
    for per in acts:
        row = []
        for i in range(nkeys):
            table = {}
            for b, v in enumerate(dom[i]):
                r = _sim(per[i], v)
                if r is not BAD:
                    pb = bitof[i].get(r)
                    if pb is not None:
                        table[pb] = table.get(pb, 0) | (1 << b)
            row.append(table)
        inv.append(row)

    # Frontier constraints: value bits the state in front of the suffix may hold.
    frontier = tuple(
        (1 << bitof[i][final.get(k, ABSENT)]) if final.get(k, ABSENT) in bitof[i] else 0
        for i, k in enumerate(keys))
    start_bits = [1 << bitof[i][initial.get(k, ABSENT)] for i, k in enumerate(keys)]

    # must_follow[t]: transactions that have to be placed after t.
    must_follow = []
    for t in range(n):
        end = txs[t][2]
        must_follow.append(sum(1 << u for u in range(n) if end <= txs[u][1]))

    # Try the most recently started transactions first: they belong at the end.
    cand_order = sorted(range(n), key=lambda t: (txs[t][1], txs[t][2], t), reverse=True)

    full = (1 << n) - 1
    memo = set()
    chosen = []
    ticks = [0]

    def dfs(remaining, f):
        ticks[0] += 1
        if not (ticks[0] & 255) and time.monotonic() > deadline:
            raise OutOfTime
        if not remaining:
            for i in range(nkeys):
                if not (f[i] & start_bits[i]):
                    return False
            return True
        key = (remaining, f)
        if key in memo:
            return False
        memo.add(key)                      # recorded as a failure while explored
        for t in cand_order:
            if not ((remaining >> t) & 1) or (must_follow[t] & remaining):
                continue
            row = inv[t]
            nf = []
            for i in range(nkeys):
                table = row[i]
                if not table:               # this transaction can never be replayed
                    break
                m = 0
                fi = f[i]
                for pb, pm in table.items():
                    if fi & (1 << pb):
                        m |= pm
                if not m:                   # no previous value can feed this suffix
                    break
                nf.append(m)
            else:
                chosen.append(t)
                if dfs(remaining & ~(1 << t), tuple(nf)):
                    return True
                chosen.pop()
        return False

    try:
        found = dfs(full, frontier)
    except OutOfTime:
        return None, False
    except RecursionError:
        return None, False
    if found:
        return [txs[t][0] for t in reversed(chosen)], True
    return None, True


# ------------------------------------------- literal replay (as reference) ---

def literal_apply(state, ops):
    """Replay one transaction's ops literally.  Returns the new state, or None."""
    state = dict(state)
    for op in ops:
        try:
            if op[0] == 'get':
                if state.get(op[1]) != op[2]:
                    return None
            elif op[0] == 'put':
                state[op[1]] = op[2]
            elif op[0] == 'del':
                state.pop(op[1], None)
            elif op[0] == 'cas':
                key, old, new, want = op[1], op[2], op[3], op[4]
                ok = state.get(key) == old
                if ok is not want:
                    return None
                if ok:
                    if new is None:
                        state.pop(key, None)
                    else:
                        state[key] = new
            else:
                if sorted([[k, v] for k, v in state.items() if op[1] <= k < op[2]]) != op[3]:
                    return None
        except (TypeError, KeyError, IndexError):
            return None
    return state


def literal_valid(req, order):
    """Re-check a witness with the literal semantics the reference uses."""
    try:
        tx = {t['id']: t for t in req['transactions']}
        if (not isinstance(order, list) or len(order) != len(tx)
                or any(not isinstance(x, str) for x in order) or set(order) != set(tx)):
            return False
        ranks = {x: i for i, x in enumerate(order)}
        for a in tx.values():
            for b in tx.values():
                if a['end'] <= b['start'] and ranks[a['id']] >= ranks[b['id']]:
                    return False
        state = req['initial'].copy()
        for name in order:
            for op in tx[name]['ops']:
                if op[0] == 'get':
                    if state.get(op[1]) != op[2]:
                        return False
                elif op[0] == 'put':
                    state[op[1]] = op[2]
                elif op[0] == 'del':
                    state.pop(op[1], None)
                elif op[0] == 'cas':
                    _, key, old, new, want = op
                    ok = state.get(key) == old
                    if ok is not want:
                        return False
                    if ok:
                        if new is None:
                            state.pop(key, None)
                        else:
                            state[key] = new
                else:
                    if sorted([[k, v] for k, v in state.items()
                                if op[1] <= k < op[2]]) != op[3]:
                        return False
        return state == req['final']
    except (TypeError, KeyError, IndexError, AttributeError):
        return False


def literal_forward(req, deadline):
    """Plain forward search replaying operations literally (fallback path)."""
    try:
        txs = req['transactions']
        initial = req['initial']
        final = req['final']
        n = len(txs)
        ids = [t['id'] for t in txs]
        preds = []
        for t in range(n):
            preds.append(sum(1 << u for u in range(n)
                             if txs[u]['end'] <= txs[t]['start']))
        full = (1 << n) - 1
        memo = set()
        chosen = []
        ticks = [0]

        def dfs(placed, state):
            ticks[0] += 1
            if not (ticks[0] & 255) and time.monotonic() > deadline:
                raise OutOfTime
            if placed == full:
                return state == final
            try:
                mkey = (placed, frozenset(state.items()))
            except TypeError:
                mkey = None
            if mkey is not None and mkey in memo:
                return False
            for t in range(n):
                if not ((placed >> t) & 1) and (preds[t] & placed) == preds[t]:
                    nxt = literal_apply(state, txs[t]['ops'])
                    if nxt is None:
                        continue
                    chosen.append(t)
                    if dfs(placed | (1 << t), nxt):
                        return True
                    chosen.pop()
            if mkey is not None:
                memo.add(mkey)
            return False

        if dfs(0, dict(initial)):
            return [ids[t] for t in chosen]
        return None
    except OutOfTime:
        return None
    except Exception:
        return None


# ------------------------------------------------------------------ driver --

def solve(req):
    try:
        txs, initial, final = parse_request(req)
    except UnsatError:
        return {"order": None}                      # an impossible observation
    except WeirdError:
        return {"order": literal_forward(req, _deadline(1.0))}

    order, complete = backward_search(txs, initial, final, _deadline(1.0))
    if order is not None:
        if literal_valid(req, order):
            return {"order": order}
        # Should not happen: settle it with the literal search.
        return {"order": literal_forward(req, _deadline(1.0))}
    if complete:
        return {"order": None}                      # proved: no witness exists
    return {"order": literal_forward(req, _deadline(1.0))}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            answer = solve(json.loads(line))
        except Exception:
            answer = {"order": None}
        out.write(json.dumps(answer) + "\n")
    out.flush()


if __name__ == '__main__':
    main()
