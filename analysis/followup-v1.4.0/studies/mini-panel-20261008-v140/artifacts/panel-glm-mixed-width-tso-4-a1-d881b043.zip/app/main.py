#!/usr/bin/env python3
"""Exhaustive terminal outcomes of a small mixed-width buffered (TSO-like) machine.

Machine summary (a deliberately specified teaching model):

Per-thread state: program counter, FIFO store buffer, observation list.
Shared memory: byte array (little-endian multi-byte values).

Enabled transitions (choose exactly one per step):

  1. Execute the next instruction of any thread, in program order:
       * store  -> append the complete (address,width,value) store to that
                   thread's FIFO buffer; memory is untouched
       * load   -> read each byte independently: the youngest buffered store of
                   the *same* thread covering that byte wins, otherwise shared
                   memory; assemble little-endian into one observation (never
                   blocks on a non-empty buffer)
       * fence  -> enabled only when that thread's buffer is empty
       * xchg   -> enabled only when that thread's buffer is empty; atomically
                   read the shared-memory value into observations and write the
                   supplied value to shared memory (other buffers irrelevant)
  2. Drain the oldest store of any non-empty buffer: all of its bytes become
     globally visible together (possible after the issuing thread finishes).

A state is terminal only when every thread has finished AND every buffer is
empty.  Every enabled transition strictly consumes work (an instruction or a
buffered store), so all executions are finite and each maximal execution ends in
a terminal state.

Observations are only ever appended and never influence the future, so the set
of (remaining observations, final memory) pairs is a pure function of the "core"
state (program counters, buffers, shared memory).  The search therefore
memoizes on that core state and unions the results of every enabled transition,
which is exact yet avoids re-expanding interleavings that differ only in the
already-recorded prefix.

Output: the complete set of distinct terminal outcomes, i.e. one observation
list per thread together with the final memory bytes.  Duplicates are
impossible by construction (results live in a set).
"""

import json
import sys


def solve(request):
    memory0 = tuple(int(b) & 0xFF for b in request["memory"])
    threads = tuple(tuple(tuple(op) for op in prog) for prog in request["threads"])
    nthreads = len(threads)
    lens = tuple(len(prog) for prog in threads)

    # ---------------------------------------------------------------- helpers
    def read_shared(memory, addr, width):
        value = 0
        for i in range(width):
            value |= memory[addr + i] << (8 * i)
        return value

    def read_forwarded(buffer, memory, addr, width):
        """Byte-granular store-buffer forwarding, youngest store wins."""
        value = 0
        for i in range(width):
            addr_i = addr + i
            byte = None
            for s_addr, s_width, s_val in reversed(buffer):
                if s_addr <= addr_i < s_addr + s_width:
                    byte = (s_val >> (8 * (addr_i - s_addr))) & 0xFF
                    break
            if byte is None:
                byte = memory[addr_i]
            value |= byte << (8 * i)
        return value

    def write_shared(memory, addr, width, value):
        """Whole-access write: every byte of the access lands together."""
        new = list(memory)
        for i in range(width):
            new[addr + i] = (value >> (8 * i)) & 0xFF
        return tuple(new)

    def bump(pcs, t, value):
        return pcs[:t] + (value,) + pcs[t + 1:]

    def set_buffer(buffers, t, buf):
        return buffers[:t] + (buf,) + buffers[t + 1:]

    empty_reads = tuple(tuple() for _ in range(nthreads))
    memo = {}

    def compute(pcs, buffers, memory):
        """All (per-thread observations still to come, final memory) pairs."""
        key = (pcs, buffers, memory)
        cached = memo.get(key)
        if cached is not None:
            return cached

        results = set()

        # --- 1. execute the next instruction of some thread -----------------
        for t in range(nthreads):
            pc = pcs[t]
            if pc >= lens[t]:
                continue
            op = threads[t][pc]
            kind = op[0]
            buffer = buffers[t]

            if kind == "store":
                # enters the FIFO only; nothing becomes globally visible yet
                new_buffer = buffer + ((op[1], op[2], op[3]),)
                results.update(
                    compute(bump(pcs, t, pc + 1),
                            set_buffer(buffers, t, new_buffer), memory)
                )
            elif kind == "load":
                value = read_forwarded(buffer, memory, op[1], op[2])
                for reads, mem in compute(bump(pcs, t, pc + 1), buffers, memory):
                    results.add(
                        (reads[:t] + ((value,) + reads[t],) + reads[t + 1:], mem)
                    )
            elif kind == "fence":
                # fences only wait for this thread's own buffer to be empty
                if not buffer:
                    results.update(compute(bump(pcs, t, pc + 1), buffers, memory))
            elif kind == "xchg":
                # atomic read-modify-write of shared memory; needs empty buffer
                if not buffer:
                    value = read_shared(memory, op[1], op[2])
                    new_memory = write_shared(memory, op[1], op[2], op[3])
                    for reads, mem in compute(
                        bump(pcs, t, pc + 1), buffers, new_memory
                    ):
                        results.add(
                            (reads[:t] + ((value,) + reads[t],) + reads[t + 1:], mem)
                        )
            else:  # pragma: no cover - unknown opcode: skip it harmlessly
                results.update(compute(bump(pcs, t, pc + 1), buffers, memory))

        # --- 2. drain the oldest store of some non-empty buffer -------------
        for t in range(nthreads):
            buffer = buffers[t]
            if buffer:
                s_addr, s_width, s_val = buffer[0]
                results.update(
                    compute(
                        pcs,
                        set_buffer(buffers, t, buffer[1:]),
                        write_shared(memory, s_addr, s_width, s_val),
                    )
                )

        # --- terminal state --------------------------------------------------
        if not any(buffers) and all(pcs[t] >= lens[t] for t in range(nthreads)):
            results.add((empty_reads, memory))

        memo[key] = results
        return results

    finals = compute(
        tuple(0 for _ in range(nthreads)),
        tuple(tuple() for _ in range(nthreads)),
        memory0,
    )

    return {
        "outcomes": [
            {"reads": [list(r) for r in reads], "memory": list(mem)}
            for reads, mem in finals
        ]
    }


def main():
    # every maximal execution has at most (instructions + stores) transitions,
    # so recursion is shallow; the raised limit is pure headroom.
    sys.setrecursionlimit(100000)
    for line in sys.stdin:
        if not line.strip():
            continue  # tolerate stray blank lines without shifting the output
        try:
            response = solve(json.loads(line))
        except Exception as exc:  # keep the process alive for remaining lines
            print("error: %r" % (exc,), file=sys.stderr)
            response = {"outcomes": []}
        sys.stdout.write(json.dumps(response) + "\n")
    sys.stdout.flush()


if __name__ == "__main__":
    main()
