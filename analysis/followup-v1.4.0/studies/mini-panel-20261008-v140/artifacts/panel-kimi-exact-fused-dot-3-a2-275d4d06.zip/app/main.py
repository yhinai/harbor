import sys
import json


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    W = ebits + fbits  # sign shift

    any_nan = False
    invalid = False
    pos_inf = False
    neg_inf = False
    zero_signs = []   # signs of finite zero products
    terms = []        # (sign, m, t): value = (-1)^sign * m * 2^t, m > 0

    fmask = F - 1
    topbit = 1 << (fbits - 1)

    for a_hex, b_hex in pairs:
        a = int(a_hex, 16)
        b = int(b_hex, 16)
        sa = (a >> W) & 1
        ea = (a >> fbits) & Eall
        fa = a & fmask
        sb = (b >> W) & 1
        eb = (b >> fbits) & Eall
        fb = b & fmask

        # classify: 0=finite, 1=inf, 2=qnan, 3=snan
        if ea == Eall:
            ca = 1 if fa == 0 else (2 if fa & topbit else 3)
        else:
            ca = 0
        if eb == Eall:
            cb = 1 if fb == 0 else (2 if fb & topbit else 3)
        else:
            cb = 0

        if ca == 3 or cb == 3:
            invalid = True
        if ca >= 2 or cb >= 2:
            any_nan = True
            continue  # NaN pair: no product, never 0*inf

        ps = sa ^ sb
        if ca == 1 or cb == 1:
            # one is infinite; the other is finite or infinite
            za = ca == 0 and ea == 0 and fa == 0
            zb = cb == 0 and eb == 0 and fb == 0
            if za or zb:
                invalid = True  # zero times infinity
                continue
            if ps:
                neg_inf = True
            else:
                pos_inf = True
            continue

        # finite x finite
        if ea == 0:
            ma = fa
            ta = emin - fbits
        else:
            ma = F + fa
            ta = ea - bias - fbits
        if eb == 0:
            mb = fb
            tb = emin - fbits
        else:
            mb = F + fb
            tb = eb - bias - fbits
        m = ma * mb
        if m == 0:
            zero_signs.append(ps)
        else:
            terms.append((ps, m, ta + tb))

    canon_nan = (Eall << fbits) | topbit

    invalid = invalid or (pos_inf and neg_inf)
    if any_nan or invalid:
        return {"bits": format(canon_nan, "x"),
                "flags": ["invalid"] if invalid else []}
    if pos_inf or neg_inf:
        bits = ((1 if neg_inf else 0) << W) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # ---- finite exact sum ----
    if terms:
        min_t = min(t for _, _, t in terms)
        S = 0
        for ps, m, t in terms:
            v = m << (t - min_t)
            S = S - v if ps else S + v
    else:
        min_t = 0
        S = 0

    if S == 0:
        # exact zero
        if terms:
            neg = mode == "RDN"          # cancellation
        elif zero_signs:
            neg = all(z == 1 for z in zero_signs) or mode == "RDN"
        else:
            neg = mode == "RDN"          # empty
        bits = (1 << W) if neg else 0
        return {"bits": format(bits, "x"), "flags": []}

    sign = 1 if S < 0 else 0
    A = -S if S < 0 else S
    L = A.bit_length() - 1 + min_t
    qe = max(emin - fbits, L - fbits)

    if min_t >= qe:
        n = A << (min_t - qe)
        inexact = False
    else:
        d = qe - min_t
        quo = A >> d
        rem = A & ((1 << d) - 1)
        inexact = rem != 0
        if mode == "RNE":
            half = 1 << (d - 1)
            if rem > half or (rem == half and (quo & 1)):
                quo += 1
        elif mode == "RNA":
            if rem >= (1 << (d - 1)):
                quo += 1
        elif mode == "RUP":
            if sign == 0 and rem:
                quo += 1
        elif mode == "RDN":
            if sign == 1 and rem:
                quo += 1
        # RTZ: truncate
        n = quo

    # overflow?
    if n and n.bit_length() - 1 + qe >= emax + 1:
        if mode in ("RNE", "RNA") or (mode == "RUP" and sign == 0) \
                or (mode == "RDN" and sign == 1):
            bits = (sign << W) | (Eall << fbits)           # signed inf
        else:
            bits = (sign << W) | ((Eall - 1) << fbits) | fmask  # max finite
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    underflow = inexact and (n == 0 or n.bit_length() - 1 + qe < emin)
    flags = (["underflow"] if underflow else []) + (["inexact"] if inexact else [])

    if n == 0:
        # nonzero exact value rounded to zero: keep exact sign
        return {"bits": format(sign << W, "x"), "flags": flags}

    Ly = n.bit_length() - 1 + qe
    if Ly >= emin:
        e = Ly + bias
        shift = Ly - fbits
        if qe >= shift:
            sig = n << (qe - shift)
        else:
            sig = n >> (shift - qe)
        frac = sig - F
    else:
        e = 0
        frac = n
    bits = (sign << W) | (e << fbits) | frac
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
