#!/usr/bin/env python3
"""Exact fused dot product over a parameterized binary floating-point format.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line.  All products and the accumulation are performed exactly (integer
arithmetic); only the final sum is rounded once, in the requested mode.
"""

import json
import sys

INVALID = 'invalid'
OVERFLOW = 'overflow'
UNDERFLOW = 'underflow'
INEXACT = 'inexact'


def solve(req):
    ebits = int(req['ebits'])
    fbits = int(req['fbits'])
    mode = req.get('mode', 'RNE')
    pairs = req.get('pairs') or []

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                    # 2**fbits
    Eall = (1 << ebits) - 1
    ssh = ebits + fbits               # bits used by exponent + fraction
    wmask = (1 << (1 + ssh)) - 1
    fmask = F - 1
    topfrac = 1 << (fbits - 1)        # quiet bit inside the fraction
    emin = 1 - bias
    emax = Eall - 1 - bias
    unit_exp = emin - fbits           # exponent of the subnormal quantum

    # ------------------------------------------------------------------ decode
    def decode(h):
        """-> (kind, sign, mantissa, exponent); magnitude = mantissa*2**exponent."""
        if isinstance(h, str):
            t = h.strip().lower()
            if t.startswith('0x'):
                t = t[2:]
            b = int(t, 16) if t else 0
        elif isinstance(h, int):
            b = h
        else:
            t = str(h).strip().lower()
            if t.startswith('0x'):
                t = t[2:]
            b = int(t, 16) if t else 0
        b &= wmask
        s = b >> ssh
        e = (b >> fbits) & Eall
        f = b & fmask
        if e == Eall:
            if f == 0:
                return ('inf', s, 0, 0)
            return ('qnan' if (f & topfrac) else 'snan', s, 0, 0)
        if e == 0:
            return ('fin', s, f, unit_exp)          # zero or subnormal
        return ('fin', s, F + f, e - bias - fbits)  # normal

    def pack(sign, e_field, f_field):
        return (sign << ssh) | (e_field << fbits) | f_field

    # ------------------------------------------------- scan for exceptional terms
    invalid = False
    saw_nan = False
    pos_inf = False
    neg_inf = False
    prods = []                        # (sign, mantissa, exponent) exact products

    for pair in pairs:
        a = decode(pair[0])
        b = decode(pair[1])
        if a[0] in ('qnan', 'snan') or b[0] in ('qnan', 'snan'):
            saw_nan = True
            if a[0] == 'snan' or b[0] == 'snan':
                invalid = True
            continue
        a_inf = a[0] == 'inf'
        b_inf = b[0] == 'inf'
        a_zero = a[0] == 'fin' and a[2] == 0
        b_zero = b[0] == 'fin' and b[2] == 0
        if (a_inf and b_zero) or (a_zero and b_inf):
            invalid = True
            continue
        if a_inf or b_inf:
            if a[1] ^ b[1]:
                neg_inf = True
            else:
                pos_inf = True
            continue
        prods.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    if saw_nan or invalid:
        return {'bits': format(pack(0, Eall, topfrac), 'x'),
                'flags': [INVALID] if invalid else []}
    if pos_inf or neg_inf:
        return {'bits': format(pack(1 if neg_inf else 0, Eall, 0), 'x'),
                'flags': []}

    # ------------------------------------------------------- exact zero results
    if not prods or all(m == 0 for _, m, _ in prods):
        neg = (mode == 'RDN') or (bool(prods) and all(sg == 1 for sg, _, _ in prods))
        return {'bits': format(pack(1 if neg else 0, 0, 0), 'x'), 'flags': []}

    # -------------------------------------------------- exact sum of the products
    min_e = min(ee for _, m, ee in prods if m)
    total = 0
    for sg, m, ee in prods:
        if not m:
            continue                      # exact zero product contributes 0
        v = m << (ee - min_e)
        total = total - v if sg else total + v
    sign = 1 if total < 0 else 0
    mag = -total if total < 0 else total          # exact magnitude = mag*2**min_e

    # ------------------------------------------------------------------- rounding
    L = mag.bit_length() - 1 + min_e              # floor(log2(x))
    qe = L - fbits if L - fbits > unit_exp else unit_exp   # quantum = 2**qe
    shift = min_e - qe
    if shift >= 0:
        base = mag << shift
        rem = 0
        k = 0
    else:
        k = -shift
        base = mag >> k
        rem = mag - (base << k)                   # x/q = base + rem/2**k
    if rem:
        twice = rem << 1
        full = 1 << k
        if mode == 'RNE':
            n = base + 1 if (twice > full or (twice == full and (base & 1))) else base
        elif mode == 'RNA':
            n = base + 1 if twice >= full else base
        elif mode == 'RTZ':
            n = base
        elif mode == 'RUP':
            n = base + 1 if sign == 0 else base
        elif mode == 'RDN':
            n = base + 1 if sign == 1 else base
        else:
            n = base
    else:
        n = base
    inexact = rem != 0                            # rounded magnitude != x

    # ------------------------------------------------------------------- overflow
    # rounded magnitude y = n * 2**qe ; overflow iff y >= 2**(emax+1)
    t = emax + 1 - qe
    over = (n >= (1 << t)) if t >= 0 else (n >= 1)
    if over:
        away = (mode in ('RNE', 'RNA')
                or (mode == 'RUP' and sign == 0)
                or (mode == 'RDN' and sign == 1))
        out = pack(sign, Eall, 0) if away else pack(sign, Eall - 1, fmask)
        return {'bits': format(out, 'x'), 'flags': [OVERFLOW, INEXACT]}

    # -------------------------------------------------------- zero after rounding
    if n == 0:
        flags = [INEXACT, UNDERFLOW] if inexact else []
        return {'bits': format(pack(sign, 0, 0), 'x'), 'flags': flags}

    # ------------------------------------------------------------- other results
    flags = []
    if inexact:
        flags.append(INEXACT)
        u = emin - qe                             # tiny iff n*2**qe < 2**emin
        if (n < (1 << u)) if u >= 0 else False:
            flags.append(UNDERFLOW)

    ly = n.bit_length() - 1 + qe                  # floor(log2(y))
    if ly >= emin:
        t2 = n.bit_length() - 1
        sig = n << (fbits - t2) if fbits >= t2 else n >> (t2 - fbits)
        out = pack(sign, ly + bias, sig - F)
    else:
        out = pack(sign, 0, n << (qe - unit_exp))
    return {'bits': format(out, 'x'), 'flags': flags}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))


if __name__ == '__main__':
    main()
