import json
import sys

# Bit-exact fused dot product for a parameterized binary floating-point format.
#
# Operands are decoded exactly as sign / integer significand / power-of-two
# exponent, products are accumulated exactly with Python big integers, and only
# the final exact sum is rounded to the destination format.

def solve(request):
    ebits = request["ebits"]
    fbits = request["fbits"]
    mode = request["mode"]
    pairs = request["pairs"]

    Eall = (1 << ebits) - 1
    F = 1 << fbits
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    fshift = fbits
    eshift = ebits + fbits

    def decode(h):
        # returns (kind, sign, mantissa, exponent) for kind in num/inf/nan
        v = int(h, 16) if h else 0
        s = (v >> eshift) & 1
        e = (v >> fshift) & Eall
        f = v & (F - 1)
        if e == Eall:
            if f == 0:
                return ("inf", s, 0, 0)
            quiet = (f >> (fbits - 1)) & 1
            return ("nan", s, quiet, 0)
        if e == 0:
            return ("num", s, f, emin - fbits)
        return ("num", s, F + f, e - bias - fbits)

    def canonical_nan(flags):
        bits = (Eall << fshift) | (1 << (fbits - 1))
        return {"bits": format(bits, "x"), "flags": flags}

    any_nan = False
    any_snan = False
    invalid = False
    inf_signs = set()
    prods = []  # (sign, mantissa, exp2); zero mantissa means a signed zero product

    for pair in pairs:
        da = decode(pair[0])
        db = decode(pair[1])
        if da[0] == "nan" or db[0] == "nan":
            any_nan = True
            if da[0] == "nan" and not da[2]:
                any_snan = True
            if db[0] == "nan" and not db[2]:
                any_snan = True
            continue
        if da[0] == "inf" or db[0] == "inf":
            # zero * infinity is invalid
            if (da[0] == "inf" and db[0] == "num" and db[2] == 0) or \
               (db[0] == "inf" and da[0] == "num" and da[2] == 0):
                invalid = True
                continue
            inf_signs.add(da[1] ^ db[1])
            continue
        sa, ma, ea = da[1], da[2], da[3]
        sb, mb, eb = db[1], db[2], db[3]
        if ma == 0 or mb == 0:
            prods.append((sa ^ sb, 0, 0))
        else:
            prods.append((sa ^ sb, ma * mb, ea + eb))

    if any_nan or invalid:
        return canonical_nan(["invalid"] if (any_snan or invalid) else [])
    if len(inf_signs) == 2:
        return canonical_nan(["invalid"])
    if inf_signs:
        s = next(iter(inf_signs))
        bits = (s << eshift) | (Eall << fshift)
        return {"bits": format(bits, "x"), "flags": []}

    # Exact accumulation of all (finite) products.
    terms = [(s, m, e) for (s, m, e) in prods if m != 0]
    if terms:
        base = min(e for _, _, e in terms)
        M = 0
        for s, m, e in terms:
            v = m << (e - base)
            M += v if s == 0 else -v
    else:
        M = 0

    if M == 0:
        # Exact zero: sign per the rules (all products negative zeros, or RDN).
        neg = (mode == "RDN") or (
            len(prods) > 0 and all(s == 1 and m == 0 for s, m, _ in prods)
        )
        bits = (1 << eshift) if neg else 0
        return {"bits": format(bits, "x"), "flags": []}

    sign = 1 if M < 0 else 0
    A = -M if M < 0 else M
    L = A.bit_length() - 1 + base
    q_exp = max(emin - fbits, L - fbits)

    # t = A * 2**base / 2**q_exp, an exact rational.
    sh = base - q_exp
    if sh >= 0:
        num = A << sh
        den = 1
    else:
        num = A
        den = 1 << (-sh)
    n, r = divmod(num, den)

    if mode == "RNE":
        twice = 2 * r
        if twice < den:
            y = n
        elif twice > den:
            y = n + 1
        else:
            y = n if (n & 1) == 0 else n + 1
    elif mode == "RNA":
        y = n if 2 * r < den else n + 1
    elif mode == "RTZ":
        y = n
    elif mode == "RUP":
        y = n + 1 if (r != 0 and sign == 0) else n
    else:  # RDN
        y = n + 1 if (r != 0 and sign == 1) else n

    # Overflow: rounded magnitude y * 2**q_exp >= 2**(emax+1).
    if q_exp >= emax + 1:
        overflow = y >= 1
    else:
        overflow = y >= (1 << (emax + 1 - q_exp))

    if overflow:
        to_inf = mode in ("RNE", "RNA") or (mode == "RUP" and sign == 0) or \
                 (mode == "RDN" and sign == 1)
        if to_inf:
            bits = (sign << eshift) | (Eall << fshift)
        else:
            bits = (sign << eshift) | ((Eall - 1) << fshift) | (F - 1)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    inexact = r != 0
    if y == 0:
        below = True
    elif q_exp >= emin:
        below = False
    else:
        below = y < (1 << (emin - q_exp))
    underflow = inexact and below

    flags = []
    if underflow:
        flags.append("underflow")
    if inexact:
        flags.append("inexact")

    if y == 0:
        bits = sign << eshift
        return {"bits": format(bits, "x"), "flags": flags}

    if below:
        # Subnormal: stored fraction is y itself.
        bits = (sign << eshift) | y
        return {"bits": format(bits, "x"), "flags": flags}

    # Normal: significand in [2**fbits, 2**(fbits+1)).
    Lv = y.bit_length() - 1 + q_exp
    sh2 = q_exp - (Lv - fbits)
    if sh2 >= 0:
        m = y << sh2
    else:
        m = y >> (-sh2)
    e_field = Lv + bias
    frac = m - F
    bits = (sign << eshift) | (e_field << fshift) | frac
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        resp = solve(json.loads(line))
        out.write(json.dumps(resp) + "\n")


if __name__ == "__main__":
    main()
