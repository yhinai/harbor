#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating format.

Every multiplication and every accumulation is performed exactly with scaled
integer arithmetic; only the final sum is rounded, once, in the requested mode.

Layout of a bit pattern, most to least significant: sign (1), exponent
(`ebits`), fraction (`fbits`).  With ``bias = 2**(ebits-1)-1`` and
``F = 2**fbits``:

* ``0 < e < Eall``  ->  (-1)**s * (F+f) * 2**(e-bias-fbits)      (normal)
* ``e == 0``        ->  (-1)**s * f   * 2**(1-bias-fbits)        (subnormal/zero)
* ``e == Eall, f==0``  ->  signed infinity;  ``f != 0``  ->  NaN
  (quiet iff the top fraction bit is set)
"""
import json
import sys

NEAREST = ('RNE', 'RNA')          # modes that overflow to infinity


def solve(req):
    ebits = int(req['ebits'])
    fbits = int(req['fbits'])
    mode = req['mode']
    pairs = req['pairs']

    Eall = (1 << ebits) - 1                   # all-ones exponent field
    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                            # implicit leading significand unit
    fmask = F - 1
    emin = 1 - bias                           # minimum normal exponent
    emax = Eall - 1 - bias                    # maximum normal exponent
    top = 1 << (fbits - 1)                    # top fraction bit: quiet-NaN marker
    eshift = ebits + fbits                    # right shift of the sign bit
    vmask = (1 << (eshift + 1)) - 1
    subexp = 1 - bias - fbits                 # exponent of the subnormal spacing

    # ---- pass over the operands: exact products + exception bookkeeping ----
    nan_seen = False                          # any NaN operand
    invalid = False                           # sNaN / 0*inf / +-inf products
    pos_inf = neg_inf = False                 # signs of infinite products
    terms = []                                # finite products (sign, sig, exp)

    for pair in pairs:
        va = int(pair[0], 16) & vmask
        vb = int(pair[1], 16) & vmask
        sa = va >> eshift
        sb = vb >> eshift
        ea = (va >> fbits) & Eall
        eb = (vb >> fbits) & Eall
        fa = va & fmask
        fb = vb & fmask
        nana = ea == Eall and fa != 0
        nanb = eb == Eall and fb != 0
        if nana or nanb:                      # a NaN pair yields no product
            nan_seen = True
            if (nana and not fa & top) or (nanb and not fb & top):
                invalid = True                # signaling NaN
            continue
        if ea == Eall or eb == Eall:          # an infinity is involved
            if (ea == 0 and fa == 0) or (eb == 0 and fb == 0):
                invalid = True                # zero times infinity
            elif sa ^ sb:
                neg_inf = True                # infinite product
            else:
                pos_inf = True
            continue
        # finite x finite: value = sig * 2**exp, sign = sa ^ sb
        if ea == 0:
            siga, expa = fa, subexp
        else:
            siga, expa = F + fa, ea - bias - fbits
        if eb == 0:
            sigb, expb = fb, subexp
        else:
            sigb, expb = F + fb, eb - bias - fbits
        terms.append((sa ^ sb, siga * sigb, expa + expb))

    # ---- exceptional results ----
    if pos_inf and neg_inf:                   # both infinite product signs
        invalid = True
    if nan_seen or invalid:
        # canonical NaN: sign 0, exponent Eall, only the top fraction bit set
        return {'bits': format((Eall << fbits) | top, 'x'),
                'flags': ['invalid'] if invalid else []}
    if pos_inf or neg_inf:                   # an infinite product wins
        s = 1 if neg_inf else 0
        return {'bits': format(((s << ebits | Eall) << fbits), 'x'), 'flags': []}

    # ---- exact accumulation of the finite products ----
    nonz = [t for t in terms if t[1]]
    if not nonz:                              # only zero (or no) products
        neg = mode == 'RDN' or (bool(terms) and all(t[0] for t in terms))
        return {'bits': format((1 if neg else 0) << eshift, 'x'), 'flags': []}
    minexp = min(t[2] for t in nonz)
    total = 0
    for sgn, sig, exp in nonz:                # scale onto the smallest exponent
        v = sig << (exp - minexp)
        total = total - v if sgn else total + v
    if total == 0:                            # exact cancellation
        neg = mode == 'RDN' or all(t[0] for t in terms)
        return {'bits': format((1 if neg else 0) << eshift, 'x'), 'flags': []}
    if total < 0:
        sign, n = 1, -total
    else:
        sign, n = 0, total

    # ---- single rounding of the exact magnitude x = n * 2**minexp ----
    L = n.bit_length() - 1 + minexp           # floor(log2(x))
    qexp = emin - fbits                       # quantum q = 2**qexp
    if L - fbits > qexp:
        qexp = L - fbits
    d = qexp - minexp                         # x/q = n / 2**d
    if d > 0:
        base = n >> d
        rem = n & ((1 << d) - 1)
        half = 1 << (d - 1)
    else:
        base = n << -d if d < 0 else n        # already an integer multiple
        rem = 0
        half = 0
    inexact = rem != 0

    if inexact:
        if mode == 'RNE':                     # ties to an even significand
            if rem > half or (rem == half and base & 1):
                base += 1
        elif mode == 'RNA':                   # ties away from zero
            if rem >= half:
                base += 1
        elif mode == 'RUP':                   # toward +inf
            if sign == 0:
                base += 1
        elif mode == 'RDN':                   # toward -inf
            if sign == 1:
                base += 1
        # 'RTZ' truncates
    m = base                                  # rounded value y = m * 2**qexp

    if m == 0:                                # rounded to zero: keep exact sign
        return {'bits': format(sign << eshift, 'x'),
                'flags': ['inexact', 'underflow']}

    Lp = m.bit_length() - 1 + qexp            # floor(log2(y))
    if Lp > emax:                             # y >= 2**(emax+1): overflow
        away = (mode in NEAREST or (mode == 'RUP' and sign == 0)
                or (mode == 'RDN' and sign == 1))
        if away:
            return {'bits': format(((sign << ebits | Eall) << fbits), 'x'),
                    'flags': ['overflow', 'inexact']}
        return {'bits': format(((sign << ebits | (Eall - 1)) << fbits | (F - 1)), 'x'),
                'flags': ['overflow', 'inexact']}

    # ---- encode the rounded magnitude as (exponent, fraction) ----
    if Lp >= emin:                            # normal
        sh = qexp - (Lp - fbits)
        sig = m << sh if sh > 0 else (m >> -sh if sh < 0 else m)
        e = Lp + bias
        f = sig - F
    else:                                     # subnormal
        sh = qexp - subexp
        f = m << sh if sh > 0 else (m >> -sh if sh < 0 else m)
        e = 0
    bits = format(((sign << ebits | e) << fbits) | f, 'x')
    if not inexact:
        return {'bits': bits, 'flags': []}
    flags = ['inexact']
    if Lp < emin:                             # rounded magnitude below 2**emin
        flags.append('underflow')
    return {'bits': bits, 'flags': flags}


def main():
    write = sys.stdout.write
    for line in sys.stdin:                    # one JSON request per line
        if not line.strip():
            continue
        write(json.dumps(solve(json.loads(line))))
        write('\n')


if __name__ == '__main__':
    main()
