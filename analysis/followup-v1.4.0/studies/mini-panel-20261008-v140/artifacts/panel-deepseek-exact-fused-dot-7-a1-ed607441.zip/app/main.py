#!/usr/bin/env python3
"""Bit-exact fused dot product for a parameterized binary float format.

Reads newline-delimited JSON requests from stdin, writes one JSON response per
line to stdout.  All products and the accumulation are computed exactly with
Python integers; only the final sum is rounded to the target format.
"""

import json
import sys

def decode_operand(v, ebits, fbits, Eall, F, bias):
    """Decode a bit pattern into ('nan', sign, quiet) / ('inf', sign) /
    ('fin', sign, magnitude, exp2) where the value is
    (-1)**sign * magnitude * 2**exp2."""
    s = (v >> (ebits + fbits)) & 1
    e = (v >> fbits) & Eall
    f = v & (F - 1)
    if e == Eall:
        if f == 0:
            return ("inf", s)
        quiet = 1 if (f >> (fbits - 1)) & 1 else 0
        return ("nan", s, quiet)
    if e == 0:
        return ("fin", s, f, 1 - bias - fbits)
    return ("fin", s, F + f, e - bias - fbits)


def solve(request):
    ebits = request["ebits"]
    fbits = request["fbits"]
    mode = request["mode"]
    pairs = request["pairs"]

    Eall = (1 << ebits) - 1
    F = 1 << fbits
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    sign_bit = 1 << (ebits + fbits)

    nan_seen = False
    signaling = False
    invalid = False
    inf_signs = set()
    nonzero = []      # (sign, magnitude, exp2) for nonzero finite products
    zero_prods = []   # signs of zero products

    for pair in pairs:
        a = decode_operand(int(pair[0], 16), ebits, fbits, Eall, F, bias)
        b = decode_operand(int(pair[1], 16), ebits, fbits, Eall, F, bias)

        a_nan = a[0] == "nan"
        b_nan = b[0] == "nan"
        if a_nan or b_nan:
            nan_seen = True
            if a_nan and a[2] == 0:
                signaling = True
            if b_nan and b[2] == 0:
                signaling = True
            # A pair with a NaN operand contributes no infinite product and
            # cannot itself count as zero times infinity.
            continue

        a_inf = a[0] == "inf"
        b_inf = b[0] == "inf"
        if a_inf and b_inf:
            inf_signs.add(a[1] ^ b[1])
            continue
        if a_inf or b_inf:
            fin = b if a_inf else a
            if fin[2] == 0:            # finite operand is zero
                invalid = True         # zero times infinity
            else:
                inf_signs.add(a[1] ^ b[1])
            continue

        # Both operands finite.
        sign = a[1] ^ b[1]
        mag = a[2] * b[2]
        exp2 = a[3] + b[3]
        if mag == 0:
            zero_prods.append(sign)
        else:
            nonzero.append((sign, mag, exp2))

    if signaling:
        invalid = True
    if len(inf_signs) > 1:
        invalid = True

    if nan_seen or invalid:
        bits = (Eall << fbits) | (1 << (fbits - 1))   # canonical NaN
        return {"bits": format(bits, "x"), "flags": ["invalid"] if invalid else []}

    if inf_signs:
        sign = next(iter(inf_signs))
        bits = (sign << (ebits + fbits)) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # ----- finite case -----
    if not nonzero:
        # Every product is an exact signed zero (or there are no products).
        if pairs and all(s == 1 for s in zero_prods):
            neg = True
        else:
            neg = mode == "RDN"
        return {"bits": format(sign_bit if neg else 0, "x"), "flags": []}

    minexp = min(p[2] for p in nonzero)
    total = 0
    for sign, mag, exp2 in nonzero:
        term = mag << (exp2 - minexp)
        total += -term if sign else term

    if total == 0:
        # Cancellation involving nonzero products.
        neg = mode == "RDN"
        return {"bits": format(sign_bit if neg else 0, "x"), "flags": []}

    sign = 1 if total < 0 else 0
    x_abs = -total if total < 0 else total

    # Round the exact magnitude x = x_abs * 2**minexp.
    L = x_abs.bit_length() - 1 + minexp
    qexp = max(emin - fbits, L - fbits)
    shift = qexp - minexp
    if shift > 0:
        n = x_abs >> shift
        rem = x_abs & ((1 << shift) - 1)
        d = 1 << shift
    else:
        n = x_abs << (-shift)
        rem = 0
        d = 1

    if rem == 0:
        yint = n
    else:
        twice = rem << 1
        if mode == "RNE":
            if twice < d:
                yint = n
            elif twice > d:
                yint = n + 1
            else:
                yint = n if (n & 1) == 0 else n + 1
        elif mode == "RNA":
            yint = n + 1 if twice >= d else n
        elif mode == "RTZ":
            yint = n
        elif mode == "RUP":
            yint = n + 1 if sign == 0 else n
        else:  # RDN
            yint = n if sign == 0 else n + 1

    if yint == 0:
        # Nonzero exact value rounded to zero; it keeps its exact sign.
        return {"bits": format(sign_bit if sign else 0, "x"),
                "flags": ["underflow", "inexact"]}

    Lr = yint.bit_length() - 1 + qexp          # floor(log2(rounded magnitude))
    if Lr >= emax + 1:
        # Overflow.
        if (mode in ("RNE", "RNA")
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1)):
            bits = (sign << (ebits + fbits)) | (Eall << fbits)
        else:
            bits = (sign << (ebits + fbits)) | ((Eall - 1) << fbits) | (F - 1)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if rem != 0:
        flags.append("inexact")
        if Lr < emin:
            flags.append("underflow")

    if Lr < emin:
        # Subnormal: qexp == emin - fbits and yint < F.
        e = 0
        f = yint
    else:
        sft = qexp - (Lr - fbits)
        M = yint << sft if sft >= 0 else yint >> (-sft)
        e = Lr + bias
        f = M - F

    bits = (sign << (ebits + fbits)) | (e << fbits) | f
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        response = solve(json.loads(line))
        out.write(json.dumps(response) + "\n")
        out.flush()


if __name__ == "__main__":
    main()
