import sys, json
from collections import defaultdict


def solve(req):
    mem_bytes = req['memory']
    threads = req['threads']
    nt = len(threads)
    ninstr = [len(t) for t in threads]

    mem0 = 0
    for i, b in enumerate(mem_bytes):
        mem0 |= b << (8 * i)

    stores = []      # stores[t] = list of (addr, width, value)
    issued = []      # issued[t][pc] = number of stores among first pc instrs
    ops = []         # ops[t][pc] = (code, addr, width, value, slot)
    slots = []       # slots[t] = global observation slot of each load/xchg of t
    slot_count = 0
    for t in threads:
        st = []
        iss = [0]
        op = []
        sl = []
        for ins in t:
            k = ins[0]
            if k == 'store':
                st.append((ins[1], ins[2], ins[3]))
                op.append((0, ins[1], ins[2], ins[3], -1))
                iss.append(iss[-1] + 1)
            elif k == 'load':
                op.append((1, ins[1], ins[2], 0, slot_count))
                sl.append(slot_count)
                slot_count += 1
                iss.append(iss[-1])
            elif k == 'fence':
                op.append((2, 0, 0, 0, -1))
                iss.append(iss[-1])
            else:  # xchg
                op.append((3, ins[1], ins[2], ins[3], slot_count))
                sl.append(slot_count)
                slot_count += 1
                iss.append(iss[-1])
        stores.append(st)
        issued.append(iss)
        ops.append(op)
        slots.append(sl)

    nstore = [len(s) for s in stores]
    start = (mem0, 0, 0)
    obs_sets = {start: {0}}
    levels = defaultdict(list)
    levels[0].append(start)
    maxlevel = sum(ninstr) + sum(nstore)
    outcomes = set()
    nmem = len(mem_bytes)

    for level in range(maxlevel + 1):
        for state in levels[level]:
            mem, pcs, drained = state
            obsset = obs_sets[state]

            # terminal check
            fin = True
            for t in range(nt):
                if ((pcs >> (3 * t)) & 7) != ninstr[t] or ((drained >> (3 * t)) & 7) != nstore[t]:
                    fin = False
                    break
            if fin:
                for o in obsset:
                    outcomes.add((o, mem))
                continue

            nxt = levels[level + 1]
            for t in range(nt):
                pc = (pcs >> (3 * t)) & 7
                if pc >= ninstr[t]:
                    continue
                code, a, w, v, slot = ops[t][pc]
                npcs = pcs + (1 << (3 * t))
                if code == 0:  # store
                    ns = (mem, npcs, drained)
                    s2 = obs_sets.get(ns)
                    if s2 is None:
                        obs_sets[ns] = set(obsset)
                        nxt.append(ns)
                    else:
                        s2 |= obsset
                elif code == 1:  # load
                    d = (drained >> (3 * t)) & 7
                    e = issued[t][pc]
                    if d == e:
                        val = (mem >> (8 * a)) & ((1 << (8 * w)) - 1)
                    else:
                        val = 0
                        buf = stores[t]
                        for i in range(w):
                            ad = a + i
                            bb = -1
                            for k in range(e - 1, d - 1, -1):
                                sa, sw, sv = buf[k]
                                if sa <= ad < sa + sw:
                                    bb = (sv >> (8 * (ad - sa))) & 0xFF
                                    break
                            if bb < 0:
                                bb = (mem >> (8 * ad)) & 0xFF
                            val |= bb << (8 * i)
                    ns = (mem, npcs, drained)
                    shift = 32 * slot
                    tgt = obs_sets.get(ns)
                    if tgt is None:
                        obs_sets[ns] = {o | (val << shift) for o in obsset}
                        nxt.append(ns)
                    else:
                        tgt.update(o | (val << shift) for o in obsset)
                elif code == 2:  # fence
                    if ((drained >> (3 * t)) & 7) == issued[t][pc]:
                        ns = (mem, npcs, drained)
                        s2 = obs_sets.get(ns)
                        if s2 is None:
                            obs_sets[ns] = set(obsset)
                            nxt.append(ns)
                        else:
                            s2 |= obsset
                else:  # xchg
                    if ((drained >> (3 * t)) & 7) == issued[t][pc]:
                        val = (mem >> (8 * a)) & ((1 << (8 * w)) - 1)
                        mask = ((1 << (8 * w)) - 1) << (8 * a)
                        nm = (mem & ~mask) | ((v << (8 * a)) & mask)
                        ns = (nm, npcs, drained)
                        shift = 32 * slot
                        tgt = obs_sets.get(ns)
                        if tgt is None:
                            obs_sets[ns] = {o | (val << shift) for o in obsset}
                            nxt.append(ns)
                        else:
                            tgt.update(o | (val << shift) for o in obsset)

            for t in range(nt):
                d = (drained >> (3 * t)) & 7
                e = issued[t][(pcs >> (3 * t)) & 7]
                if d < e:
                    sa, sw, sv = stores[t][d]
                    mask = ((1 << (8 * sw)) - 1) << (8 * sa)
                    nm = (mem & ~mask) | ((sv << (8 * sa)) & mask)
                    nd = drained + (1 << (3 * t))
                    ns = (nm, pcs, nd)
                    s2 = obs_sets.get(ns)
                    if s2 is None:
                        obs_sets[ns] = set(obsset)
                        nxt.append(ns)
                    else:
                        s2 |= obsset

    out = []
    for o, mem in outcomes:
        reads = []
        for t in range(nt):
            lst = []
            for slot in slots[t]:
                lst.append((o >> (32 * slot)) & 0xFFFFFFFF)
            reads.append(lst)
        out.append({'reads': reads,
                    'memory': [(mem >> (8 * i)) & 0xFF for i in range(nmem)]})
    return {'outcomes': out}


if __name__ == '__main__':
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))), flush=True)
