#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin, writes one JSON response per
line to stdout.  See instruction.md for the format description.
"""

import json
import re
import string
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_SIZE = 13
CRC_SIZE = 4

BEGIN = 1
PATCH = 2
COMMIT = 3
ABORT = 4

_HEX_DIGITS = set(string.hexdigits)
_HEX_ONLY = re.compile(r"\A[0-9a-fA-F]*\Z")


def hex_to_bytes(text):
    """Decode a hex string, tolerating a torn final nibble / corrupt tail.

    Only complete hex byte pairs are decoded; anything from the first invalid
    pair onward (including a lone trailing nibble) is treated as a torn tail.
    """
    if _HEX_ONLY.match(text):
        if len(text) % 2 == 0:
            return bytes.fromhex(text)
        return bytes.fromhex(text[:-1])
    out = bytearray()
    i = 0
    n = len(text)
    while i + 1 < n:
        a = text[i]
        b = text[i + 1]
        if a in _HEX_DIGITS and b in _HEX_DIGITS:
            out.append(int(a + b, 16))
            i += 2
        else:
            break
    return bytes(out)


def solve(request):
    pages = [bytearray(hex_to_bytes(p)) for p in request["pages"]]
    page_count = len(pages)
    page_lengths = [len(p) for p in pages]
    checkpoint = request["checkpoint"]
    data = hex_to_bytes(request["log"])
    total = len(data)

    pos = 0
    valid_bytes = 0
    last_seq = 0
    # transaction id -> [patch_count, running_crc, [patch payloads]]
    active = {}

    while total - pos >= HEADER_SIZE:
        payload_length = int.from_bytes(data[pos:pos + 4], "little")
        if payload_length > MAX_PAYLOAD:
            break
        record_end = pos + HEADER_SIZE + payload_length + CRC_SIZE
        if record_end > total:
            break

        header = data[pos:pos + HEADER_SIZE]
        payload_start = pos + HEADER_SIZE
        payload = data[payload_start:payload_start + payload_length]
        stored_crc = int.from_bytes(
            data[payload_start + payload_length:record_end], "little"
        )
        if (zlib.crc32(payload, zlib.crc32(header)) & 0xFFFFFFFF) != stored_crc:
            break

        sequence = int.from_bytes(header[4:8], "little")
        kind = header[8]
        transaction_id = int.from_bytes(header[9:13], "little")

        if sequence == 0 or sequence <= last_seq:
            break
        if transaction_id == 0:
            break

        if kind == BEGIN or kind == ABORT:
            if payload_length != 0:
                break
        elif kind == PATCH:
            if payload_length < 7:
                break
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            if page_index >= page_count:
                break
            if byte_offset + byte_count > page_lengths[page_index]:
                break
        elif kind == COMMIT:
            if payload_length != 8:
                break
        else:
            break

        # Record is structurally valid: it is part of the prefix.
        valid_bytes = record_end
        last_seq = sequence

        if kind == BEGIN:
            # Fresh incarnation, discarding any unfinished one.
            active[transaction_id] = [0, 0, []]
        elif kind == PATCH:
            incarnation = active.get(transaction_id)
            if incarnation is not None:
                incarnation[0] += 1
                incarnation[1] = zlib.crc32(payload, incarnation[1]) & 0xFFFFFFFF
                incarnation[2].append(payload)
        elif kind == ABORT:
            active.pop(transaction_id, None)
        else:  # COMMIT
            incarnation = active.pop(transaction_id, None)
            if incarnation is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (
                    patch_count == incarnation[0]
                    and digest == incarnation[1]
                    and sequence > checkpoint
                ):
                    for patch in incarnation[2]:
                        page_index = int.from_bytes(patch[0:2], "little")
                        byte_offset = int.from_bytes(patch[2:4], "little")
                        byte_count = int.from_bytes(patch[4:6], "little")
                        pages[page_index][byte_offset:byte_offset + byte_count] = (
                            patch[6:6 + byte_count]
                        )

        pos = record_end

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    stdout = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        response = solve(json.loads(line))
        stdout.write(json.dumps(response))
        stdout.write("\n")
        stdout.flush()


if __name__ == "__main__":
    main()
