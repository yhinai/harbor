#!/usr/bin/env python3
"""Linearizability / serializability checker for atomic range transactions.

A whole transaction is one atomic operation, so a witness is a linear extension
of the real-time precedence partial order (A.end <= B.start  =>  A before B)
whose sequential execution from `initial` reproduces every observed value and
ends exactly at `final`.

Core observation used for speed: because every operation carries its expected
result, a transaction's *write* effect is statically determined (put/del always
write; a cas writes exactly when it is expected to succeed, and then it writes a
known value).  Hence a transaction is

    state --(if its read constraints hold)--> state overlaid with fixed writes

which makes strong static reasoning possible:

  * the last writer of a key must be one of the transactions whose net write of
    that key equals the final value and which can still be ordered last;
  * a read of a key must be fed by the initial value or by some transaction
    whose net write of that key matches the observed value and which can be
    ordered before the reader.

Both give implied precedence edges (and quick refutations), which are
propagated to a fixed point before a memoized DFS over linear extensions.
"""

import json
import sys
import time

ABSENT = object()          # key not present in the map
K_EQ, K_ABS, K_NE = 0, 1, 2  # constraint kinds on a state slot


class Infeasible(Exception):
    """Raised when it is proven that no witness exists."""


class Budget(Exception):
    """Raised when a safety-net search runs out of its node budget."""


def obs(v):
    """Observed value of a slot: a missing key reads as null."""
    return None if v is ABSENT else v


def _bits(m):
    while m:
        b = m & -m
        yield b.bit_length() - 1
        m ^= b


def _closure(pred, n):
    """Transitive closure: anc[i] = bitmask of transactions that must precede i."""
    anc = list(pred)
    for k in range(n):
        ak = anc[k]
        if not ak:
            continue
        bk = 1 << k
        for i in range(n):
            if anc[i] & bk:
                anc[i] |= ak
    return anc


# --------------------------------------------------------------------------
# compilation of one transaction
# --------------------------------------------------------------------------

def _compile(t, kidx, keys):
    """Return (constraints, writes).

    constraints : tuple of (kind, slot, value)
        K_EQ  -- obs(state[slot]) == value        (get / cas-success / scan pair)
        K_ABS -- state[slot] is exactly absent    (scan: key not in the pairs)
        K_NE  -- obs(state[slot]) != value        (cas expected to fail)
    writes      : tuple of (slot, value) net effect on the map (last write wins)
    Raises Infeasible when the transaction can never be applied.
    """
    cl = []
    wr = {}
    cur = {}   # slot -> value already written inside this transaction
    bad = False

    for op in t['ops']:
        kind = op[0]
        if kind == 'get':
            idx = kidx.get(op[1]) if isinstance(op[1], str) else None
            if idx is None:
                bad = True
            elif idx in cur:
                if obs(cur[idx]) != op[2]:
                    bad = True
            else:
                cl.append((K_EQ, idx, op[2]))
        elif kind == 'put':
            idx = kidx.get(op[1]) if isinstance(op[1], str) else None
            if idx is None:
                bad = True
            else:
                wr[idx] = op[2]
                cur[idx] = op[2]
        elif kind == 'del':
            idx = kidx.get(op[1]) if isinstance(op[1], str) else None
            if idx is None:
                bad = True
            else:
                wr[idx] = ABSENT
                cur[idx] = ABSENT
        elif kind == 'cas':
            _, key, old, new, want = op
            idx = kidx.get(key) if isinstance(key, str) else None
            if idx is None:
                bad = True
            else:
                known = idx in cur
                ok = (obs(cur[idx]) == old) if known else None
                if want is True:
                    if ok is False:
                        bad = True           # needs success but internal value differs
                    elif ok is None:
                        cl.append((K_EQ, idx, old))
                    val = ABSENT if new is None else new
                    wr[idx] = val
                    cur[idx] = val
                elif want is False:
                    if ok is True:
                        bad = True
                    elif ok is None:
                        cl.append((K_NE, idx, old))
                    # a failed cas writes nothing
                else:
                    bad = True               # expected result is not a boolean
        elif kind == 'scan':
            low, high, pairs = op[1], op[2], op[3]
            try:
                items = [(p[0], p[1]) for p in pairs]
            except Exception:
                bad = True
                items = []
            if not (isinstance(low, str) and isinstance(high, str)):
                bad = True
            else:
                prev = None
                for k, _v in items:
                    if prev is not None and not prev < k:
                        bad = True   # pairs must come out sorted with unique keys
                    prev = k
                expmap = dict(items)
                for k in expmap:
                    if k not in kidx or not (low <= k < high):
                        bad = True   # a key that can never be present / out of range
                if not bad:
                    for k in keys:
                        if not (low <= k < high):
                            continue
                        idx = kidx[k]
                        if k in expmap:
                            if idx in cur:
                                if obs(cur[idx]) != expmap[k]:
                                    bad = True
                            else:
                                cl.append((K_EQ, idx, expmap[k]))
                        else:
                            if idx in cur:
                                if cur[idx] is not ABSENT:
                                    bad = True   # would appear in the scan result
                            else:
                                cl.append((K_ABS, idx, None))
        else:
            bad = True

    if bad:
        raise Infeasible()
    return tuple(cl), tuple(sorted(wr.items()))


# --------------------------------------------------------------------------
# main solver
# --------------------------------------------------------------------------

def _solve(req):
    initial = req.get('initial') or {}
    final = req.get('final') or {}
    txs = req.get('transactions') or []
    n = len(txs)

    if n == 0:
        return [] if dict(initial) == dict(final) else None

    ids = [t['id'] for t in txs]
    starts = [t['start'] for t in txs]
    ends = [t['end'] for t in txs]

    ks = set(initial) | set(final)
    for t in txs:
        for op in t['ops']:
            if op[0] in ('get', 'put', 'del', 'cas') and isinstance(op[1], str):
                ks.add(op[1])
    keys = sorted(ks)
    K = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}
    slots0 = tuple(initial.get(k, ABSENT) for k in keys)
    final_slots = tuple(final.get(k, ABSENT) for k in keys)

    cons = []
    wr_list = []
    for t in txs:
        c, w = _compile(t, kidx, keys)
        cons.append(c)
        wr_list.append(w)

    # ---- per-key writer tables -------------------------------------------
    WR = [dict() for _ in range(K)]      # WR[slot] = {tx index: written value}
    writer_mask = [0] * K                # bitmask of transactions writing the slot
    for i in range(n):
        for idx, v in wr_list[i]:
            WR[idx][i] = v
            writer_mask[idx] |= 1 << i

    # ---- real time precedence -------------------------------------------
    rt_pred = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and ends[j] <= starts[i]:
                rt_pred[i] |= 1 << j

    # ---- static propagation of implied precedence -----------------------
    edges = list(rt_pred)
    while True:
        anc = _closure(edges, n)
        for i in range(n):
            if (anc[i] >> i) & 1:
                raise Infeasible()        # the implied constraints are cyclic
        changed = False

        # (a) the last writer of each key must be able to produce the final value
        last_ok = [0] * K
        for idx in range(K):
            W = writer_mask[idx]
            if W == 0:
                if slots0[idx] != final_slots[idx]:
                    raise Infeasible()
                continue
            ok = 0
            for L in _bits(W):
                if WR[idx].get(L) != final_slots[idx]:
                    continue
                good = True
                for b in _bits(W):
                    if b != L and (anc[b] >> L) & 1:
                        good = False      # b is forced after L, so L cannot be last
                        break
                if good:
                    ok |= 1 << L
            if ok == 0:
                raise Infeasible()
            last_ok[idx] = ok
            if ok & (ok - 1) == 0:        # unique possible last writer
                L = ok.bit_length() - 1
                for b in _bits(W):
                    if b != L and not (edges[L] >> b) & 1:
                        edges[L] |= 1 << b
                        changed = True

        # (b) every read must be fed by the initial value or by a matching writer
        fc = []
        for i in range(n):
            fcl = []
            for (kind, idx, val) in cons[i]:
                prov = 0
                for U, w in WR[idx].items():
                    if U == i or (anc[U] >> i) & 1:
                        continue          # U cannot be ordered before i
                    if kind == K_EQ:
                        m = (obs(w) == val)
                    elif kind == K_ABS:
                        m = (w is ABSENT)
                    else:
                        m = (obs(w) != val)
                    if m:
                        prov |= 1 << U
                if kind == K_EQ:
                    init_ok = (obs(slots0[idx]) == val)
                elif kind == K_ABS:
                    init_ok = (slots0[idx] is ABSENT)
                else:
                    init_ok = (obs(slots0[idx]) != val)

                if prov == 0 and not init_ok:
                    raise Infeasible()    # nothing can ever feed this read
                if prov == 0:
                    # the value must still be the initial one: nobody may write before
                    for U in WR[idx]:
                        if U != i and not (edges[U] >> i) & 1:
                            edges[U] |= 1 << i
                            changed = True
                elif prov & (prov - 1) == 0 and not init_ok:
                    U = prov.bit_length() - 1
                    if not (edges[i] >> U) & 1:
                        edges[i] |= 1 << U
                        changed = True
                fcl.append((idx, kind, val, prov, init_ok))
            fc.append(tuple(fcl))
        if not changed:
            break

    full = (1 << n) - 1

    # ---- per transaction applicability (cached on the slots it depends on) --
    deps = []
    for i in range(n):
        s = set()
        for (_k, idx, _v) in cons[i]:
            s.add(idx)
        deps.append(tuple(sorted(s)))
    caches = [dict() for _ in range(n)]
    has_cons = any(cons[i] for i in range(n))

    def applicable(i, state):
        d = deps[i]
        if not d:
            return True
        if len(d) == 1:
            k = (state[d[0]],)
        else:
            k = (state[d[0]],) + tuple(state[j] for j in d[1:])
        c = caches[i]
        r = c.get(k)
        if r is None:
            r = True
            for (kind, idx, val) in cons[i]:
                s = state[idx]
                if kind == K_EQ:
                    if (s if s is not ABSENT else None) != val:
                        r = False
                        break
                elif kind == K_ABS:
                    if s is not ABSENT:
                        r = False
                        break
                else:
                    if (s if s is not ABSENT else None) == val:
                        r = False
                        break
            c[k] = r
        return r

    def apply_writes(i, state):
        w = wr_list[i]
        if not w:
            return state
        lst = list(state)
        for idx, v in w:
            lst[idx] = v
        return tuple(lst)

    def forward_ok(done, state):
        """Cheap necessary conditions for completing from this node."""
        rem = full & ~done
        for idx in range(K):
            w = rem & writer_mask[idx]
            if w:
                if not (w & last_ok[idx]):
                    return False
            elif state[idx] != final_slots[idx]:
                return False
        if rem and has_cons:
            for i in _bits(rem):
                for (idx, kind, val, prov, init_ok) in fc[i]:
                    s = state[idx]
                    if kind == K_EQ:
                        if (s if s is not ABSENT else None) == val:
                            continue
                    elif kind == K_ABS:
                        if s is ABSENT:
                            continue
                    else:
                        if (s if s is not ABSENT else None) != val:
                            continue
                    if prov & rem:
                        continue
                    if init_ok and not (rem & writer_mask[idx] & ~(1 << i) & anc[i]):
                        continue
                    return False
        return True

    cand_order = sorted(range(n), key=lambda i: (ends[i], starts[i], i))
    dead = set()

    def dfs(done, state):
        if done == full:
            return () if state == final_slots else None
        dkey = (done, state)
        if dkey in dead:
            return None
        for i in cand_order:
            b = 1 << i
            if done & b:
                continue
            if anc[i] & ~done:
                continue
            if not applicable(i, state):
                continue
            nstate = apply_writes(i, state)
            ndone = done | b
            if not forward_ok(ndone, nstate):
                continue
            sub = dfs(ndone, nstate)
            if sub is not None:
                return (i,) + sub
        dead.add(dkey)
        return None

    order = dfs(0, slots0)
    if order is None:
        return None
    return [ids[i] for i in order]


# --------------------------------------------------------------------------
# independent safety nets: a literal simulator and an unoptimised search
# --------------------------------------------------------------------------

def simulate(t, d):
    """Apply one transaction to dict d; return the new dict or None if any
    observed value mismatches.  Follows the specification literally."""
    d = dict(d)
    for op in t['ops']:
        o = op[0]
        if o == 'get':
            if d.get(op[1]) != op[2]:
                return None
        elif o == 'put':
            d[op[1]] = op[2]
        elif o == 'del':
            d.pop(op[1], None)
        elif o == 'cas':
            _t, key, old, new, want = op
            ok = (d.get(key) == old)
            if ok is not want:
                return None
            if ok:
                if new is None:
                    d.pop(key, None)
                else:
                    d[key] = new
        elif o == 'scan':
            try:
                got = sorted([[k, v] for k, v in d.items() if op[1] <= k < op[2]])
            except TypeError:
                return None
            if got != op[3]:
                return None
        else:
            return None
    return d


def verify(req, order):
    """Literal check of a witness against the specification."""
    tx = {t['id']: t for t in req['transactions']}
    if not isinstance(order, list) or len(order) != len(tx) or set(order) != set(tx):
        return False
    ranks = {x: i for i, x in enumerate(order)}
    for a in tx.values():
        for b in tx.values():
            if a['end'] <= b['start'] and ranks[a['id']] >= ranks[b['id']]:
                return False
    d = dict(req.get('initial') or {})
    for name in order:
        d2 = simulate(tx[name], d)
        if d2 is None:
            return False
        d = d2
    return d == (req.get('final') or {})


def naive_search(req, node_budget=60000, deadline=None):
    """Unoptimised exact search: literal simulation, real-time order only, no
    derived constraints.  Used purely as a safety net; it gives up (raising
    Budget) once its node budget is exhausted."""
    txs = req['transactions']
    n = len(txs)
    init = dict(req.get('initial') or {})
    fin = req.get('final') or {}
    if n == 0:
        return [] if init == fin else None
    ends = [t['end'] for t in txs]
    starts = [t['start'] for t in txs]
    pred = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and ends[j] <= starts[i]:
                pred[i] |= 1 << j
    full = (1 << n) - 1
    dead = set()
    budget_ticks = [0]

    def tick():
        budget_ticks[0] += 1
        if budget_ticks[0] > node_budget:
            raise Budget()
        if deadline is not None and not budget_ticks[0] & 255 \
                and time.monotonic() > deadline:
            raise Budget()

    def dfs(done, d):
        tick()
        if done == full:
            return () if d == fin else None
        key = (done, tuple(sorted(d.items())))
        if key in dead:
            return None
        for i in range(n):
            b = 1 << i
            if done & b or (pred[i] & ~done):
                continue
            nd = simulate(txs[i], d)
            if nd is None:
                continue
            sub = dfs(done | b, nd)
            if sub is not None:
                return (i,) + sub
        dead.add(key)
        return None

    res = dfs(0, dict(init))
    if res is None:
        return None
    return [txs[i]['id'] for i in res]


# --------------------------------------------------------------------------

def solve(req):
    order = None
    try:
        order = _solve(req)
    except Infeasible:
        order = None
    except Exception as exc:            # pragma: no cover - defensive
        sys.stderr.write('solver error: %r\n' % (exc,))
        order = None

    if order is not None and not verify(req, order):
        # should never happen; fall back to the literal search
        sys.stderr.write('witness rejected by verifier, retrying\n')
        order = None

    if order is None and len(req.get('transactions') or []) >= 2:
        try:
            alt = naive_search(req, deadline=time.monotonic() + 0.6)
            if alt is not None:
                order = alt
        except Budget:
            pass
        except Exception as exc:        # pragma: no cover - defensive
            sys.stderr.write('fallback error: %r\n' % (exc,))
    return {'order': order}


def main():
    out = []
    data = sys.stdin.read()
    for line in data.splitlines():
        if not line.strip():
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))


if __name__ == '__main__':
    main()
