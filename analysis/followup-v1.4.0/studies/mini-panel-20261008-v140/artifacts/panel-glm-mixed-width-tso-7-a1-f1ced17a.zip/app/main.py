#!/usr/bin/env python3
"""Enumerate all terminal observable outcomes of the mixed-width buffered machine.

Model (deliberately specified TSO-like teaching model):

  * Each thread has a program counter, a FIFO store buffer and an observation list.
  * store  -> appends (address,width,value) to the issuing thread's buffer, advances pc.
  * load   -> per byte: youngest own buffered store covering that byte wins, else
              shared memory; assembled little-endian into one unsigned value which is
              appended to the thread's observations; advances pc.  Never blocks.
  * fence  -> enabled only when the issuing thread's buffer is empty.
  * xchg   -> enabled only when the issuing thread's buffer is empty; atomically reads
              the shared-memory value, appends it to the observations and writes the
              supplied value to shared memory.
  * drain  -> moves the oldest store of any non-empty buffer into shared memory,
              all of its bytes at once.

A state is terminal when every thread is finished and every buffer is empty.  All
transitions are atomic, multi-byte accesses included.

The search is a dynamic program over "machine states" (shared memory, program
counters, drained-store counts).  Everything a thread still has buffered is
determined by (pc, drained-count), because the buffer is FIFO and stores enter in
program order.  The future behaviour of a machine state does not depend on the
observations made so far, so the set of (suffix observations, final memory) pairs
is memoised per machine state and shared by every path reaching it.
"""

import json
import sys


def _payload(value, width):
    """Little-endian byte tuple of an unsigned value of the given width."""
    return tuple((value >> (8 * i)) & 0xFF for i in range(width))


def _read(mem, addr, width):
    """Assemble `width` bytes of shared memory at `addr` (little-endian)."""
    val = 0
    for i in range(width - 1, -1, -1):
        val = (val << 8) | mem[addr + i]
    return val


def _write(mem, addr, payload):
    if not payload:
        return mem
    start = addr
    stop = addr + len(payload)
    return mem[:start] + tuple(payload) + mem[stop:]


def solve(request):
    mem0 = tuple(request['memory'])
    programs = []
    for thread in request['threads']:
        instrs = []
        for op in thread:
            kind = op[0]
            if kind == 'store':
                addr, width, value = op[1], op[2], op[3]
                instrs.append(('store', addr, _payload(value, width)))
            elif kind == 'load':
                instrs.append(('load', op[1], op[2]))
            elif kind == 'fence':
                instrs.append(('fence',))
            elif kind == 'xchg':
                addr, width, value = op[1], op[2], op[3]
                instrs.append(('xchg', addr, _payload(value, width)))
            else:
                raise ValueError('unknown instruction %r' % (kind,))
        programs.append(tuple(instrs))

    nthreads = len(programs)

    # stores_before[t][pc] = number of stores issued by thread t among instrs[:pc]
    # store_list[t][k]     = the k-th store of thread t as (address, byte payload)
    stores_before = []
    store_list = []
    for instrs in programs:
        prefix = [0]
        issued = []
        for ins in instrs:
            if ins[0] == 'store':
                issued.append((ins[1], ins[2]))
            prefix.append(len(issued))
        stores_before.append(tuple(prefix))
        store_list.append(tuple(issued))

    lengths = tuple(len(p) for p in programs)
    no_reads = tuple(tuple() for _ in range(nthreads))
    memo = {}

    def buffered(t, pc, drained):
        """Contents of thread t's FIFO buffer (oldest first)."""
        return store_list[t][drained:stores_before[t][pc]]

    def load_value(mem, buf, addr, width):
        val = 0
        for i in range(width - 1, -1, -1):
            b = addr + i
            byte = None
            for saddr, payload in reversed(buf):
                if saddr <= b < saddr + len(payload):
                    byte = payload[b - saddr]
                    break
            if byte is None:
                byte = mem[b]
            val = (val << 8) | byte
        return val

    def transitions(state):
        """Yield (child_state, thread, observed_value_or_None) for enabled steps."""
        mem, pcs, drains = state
        for t in range(nthreads):
            pc = pcs[t]
            drained = drains[t]
            issued = stores_before[t][pc]
            if pc < lengths[t]:
                ins = programs[t][pc]
                kind = ins[0]
                npc = pc + 1
                new_pcs = pcs[:t] + (npc,) + pcs[t + 1:]
                if kind == 'store':
                    yield ((mem, new_pcs, drains), t, None)
                elif kind == 'load':
                    addr, width = ins[1], ins[2]
                    buf = buffered(t, pc, drained)
                    val = load_value(mem, buf, addr, width)
                    yield ((mem, new_pcs, drains), t, val)
                elif kind == 'fence':
                    if drained == issued:
                        yield ((mem, new_pcs, drains), t, None)
                else:  # xchg
                    if drained == issued:
                        addr, payload = ins[1], ins[2]
                        val = _read(mem, addr, len(payload))
                        yield ((_write(mem, addr, payload), new_pcs, drains), t, val)
            if drained < issued:
                # drain the oldest buffered store of thread t
                addr, payload = store_list[t][drained]
                new_drains = drains[:t] + (drained + 1,) + drains[t + 1:]
                yield ((_write(mem, addr, payload), pcs, new_drains), t, None)

    def dfs(state):
        """Set of (per-thread observations from here on, final memory) pairs."""
        cached = memo.get(state)
        if cached is not None:
            return cached
        mem, pcs, drains = state
        results = set()
        terminal = True
        for t in range(nthreads):
            if pcs[t] != lengths[t] or drains[t] != stores_before[t][pcs[t]]:
                terminal = False
                break
        if terminal:
            results.add((no_reads, mem))
        else:
            for child, t, observed in transitions(state):
                sub = dfs(child)
                if observed is None:
                    results |= sub
                else:
                    for reads, final_mem in sub:
                        grown = list(reads)
                        grown[t] = (observed,) + reads[t]
                        results.add((tuple(grown), final_mem))
        memo[state] = results
        return results

    outcomes = dfs((mem0, (0,) * nthreads, (0,) * nthreads))

    rendered = []
    for reads, final_mem in sorted(outcomes, key=repr):
        rendered.append({
            'reads': [list(r) for r in reads],
            'memory': list(final_mem),
        })
    return {'outcomes': rendered}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    if out:
        sys.stdout.write('\n'.join(out) + '\n')


if __name__ == '__main__':
    sys.setrecursionlimit(100000)
    main()
