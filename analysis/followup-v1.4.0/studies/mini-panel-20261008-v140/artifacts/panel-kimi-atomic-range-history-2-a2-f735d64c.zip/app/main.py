import json
import sys

# Operation tags (internal)
GET, PUT, DEL, CAS, SCAN = range(5)
UNKNOWN = object()  # sentinel: transaction's effect on a key depends on input


def solve(request):
    txs = request.get('transactions') or []
    initial = request.get('initial') or {}
    final = request.get('final') or {}
    n = len(txs)

    if n == 0:
        return {"order": [] if initial == final else None}

    # Universe of keys that can ever be present in the map.
    keyset = set(initial) | set(final)
    for t in txs:
        for op in t['ops']:
            if op[0] != 'scan':
                keyset.add(op[1])
    keys = sorted(keyset)
    K = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    # Compile operations to work on a value tuple aligned with `keys`.
    # None represents an absent key.
    compiled = []
    for t in txs:
        c = []
        for op in t['ops']:
            tag = op[0]
            if tag == 'get':
                c.append((GET, kidx[op[1]], op[2]))
            elif tag == 'put':
                c.append((PUT, kidx[op[1]], op[2]))
            elif tag == 'del':
                c.append((DEL, kidx[op[1]]))
            elif tag == 'cas':
                c.append((CAS, kidx[op[1]], op[2], op[3], op[4]))
            else:  # scan
                lo, hi, exp = op[1], op[2], op[3]
                idxs = tuple(j for j, k in enumerate(keys) if lo <= k < hi)
                c.append((SCAN, idxs, exp))
        compiled.append(c)

    init_state = tuple(initial.get(k) for k in keys)
    final_state = tuple(final.get(k) for k in keys)

    starts = [t['start'] for t in txs]
    ends = [t['end'] for t in txs]

    # Per (tx, key): cert = value the tx certainly leaves (UNKNOWN if it may
    # depend on the incoming state), poss = set of values it may leave for
    # some incoming state.
    cert = [[UNKNOWN] * K for _ in range(n)]
    poss = [None] * n
    for i, c in enumerate(compiled):
        pc = [set() for _ in range(K)]
        poss[i] = pc
        for op in c:
            tag = op[0]
            if tag == PUT or tag == DEL:
                v = op[2] if tag == PUT else None
                cert[i][op[1]] = v
                pc[op[1]] = {v}
            elif tag == CAS:
                j = op[1]
                old, new = op[2], op[3]
                if cert[i][j] is UNKNOWN:
                    pc[j].add(new)
                else:
                    cert[i][j] = new if cert[i][j] == old else cert[i][j]
                    pc[j] = {cert[i][j]}

    # Real-time precedence: j must precede i iff end[j] <= start[i].
    pre = [0] * n
    for i in range(n):
        m = 0
        si = starts[i]
        for j in range(n):
            if j != i and ends[j] <= si:
                m |= 1 << j
        pre[i] = m

    # Producer mask per key: which txs may leave each value.
    # Derived precedence: in any witness the last effective writer of key j
    # must be able to leave final[j]. If exactly one tx w can, every tx that
    # certainly leaves a different value must precede w.
    prod = [dict() for _ in range(K)]  # key -> {value: bitmask}
    impossible = False
    for j in range(K):
        pm = prod[j]
        for i in range(n):
            for v in poss[i][j]:
                pm[v] = pm.get(v, 0) | (1 << i)
        fj = final_state[j]
        S = [i for i in range(n) if poss[i][j]]
        if not S:
            continue
        P = [i for i in S if fj in poss[i][j]]
        if not P:
            # Nobody can leave the final value: hopeless if some tx certainly
            # rewrites the key, or the persisted initial value is wrong too.
            if init_state[j] != fj or any(cert[i][j] is not UNKNOWN for i in S):
                impossible = True
                break
            continue
        if len(P) == 1:
            w = P[0]
            for u in S:
                if u != w and cert[u][j] is not UNKNOWN and cert[u][j] != fj:
                    pre[w] |= 1 << u

    if not impossible:
        # Transitive closure of precedence; a cycle means no witness.
        for i in range(n):
            m = pre[i]
            while True:
                add = 0
                mm = m
                while mm:
                    b = mm & (-mm)
                    add |= pre[b.bit_length() - 1]
                    mm ^= b
                add &= ~m
                if not add:
                    break
                m |= add
            pre[i] = m
            if (m >> i) & 1:
                impossible = True
                break
    if impossible:
        return {"order": None}

    full = (1 << n) - 1
    # Try candidates in time order: usually finds a witness quickly.
    cand = sorted(range(n), key=lambda i: (starts[i], ends[i], i))

    memo = set()  # failed (placed_mask, state) entries

    def simulate(c, state):
        vals = list(state)
        for op in c:
            tag = op[0]
            if tag == GET:
                if vals[op[1]] != op[2]:
                    return None
            elif tag == PUT:
                vals[op[1]] = op[2]
            elif tag == DEL:
                vals[op[1]] = None
            elif tag == CAS:
                ok = vals[op[1]] == op[2]
                if ok != op[4]:
                    return None
                if ok:
                    vals[op[1]] = op[3]  # op[3] is None -> delete
            else:  # SCAN
                got = [[keys[j], vals[j]] for j in op[1] if vals[j] is not None]
                if got != op[2]:
                    return None
        return tuple(vals)

    def dfs(placed, state):
        if placed == full:
            return () if state == final_state else None
        entry = (placed, state)
        if entry in memo:
            return None
        remaining = full ^ placed
        # Prune: every key whose current value differs from its final value
        # needs some remaining transaction able to leave the final value.
        for j in range(K):
            fj = final_state[j]
            if state[j] != fj and not (prod[j].get(fj, 0) & remaining):
                memo.add(entry)
                return None
        for i in cand:
            b = 1 << i
            if (placed & b) or (pre[i] & remaining):
                continue
            ns = simulate(compiled[i], state)
            if ns is None:
                continue
            r = dfs(placed | b, ns)
            if r is not None:
                return (i,) + r
        memo.add(entry)
        return None

    path = dfs(0, init_state)
    if path is None:
        return {"order": None}
    return {"order": [txs[i]['id'] for i in path]}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            out.append(json.dumps(solve(json.loads(line))))
        except Exception as exc:  # defensive: never crash the batch
            print('error: %r' % (exc,), file=sys.stderr)
            out.append(json.dumps({"order": None}))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))


if __name__ == '__main__':
    main()
