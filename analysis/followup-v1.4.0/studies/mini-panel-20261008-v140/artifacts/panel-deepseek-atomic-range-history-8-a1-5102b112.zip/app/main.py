#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Each transaction is one atomic operation.  We must find a serial order of the
transactions that (a) respects real-time order (A.end <= B.start  =>  A before B)
and (b) reproduces every observation and the final map.

Approach: meet in the middle over the partial order.
  * Forward: for every downset S of size h = ceil(n/2), compute all concrete
    states reachable by executing exactly S in some linear extension.
  * Backward: for every upset C of size n-h, compute all states from which the
    transactions of C can be executed (respecting their internal order) and
    still reach the final state.  Such sets are unions of "patterns"; a pattern
    is a per-key set of allowed values (20-bit mask: values -9..9 plus absent).
    Because every CAS outcome is fixed by expected_success, the preimage of a
    product set under one transaction is again a single product set, so each
    upset of size k contributes at most k! patterns.
Any valid serial order has a prefix downset S of size h; matching a forward
state of S against a backward pattern of C = complement(S) yields a witness.
"""

import json
import sys

ABSENT = 19          # encoded value for a missing key
FULL = (1 << 20) - 1  # all 20 encoded values allowed


def _enc(v):
    """Encode an integer in [-9,9] or None (absent) as 0..19."""
    return ABSENT if v is None else v + 9


def _apply(comp, state):
    """Execute a compiled transaction on a concrete state.

    Returns the new state tuple, or None if an observation fails.
    """
    st = list(state)
    for op in comp:
        c = op[0]
        if c == 1:                      # put
            st[op[1]] = op[2]
        elif c == 2:                    # del
            st[op[1]] = ABSENT
        elif c == 0:                    # get
            if st[op[1]] != op[2]:
                return None
        elif c == 3:                    # cas
            i = op[1]
            cur = st[i]
            out = (cur == op[2])
            if out != op[4]:
                return None
            if out:
                st[i] = op[3]
        else:                           # scan
            actual = []
            for i, ks, _e in op[1]:
                v = st[i]
                if v != ABSENT:
                    actual.append((ks, v))
            if actual != list(op[2]):
                return None
    return tuple(st)


def _preimage(comp, pattern, m):
    """Preimage of a product-set pattern under one transaction.

    Returns the pattern (tuple of allowed-value masks) of all states s such
    that executing the transaction from s succeeds and ends in a state that
    matches `pattern`, or None if there is no such state.
    """
    constraints = [FULL] * m
    pending = [None] * m       # None = still the initial value (symbolic)
    for op in comp:
        c = op[0]
        if c == 1:                      # put
            pending[op[1]] = op[2]
        elif c == 2:                    # del
            pending[op[1]] = ABSENT
        elif c == 0:                    # get
            i = op[1]
            e = op[2]
            pv = pending[i]
            if pv is not None:
                if pv != e:
                    return None
            else:
                constraints[i] &= 1 << e
                if constraints[i] == 0:
                    return None
        elif c == 3:                    # cas
            i = op[1]
            o = op[2]
            nv = op[3]
            succ = op[4]
            pv = pending[i]
            if pv is not None:
                out = (pv == o)
                if out != succ:
                    return None
                if out:
                    pending[i] = nv
            else:
                if succ:
                    constraints[i] &= 1 << o
                    if constraints[i] == 0:
                        return None
                    pending[i] = nv
                else:
                    constraints[i] &= FULL ^ (1 << o)
                    if constraints[i] == 0:
                        return None
        else:                           # scan
            for i, _ks, e in op[1]:
                pv = pending[i]
                if pv is not None:
                    if pv != e:
                        return None
                else:
                    constraints[i] &= 1 << e
                    if constraints[i] == 0:
                        return None
    # Post-state: written keys are constants, others keep their initial value.
    for i in range(m):
        pv = pending[i]
        if pv is not None:
            if not (pattern[i] >> pv) & 1:
                return None
        else:
            constraints[i] &= pattern[i]
            if constraints[i] == 0:
                return None
    return tuple(constraints)


def solve(request):
    initial = request.get("initial") or {}
    final = request.get("final") or {}
    txs = request.get("transactions") or []
    n = len(txs)

    # ---- key universe (keys never mentioned are always absent) ----
    keyset = set(initial) | set(final)
    for t in txs:
        for op in t.get("ops") or []:
            kind = op[0]
            if kind == "scan":
                keyset.add(op[1])
                keyset.add(op[2])
                for pair in op[3]:
                    keyset.add(pair[0])
            elif kind in ("get", "put", "del", "cas"):
                keyset.add(op[1])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}
    m = len(keys)

    init_state = tuple(_enc(initial.get(k)) for k in keys)
    final_state = tuple(_enc(final.get(k)) for k in keys)
    final_pattern = tuple(1 << e for e in final_state)

    # ---- compile operations ----
    compiled = []
    for t in txs:
        ops = []
        good = True
        for op in t.get("ops") or []:
            kind = op[0]
            if kind == "get":
                ops.append((0, kidx[op[1]], _enc(op[2])))
            elif kind == "put":
                ops.append((1, kidx[op[1]], _enc(op[2])))
            elif kind == "del":
                ops.append((2, kidx[op[1]]))
            elif kind == "cas":
                ops.append((3, kidx[op[1]], _enc(op[2]), _enc(op[3]), bool(op[4])))
            elif kind == "scan":
                low, high = op[1], op[2]
                exp = op[3]
                exp_map = {}
                exp_list = []
                bad = not (isinstance(low, str) and isinstance(high, str) and low < high)
                if not bad:
                    for pair in exp:
                        kk = pair[0]
                        if kk in exp_map or kk not in kidx or not (low <= kk < high):
                            bad = True
                            break
                        e = _enc(pair[1])
                        exp_map[kk] = e
                        exp_list.append((kk, e))
                if not bad:
                    for a, b in zip(exp_list, exp_list[1:]):
                        if a[0] >= b[0]:
                            bad = True
                            break
                if bad:
                    good = False
                    break
                items = tuple(
                    (i, keys[i], exp_map.get(keys[i], ABSENT))
                    for i in range(m) if low <= keys[i] < high
                )
                ops.append((4, items, tuple(exp_list)))
            else:
                good = False
                break
        compiled.append(ops if good else None)

    # ---- real-time partial order ----
    # edge j -> i  iff  txs[j].end <= txs[i].start
    pred = [0] * n
    succ = [0] * n
    for i in range(n):
        si = txs[i].get("start", 0)
        for j in range(n):
            if i != j and txs[j].get("end", 0) <= si:
                pred[i] |= 1 << j
                succ[j] |= 1 << i

    full = (1 << n) - 1
    if n == 0:
        return [] if init_state == final_state else None

    # ---- downsets / upsets grouped by size ----
    downsets = [[] for _ in range(n + 1)]
    upsets = [[] for _ in range(n + 1)]
    for mask in range(full + 1):
        okd = oku = True
        x = mask
        while x:
            b = x & (-x)
            i = b.bit_length() - 1
            if pred[i] & ~mask:
                okd = False
            if succ[i] & ~mask:
                oku = False
            if not okd and not oku:
                break
            x ^= b
        if okd:
            downsets[bin(mask).count("1")].append(mask)
        if oku:
            upsets[bin(mask).count("1")].append(mask)

    h = (n + 1) // 2          # forward prefix size
    maxc = n - h              # backward suffix size

    # ---- forward DP over downsets ----
    # fwd[k][mask][state] = (predecessor state, transaction index)
    fwd = [dict() for _ in range(h + 1)]
    fwd[0][0] = {init_state: None}
    for k in range(h):
        nxt = fwd[k + 1]
        for mask, states in fwd[k].items():
            for i in range(n):
                bit = 1 << i
                if mask & bit or (pred[i] & ~mask):
                    continue
                comp = compiled[i]
                if comp is None:
                    continue
                nmask = mask | bit
                d = nxt.get(nmask)
                if d is None:
                    d = {}
                    nxt[nmask] = d
                for s in states:
                    ns = _apply(comp, s)
                    if ns is not None and ns not in d:
                        d[ns] = (s, i)

    # ---- backward DP over upsets ----
    # bwd[j][mask] = set of patterns; deriv[j][(mask, pattern)] = (txn, next pattern)
    bwd = [dict() for _ in range(maxc + 1)]
    deriv = [dict() for _ in range(maxc + 1)]
    bwd[0][0] = {final_pattern}
    for j in range(1, maxc + 1):
        nxt = bwd[j]
        derv = deriv[j]
        prev_layer = bwd[j - 1]
        for cmask in upsets[j]:
            for i in range(n):
                bit = 1 << i
                if not (cmask & bit) or (pred[i] & cmask):
                    continue        # i must be a source of cmask
                prev = prev_layer.get(cmask ^ bit)
                if not prev:
                    continue
                comp = compiled[i]
                if comp is None:
                    continue
                d = nxt.get(cmask)
                if d is None:
                    d = set()
                    nxt[cmask] = d
                for p in prev:
                    q = _preimage(comp, p, m)
                    if q is not None and q not in d:
                        d.add(q)
                        derv[(cmask, q)] = (i, p)

    # ---- combine ----
    for S in downsets[h]:
        C = full ^ S
        fstates = fwd[h].get(S)
        if not fstates:
            continue
        pats = bwd[maxc].get(C)
        if not pats:
            continue
        found = None
        for s in fstates:
            for p in pats:
                ok = True
                for a in range(m):
                    if not (p[a] >> s[a]) & 1:
                        ok = False
                        break
                if ok:
                    found = (s, p)
                    break
            if found is not None:
                break
        if found is None:
            continue
        s, p = found
        # forward order
        order = []
        k = h
        mask = S
        st = s
        while k:
            ps, ti = fwd[k][mask][st]
            order.append(ti)
            mask ^= 1 << ti
            st = ps
            k -= 1
        order.reverse()
        # backward order
        cmask = C
        pat = p
        j = maxc
        while j:
            ti, pp = deriv[j][(cmask, pat)]
            order.append(ti)
            cmask ^= 1 << ti
            pat = pp
            j -= 1
        # safety verification
        st = init_state
        ok = True
        for ti in order:
            st = _apply(compiled[ti], st)
            if st is None:
                ok = False
                break
        if ok and st == final_state:
            return [txs[i].get("id") for i in order]
    return None


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        order = solve(request)
        out.write(json.dumps({"order": order}) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
