#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Each request is a completed concurrent history of whole transactions (a
transaction is one atomic operation).  A witness is a serial order of the
transactions that respects real time (A.end <= B.start => A before B), in which
every observed return value matches and the resulting map equals the final map.

The checker searches serial orders with depth first search over
(prefix-of-witness, state) nodes, memoising failed nodes.  Each transaction is
compiled into a small Python function that applies its operations to a state
tuple (returning None when an observation would not match), which keeps the
inner loop fast.  Sound necessary-condition prunes (based on which values the
remaining transactions can still write / still need to read) cut off hopeless
subtrees early.

Reads newline delimited JSON requests from stdin, writes one JSON object per
input line to stdout: {"order": [...]} or {"order": null}.
"""

import json
import math
import os
import sys
import traceback

# Sentinel stored in a state slot when the key is absent (a missing key is
# different from a key holding zero, and also from a key holding null).
_A = object()

# Pruning can be disabled for experiments without changing the answer.
_PRUNE = os.environ.get("ARC_NOPRUNE") is None


class _NoWitness(Exception):
    """Raised while compiling when a transaction can never be applied."""


def _freeze(v):
    """Hashable, ==-compatible key for a JSON value (lists/dicts included)."""
    t = type(v)
    if t is list:
        return ("L",) + tuple(_freeze(x) for x in v)
    if t is dict:
        return ("D",) + tuple(sorted((_freeze(k), _freeze(x)) for k, x in v.items()))
    return v


def _unhashable(v):
    try:
        hash(v)
    except TypeError:
        return True
    return False


def _expr(v, ns):
    """Source expression for the constant v (binding exotic values in ns)."""
    t = type(v)
    if t is int or t is str or t is bool:
        return repr(v)
    if t is float and math.isfinite(v):
        return repr(v)
    name = "c%d" % len(ns)
    ns[name] = v
    return name


def _compile_txn(ops, kidx, ns, writes_out, reads_out):
    """Compile one transaction into f(state) -> new state or None.

    ``state`` is a tuple with one slot per key of the key universe; a slot is
    _A when the key is absent, the stored value otherwise (a stored null only
    for out-of-spec inputs).  The generated code mirrors the reference
    semantics exactly: a read of an absent key yields null, cas succeeds iff
    the current effective value equals the expected old value, and a scan
    reports the present keys with low <= key < high sorted by key.
    Raises _NoWitness when no state whatsoever can satisfy the transaction.
    """
    lines = ["def f(s):", "    s = list(s)"]
    for op in ops:
        if not isinstance(op, (list, tuple)) or not op:
            raise _NoWitness
        kind = op[0]
        if kind == "get":
            if len(op) < 3:
                raise _NoWitness
            e = op[2]
            i = kidx.get(op[1]) if type(op[1]) is str else None
            if i is None:
                # Such a key is never present, so the read yields null.
                if e is None:
                    continue
                raise _NoWitness
            if e is None:
                lines.append(
                    "    if s[%d] is not _A and s[%d] is not None: return None"
                    % (i, i)
                )
            else:
                lines.append("    if s[%d] != %s: return None" % (i, _expr(e, ns)))
            reads_out.append((i, _A if e is None else e))
        elif kind == "put":
            if len(op) < 3:
                raise _NoWitness
            i = kidx.get(op[1]) if type(op[1]) is str else None
            if i is None:
                raise _NoWitness  # cannot represent a write to this key
            lines.append("    s[%d] = %s" % (i, _expr(op[2], ns)))
            writes_out.append((i, op[2]))
        elif kind == "del":
            if len(op) < 2:
                raise _NoWitness
            i = kidx.get(op[1]) if type(op[1]) is str else None
            if i is None:
                continue  # key cannot be present: no effect
            lines.append("    s[%d] = _A" % i)
            writes_out.append((i, _A))
        elif kind == "cas":
            if len(op) < 5:
                raise _NoWitness
            old = op[2]
            new = op[3]
            want = op[4]
            i = kidx.get(op[1]) if type(op[1]) is str else None
            if want is True:
                if i is None:
                    # The key is never present: succeeds only when expecting
                    # null, and then only a delete is representable.
                    if old is not None or new is not None:
                        raise _NoWitness
                    continue
                if old is None:
                    lines.append(
                        "    if s[%d] is not _A and s[%d] is not None: return None"
                        % (i, i)
                    )
                else:
                    lines.append(
                        "    if s[%d] != %s: return None" % (i, _expr(old, ns))
                    )
                if new is None:
                    lines.append("    s[%d] = _A" % i)
                else:
                    lines.append("    s[%d] = %s" % (i, _expr(new, ns)))
                reads_out.append((i, _A if old is None else old))
                writes_out.append((i, _A if new is None else new))
            elif want is False:
                if i is None:
                    if old is None:
                        raise _NoWitness  # would succeed, contradicting want
                    continue  # fails as expected, no effect
                if old is None:
                    lines.append(
                        "    if s[%d] is _A or s[%d] is None: return None" % (i, i)
                    )
                else:
                    lines.append(
                        "    if s[%d] == %s: return None" % (i, _expr(old, ns))
                    )
            else:
                raise _NoWitness  # expected success flag is not a boolean
        else:
            # "scan" (and, per the reference semantics, any other op kind).
            if len(op) < 4:
                raise _NoWitness
            lo = op[1]
            hi = op[2]
            pairs = op[3]
            loi = kidx.get(lo) if type(lo) is str else None
            hii = kidx.get(hi) if type(hi) is str else None
            if loi is None or hii is None:
                raise _NoWitness
            if not isinstance(pairs, list):
                raise _NoWitness
            expected = {}
            prev = -1
            for pr in pairs:
                if not isinstance(pr, (list, tuple)) or len(pr) != 2:
                    raise _NoWitness
                if type(pr[0]) is not str:
                    raise _NoWitness
                i = kidx.get(pr[0])
                if i is None or i <= prev or not (loi <= i < hii):
                    raise _NoWitness
                expected[i] = pr[1]
                prev = i
            for i in range(loi, hii):
                if i in expected:
                    v = expected[i]
                    lines.append(
                        "    if s[%d] is _A or s[%d] != %s: return None"
                        % (i, i, _expr(v, ns))
                    )
                    reads_out.append((i, v))
                else:
                    lines.append("    if s[%d] is not _A: return None" % i)
                    reads_out.append((i, _A))
    lines.append("    return tuple(s)")
    g = {"_A": _A}
    g.update(ns)
    exec("\n".join(lines), g)
    return g["f"]


def _prunable(v, allow_none):
    """Is v usable as a value in the pruning tables?"""
    if v is None:
        return allow_none
    if isinstance(v, bool) or isinstance(v, int) or isinstance(v, str):
        return True
    if isinstance(v, float):
        return v == v  # reject NaN (never equal to itself)
    return False


def _solve(r):
    """Return a witness order (list of ids) or None if no witness exists."""
    if not isinstance(r, dict):
        return None
    initial = r.get("initial")
    final = r.get("final")
    if initial is None:
        initial = {}
    if final is None:
        final = {}
    if not isinstance(initial, dict) or not isinstance(final, dict):
        return None
    txs = r.get("transactions")
    if txs is None:
        txs = []
    if not isinstance(txs, list):
        return None

    n = len(txs)
    ids = []
    starts = []
    ends = []
    ops_list = []
    seen_ids = set()
    for t in txs:
        if not isinstance(t, dict):
            return None
        if not isinstance(t.get("id"), str):
            return None
        tstart = t.get("start")
        tend = t.get("end")
        if not isinstance(tstart, (int, float)) or not isinstance(tend, (int, float)):
            return None
        tops = t.get("ops")
        if not isinstance(tops, list):
            return None
        if tend <= tstart:
            return None  # no order can place a transaction before itself
        if t["id"] in seen_ids:
            return None  # ids must be unique to list each transaction once
        seen_ids.add(t["id"])
        ids.append(t["id"])
        starts.append(tstart)
        ends.append(tend)
        ops_list.append(tops)

    # Key universe: keys of the maps, of every operation and of scan bounds.
    keys = set()
    for k in initial:
        if type(k) is str:
            keys.add(k)
    for k in final:
        if type(k) is str:
            keys.add(k)
    for tops in ops_list:
        for op in tops:
            if not isinstance(op, (list, tuple)) or not op:
                continue
            if len(op) >= 2 and type(op[1]) is str:
                keys.add(op[1])
            if len(op) >= 3 and type(op[2]) is str:
                keys.add(op[2])
            if len(op) >= 4 and isinstance(op[3], list):
                for pr in op[3]:
                    if (
                        isinstance(pr, (list, tuple))
                        and pr
                        and type(pr[0]) is str
                    ):
                        keys.add(pr[0])
    keylist = sorted(keys)
    kidx = {k: i for i, k in enumerate(keylist)}
    K = len(keylist)
    init_state = tuple(_A if k not in initial else initial[k] for k in keylist)
    final_state = tuple(_A if k not in final else final[k] for k in keylist)

    # Compile every transaction; an inapplicable one means no witness at all.
    ns = {}
    fns = []
    txn_writes = []
    txn_reads = []
    try:
        for ti in range(n):
            w = []
            rd = []
            fns.append(_compile_txn(ops_list[ti], kidx, ns, w, rd))
            txn_writes.append(w)
            txn_reads.append(rd)
    except _NoWitness:
        return None

    if n == 0:
        return [] if init_state == final_state else None

    # Values that can be stored in a slot: initial values and write results.
    may_unhashable = any(
        _unhashable(v) for v in list(initial.values()) + list(final.values())
    )
    if not may_unhashable:
        for ti in range(n):
            for _k, v in txn_writes[ti]:
                if _unhashable(v):
                    may_unhashable = True
                    break
            if may_unhashable:
                break
    frz = _freeze if may_unhashable else None

    # Real time precedence: A.end <= B.start forces A before B.
    full = (1 << n) - 1
    bits = [1 << i for i in range(n)]
    preds = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and ends[i] <= starts[j]:
                preds[j] |= bits[i]

    # Static candidate order (leftmost linearisation heuristic).
    order = sorted(range(n), key=lambda i: (ends[i], starts[i], i))

    # ---- pruning tables (only for in-spec value domains) -------------------
    clean = True
    for v in list(initial.values()) + list(final.values()):
        if not _prunable(v, False):
            clean = False
            break
    if clean:
        for tops in ops_list:
            for op in tops:
                if not isinstance(op, (list, tuple)) or not op:
                    clean = False
                    break
                kind = op[0]
                if kind == "get":
                    if len(op) < 3 or not _prunable(op[2], True):
                        clean = False
                        break
                elif kind == "put":
                    if len(op) < 3 or not _prunable(op[2], False):
                        clean = False
                        break
                elif kind == "cas":
                    if (
                        len(op) < 5
                        or not _prunable(op[2], True)
                        or not _prunable(op[3], True)
                    ):
                        clean = False
                        break
                else:
                    if len(op) < 4 or not isinstance(op[3], list):
                        clean = False
                        break
                    for pr in op[3]:
                        if (
                            not isinstance(pr, (list, tuple))
                            or len(pr) != 2
                            or not _prunable(pr[1], False)
                        ):
                            clean = False
                            break
                    if not clean:
                        break
            if not clean:
                break

    feasible = None
    if clean and _PRUNE:
        # writers[i][v]: transactions that may store v in key i.
        writers = [dict() for _ in range(K)]
        for ti in range(n):
            m = bits[ti]
            for i, v in txn_writes[ti]:
                writers[i][v] = writers[i].get(v, 0) | m
        reads_flat = []
        for ti in range(n):
            flat = []
            for i, v in txn_reads[ti]:
                flat.append(i)
                flat.append(v)
            reads_flat.append(tuple(flat))
        # notaft[t]: transactions that may be placed before t (t included).
        notaft = []
        for ti in range(n):
            aft = 0
            for u in range(n):
                if u != ti and ends[ti] <= starts[u]:
                    aft |= bits[u]
            notaft.append(full & ~aft)

        def feasible(mask, state):
            rem = full & ~mask
            # The final map still has to be reachable.
            for i in range(K):
                fc = final_state[i]
                if state[i] != fc:
                    w = writers[i].get(fc, 0)
                    if not (w & rem):
                        return False
            # Every read of a remaining transaction must still be feedable.
            for t in range(n):
                if mask & bits[t]:
                    continue
                rr = reads_flat[t]
                if not rr:
                    continue
                na = notaft[t] & rem
                for j in range(0, len(rr), 2):
                    i = rr[j]
                    c = rr[j + 1]
                    if state[i] == c:
                        continue
                    w = writers[i].get(c, 0)
                    if not (w & na):
                        return False
            return True

    # ---- search ------------------------------------------------------------
    dead = set()

    def dfs(mask, state):
        if mask == full:
            return () if state == final_state else None
        key = (mask, tuple(map(frz, state))) if frz is not None else (mask, state)
        if key in dead:
            return None
        if feasible is not None and not feasible(mask, state):
            dead.add(key)
            return None
        for i in order:
            b = bits[i]
            if (mask & b) or (preds[i] & ~mask):
                continue
            nstate = fns[i](state)
            if nstate is None:
                continue
            sub = dfs(mask | b, nstate)
            if sub is not None:
                return (ids[i],) + sub
        dead.add(key)
        return None

    res = dfs(0, init_state)
    return list(res) if res is not None else None


def solve(request):
    """Public entry point: {"order": witness} or {"order": null}."""
    try:
        result = _solve(request)
    except Exception:  # never let one request break the batch
        traceback.print_exc(file=sys.stderr)
        result = None
    return {"order": result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except Exception:
            traceback.print_exc(file=sys.stderr)
            response = {"order": None}
        else:
            response = solve(request)
        out.write(json.dumps(response))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
