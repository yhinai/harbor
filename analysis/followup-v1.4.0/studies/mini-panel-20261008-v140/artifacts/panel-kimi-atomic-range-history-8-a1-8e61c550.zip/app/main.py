import json
import sys
from bisect import bisect_left


def solve(request):
    initial = request['initial']
    final = request['final']
    txns = request['transactions']
    n = len(txns)

    # ---- collect all keys (<=6 by contract) ----
    keyset = set(initial)
    keyset.update(final)
    for t in txns:
        for op in t['ops']:
            if op[0] == 'scan':
                keyset.add(op[1])
                keyset.add(op[2])
                for pair in op[3]:
                    keyset.add(pair[0])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}

    # ---- parse ops into compact programs ----
    # codes: 0=get(i,exp) 1=put(i,v) 2=del(i) 3=cas(i,old,new,want) 4=scan(lo,hi,exp)
    progs = []
    for t in txns:
        prog = []
        for op in t['ops']:
            kind = op[0]
            if kind == 'get':
                prog.append((0, kidx[op[1]], op[2]))
            elif kind == 'put':
                prog.append((1, kidx[op[1]], op[2]))
            elif kind == 'del':
                prog.append((2, kidx[op[1]]))
            elif kind == 'cas':
                prog.append((3, kidx[op[1]], op[2], op[3], op[4]))
            else:  # scan
                lo = bisect_left(keys, op[1])
                hi = bisect_left(keys, op[2])
                exp = tuple((kidx[k], v) for k, v in op[3])
                prog.append((4, lo, hi, exp))
        progs.append(prog)

    def run(prog, st):
        # st: tuple of values / None. Returns new tuple or None on observation mismatch.
        st = list(st)
        for op in prog:
            c = op[0]
            if c == 0:
                if st[op[1]] != op[2]:
                    return None
            elif c == 1:
                st[op[1]] = op[2]
            elif c == 2:
                st[op[1]] = None
            elif c == 3:
                i = op[1]
                ok = st[i] == op[2]
                if ok != op[4]:
                    return None
                if ok:
                    st[i] = op[3]  # None means delete
            else:
                lo = op[1]
                hi = op[2]
                if tuple((i, st[i]) for i in range(lo, hi) if st[i] is not None) != op[3]:
                    return None
        return tuple(st)

    # ---- real-time precedence: i before j iff end_i <= start_j ----
    pred = [0] * n
    starts = [t['start'] for t in txns]
    ends = [t['end'] for t in txns]
    for i in range(n):
        ei = ends[i]
        for j in range(n):
            if ei <= starts[j]:
                pred[j] |= 1 << i

    init_state = tuple(initial.get(k) for k in keys)
    final_state = tuple(final.get(k) for k in keys)
    full = (1 << n) - 1
    ids = [t['id'] for t in txns]
    failed = set()
    order = []

    def dfs(mask, st):
        if mask == full:
            return st == final_state
        if (mask, st) in failed:
            return False
        for i in range(n):
            bit = 1 << i
            if mask & bit or pred[i] & ~mask:
                continue
            ns = run(progs[i], st)
            if ns is None:
                continue
            order.append(ids[i])
            if dfs(mask | bit, ns):
                return True
            order.pop()
        failed.add((mask, st))
        return False

    if dfs(0, init_state):
        return {'order': list(order)}
    return {'order': None}


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        write(json.dumps(solve(json.loads(line))))
        write('\n')
    sys.stdout.flush()


if __name__ == '__main__':
    main()
