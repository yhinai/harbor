import sys
import json

# Kind codes
_ZERO = 0
_INF = 1
_FIN = 2
_NAN = 3


def _decode(v, ebits, fbits, Eall, F, bias):
    sign = v >> (ebits + fbits)
    e = (v >> fbits) & Eall
    f = v & (F - 1)
    if e == Eall:
        if f == 0:
            return (_INF, sign, 0, 0, False)
        # NaN: top fraction bit 1 -> quiet, 0 -> signaling
        signaling = ((f >> (fbits - 1)) & 1) == 0
        return (_NAN, sign, 0, 0, signaling)
    if e == 0:
        if f == 0:
            return (_ZERO, sign, 0, 0, False)
        return (_FIN, sign, f, 1 - bias - fbits, False)
    return (_FIN, sign, F + f, e - bias - fbits, False)


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    SSH = ebits + fbits  # shift to the sign bit

    nan_present = False
    invalid = False
    inf_signs = 0          # bit0: seen positive infinite product; bit1: negative
    terms = []             # (sign, significand, exponent) of nonzero finite products
    n_products = 0         # number of finite*finite pairs
    all_neg_zero = True    # every finite product is a negative signed zero?

    for pair in pairs:
        ka, sa, ma, ea, siga = _decode(int(pair[0], 16), ebits, fbits, Eall, F, bias)
        kb, sb, mb, eb, sigb = _decode(int(pair[1], 16), ebits, fbits, Eall, F, bias)

        if ka == _NAN or kb == _NAN:
            nan_present = True
            if (ka == _NAN and siga) or (kb == _NAN and sigb):
                invalid = True
            # A pair with a NaN contributes no infinite product and cannot
            # count as zero times infinity.
            continue

        if ka == _INF or kb == _INF:
            if (ka == _INF and kb == _ZERO) or (kb == _INF and ka == _ZERO):
                invalid = True
            else:
                inf_signs |= (2 if (sa ^ sb) else 1)
                if inf_signs == 3:
                    invalid = True
            continue

        n_products += 1
        s = sa ^ sb
        m = ma * mb
        if m:
            all_neg_zero = False
            terms.append((s, m, ea + eb))
        else:
            if not s:
                all_neg_zero = False

    if nan_present or invalid:
        bits = (Eall << fbits) | (1 << (fbits - 1))  # canonical NaN
        return {"bits": format(bits, "x"),
                "flags": ["invalid"] if invalid else []}

    if inf_signs:
        bits = ((1 if inf_signs == 2 else 0) << SSH) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    def zero_result():
        sign = 1 if (mode == "RDN" or (n_products > 0 and all_neg_zero)) else 0
        return {"bits": format(sign << SSH, "x"), "flags": []}

    if not terms:
        return zero_result()

    E_min = min(t[2] for t in terms)
    N = 0
    for s, m, e in terms:
        v = m << (e - E_min)
        N = N - v if s else N + v

    if N == 0:
        return zero_result()

    if N < 0:
        sign = 1
        M = -N
    else:
        sign = 0
        M = N
    k = E_min                      # exact magnitude x = M * 2**k
    L = M.bit_length() - 1 + k     # floor(log2(x))
    q_exp = emin - fbits
    if L - fbits > q_exp:
        q_exp = L - fbits          # quantum q = 2**q_exp

    if k >= q_exp:
        n = M << (k - q_exp)
        inexact = False
    else:
        shift = q_exp - k
        n_floor = M >> shift
        rem = M & ((1 << shift) - 1)
        inexact = rem != 0
        if mode == "RNE":
            twice = rem << 1
            D = 1 << shift
            up = twice > D or (twice == D and (n_floor & 1))
        elif mode == "RNA":
            up = (rem << 1) >= (1 << shift)
        elif mode == "RTZ":
            up = False
        elif mode == "RUP":
            up = (rem != 0) and not sign
        else:  # RDN
            up = (rem != 0) and sign == 1
        n = n_floor + 1 if up else n_floor

    # y = n * 2**q_exp is the rounded magnitude.
    if n and n.bit_length() - 1 + q_exp >= emax + 1:
        # Overflow
        if (mode in ("RNE", "RNA")
                or (mode == "RUP" and not sign)
                or (mode == "RDN" and sign)):
            bits = (sign << SSH) | (Eall << fbits)
        else:
            bits = (sign << SSH) | ((Eall - 1) << fbits) | (F - 1)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
        if n == 0 or n.bit_length() - 1 + q_exp < emin:
            flags.append("underflow")

    if n == 0:
        return {"bits": format(sign << SSH, "x"), "flags": flags}

    Ly = n.bit_length() - 1 + q_exp
    if Ly >= emin:
        e_field = Ly + bias
        sig = n >> (n.bit_length() - 1 - fbits)
        frac = sig - F
    else:
        e_field = 0
        frac = n
    bits = (sign << SSH) | (e_field << fbits) | frac
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        r = solve(json.loads(line))
        out.append(json.dumps({"bits": r["bits"], "flags": r["flags"]},
                              separators=(",", ":")))
    if out:
        sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
