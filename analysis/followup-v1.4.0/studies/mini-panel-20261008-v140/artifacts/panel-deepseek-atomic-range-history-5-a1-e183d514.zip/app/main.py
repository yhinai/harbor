import json
import sys


def solve(request):
    initial = request.get("initial") or {}
    final = request.get("final") or {}
    txns = request.get("transactions") or []
    n = len(txns)

    # ------------------------------------------------------------------
    # Universe of keys.  The state is tracked only over these keys.
    # ------------------------------------------------------------------
    keyset = set(initial) | set(final)
    for t in txns:
        for op in t["ops"]:
            c = op[0]
            if c == "scan":
                for kv in op[3]:
                    keyset.add(kv[0])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    nk = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    def bit(v):
        # -9..9 -> bits 0..18, absent -> bit 19
        return 1 << (v + 9) if v is not None else (1 << 19)

    initial_vec = tuple(initial.get(k) for k in keys)
    final_vec = tuple(final.get(k) for k in keys)
    final_bits = tuple(bit(final.get(k)) for k in keys)

    # ------------------------------------------------------------------
    # Compile transactions.
    # ------------------------------------------------------------------
    ops_list = []
    pre = [0] * n                    # real-time predecessors bitmask
    writes_any = [0] * n             # keys written (ever), as bitmask
    last_val = [None] * n            # key idx -> value of last write
    all_vals = [None] * n            # key idx -> bitset of all written values
    reqs = [None] * n                # list of (key idx, kind, bitset)
    starts = [0] * n
    ends = [0] * n

    for i, t in enumerate(txns):
        starts[i] = t["start"]
        ends[i] = t["end"]
        ops = []
        rq = []
        lv = {}
        av = {}
        wa = 0
        for op in t["ops"]:
            c = op[0]
            if c == "get":
                ki = kidx[op[1]]
                ops.append(("g", ki, op[2]))
                rq.append((ki, 0, bit(op[2])))
            elif c == "put":
                ki = kidx[op[1]]
                v = op[2]
                ops.append(("p", ki, v))
                wa |= 1 << ki
                lv[ki] = v
                av[ki] = av.get(ki, 0) | bit(v)
            elif c == "del":
                ki = kidx[op[1]]
                ops.append(("d", ki))
                wa |= 1 << ki
                lv[ki] = None
                av[ki] = av.get(ki, 0) | bit(None)
            elif c == "cas":
                _, key, old, new, want = op
                ki = kidx[key]
                want = bool(want)
                ops.append(("c", ki, old, new, want))
                # The required return value forces the CAS outcome, so a
                # valid execution has a deterministic effect.
                if want:
                    rq.append((ki, 0, bit(old)))
                    wa |= 1 << ki
                    lv[ki] = new
                    av[ki] = av.get(ki, 0) | bit(new)
                else:
                    rq.append((ki, 1, bit(old)))
            else:  # scan
                _, low, high, pairs = op
                rng = tuple(ki for ki in range(nk) if low <= keys[ki] < high)
                exp = []
                expmap = {}
                for kv in pairs:
                    ki = kidx[kv[0]]
                    exp.append((ki, kv[1]))
                    expmap[ki] = kv[1]
                ops.append(("s", rng, tuple(exp)))
                for ki in rng:
                    if ki in expmap:
                        rq.append((ki, 0, bit(expmap[ki])))
                    else:
                        rq.append((ki, 0, bit(None)))
        ops_list.append(tuple(ops))
        writes_any[i] = wa
        last_val[i] = lv
        all_vals[i] = av
        reqs[i] = tuple(rq)
        m = 0
        for j in range(n):
            if j != i and txns[j]["end"] <= t["start"]:
                m |= 1 << j
        pre[i] = m

    full = (1 << n) - 1
    failed = set()
    info_cache = {}
    nodes = [0]

    def maskinfo(mask):
        """(last_mask per key, all_vals mask per key, requirements, norm keys)."""
        info = info_cache.get(mask)
        if info is not None:
            return info
        rem = full ^ mask
        lm = [0] * nk
        am = [0] * nk
        allreq = []
        m = rem
        while m:
            b = m & -m
            i = b.bit_length() - 1
            m ^= b
            w = writes_any[i]
            if w:
                lvi = last_val[i]
                avi = all_vals[i]
                mm = w
                while mm:
                    kb = mm & -mm
                    ki = kb.bit_length() - 1
                    mm ^= kb
                    lm[ki] |= bit(lvi[ki])
                    am[ki] |= avi[ki]
            if reqs[i]:
                allreq.extend(reqs[i])
        norm = tuple(ki for ki in range(nk) if lm[ki])
        # Requirements on keys with no remaining writer are already pinned
        # to their final value, so they can be checked statically.
        static_ok = True
        exact = {}
        nots = []
        for ki, kind, rq in allreq:
            if lm[ki]:
                if kind == 0:
                    exact[ki] = exact.get(ki, 0) | rq
                else:
                    nots.append((ki, rq))
            else:
                fb = final_bits[ki]
                if kind == 0:
                    if not (rq & fb):
                        static_ok = False
                        break
                elif not (fb & ~rq):
                    static_ok = False
                    break
        info = (lm, am, static_ok, exact, tuple(nots), norm)
        info_cache[mask] = info
        return info

    # ------------------------------------------------------------------
    # Execute transaction i atomically from vec; None on failed observation.
    # ------------------------------------------------------------------
    def apply(i, vec):
        st = list(vec)
        for op in ops_list[i]:
            c = op[0]
            if c == "g":
                if st[op[1]] != op[2]:
                    return None
            elif c == "p":
                st[op[1]] = op[2]
            elif c == "d":
                st[op[1]] = None
            elif c == "c":
                _, ki, old, new, want = op
                ok = st[ki] == old
                if ok != want:
                    return None
                if ok:
                    st[ki] = new
            else:
                _, rng, exp = op
                ne = len(exp)
                j = 0
                for ki in rng:
                    v = st[ki]
                    if v is not None:
                        if j >= ne or exp[j][0] != ki or exp[j][1] != v:
                            return None
                        j += 1
                if j != ne:
                    return None
        return tuple(st)

    # ------------------------------------------------------------------
    # Depth-first search over serial orders with memoization of failed
    # (remaining-set, normalized-state) pairs.
    # ------------------------------------------------------------------
    def dfs(mask, vec):
        nodes[0] += 1
        if mask == full:
            return () if vec == final_vec else None
        lm, am, static_ok, exact, nots, norm = maskinfo(mask)
        mkey = (mask, tuple(vec[ki] for ki in norm))
        if mkey in failed:
            return None
        # Necessary conditions: final reachability and observation feasibility.
        ok = static_ok
        nonnorm_bad = False
        if ok:
            for ki in range(nk):
                if lm[ki]:
                    if not (final_bits[ki] & lm[ki]):
                        ok = False
                        break
                elif vec[ki] != final_vec[ki]:
                    # This node is dead, but its normalized state does not
                    # determine the offending value, so do not memoize it.
                    nonnorm_bad = True
                    ok = False
                    break
        if ok:
            for ki, rq in exact.items():
                if not (rq & (bit(vec[ki]) | am[ki])):
                    ok = False
                    break
        if ok:
            for ki, rq in nots:
                if not ((bit(vec[ki]) | am[ki]) & ~rq):
                    ok = False
                    break
        if not ok:
            if not nonnorm_bad:
                failed.add(mkey)
            return None

        notmask = full ^ mask
        cands = []
        for i in range(n):
            if not (mask >> i) & 1 and (pre[i] & notmask) == 0:
                cands.append(i)
        if n > 1:
            cands.sort(key=lambda i: (ends[i], starts[i], i))
        for i in cands:
            ns = apply(i, vec)
            if ns is None:
                continue
            res = dfs(mask | (1 << i), ns)
            if res is not None:
                return (i,) + res
        failed.add(mkey)
        return None

    res = dfs(0, initial_vec)
    solve.last_nodes = nodes[0]
    if res is None:
        return {"order": None}
    return {"order": [txns[i]["id"] for i in res]}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req)))
        out.write("\n")
        out.flush()
    out.flush()


if __name__ == "__main__":
    main()
