import sys
import json


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = req['mode']
    pairs = req['pairs']

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias  # == bias
    fmask = F - 1
    spos = ebits + fbits  # sign bit position

    # decode: returns ('fin'|'inf'|'nan', sign, m, E) with value = (-1)^sign * m * 2^E
    def parse(h):
        v = int(h, 16)
        s = (v >> spos) & 1
        e = (v >> fbits) & Eall
        f = v & fmask
        if e == Eall:
            if f == 0:
                return (1, s, 0, 0)          # infinity
            return (2, s, f, 0)              # NaN (m holds fraction)
        if e == 0:
            return (0, s, f, 1 - bias - fbits)   # subnormal / zero
        return (0, s, F + f, e - bias - fbits)   # normal

    saw_nan = False
    invalid = False
    inf_mask = 0  # bit0: +inf product, bit1: -inf product
    prods = []    # finite products (sign, m, E)

    for pair in pairs:
        a = parse(pair[0])
        b = parse(pair[1])
        a_nan = a[0] == 2
        b_nan = b[0] == 2
        if a_nan:
            saw_nan = True
            if not ((a[2] >> (fbits - 1)) & 1):  # signaling NaN
                invalid = True
        if b_nan:
            saw_nan = True
            if not ((b[2] >> (fbits - 1)) & 1):
                invalid = True
        if a_nan or b_nan:
            continue  # no product contribution at all
        if a[0] == 1 or b[0] == 1:
            # at least one infinity (no NaN in this pair)
            if (a[0] == 0 and a[2] == 0) or (b[0] == 0 and b[2] == 0):
                invalid = True            # zero times infinity
            else:
                inf_mask |= 1 << (a[1] ^ b[1])
            continue
        prods.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    nan_bits = (Eall << fbits) | (1 << (fbits - 1))  # canonical NaN
    if inf_mask == 3:  # both +inf and -inf products
        invalid = True
    if invalid:
        return {"bits": format(nan_bits, 'x'), "flags": ["invalid"]}
    if saw_nan:
        return {"bits": format(nan_bits, 'x'), "flags": []}
    if inf_mask:
        s = 1 if inf_mask == 2 else 0
        return {"bits": format((s << spos) | (Eall << fbits), 'x'), "flags": []}

    # ---- finite exact accumulation ----
    total = 0
    E0 = 0
    first = True
    for s, m, E in prods:
        if m == 0:
            continue
        if first:
            E0 = E
            first = False
        elif E < E0:
            total <<= (E0 - E)
            E0 = E
        if s:
            total -= m << (E - E0)
        else:
            total += m << (E - E0)

    if total == 0:
        # exact zero
        if prods and all(m == 0 and s == 1 for s, m, _ in prods):
            s = 1
        elif mode == 'RDN':
            s = 1
        else:
            s = 0
        return {"bits": format(s << spos, 'x'), "flags": []}

    s = 1 if total < 0 else 0
    a = -total if s else total          # x = a * 2^E0, a > 0
    L = a.bit_length() - 1 + E0         # floor(log2(x))
    q_exp = emin - fbits
    if L - fbits > q_exp:
        q_exp = L - fbits
    shift = q_exp - E0
    if shift <= 0:
        n = a << (-shift)
        rem = 0
        half = 0
    else:
        n = a >> shift
        rem = a - (n << shift)
        half = 1 << (shift - 1)

    if rem:
        if mode == 'RNE':
            if rem > half or (rem == half and (n & 1)):
                n += 1
        elif mode == 'RNA':
            if rem >= half:
                n += 1
        elif mode == 'RUP':
            if s == 0:
                n += 1
        elif mode == 'RDN':
            if s == 1:
                n += 1
        # RTZ: truncate
        inexact = True
    else:
        inexact = False

    # y = n * 2^q_exp is the rounded magnitude
    if n and n.bit_length() - 1 + q_exp >= emax + 1:
        # overflow
        if mode == 'RNE' or mode == 'RNA' or (mode == 'RUP' and s == 0) or (mode == 'RDN' and s == 1):
            bits = (s << spos) | (Eall << fbits)             # signed infinity
        else:
            bits = (s << spos) | ((Eall - 1) << fbits) | fmask  # signed max finite
        return {"bits": format(bits, 'x'), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append('inexact')
        if n.bit_length() + q_exp <= emin:  # y < 2^emin (includes y == 0)
            flags.append('underflow')

    if n == 0:
        return {"bits": format(s << spos, 'x'), "flags": flags}

    L_y = n.bit_length() - 1 + q_exp
    if L_y < emin:
        e_field = 0
        f = n << (q_exp - (emin - fbits))  # q_exp == emin-fbits here, so f == n
    else:
        e_field = L_y + bias
        sh2 = L_y - fbits - q_exp
        sig = (n >> sh2) if sh2 >= 0 else (n << (-sh2))
        f = sig - F
    bits = (s << spos) | (e_field << fbits) | f
    return {"bits": format(bits, 'x'), "flags": flags}


if __name__ == '__main__':
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    if out:
        sys.stdout.write('\n'.join(out) + '\n')
