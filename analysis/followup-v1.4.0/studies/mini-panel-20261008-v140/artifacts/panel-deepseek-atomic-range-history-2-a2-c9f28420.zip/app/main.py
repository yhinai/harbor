import heapq
import json
import sys


def _collect_keys(req):
    """All keys that can ever be present in the state or observed by a scan."""
    keys = set(req.get('initial') or {})
    keys.update(req.get('final') or {})
    for t in req.get('transactions') or []:
        for op in t.get('ops') or []:
            kind = op[0]
            if kind == 'get':
                keys.add(op[1])
            elif kind in ('put', 'del', 'cas'):
                keys.add(op[1])
            elif kind == 'scan':
                # Scan boundaries themselves need not be state keys, but any key
                # explicitly expected by the scan is a key.
                for p in op[3]:
                    keys.add(p[0])
    return sorted(keys)


def _collect_values(req):
    """All integer values that occur anywhere in the request, plus None."""
    vals = {None}
    for d in (req.get('initial') or {}, req.get('final') or {}):
        for v in d.values():
            vals.add(v)
    for t in req.get('transactions') or []:
        for op in t.get('ops') or []:
            kind = op[0]
            if kind == 'get':
                vals.add(op[2])
            elif kind == 'put':
                vals.add(op[2])
            elif kind == 'cas':
                vals.add(op[2])
                vals.add(op[3])
            elif kind == 'scan':
                for p in op[3]:
                    vals.add(p[1])
    return [None] + sorted(v for v in vals if v is not None)


def _prep_tx(t, keys, final, valset):
    """Symbolically execute one transaction.

    Returns (dep, writes, impossible):
      dep    : key -> frozenset of acceptable *entry* values, for keys read
               before they are first written in this transaction.
      writes : key -> constant value written (None means absent).
    """
    unknown = {k: True for k in keys}
    const = {}
    allowed = {k: set(valset) for k in keys}
    constrained = set()
    for op in t['ops']:
        kind = op[0]
        if kind == 'get':
            k = op[1]
            exp = op[2]
            if unknown[k]:
                constrained.add(k)
                allowed[k].intersection_update((exp,))
                if not allowed[k]:
                    return None, None, True
            else:
                if const[k] != exp:
                    return None, None, True
        elif kind == 'put':
            k = op[1]
            unknown[k] = False
            const[k] = op[2]
        elif kind == 'del':
            k = op[1]
            unknown[k] = False
            const[k] = None
        elif kind == 'cas':
            k = op[1]
            old = op[2]
            new = op[3]
            want = op[4]
            if unknown[k]:
                constrained.add(k)
                if want:
                    allowed[k].intersection_update((old,))
                    if not allowed[k]:
                        return None, None, True
                    unknown[k] = False
                    const[k] = new
                else:
                    allowed[k].discard(old)
                    if not allowed[k]:
                        return None, None, True
                    # Failure leaves the key at its entry value.
            else:
                ok = (const[k] == old)
                if ok != bool(want):
                    return None, None, True
                if ok:
                    const[k] = new
        elif kind == 'scan':
            low = op[1]
            high = op[2]
            pairs = op[3]
            expected = {}
            prev = None
            valid = True
            for p in pairs:
                k = p[0]
                if not (low <= k < high) or k in expected or (prev is not None and k <= prev):
                    valid = False
                    break
                prev = k
                expected[k] = p[1]
            if not valid:
                return None, None, True
            for k in keys:
                if low <= k < high:
                    exp = expected.get(k, None)
                    if unknown[k]:
                        constrained.add(k)
                        allowed[k].intersection_update((exp,))
                        if not allowed[k]:
                            return None, None, True
                    else:
                        if const[k] != exp:
                            return None, None, True
        else:
            return None, None, True
    writes = {k: const[k] for k in keys if not unknown[k]}
    dep = {k: frozenset(allowed[k]) for k in constrained}
    return dep, writes, False


def _solve_core(req):
    initial = req.get('initial') or {}
    final = req.get('final') or {}
    txs = req.get('transactions') or []
    n = len(txs)
    if n == 0:
        return {"order": [] if dict(initial) == dict(final) else None}

    keys = _collect_keys(req)
    vals = _collect_values(req)
    valset = frozenset(vals)

    dep_list = []
    write_list = []
    for t in txs:
        dep, writes, bad = _prep_tx(t, keys, final, valset)
        if bad:
            return {"order": None}
        dep_list.append(dep)
        write_list.append(writes)

    # Interval order: i -> j whenever i.end <= j.start.
    pred = [0] * n
    succ = [0] * n
    for i in range(n):
        si = txs[i]['start']
        for j in range(n):
            if i != j and txs[j]['end'] <= si:
                pred[i] |= 1 << j
                succ[j] |= 1 << i

    # Transitive closure of the interval order.
    reach = [0] * n
    for i in range(n):
        r = 0
        frontier = succ[i]
        while frontier:
            r |= frontier
            nf = 0
            f = frontier
            while f:
                b = f & -f
                f ^= b
                nf |= succ[b.bit_length() - 1]
            frontier = nf & ~r
        reach[i] = r

    all_mask = (1 << n) - 1
    final_bit = 1 << n

    # For each key/value: bit i says that transaction i accepts this value as
    # the entry value of that key; final_bit says value == final[key].
    masks = []
    for k in keys:
        mk = {}
        fv = final.get(k, None)
        for v in vals:
            m = 0
            for i in range(n):
                a = dep_list[i].get(k)
                if a is not None and v in a:
                    m |= 1 << i
            if v == fv:
                m |= final_bit
            mk[v] = m
        masks.append(mk)

    kidx = {k: i for i, k in enumerate(keys)}
    deps = []
    wops = []
    writer_mask = [0] * len(keys)
    for i in range(n):
        deps.append([(kidx[k], 1 << i) for k in dep_list[i]])
        wl = []
        for k, v in write_list[i].items():
            ki = kidx[k]
            wl.append((ki, v))
            writer_mask[ki] |= 1 << i
        wops.append(wl)

    initial_state = tuple(masks[ki][initial.get(k, None)] for ki, k in enumerate(keys))
    failed = set()

    def final_possible(executed, state):
        rem = all_mask ^ executed
        if rem == 0:
            for m in state:
                if not (m & final_bit):
                    return False
            return True
        for ki in range(len(keys)):
            w = writer_mask[ki] & rem
            if w == 0:
                if not (state[ki] & final_bit):
                    return False
            else:
                ok = False
                ww = w
                while ww:
                    b = ww & -ww
                    j = b.bit_length() - 1
                    ww ^= b
                    v = write_list[j].get(keys[ki], None)
                    if (masks[ki][v] & final_bit) and (reach[j] & w) == 0:
                        ok = True
                        break
                if not ok:
                    return False
        return True

    def tx_possible(i, state, executed):
        """Necessary condition: transaction i can still be made executable."""
        rem = all_mask ^ executed
        for ki, bit in deps[i]:
            if state[ki] & bit:
                continue
            # The current value is not accepted.  Some remaining writer of this
            # key must overwrite it with an accepted value before i executes.
            k = keys[ki]
            forced_before_writers = pred[i] & rem & writer_mask[ki]
            ok = False
            w = writer_mask[ki] & rem
            while w:
                b = w & -w
                j = b.bit_length() - 1
                w ^= b
                if j == i:
                    continue
                # j must be allowed before i.
                if reach[i] & (1 << j):
                    continue
                # j must be able to be the last writer of k before i: no
                # writer that is forced before i may have to come after j.
                if reach[j] & forced_before_writers:
                    continue
                if write_list[j].get(k, None) in dep_list[i][k]:
                    ok = True
                    break
            if not ok:
                return False
        return True

    def dfs(executed, state):
        if executed == all_mask:
            for m in state:
                if not (m & final_bit):
                    return None
            return ()
        key = (executed, state)
        if key in failed:
            return None
        if not final_possible(executed, state):
            failed.add(key)
            return None
        rem = all_mask ^ executed
        cands = []
        r = rem
        while r:
            b = r & -r
            i = b.bit_length() - 1
            r ^= b
            if (executed & pred[i]) != pred[i]:
                continue
            ok = True
            for ki, bit in deps[i]:
                if not (state[ki] & bit):
                    ok = False
                    break
            if ok:
                cands.append(i)
        if not cands:
            failed.add(key)
            return None
        for i in range(n):
            if not (executed & (1 << i)) and not tx_possible(i, state, executed):
                failed.add(key)
                return None

        scored = []
        for i in cands:
            new_exec = executed | (1 << i)
            keep = (all_mask ^ new_exec) | final_bit
            ns = list(state)
            for ki, v in wops[i]:
                ns[ki] = masks[ki][v] & keep
            ns = tuple(m & keep for m in ns)
            nxt = 0
            rr = all_mask ^ new_exec
            while rr:
                b = rr & -rr
                j = b.bit_length() - 1
                rr ^= b
                if (new_exec & pred[j]) != pred[j]:
                    continue
                ok = True
                for ki, bit in deps[j]:
                    if not (ns[ki] & bit):
                        ok = False
                        break
                if ok:
                    nxt += 1
            critical = (reach[i] & rem).bit_count()
            scored.append((-critical, nxt, i, ns, new_exec))
        scored.sort(key=lambda x: (x[0], x[1], x[2]))
        for _, _, i, ns, new_exec in scored:
            res = dfs(new_exec, ns)
            if res is not None:
                return (i,) + res
        failed.add(key)
        return None

    res = dfs(0, initial_state)
    if res is None:
        return {"order": None}
    return {"order": [txs[i]['id'] for i in res]}


def solve(req):
    initial = req.get('initial') or {}
    final = req.get('final') or {}
    txs = req.get('transactions') or []
    n = len(txs)
    if n == 0:
        return {"order": [] if dict(initial) == dict(final) else None}

    keys = _collect_keys(req)
    vals = _collect_values(req)
    valset = frozenset(vals)

    dep_list = []
    write_list = []
    for t in txs:
        dep, writes, bad = _prep_tx(t, keys, final, valset)
        if bad:
            return {"order": None}
        dep_list.append(dep)
        write_list.append(writes)

    # Keys touched by each transaction (writes, reads, and keys visible to scans).
    touched = []
    for i, t in enumerate(txs):
        s = set(dep_list[i]) | set(write_list[i])
        for op in t['ops']:
            if op[0] == 'scan':
                low, high = op[1], op[2]
                for k in keys:
                    if low <= k < high:
                        s.add(k)
        touched.append(s)

    # Connected components of transactions through shared keys.
    parent = list(range(n))

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[rb] = ra

    owner = {}
    for i, s in enumerate(touched):
        for k in s:
            if k in owner:
                union(i, owner[k])
            else:
                owner[k] = i

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    if len(groups) > 1:
        # Decomposition is only used when no interval constraint crosses
        # components.  Then component orders can be concatenated freely.
        cross = False
        for i in range(n):
            si = txs[i]['start']
            for j in range(n):
                if i != j and txs[j]['end'] <= si and find(i) != find(j):
                    cross = True
                    break
            if cross:
                break
        if not cross:
            # Keys not touched by any transaction are constant.
            touched_any = set()
            for s in touched:
                touched_any |= s
            for k in keys:
                if k not in touched_any and initial.get(k) != final.get(k):
                    return {"order": None}

            id_to_idx = {t['id']: i for i, t in enumerate(txs)}
            result = []
            for ids in groups.values():
                sub_keys = set()
                for i in ids:
                    sub_keys |= touched[i]
                sub_initial = {k: v for k, v in initial.items() if k in sub_keys}
                sub_final = {k: v for k, v in final.items() if k in sub_keys}
                sub_txs = [txs[i] for i in ids]
                subreq = {
                    'initial': sub_initial,
                    'final': sub_final,
                    'transactions': sub_txs,
                }
                subres = _solve_core(subreq)
                if subres['order'] is None:
                    return {"order": None}
                result.extend(id_to_idx[x] for x in subres['order'])
            return {"order": [txs[i]['id'] for i in result]}

    return _solve_core(req)


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req), separators=(',', ':')) + '\n')
    out.flush()


if __name__ == '__main__':
    main()
