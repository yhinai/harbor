"""Exhaustive outcome enumeration for the mixed-width buffered (TSO-like) machine.

State layout (a single fixed-length ``bytes`` object per state, which makes
hashing/equality cheap):

    [ memory bytes (nmem) ]
    per thread t:
        pc      (1 byte)
        nd      (1 byte)   number of that thread's stores already drained
        observations (4 bytes each, little endian, slots preallocated)

The number of observation slots a thread has is fixed: every ``load`` and
``xchg`` appends exactly one value, so the slot for the next observation is a
function of ``pc`` alone.  Because drains are FIFO, the buffered stores of a
thread are exactly ``stores[nd:store_prefix[pc]]``.
"""

import json
import sys


def solve(request):
    mem0 = bytes(request["memory"])
    threads = request["threads"]
    nthreads = len(threads)
    nmem = len(mem0)

    offs = []       # offs[t] = offset of pc byte for thread t
    nstores = []    # total number of store instructions per thread
    nobs = []       # total number of load/xchg instructions per thread
    stores = []     # stores[t][j] = (addr, width, value)
    sprefix = []    # sprefix[t][k] = #stores among first k instructions
    obsprefix = []  # obsprefix[t][k] = #load/xchg among first k instructions
    drain_bytes = []  # drain_bytes[t][j] = little-endian bytes of store j
    drain_addr = []   # drain_addr[t][j] = address of store j

    pos = nmem
    for ins in threads:
        st = []
        sp = [0] * (len(ins) + 1)
        op = [0] * (len(ins) + 1)
        for i, o in enumerate(ins):
            sp[i + 1] = sp[i]
            op[i + 1] = op[i]
            kind = o[0]
            if kind == "store":
                st.append((o[1], o[2], o[3]))
                sp[i + 1] += 1
            elif kind == "load" or kind == "xchg":
                op[i + 1] += 1
        offs.append(pos)
        nstores.append(len(st))
        nobs.append(op[len(ins)])
        stores.append(st)
        sprefix.append(sp)
        obsprefix.append(op)
        drain_bytes.append([
            bytes((v >> (8 * k)) & 0xFF for k in range(w)) for (a, w, v) in st
        ])
        drain_addr.append([a for (a, w, v) in st])
        pos += 2 + 4 * op[len(ins)]
    total_len = pos

    # Per thread, per load instruction (indexed by pc), per nd: the byte
    # sources.  memsrc = [(memory_offset, dest_shift)], storesrc = [(store
    # index, source shift, dest shift)].
    kinds = []
    loadsrc = []
    for t, ins in enumerate(threads):
        kk = [o[0] for o in ins]
        ls = [None] * len(ins)
        for i, o in enumerate(ins):
            if o[0] != "load":
                continue
            a, w = o[1], o[2]
            nbuf = sprefix[t][i]
            table = []
            for nd in range(nbuf + 1):
                memsrc = []
                storesrc = []
                for k in range(w):
                    p = a + k
                    found = False
                    for j in range(nbuf - 1, nd - 1, -1):
                        sa, sw, sv = stores[t][j]
                        if sa <= p < sa + sw:
                            storesrc.append((j, p - sa, 8 * k))
                            found = True
                            break
                    if not found:
                        memsrc.append((p, 8 * k))
                table.append((memsrc, storesrc))
            ls[i] = table
        kinds.append(kk)
        loadsrc.append(ls)

    nins = [len(ins) for ins in threads]

    start = bytearray(total_len)
    start[0:nmem] = mem0
    start = bytes(start)

    seen = {start}
    stack = [start]
    push = stack.append
    outcomes = set()

    while stack:
        s = stack.pop()

        # Terminal: every thread finished and every buffer empty.
        terminal = True
        for t in range(nthreads):
            o = offs[t]
            if s[o] != nins[t] or s[o + 1] != nstores[t]:
                terminal = False
                break
        if terminal:
            out = bytearray(s[0:nmem])
            for t in range(nthreads):
                o = offs[t] + 2
                out += s[o:o + 4 * nobs[t]]
            outcomes.add(bytes(out))
            continue

        for t in range(nthreads):
            o = offs[t]
            pc = s[o]
            nd = s[o + 1]
            sp = sprefix[t]

            # 2. Drain the oldest buffered store of this thread.
            if nd < sp[pc]:
                ba = bytearray(s)
                a = drain_addr[t][nd]
                db = drain_bytes[t][nd]
                ba[a:a + len(db)] = db
                ba[o + 1] = nd + 1
                ns = bytes(ba)
                if ns not in seen:
                    seen.add(ns)
                    push(ns)

            # 1. Execute the next instruction.
            if pc >= nins[t]:
                continue
            kind = kinds[t][pc]

            if kind == "store":
                ba = bytearray(s)
                ba[o] = pc + 1
                ns = bytes(ba)
                if ns not in seen:
                    seen.add(ns)
                    push(ns)
            elif kind == "fence":
                if nd == sp[pc]:
                    ba = bytearray(s)
                    ba[o] = pc + 1
                    ns = bytes(ba)
                    if ns not in seen:
                        seen.add(ns)
                        push(ns)
            elif kind == "load":
                memsrc, storesrc = loadsrc[t][pc][nd]
                val = 0
                for p, d in memsrc:
                    val |= s[p] << d
                for j, sh, d in storesrc:
                    val |= ((stores[t][j][2] >> (8 * sh)) & 0xFF) << d
                ba = bytearray(s)
                ba[o] = pc + 1
                q = o + 2 + 4 * obsprefix[t][pc]
                ba[q:q + 4] = val.to_bytes(4, "little")
                ns = bytes(ba)
                if ns not in seen:
                    seen.add(ns)
                    push(ns)
            else:  # xchg
                if nd == sp[pc]:
                    a, w, v = threads[t][pc][1], threads[t][pc][2], threads[t][pc][3]
                    val = 0
                    for k in range(w):
                        val |= s[a + k] << (8 * k)
                    ba = bytearray(s)
                    ba[o] = pc + 1
                    q = o + 2 + 4 * obsprefix[t][pc]
                    ba[q:q + 4] = val.to_bytes(4, "little")
                    for k in range(w):
                        ba[a + k] = (v >> (8 * k)) & 0xFF
                    ns = bytes(ba)
                    if ns not in seen:
                        seen.add(ns)
                        push(ns)

    result = []
    for out in outcomes:
        reads = []
        p = nmem
        for t in range(nthreads):
            n = nobs[t]
            reads.append([
                int.from_bytes(out[p + 4 * i:p + 4 * i + 4], "little")
                for i in range(n)
            ])
            p += 4 * n
        result.append({"reads": reads, "memory": list(out[:nmem])})
    return {"outcomes": result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
