#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per request line to stdout.

Record layout (all integers unsigned little-endian, no implicit padding):

    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32

The fixed header is 13 bytes and the trailing crc is
zlib.crc32(header + payload) & 0xffffffff.
"""

import json
import sys
import zlib

BEGIN = 1
PATCH = 2
COMMIT = 3
ABORT = 4
KINDS = frozenset((BEGIN, PATCH, COMMIT, ABORT))

HEADER_SIZE = 13
TRAILER_SIZE = 4
MAX_PAYLOAD = 4096


def solve(request):
    """Recover the journal described by ``request`` and build the response."""
    pages_hex = request["pages"]
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])

    pages = [bytearray(bytes.fromhex(p)) for p in pages_hex]
    page_count = len(pages)

    # Active incarnations: txid -> [staged patches, concatenated patch payloads]
    active = {}

    valid_bytes = 0
    last_seq = 0

    size = len(log)
    off = 0
    while off + HEADER_SIZE <= size:
        head = log[off:off + HEADER_SIZE]
        payload_length = int.from_bytes(head[0:4], "little")
        sequence = int.from_bytes(head[4:8], "little")
        kind = head[8]
        txid = int.from_bytes(head[9:13], "little")

        # Structural checks that need no payload bytes.
        if (
            payload_length > MAX_PAYLOAD
            or sequence <= last_seq          # covers sequence == 0 too
            or txid == 0
            or kind not in KINDS
        ):
            break

        end = off + HEADER_SIZE + payload_length + TRAILER_SIZE
        if end > size:  # torn / truncated record
            break

        payload = log[off + HEADER_SIZE:off + HEADER_SIZE + payload_length]
        stored_crc = int.from_bytes(log[end - TRAILER_SIZE:end], "little")
        if zlib.crc32(payload, zlib.crc32(head)) != stored_crc:
            break

        # Payload shape / bounds validation (required before any semantic effect).
        if kind == BEGIN or kind == ABORT:
            if payload_length != 0:
                break
        elif kind == COMMIT:
            if payload_length != 8:
                break
            patch_count = int.from_bytes(payload[0:4], "little")
            digest = int.from_bytes(payload[4:8], "little")
        else:  # PATCH
            if payload_length < 6:
                break
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            if page_index >= page_count:
                break
            page_size = len(pages[page_index])
            if byte_offset > page_size - byte_count:
                break

        # The record is valid: it now takes its semantic effect.
        if kind == BEGIN:
            # Fresh incarnation; any unfinished one is discarded.
            active[txid] = ([], bytearray())
        elif kind == PATCH:
            state = active.get(txid)
            if state is not None:
                staged, concat = state
                staged.append((page_index, byte_offset, payload[6:]))
                concat += payload
        elif kind == ABORT:
            active.pop(txid, None)
        else:  # COMMIT: always closes the incarnation, if any.
            state = active.pop(txid, None)
            if state is not None:
                staged, concat = state
                if (
                    len(staged) == patch_count
                    and zlib.crc32(concat) == digest
                    and sequence > checkpoint
                ):
                    for page_index, byte_offset, data in staged:
                        target = pages[page_index]
                        target[byte_offset:byte_offset + len(data)] = data

        valid_bytes = end
        last_seq = sequence
        off = end

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = []
    for line in sys.stdin:
        if not line.strip():
            continue
        request = None
        try:
            request = json.loads(line)
            result = solve(request)
        except Exception as exc:  # pragma: no cover - input is specified well-formed
            # Never let one bad line abort the whole batch.
            print("request failed: %r" % (exc,), file=sys.stderr)
            pages = request.get("pages", []) if isinstance(request, dict) else []
            if not isinstance(pages, list):
                pages = []
            result = {"pages": pages, "valid_bytes": 0, "last_seq": 0}
        out.append(json.dumps(result))
    if out:
        sys.stdout.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
