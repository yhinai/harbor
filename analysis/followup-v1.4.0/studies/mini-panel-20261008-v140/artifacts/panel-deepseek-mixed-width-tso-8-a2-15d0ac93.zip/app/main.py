import json
import sys


def solve(request):
    mem0 = bytes(request["memory"])
    raw_threads = request["threads"]
    nthreads = len(raw_threads)

    # For each thread: instruction list, number of stores executed before each
    # pc, and the ordered list of its store instructions.
    instrs = []
    prefix_stores = []
    stores_by_thread = []
    for th in raw_threads:
        ilist = [tuple(ins) for ins in th]
        instrs.append(ilist)
        pref = [0] * (len(ilist) + 1)
        stores = []
        for i, ins in enumerate(ilist):
            pref[i + 1] = pref[i] + (1 if ins[0] == "store" else 0)
            if ins[0] == "store":
                stores.append((ins[1], ins[2], ins[3]))
        prefix_stores.append(pref)
        stores_by_thread.append(stores)

    zero_pcs = tuple(0 for _ in range(nthreads))
    zero_drained = tuple(0 for _ in range(nthreads))
    empty_obs = tuple(() for _ in range(nthreads))

    start = (zero_pcs, zero_drained, empty_obs, mem0)
    seen = {start}
    stack = [start]
    outcomes = set()

    while stack:
        pcs, drained, obs, mem = stack.pop()

        # Terminal: every thread finished and every buffer drained.
        terminal = True
        for t in range(nthreads):
            if pcs[t] != len(instrs[t]) or drained[t] != prefix_stores[t][pcs[t]]:
                terminal = False
                break
        if terminal:
            outcomes.add((obs, mem))
            continue

        for t in range(nthreads):
            pc = pcs[t]
            ilist = instrs[t]
            if pc >= len(ilist):
                continue
            ins = ilist[pc]
            op = ins[0]

            if op == "store":
                # Appends to the buffer implicitly (pc advances); no memory write.
                ns = (pcs[:t] + (pc + 1,) + pcs[t + 1:],
                      drained, obs, mem)

            elif op == "load":
                addr, width = ins[1], ins[2]
                buf = stores_by_thread[t]
                lo = drained[t]
                hi = prefix_stores[t][pc]
                val = 0
                shift = 0
                for a in range(addr, addr + width):
                    byte = None
                    for k in range(hi - 1, lo - 1, -1):
                        sa, sw, sv = buf[k]
                        if sa <= a < sa + sw:
                            byte = (sv >> (8 * (a - sa))) & 0xFF
                            break
                    if byte is None:
                        byte = mem[a]
                    val |= byte << shift
                    shift += 8
                ns = (pcs[:t] + (pc + 1,) + pcs[t + 1:],
                      drained,
                      obs[:t] + (obs[t] + (val,),) + obs[t + 1:],
                      mem)

            elif op == "fence":
                if drained[t] != prefix_stores[t][pc]:
                    continue
                ns = (pcs[:t] + (pc + 1,) + pcs[t + 1:],
                      drained, obs, mem)

            elif op == "xchg":
                if drained[t] != prefix_stores[t][pc]:
                    continue
                addr, width, value = ins[1], ins[2], ins[3]
                old = int.from_bytes(mem[addr:addr + width], "little")
                newmem = bytearray(mem)
                newmem[addr:addr + width] = value.to_bytes(width, "little")
                ns = (pcs[:t] + (pc + 1,) + pcs[t + 1:],
                      drained,
                      obs[:t] + (obs[t] + (old,),) + obs[t + 1:],
                      bytes(newmem))

            else:
                raise ValueError("unknown instruction: %r" % (ins,))

            if ns not in seen:
                seen.add(ns)
                stack.append(ns)

        # Drain the oldest buffered store of any thread.
        for t in range(nthreads):
            pc = pcs[t]
            if drained[t] >= prefix_stores[t][pc]:
                continue
            addr, width, value = stores_by_thread[t][drained[t]]
            newmem = bytearray(mem)
            newmem[addr:addr + width] = value.to_bytes(width, "little")
            ns = (pcs,
                  drained[:t] + (drained[t] + 1,) + drained[t + 1:],
                  obs, bytes(newmem))
            if ns not in seen:
                seen.add(ns)
                stack.append(ns)

    out = []
    for obs, mem in outcomes:
        out.append({"reads": [list(o) for o in obs], "memory": list(mem)})
    return {"outcomes": out}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))))


if __name__ == "__main__":
    main()
