"""Deterministic recovery of a checkpointed transactional byte journal.

Input : newline-delimited JSON requests on stdin.
Output: one JSON response object per request line, in order.

Record layout (all integers unsigned little-endian, no padding):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32
The fixed header is 13 bytes and crc covers header + payload.
"""

import json
import struct
import sys
import zlib

HEADER = struct.Struct('<IIBI')        # payload_length, sequence, kind, transaction_id
PATCH_HEAD = struct.Struct('<HHH')     # page_index, byte_offset, byte_count
U32 = struct.Struct('<I')

HEADER_SIZE = 13
CRC_SIZE = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4
VALID_KINDS = frozenset((KIND_BEGIN, KIND_PATCH, KIND_COMMIT, KIND_ABORT))


def _decode_hex(text):
    """Hex string -> bytes (case insensitive). Returns b'' when unusable."""
    if not text:
        return b''
    if isinstance(text, (bytes, bytearray)):
        return bytes(text)
    try:
        return bytes.fromhex(text)
    except (ValueError, TypeError):
        return b''


class Recovery(object):
    __slots__ = ('pages', 'npages', 'checkpoint', 'log',
                 'active', 'last_seq', 'valid_bytes')

    def __init__(self, pages, checkpoint, log):
        self.pages = pages            # list[bytearray] (never resized)
        self.npages = len(pages)
        self.checkpoint = checkpoint
        self.log = log
        self.active = {}              # txid -> [staged patches, running digest]
        self.last_seq = 0
        self.valid_bytes = 0

    # -- structural validation ------------------------------------------------

    def _patch_ok(self, payload):
        """Validate a PATCH payload; returns (page_index, offset, data) or None."""
        if len(payload) < 6:
            return None
        page_index, byte_offset, byte_count = PATCH_HEAD.unpack_from(payload, 0)
        if byte_count == 0 or len(payload) != 6 + byte_count:
            return None
        if page_index >= self.npages:
            return None
        if byte_offset + byte_count > len(self.pages[page_index]):
            return None
        return page_index, byte_offset, payload[6:6 + byte_count]

    # -- replay ---------------------------------------------------------------

    def run(self):
        log = self.log
        total = len(log)
        off = 0
        while off < total:
            if total - off < HEADER_SIZE:
                break                       # torn header
            payload_len, seq, kind, txid = HEADER.unpack_from(log, off)
            if payload_len > MAX_PAYLOAD:   # invalid header
                break
            if seq <= self.last_seq:        # non-positive / non-increasing sequence
                break
            if txid == 0:                   # invalid transaction id
                break
            if kind not in VALID_KINDS:     # unknown kind
                break
            end = off + HEADER_SIZE + payload_len + CRC_SIZE
            if end > total:
                break                       # torn payload / crc
            body = log[off:end - CRC_SIZE]
            if zlib.crc32(body) & 0xffffffff != U32.unpack_from(log, end - CRC_SIZE)[0]:
                break                       # bad seal
            payload = body[HEADER_SIZE:]

            if kind == KIND_BEGIN:
                if payload_len != 0:
                    break
                # A fresh incarnation discards any unfinished one.
                self.active[txid] = [[], 0]
            elif kind == KIND_PATCH:
                staged = self._patch_ok(payload)
                if staged is None:
                    break
                state = self.active.get(txid)
                if state is not None:       # inactive ids are simply ignored
                    state[0].append(staged)
                    state[1] = zlib.crc32(payload, state[1]) & 0xffffffff
            elif kind == KIND_COMMIT:
                if payload_len != 8:
                    break
                patch_count, digest = struct.unpack_from('<II', payload, 0)
                state = self.active.pop(txid, None)
                if state is not None:
                    patches, running = state
                    if (patch_count == len(patches) and digest == running
                            and seq > self.checkpoint):
                        pages = self.pages
                        for page_index, byte_offset, data in patches:
                            page = pages[page_index]
                            page[byte_offset:byte_offset + len(data)] = data
            else:                            # KIND_ABORT
                if payload_len != 0:
                    break
                self.active.pop(txid, None)

            self.last_seq = seq
            self.valid_bytes = end
            off = end
        return self


def solve(request):
    pages_hex = request.get('pages') or []
    if not isinstance(pages_hex, list):
        pages_hex = []
    pages = []
    for entry in pages_hex:
        raw = _decode_hex(entry)
        pages.append(bytearray(raw))
    checkpoint = request.get('checkpoint')
    if isinstance(checkpoint, bool) or not isinstance(checkpoint, (int, float)):
        checkpoint = 0
    if checkpoint < 0:
        checkpoint = 0
    checkpoint = int(checkpoint)
    log = _decode_hex(request.get('log'))
    rec = Recovery(pages, checkpoint, log).run()
    return {
        'pages': [bytes(page).hex() for page in rec.pages],
        'valid_bytes': rec.valid_bytes,
        'last_seq': rec.last_seq,
    }


def main(stream_in=None, stream_out=None):
    if stream_in is None:
        stream_in = sys.stdin
    if stream_out is None:
        stream_out = sys.stdout
    for line in stream_in:
        if not line.strip():
            continue
        try:
            response = solve(json.loads(line))
        except Exception as exc:  # pragma: no cover - defensive only
            sys.stderr.write('error: %r\n' % (exc,))
            response = {'pages': [], 'valid_bytes': 0, 'last_seq': 0}
        stream_out.write(json.dumps(response) + '\n')
        stream_out.flush()


if __name__ == '__main__':
    main()
