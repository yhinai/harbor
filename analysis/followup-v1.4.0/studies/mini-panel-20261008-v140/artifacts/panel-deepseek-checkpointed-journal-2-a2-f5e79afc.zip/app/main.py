import json
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_SIZE = 13  # u32 length | u32 sequence | u8 kind | u32 transaction_id
CRC_SIZE = 4
KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _hex_to_bytes(s):
    """Decode a hex string.  A trailing torn nibble cannot form a byte."""
    if len(s) & 1:
        s = s[:-1]
    return bytes.fromhex(s)


def _u16(buf, off):
    return buf[off] | (buf[off + 1] << 8)


def _u32(buf, off):
    return (
        buf[off]
        | (buf[off + 1] << 8)
        | (buf[off + 2] << 16)
        | (buf[off + 3] << 24)
    )


def solve(request):
    pages = [bytearray(_hex_to_bytes(p)) for p in request["pages"]]
    page_count = len(pages)
    page_lens = [len(p) for p in pages]
    checkpoint = request["checkpoint"]
    log = _hex_to_bytes(request["log"])
    log_len = len(log)

    # Active incarnations: transaction_id -> list of raw PATCH payloads, in
    # the order their records appeared in the log.
    active = {}

    pos = 0
    valid_bytes = 0
    last_seq = 0

    while pos + HEADER_SIZE <= log_len:
        payload_len = _u32(log, pos)
        if payload_len > MAX_PAYLOAD:
            break
        body_end = pos + HEADER_SIZE + payload_len
        record_end = body_end + CRC_SIZE
        if record_end > log_len:
            # Incomplete header/payload/CRC: torn record.
            break

        seq = _u32(log, pos + 4)
        kind = log[pos + 8]
        txid = _u32(log, pos + 9)

        stored_crc = _u32(log, body_end)
        if stored_crc != (zlib.crc32(log[pos:body_end]) & 0xFFFFFFFF):
            break
        if seq == 0 or seq <= last_seq:
            break
        if txid == 0:
            break

        payload = log[pos + HEADER_SIZE:body_end]

        # Structural validation of the record shape.  This happens for every
        # record, even ones whose transaction is inactive.
        if kind == KIND_BEGIN:
            if payload_len != 0:
                break
        elif kind == KIND_PATCH:
            if payload_len < 6:
                break
            page_index = _u16(payload, 0)
            byte_offset = _u16(payload, 2)
            byte_count = _u16(payload, 4)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_index >= page_count:
                break
            if byte_offset + byte_count > page_lens[page_index]:
                break
        elif kind == KIND_COMMIT:
            if payload_len != 8:
                break
        elif kind == KIND_ABORT:
            if payload_len != 0:
                break
        else:
            break

        # The record is part of the valid prefix from here on.
        pos = record_end
        valid_bytes = pos
        last_seq = seq

        # Semantic processing.
        if kind == KIND_BEGIN:
            active[txid] = []
        elif kind == KIND_PATCH:
            if txid in active:
                active[txid].append(payload)
        elif kind == KIND_COMMIT:
            incarnation = active.pop(txid, None)
            if incarnation is not None:
                patch_count = _u32(payload, 0)
                digest = _u32(payload, 4)
                combined = b"".join(incarnation)
                if (
                    patch_count == len(incarnation)
                    and digest == (zlib.crc32(combined) & 0xFFFFFFFF)
                    and seq > checkpoint
                ):
                    for staged in incarnation:
                        pidx = _u16(staged, 0)
                        off = _u16(staged, 2)
                        cnt = _u16(staged, 4)
                        pages[pidx][off:off + cnt] = staged[6:6 + cnt]
        else:  # KIND_ABORT
            active.pop(txid, None)

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        response = solve(json.loads(line))
        out.write(json.dumps(response, separators=(",", ":")))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
