import json
import sys


def solve(request):
    """Enumerate every terminal observable outcome of the mixed-width
    buffered (TSO-like) machine described in the task statement.

    The exploration is memoised on the *core* state (program counters, store
    buffers, shared memory).  Observations never influence future transitions,
    so from any core state the set of possible suffixes (per-thread read
    lists, final memory) is fixed; a state reached by different histories can
    reuse the same suffix set.
    """
    memory = bytes(request["memory"])
    threads = request["threads"]
    nthreads = len(threads)

    # Normalise the instruction lists into tuples.
    instrs = []
    for th in threads:
        norm = []
        for ins in th:
            op = ins[0]
            if op == "store":
                norm.append(("store", int(ins[1]), int(ins[2]), int(ins[3])))
            elif op == "load":
                norm.append(("load", int(ins[1]), int(ins[2])))
            elif op == "fence":
                norm.append(("fence",))
            elif op == "xchg":
                norm.append(("xchg", int(ins[1]), int(ins[2]), int(ins[3])))
            else:
                raise ValueError("unknown instruction %r" % (op,))
        instrs.append(tuple(norm))
    instrs = tuple(instrs)
    lens = tuple(len(t) for t in instrs)

    start_pcs = (0,) * nthreads
    start_bufs = tuple(() for _ in range(nthreads))
    empty_reads = tuple(() for _ in range(nthreads))

    sys.setrecursionlimit(10000)
    memo = {}

    def explore(pcs, bufs, mem):
        """Set of (reads, final_mem) reachable from this core state.

        `reads` is a tuple with one tuple of observed values per thread,
        containing only the observations made from this state onward.
        """
        key = (pcs, bufs, mem)
        if key in memo:
            return memo[key]

        if pcs == lens and all(not b for b in bufs):
            res = {(empty_reads, mem)}
            memo[key] = res
            return res

        results = set()

        # 1. Execute the next instruction of any unfinished thread.
        for t in range(nthreads):
            pc = pcs[t]
            if pc >= lens[t]:
                continue
            ins = instrs[t][pc]
            op = ins[0]

            if op == "store":
                addr, width, value = ins[1], ins[2], ins[3]
                nb = bufs[t] + ((addr, width, value),)
                npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                nbufs = bufs[:t] + (nb,) + bufs[t + 1:]
                results.update(explore(npcs, nbufs, mem))

            elif op == "load":
                addr, width = ins[1], ins[2]
                buf = bufs[t]
                val = 0
                shift = 0
                for k in range(width):
                    b = addr + k
                    byte = mem[b]
                    # The youngest buffered store covering this byte wins.
                    for (sa, sw, sv) in reversed(buf):
                        if sa <= b < sa + sw:
                            byte = (sv >> (8 * (b - sa))) & 0xFF
                            break
                    val |= byte << shift
                    shift += 8
                npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                for reads, m in explore(npcs, bufs, mem):
                    results.add((reads[:t] + ((val,) + reads[t],) + reads[t + 1:], m))

            elif op == "fence":
                # Enabled only when this thread's buffer is empty.
                if not bufs[t]:
                    npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                    results.update(explore(npcs, bufs, mem))

            else:  # xchg
                # Enabled only when this thread's buffer is empty.
                if not bufs[t]:
                    addr, width, value = ins[1], ins[2], ins[3]
                    val = int.from_bytes(mem[addr:addr + width], "little")
                    newmem = (mem[:addr] + value.to_bytes(width, "little")
                              + mem[addr + width:])
                    npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
                    for reads, m in explore(npcs, bufs, newmem):
                        results.add((reads[:t] + ((val,) + reads[t],) + reads[t + 1:], m))

        # 2. Drain the oldest store of any nonempty buffer to shared memory.
        for t in range(nthreads):
            buf = bufs[t]
            if buf:
                addr, width, value = buf[0]
                newmem = (mem[:addr] + value.to_bytes(width, "little")
                          + mem[addr + width:])
                nbufs = bufs[:t] + (buf[1:],) + bufs[t + 1:]
                results.update(explore(pcs, nbufs, newmem))

        memo[key] = results
        return results

    raw = explore(start_pcs, start_bufs, memory)

    outcomes = [{"reads": [list(r) for r in reads], "memory": list(mem)}
                for reads, mem in raw]
    # Deterministic ordering (the contract does not require any particular one).
    outcomes.sort(key=lambda o: (o["memory"], o["reads"]))
    return {"outcomes": outcomes}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request)))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
