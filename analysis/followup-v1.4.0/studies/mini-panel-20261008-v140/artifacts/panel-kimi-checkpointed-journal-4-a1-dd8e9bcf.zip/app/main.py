"""Deterministic recovery of a checkpointed transactional byte journal.

Record layout (all integers unsigned, little-endian):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
    | payload | crc:u32
CRC is zlib.crc32(header + payload) & 0xffffffff.

Only the structurally valid prefix of the log is replayed, and only complete,
correctly sealed transactions with COMMIT sequence greater than the checkpoint
are applied.
"""

import json
import sys
import zlib

HEADER_LEN = 13
CRC_LEN = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray.fromhex(p) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log_hex = request["log"]
    log = bytes.fromhex(log_hex) if log_hex else b""

    n_pages = len(pages)
    page_len = len(pages[0])
    n = len(log)

    # Active transaction incarnations: txid -> [staged patches, count, digest].
    active = {}

    pos = 0
    last_seq = 0
    valid_bytes = 0

    while True:
        remaining = n - pos
        if remaining < HEADER_LEN:
            break  # incomplete header

        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")

        if payload_length > MAX_PAYLOAD:
            break  # invalid header
        total = HEADER_LEN + payload_length + CRC_LEN
        if remaining < total:
            break  # incomplete record

        payload = log[pos + HEADER_LEN:pos + HEADER_LEN + payload_length]
        stored_crc = int.from_bytes(
            log[pos + HEADER_LEN + payload_length:pos + total], "little")
        if zlib.crc32(log[pos:pos + HEADER_LEN + payload_length]) & 0xFFFFFFFF != stored_crc:
            break  # invalid CRC
        if sequence == 0 or sequence <= last_seq:
            break  # invalid sequence
        if txid == 0:
            break  # invalid transaction ID

        # Kind-specific payload shape and bounds validation. A record must be
        # structurally valid before any semantic effect, even for inactive
        # transactions.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0:
                break
            if payload_length != 6 + byte_count:
                break
            if page_index >= n_pages:
                break
            if byte_offset + byte_count > page_len:
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        else:
            break  # unknown kind

        # The record is part of the valid prefix.
        pos += total
        last_seq = sequence
        valid_bytes = pos

        if kind == KIND_BEGIN:
            # Fresh incarnation; any unfinished one is discarded.
            active[txid] = [[], 0, 0]
        elif kind == KIND_PATCH:
            state = active.get(txid)
            if state is not None:
                state[0].append((page_index, byte_offset, payload[6:]))
                state[1] += 1
                state[2] = zlib.crc32(payload, state[2]) & 0xFFFFFFFF
        elif kind == KIND_ABORT:
            active.pop(txid, None)
        else:  # KIND_COMMIT always closes the active incarnation, if any.
            state = active.pop(txid, None)
            if state is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (patch_count == state[1] and digest == state[2]
                        and sequence > checkpoint):
                    for page_index, byte_offset, data in state[0]:
                        pages[page_index][byte_offset:byte_offset + len(data)] = data

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


if __name__ == "__main__":
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))))
