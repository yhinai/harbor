import json
import sys

FIN = 0
INF = 1
NAN = 2


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    F = 1 << fbits
    Eall = (1 << ebits) - 1
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    width = 1 + ebits + fbits
    mask = (1 << width) - 1
    fmask = F - 1

    def classify(h):
        # returns (sign, kind, significand, exponent, is_signaling_nan)
        v = int(h, 16) & mask
        sign = (v >> (ebits + fbits)) & 1
        e = (v >> fbits) & Eall
        f = v & fmask
        if e == Eall:
            if f == 0:
                return (sign, INF, 0, 0, False)
            snan = ((f >> (fbits - 1)) & 1) == 0
            return (sign, NAN, 0, 0, snan)
        if e == 0:
            return (sign, FIN, f, 1 - bias - fbits, False)
        return (sign, FIN, F + f, e - bias - fbits, False)

    any_nan = False
    invalid = False
    inf_signs = set()
    all_neg_zero = len(pairs) > 0
    terms = []  # (significand, exponent, sign)

    for p in pairs:
        a = classify(p[0])
        b = classify(p[1])
        if a[1] == NAN or b[1] == NAN:
            any_nan = True
            if (a[1] == NAN and a[4]) or (b[1] == NAN and b[4]):
                invalid = True
            all_neg_zero = False
            continue
        a_inf = a[1] == INF
        b_inf = b[1] == INF
        a_zero = (a[1] == FIN and a[2] == 0)
        b_zero = (b[1] == FIN and b[2] == 0)
        if (a_inf and b_zero) or (a_zero and b_inf):
            invalid = True
            all_neg_zero = False
            continue
        if a_inf or b_inf:
            inf_signs.add(a[0] ^ b[0])
            all_neg_zero = False
            continue
        s = a[0] ^ b[0]
        if a[2] == 0 or b[2] == 0:
            # signed zero product
            if s != 1:
                all_neg_zero = False
            continue
        all_neg_zero = False
        terms.append((a[2] * b[2], a[3] + b[3], s))

    if len(inf_signs) > 1:
        invalid = True

    if invalid or any_nan:
        # canonical NaN: sign 0, exponent Eall, only top fraction bit set
        bits = (Eall << fbits) | (1 << (fbits - 1))
        return bits, (["invalid"] if invalid else [])

    if inf_signs:
        s = next(iter(inf_signs))
        bits = (s << (ebits + fbits)) | (Eall << fbits)
        return bits, []

    if not terms:
        neg = all_neg_zero or (mode == "RDN")
        bits = (1 << (ebits + fbits)) if neg else 0
        return bits, []

    # exact sum = P / 2**Q
    minp = min(t[1] for t in terms)
    Q = -minp if minp < 0 else 0
    P = 0
    for m, p, s in terms:
        v = m << (p + Q)
        if s:
            P -= v
        else:
            P += v

    if P == 0:
        neg = all_neg_zero or (mode == "RDN")
        bits = (1 << (ebits + fbits)) if neg else 0
        return bits, []

    sign = 1 if P < 0 else 0
    n = -P if P < 0 else P

    L = n.bit_length() - 1 - Q
    shift = emin - fbits
    s2 = L - fbits
    if s2 > shift:
        shift = s2

    # a = n / 2**(Q+shift) exactly
    k = Q + shift
    if k >= 0:
        A = n
        Dexp = k
    else:
        A = n << (-k)
        Dexp = 0

    if Dexp:
        den = 1 << Dexp
        fl = A >> Dexp
        rem = A - (fl << Dexp)
    else:
        den = 1
        fl = A
        rem = 0

    if mode == "RNE":
        if rem == 0:
            y = fl
        else:
            twice = rem << 1
            if twice > den or (twice == den and (fl & 1)):
                y = fl + 1
            else:
                y = fl
    elif mode == "RNA":
        if rem == 0:
            y = fl
        else:
            y = fl + 1 if (rem << 1) >= den else fl
    elif mode == "RTZ":
        y = fl
    elif mode == "RUP":
        y = fl + 1 if (sign == 0 and rem > 0) else fl
    else:  # RDN
        y = fl + 1 if (sign == 1 and rem > 0) else fl

    # rounded magnitude value = y * 2**shift
    thr = emax + 1
    if y == 0:
        overflow = False
    elif shift >= thr:
        overflow = True
    else:
        overflow = y >= (1 << (thr - shift))

    if overflow:
        flags = ["overflow", "inexact"]
        away = (mode in ("RNE", "RNA")) or (mode == "RUP" and sign == 0) or (mode == "RDN" and sign == 1)
        if away:
            bits = (sign << (ebits + fbits)) | (Eall << fbits)
        else:
            bits = (sign << (ebits + fbits)) | ((Eall - 1) << fbits) | fmask
        return bits, flags

    kk = Q + shift
    if kk >= 0:
        exact = (y << kk) == n
    else:
        exact = y == (n << (-kk))

    flags = []
    if not exact:
        flags.append("inexact")
        if y == 0:
            under = True
        elif shift >= emin:
            under = False
        else:
            under = y < (1 << (emin - shift))
        if under:
            flags.append("underflow")

    if y == 0:
        bits = sign << (ebits + fbits)
        return bits, flags

    Lp = y.bit_length() - 1 + shift
    if Lp < emin:
        ef = 0
        frac = y
    else:
        ef = Lp + bias
        k2 = fbits - (y.bit_length() - 1)
        if k2 >= 0:
            M = y << k2
        else:
            M = y >> (-k2)
        frac = M - F
    bits = (sign << (ebits + fbits)) | (ef << fbits) | frac
    return bits, flags


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        bits, flags = solve(req)
        out.write(json.dumps({"bits": format(bits, "x"), "flags": flags}) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
