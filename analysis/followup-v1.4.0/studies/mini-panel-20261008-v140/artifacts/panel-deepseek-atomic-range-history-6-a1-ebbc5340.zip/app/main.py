"""Linearizability checker for atomic range transactions.

A history consists of whole transactions, each of which executes atomically.
Given the initial map, the final map and all observed return values, we must
either produce a total order of the transactions that is a linear extension of
the real-time partial order (A.end <= B.start  =>  A before B) and reproduces
every observation, or prove that no such order exists.

Algorithm: forward dynamic programming over subsets of executed transactions.
For a subset S only a *projection* of the possible states is relevant:

  * keys that are externally read by some not-yet-executed transaction keep
    their exact value (their value is observed),
  * keys that are written (put/del/cas) by some not-yet-executed transaction
    but never externally read are irrelevant (they are guaranteed to be
    overwritten before being observed) and are replaced by a wildcard,
  * every other key can never change again, so it must already equal the
    desired final value.

Additionally, if a key is externally read by the remaining transactions but is
never written by them, its value is frozen; all those reads must expect the
same value and that value must equal the final value, otherwise the subset is
dead.  This projection is sound and complete: a wildcard key is never read
before the transaction that overwrites it, and every observation reads exact
values.
"""

import sys
import json

WILD = -99  # sentinel; real values are in [-9, 9] or None (absent)


def solve(request):
    initial = request.get("initial") or {}
    final = request.get("final") or {}
    txs = request.get("transactions") or []
    n = len(txs)

    if n == 0:
        return {"order": [] if initial == final else None}

    # ---------------------------------------------------------------
    # Keys that can ever occur in a map.
    # ---------------------------------------------------------------
    keyset = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind in ("get", "put", "del", "cas"):
                keyset.add(op[1])
            elif kind == "scan":
                for p in op[3]:
                    keyset.add(p[0])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}
    K = len(keys)
    allmask = (1 << K) - 1

    final_st = tuple(final.get(k) for k in keys)
    init_st = tuple(initial.get(k) for k in keys)

    # ---------------------------------------------------------------
    # Compile operations.
    # Op codes: 0 get(i,exp) 1 put(i,val) 2 del(i) 3 cas(i,old,new,want)
    #           4 scan(idxs, expected pairs)
    # read_masks: keys whose incoming value is observed (external reads).
    # write_masks: keys written by the transaction.
    # ---------------------------------------------------------------
    compiled = []
    read_masks = []
    write_masks = []
    ext_reads = []
    for t in txs:
        cops = []
        rm = 0
        wm = 0
        reads = []
        written = 0
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                i = kidx[op[1]]
                if not (written >> i) & 1:
                    rm |= 1 << i
                    reads.append((i, op[2]))
                cops.append((0, i, op[2]))
            elif kind == "put":
                i = kidx[op[1]]
                wm |= 1 << i
                written |= 1 << i
                cops.append((1, i, op[2]))
            elif kind == "del":
                i = kidx[op[1]]
                wm |= 1 << i
                written |= 1 << i
                cops.append((2, i))
            elif kind == "cas":
                i = kidx[op[1]]
                if not (written >> i) & 1:
                    rm |= 1 << i
                    reads.append((i, op[2]))
                wm |= 1 << i
                written |= 1 << i
                cops.append((3, i, op[2], op[3], op[4]))
            else:  # scan
                low = op[1]
                high = op[2]
                idxs = tuple(j for j, k in enumerate(keys) if low <= k < high)
                expvals = {}
                for p in op[3]:
                    expvals[kidx[p[0]]] = p[1]
                for j in idxs:
                    if not (written >> j) & 1:
                        rm |= 1 << j
                        reads.append((j, expvals.get(j)))
                exp = tuple((kidx[p[0]], p[1]) for p in op[3])
                cops.append((4, idxs, exp))
        compiled.append(tuple(cops))
        read_masks.append(rm)
        write_masks.append(wm)
        ext_reads.append(tuple(reads))

    def execute(ti, st):
        """Execute transaction ti on exact state st; None if an observation fails."""
        lst = list(st)
        for op in compiled[ti]:
            code = op[0]
            if code == 0:
                if lst[op[1]] != op[2]:
                    return None
            elif code == 1:
                lst[op[1]] = op[2]
            elif code == 2:
                lst[op[1]] = None
            elif code == 3:
                i = op[1]
                ok = lst[i] == op[2]
                if ok != op[4]:
                    return None
                if ok:
                    lst[i] = op[3]
            else:
                idxs = op[1]
                exp = op[2]
                pairs = []
                for j in idxs:
                    v = lst[j]
                    if v is not None:
                        pairs.append([keys[j], v])
                if len(pairs) != len(exp):
                    return None
                for a, b in zip(pairs, exp):
                    if a[0] != keys[b[0]] or a[1] != b[1]:
                        return None
        return tuple(lst)

    # ---------------------------------------------------------------
    # Per-subset projection data and partial order constraints.
    # ---------------------------------------------------------------
    full = (1 << n) - 1
    size = 1 << n

    rr_arr = [0] * size        # exact keys (externally read by remaining)
    rw_arr = [0] * size        # keys written by remaining transactions
    fm_arr = [0] * size        # frozen keys with a required value
    fv_arr = [None] * size     # required values for frozen keys
    wild_arr = [0] * size      # irrelevant keys (overwritten, never read)
    cf_arr = [0] * size        # keys that must equal the final value
    dead = bytearray(size)

    # remaining masks by descending DP
    rr_arr[full] = 0
    rw_arr[full] = 0
    for S in range(full - 1, -1, -1):
        b = (full ^ S) & -(full ^ S)
        i = b.bit_length() - 1
        rr_arr[S] = rr_arr[S | b] | read_masks[i]
        rw_arr[S] = rw_arr[S | b] | write_masks[i]

    for S in range(size):
        rr = rr_arr[S]
        rw = rw_arr[S]
        fm = rr & ~rw
        wild_arr[S] = rw & ~rr
        cf_arr[S] = allmask & ~(rr | rw)
        if fm:
            req = {}
            bad = False
            x = full ^ S
            while x:
                b = x & -x
                i = b.bit_length() - 1
                x ^= b
                for j, v in ext_reads[i]:
                    if (fm >> j) & 1:
                        if j in req:
                            if req[j] != v:
                                bad = True
                                break
                        else:
                            req[j] = v
                if bad:
                    break
            if not bad:
                for j in req:
                    if req[j] != final_st[j]:
                        bad = True
                        break
            if bad:
                dead[S] = 1
                continue
            vals = [None] * K
            for j, v in req.items():
                vals[j] = v
            fm_arr[S] = fm
            fv_arr[S] = tuple(vals)

    def normalize(S, st):
        """Project state st onto the information relevant for the remaining txs."""
        fm = fm_arr[S]
        if fm:
            fv = fv_arr[S]
            x = fm
            while x:
                b = x & -x
                j = b.bit_length() - 1
                x ^= b
                if st[j] != fv[j]:
                    return None
        cf = cf_arr[S]
        if cf:
            x = cf
            while x:
                b = x & -x
                j = b.bit_length() - 1
                x ^= b
                if st[j] != final_st[j]:
                    return None
        w = wild_arr[S]
        if w:
            return tuple(WILD if (w >> j) & 1 else st[j] for j in range(K))
        return st

    # ---------------------------------------------------------------
    # Executable transactions for every subset (partial order).
    # ---------------------------------------------------------------
    pre = []
    for i, t in enumerate(txs):
        m = 0
        for j, u in enumerate(txs):
            if j != i and u["end"] <= t["start"]:
                m |= 1 << j
        pre.append(m)

    avail_list = [None] * size
    for S in range(size):
        x = full ^ S
        av = []
        while x:
            b = x & -x
            i = b.bit_length() - 1
            x ^= b
            if pre[i] & ~S == 0:
                av.append(i)
        avail_list[S] = av

    exec_cache = {}

    def exec_cached(ti, st):
        key = (ti, st)
        r = exec_cache.get(key, _MISS)
        if r is _MISS:
            r = execute(ti, st)
            exec_cache[key] = r
        return r

    # ---------------------------------------------------------------
    # Subset DP.
    # ---------------------------------------------------------------
    def search(normalized):
        reach = [None] * size
        if normalized:
            if dead[0]:
                return reach
            init_norm = normalize(0, init_st)
            if init_norm is None:
                return reach
        else:
            init_norm = init_st
        reach[0] = {init_norm: None}
        for S in range(full):
            cur = reach[S]
            if not cur:
                continue
            for i in avail_list[S]:
                S2 = S | (1 << i)
                if normalized and dead[S2]:
                    continue
                tgt = reach[S2]
                if tgt is None:
                    tgt = {}
                    reach[S2] = tgt
                for st in cur:
                    res = exec_cached(i, st)
                    if res is None:
                        continue
                    nst = normalize(S2, res) if normalized else res
                    if nst is None:
                        continue
                    if nst not in tgt:
                        tgt[nst] = (st, i)
        return reach

    def reconstruct(reach):
        if reach[full] is None or final_st not in reach[full]:
            return None
        order_idx = []
        S = full
        st = final_st
        while S:
            entry = reach[S].get(st)
            if entry is None:
                return None
            prev, i = entry
            order_idx.append(i)
            st = prev
            S ^= 1 << i
        order_idx.reverse()
        return order_idx

    def verify(order_idx):
        d = dict(initial)
        for i in order_idx:
            for op in txs[i]["ops"]:
                kind = op[0]
                if kind == "get":
                    if d.get(op[1]) != op[2]:
                        return False
                elif kind == "put":
                    d[op[1]] = op[2]
                elif kind == "del":
                    d.pop(op[1], None)
                elif kind == "cas":
                    _, key, old, new, want = op
                    ok = d.get(key) == old
                    if ok != want:
                        return False
                    if ok:
                        if new is None:
                            d.pop(key, None)
                        else:
                            d[key] = new
                else:
                    _, low, high, expected = op
                    got = sorted([[k, v] for k, v in d.items() if low <= k < high])
                    if got != expected:
                        return False
        return d == final

    reach = search(True)
    order_idx = reconstruct(reach)
    if order_idx is not None:
        if verify(order_idx):
            return {"order": [txs[i]["id"] for i in order_idx]}
        # Should never happen; fall back to the exact (unnormalised) search.
        reach2 = search(False)
        order_idx = reconstruct(reach2)
        if order_idx is not None and verify(order_idx):
            return {"order": [txs[i]["id"] for i in order_idx]}
        return {"order": None}
    return {"order": None}


_MISS = object()


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req)))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
