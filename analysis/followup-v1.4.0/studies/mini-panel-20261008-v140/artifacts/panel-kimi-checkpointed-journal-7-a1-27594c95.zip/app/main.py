"""Deterministic recovery of a checkpointed transactional byte journal.

Replay only structurally valid prefix records and only complete, correctly
sealed transactions newer than the supplied checkpoint.

Record layout (all integers unsigned, little-endian):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
    | payload | crc:u32
crc = zlib.crc32(header + payload) & 0xffffffff, header is the 13 fixed bytes.
"""

import json
import sys
import zlib

HEADER_LEN = 13
CRC_LEN = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log_hex = request["log"]
    log = bytes.fromhex(log_hex) if log_hex else b""

    n_pages = len(pages)
    n = len(log)
    pos = 0
    prev_seq = 0
    last_seq = 0
    valid_bytes = 0
    # txid -> [staged_patch_count, running_payload_crc, [(page, offset, data)]]
    active = {}

    while True:
        remaining = n - pos
        if remaining < HEADER_LEN:
            break  # incomplete record header
        header = log[pos:pos + HEADER_LEN]
        payload_length = int.from_bytes(header[0:4], "little")
        sequence = int.from_bytes(header[4:8], "little")
        kind = header[8]
        txid = int.from_bytes(header[9:13], "little")

        if payload_length > MAX_PAYLOAD:
            break  # invalid header
        end = pos + HEADER_LEN + payload_length + CRC_LEN
        if end > n:
            break  # incomplete record body/crc
        payload = log[pos + HEADER_LEN:pos + HEADER_LEN + payload_length]
        crc_field = int.from_bytes(
            log[pos + HEADER_LEN + payload_length:end], "little")
        if zlib.crc32(header + payload) & 0xFFFFFFFF != crc_field:
            break  # invalid CRC
        if sequence <= prev_seq:
            break  # sequence must be positive and strictly increasing
        if txid == 0:
            break  # transaction ID must be positive

        # Payload shape / bounds per kind (structural validation happens
        # before any semantic effect, even for inactive transactions).
        if kind == KIND_BEGIN:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            if page_index >= n_pages:
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        elif kind == KIND_ABORT:
            if payload_length != 0:
                break
        else:
            break  # unknown kind

        # Record is structurally valid: it extends the prefix and takes part
        # in transaction state processing regardless of the checkpoint.
        prev_seq = sequence
        last_seq = sequence
        valid_bytes = end
        pos = end

        if kind == KIND_BEGIN:
            # Fresh incarnation, discarding any unfinished one.
            active[txid] = [0, 0, []]
        elif kind == KIND_PATCH:
            inc = active.get(txid)
            if inc is not None:
                inc[0] += 1
                inc[1] = zlib.crc32(payload, inc[1]) & 0xFFFFFFFF
                inc[2].append((page_index, byte_offset, bytes(payload[6:])))
        elif kind == KIND_COMMIT:
            inc = active.pop(txid, None)  # COMMIT always closes it, if any
            if inc is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (patch_count == inc[0] and digest == inc[1]
                        and sequence > checkpoint):
                    for pi, off, data in inc[2]:
                        pages[pi][off:off + len(data)] = data
        elif kind == KIND_ABORT:
            active.pop(txid, None)

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
