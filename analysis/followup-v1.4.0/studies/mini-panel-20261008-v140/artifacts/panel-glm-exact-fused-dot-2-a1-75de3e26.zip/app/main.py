#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating-point format.

All multiplication and accumulation is done exactly (integer arithmetic);
only the final sum is rounded to the destination format.
"""
import json
import sys

NEAREST = ('RNE', 'RNA')


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = req['mode']
    pairs = req['pairs']

    width = 1 + ebits + fbits
    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                 # significand scale (2**fbits)
    fmask = F - 1                  # stored fraction mask
    topfrac = 1 << (fbits - 1)     # top fraction bit (quiet / canonical NaN)
    Eall = (1 << ebits) - 1        # all-ones exponent
    emin = 1 - bias                # minimum normal exponent
    emax = Eall - 1 - bias         # maximum normal exponent
    subexp = emin - fbits          # exponent of the subnormal quantum

    signbit = 1 << (width - 1)
    widthmask = (1 << width) - 1
    expshift = fbits

    def decode(hexpat):
        # hex string (case and leading zeros immaterial), masked to the width
        v = int(hexpat, 16) & widthmask
        s = (v >> (width - 1)) & 1
        e = (v >> expshift) & Eall
        f = v & fmask
        return s, e, f

    # ------------------------------------------------------------------
    # Pass over every pair: classify operands, gather exact products.
    # Every operand is inspected, even when another one is a NaN.
    # ------------------------------------------------------------------
    invalid = False
    has_nan = False
    pos_inf = False
    neg_inf = False
    products = []                  # (product sign, significand, exponent)

    for a_hex, b_hex in pairs:
        sa, ea, fa = decode(a_hex)
        sb, eb, fb = decode(b_hex)

        a_nan = (ea == Eall and fa != 0)
        b_nan = (eb == Eall and fb != 0)
        if a_nan or b_nan:
            # A pair with a NaN operand contributes no infinite product and
            # cannot itself count as zero times infinity.
            has_nan = True
            if (a_nan and not (fa & topfrac)) or (b_nan and not (fb & topfrac)):
                invalid = True     # signaling NaN
            continue

        a_inf = (ea == Eall)
        b_inf = (eb == Eall)
        if a_inf or b_inf:
            if (ea == 0 and fa == 0) or (eb == 0 and fb == 0):
                invalid = True     # zero times infinity, either order
            elif sa ^ sb:
                neg_inf = True      # negative infinite product
            else:
                pos_inf = True      # positive infinite product
            continue

        # Finite operand: value = mantissa * 2**exp (exact integers).
        if ea == 0:
            ma, xa = fa, subexp
        else:
            ma, xa = F + fa, ea - bias - fbits
        if eb == 0:
            mb, xb = fb, subexp
        else:
            mb, xb = F + fb, eb - bias - fbits
        products.append((sa ^ sb, ma * mb, xa + xb))

    if pos_inf and neg_inf:
        invalid = True              # +inf and -inf products cancel -> invalid

    # ------------------------------------------------------------------
    # NaN / infinity outcomes.
    # ------------------------------------------------------------------
    if has_nan or invalid:
        canonical = (Eall << expshift) | topfrac
        return {'bits': '%x' % canonical,
                'flags': ['invalid'] if invalid else []}

    if pos_inf or neg_inf:
        s = 1 if neg_inf else 0
        return {'bits': '%x' % ((s << (width - 1)) | (Eall << expshift)),
                'flags': []}

    # ------------------------------------------------------------------
    # Exact accumulation of finite products on a common power-of-two scale.
    # ------------------------------------------------------------------
    nonzero = [p for p in products if p[1]]
    if nonzero:
        e0 = min(p[2] for p in nonzero)
        total = 0
        for sgn, m, x in products:
            if m:
                term = m << (x - e0)
                total = total - term if sgn else total + term
    else:
        e0 = 0
        total = 0

    if total == 0:
        # Exact zero: negative only if every product is a negative signed zero
        # (and there is at least one), or the mode is RDN.
        neg = (mode == 'RDN') or (
            bool(products) and all(sgn == 1 and m == 0 for sgn, m, _ in products))
        return {'bits': '%x' % (signbit if neg else 0), 'flags': []}

    sign = 1 if total < 0 else 0
    X = -total if total < 0 else total      # exact magnitude = X * 2**e0
    L = X.bit_length() - 1 + e0             # floor(log2(x))
    # quantum exponent: q = 2**Q (the subnormal quantum, or the binade's grid)
    Q = subexp if (L - fbits) < subexp else (L - fbits)

    d = Q - e0
    if d <= 0:
        k = X << (-d)                       # x/q is an exact integer
        rem = 0
    else:
        fl = X >> d                          # floor(x/q) in magnitude
        rem = X - (fl << d)                  # 0 <= rem < q
        if rem == 0:
            k = fl
        else:
            up = fl + 1
            half = 1 << (d - 1)
            if mode == 'RTZ':
                k = fl
            elif mode == 'RUP':
                k = up if sign == 0 else fl
            elif mode == 'RDN':
                k = fl if sign == 0 else up
            else:                            # RNE / RNA: nearest
                if rem > half:
                    k = up
                elif rem < half:
                    k = fl
                else:                        # exact tie
                    # RNE: ties to an even significand; RNA: ties away from zero
                    k = up if (mode == 'RNA' or (fl & 1) == 1) else fl

    # y = k * 2**Q (rounded magnitude).  Helpers avoid negative shifts.
    def scale_ge(n):
        """Is k * 2**Q >= 2**n ?"""
        t = n - Q
        if t < 0:
            return k >= 1
        return k >= (1 << t)

    if scale_ge(emax + 1):
        # Overflow: always inexact.  Nearest modes and the directed mode that
        # points away from zero deliver infinity; the others max finite.
        inf_bits = (sign << (width - 1)) | (Eall << expshift)
        max_bits = (sign << (width - 1)) | ((emax + bias) << expshift) | fmask
        if mode in NEAREST:
            bits = inf_bits
        elif mode == 'RTZ':
            bits = max_bits
        elif mode == 'RUP':
            bits = inf_bits if sign == 0 else max_bits
        else:                                # RDN
            bits = inf_bits if sign == 1 else max_bits
        return {'bits': '%x' % bits, 'flags': ['overflow', 'inexact']}

    inexact = rem != 0
    underflow = inexact and not scale_ge(emin)

    if k == 0:
        e, f = 0, 0                          # rounded to zero, keeps exact sign
    else:
        t = k.bit_length() - 1 + Q           # floor(log2(y))
        if t < emin:
            # Subnormal: y = f * 2**(emin - fbits)
            e = 0
            f = k << (Q - subexp)
        else:
            e = t + bias
            sh = k.bit_length() - 1 - fbits
            f = (k >> sh) - F if sh >= 0 else (k << (-sh)) - F

    bits = (sign << (width - 1)) | (e << expshift) | f
    flags = []
    if inexact:
        flags.append('inexact')
    if underflow:
        flags.append('underflow')
    return {'bits': '%x' % bits, 'flags': flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(solve(req)) + '\n')
        out.flush()          # safe for interactive (pipe-driven) callers


if __name__ == '__main__':
    main()
