#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation.  Given a completed history of
transactions (each with a real-time interval [start, end) and a list of
operations carrying their observed return values) we must either exhibit a
serial order of the transactions that is compatible with real time and
reproduces every observation plus the final map, or prove that no such order
exists.

The search enumerates serial orders with a depth first walk over the partial
order induced by the real time constraints.  A node of the search is

    (set of already serialised transactions, resulting state)

and nodes that cannot lead to a witness are memoised, so each distinct
(state, remaining-set) pair is expanded at most once.  Several cheap but
effective necessary conditions prune branches early.
"""

import json
import sys

# marker for "key is absent".  A real stored value is an int (or, defensively,
# None coming from a "put" of JSON null), so this sentinel is distinct.
ABSENT = "\x00__absent__\x00"

# op tags (small ints keep the interpreter's dispatch cheap)
_GET, _PUT, _DEL, _CAS, _SCAN = 0, 1, 2, 3, 4


def _compile_history(request):
    """Turn a request into compact index based structures."""
    txs = request.get("transactions") or []
    initial = request.get("initial") or {}
    final = request.get("final") or {}

    keyset = set(initial)
    keyset.update(final)
    for t in txs:
        for op in t["ops"]:
            if op[0] != "scan":
                keyset.add(op[1])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}
    nkeys = len(keys)

    cops = []
    for t in txs:
        cl = []
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                cl.append((_GET, kidx[op[1]], op[2]))
            elif kind == "put":
                cl.append((_PUT, kidx[op[1]], op[2]))
            elif kind == "del":
                cl.append((_DEL, kidx[op[1]]))
            elif kind == "cas":
                cl.append((_CAS, kidx[op[1]], op[2], op[3], op[4]))
            else:  # scan
                lo, hi = op[1], op[2]
                # the range filter is static: precompute the affected slots
                rng = tuple(
                    (i, keys[i]) for i in range(nkeys) if lo <= keys[i] < hi
                )
                cl.append((_SCAN, rng, tuple((p[0], p[1]) for p in op[3])))
        cops.append(tuple(cl))

    n = len(txs)

    # real time precedence: i must be serialised before j when end_i <= start_j
    preds = [0] * n
    for i in range(n):
        end_i = txs[i]["end"]
        for j in range(n):
            if i != j and end_i <= txs[j]["start"]:
                preds[j] |= 1 << i

    # keys each transaction may write (put / del / successful cas)
    twr = [0] * n
    for i, cl in enumerate(cops):
        m = 0
        for op in cl:
            tag = op[0]
            if tag == _PUT or tag == _DEL or tag == _CAS:
                m |= 1 << op[1]
        twr[i] = m
    writers = [0] * nkeys
    for i in range(n):
        m = twr[i]
        ki = 0
        while m:
            if m & 1:
                writers[ki] |= 1 << i
            m >>= 1
            ki += 1

    init_st = tuple(ABSENT if k not in initial else initial[k] for k in keys)
    final_st = tuple(ABSENT if k not in final else final[k] for k in keys)

    return {
        "n": n,
        "keys": keys,
        "cops": cops,
        "preds": preds,
        "writers": writers,
        "init": init_st,
        "final": final_st,
        "ids": [t["id"] for t in txs],
    }


def _make_apply():
    """Return apply(ops, state) -> new state or None when an observation fails.

    The semantics mirror the specification exactly:
      get  : absent key reads as null
      put  : assign the value
      del  : remove the key
      cas  : compare with expected old (null = absent), assign new (null =
             delete) on success, the returned flag must match
      scan : all present keys in [low, high) as sorted [key, value] pairs
    """

    def apply(ops, st):
        st = list(st)
        for op in ops:
            tag = op[0]
            if tag == _PUT:
                st[op[1]] = op[2]
            elif tag == _GET:
                v = st[op[1]]
                if v is ABSENT:
                    v = None
                if v != op[2]:
                    return None
            elif tag == _CAS:
                i = op[1]
                v = st[i]
                if v is ABSENT:
                    v = None
                ok = v == op[2]
                if ok is not op[4]:
                    return None
                if ok:
                    new = op[3]
                    st[i] = ABSENT if new is None else new
            elif tag == _DEL:
                st[op[1]] = ABSENT
            else:  # scan
                got = tuple(
                    (kn, st[i]) for i, kn in op[1] if st[i] is not ABSENT
                )
                if got != op[2]:
                    return None
        return tuple(st)

    return apply


def solve(request):
    hist = _compile_history(request)
    n = hist["n"]
    cops = hist["cops"]
    preds = hist["preds"]
    writers = hist["writers"]
    init_st = hist["init"]
    final_st = hist["final"]
    nkeys = len(final_st)

    if n == 0:
        return {"order": [] if init_st == final_st else None}

    apply = _make_apply()
    full = (1 << n) - 1

    # Every key whose value still differs from the final map needs at least one
    # remaining writer, otherwise the branch is hopeless.
    def coverable(st, rem):
        for ki in range(nkeys):
            if st[ki] != final_st[ki] and not (writers[ki] & rem):
                return False
        return True

    if not coverable(init_st, full):
        return {"order": None}

    failed = set()
    path = []
    push = path.append
    pop = path.pop

    def dfs(mask, st):
        if mask == full:
            return True
        memo = (mask, st)
        if memo in failed:
            return False
        rem = full ^ mask
        for i in range(n):
            bit = 1 << i
            if mask & bit:
                continue
            p = preds[i]
            if (p & mask) != p:
                continue
            nst = apply(cops[i], st)
            if nst is None:
                continue
            nrem = rem ^ bit
            if nrem and not coverable(nst, nrem):
                continue
            elif not nrem and nst != final_st:
                continue
            push(i)
            if dfs(mask | bit, nst):
                return True
            pop()
        failed.add(memo)
        return False

    if dfs(0, init_st):
        ids = hist["ids"]
        return {"order": [ids[i] for i in path]}
    return {"order": None}


def main():
    out = []
    data = sys.stdin.read()
    dec = json.JSONDecoder()
    idx = 0
    ln = len(data)
    while idx < ln:
        while idx < ln and data[idx] in " \t\r\n":
            idx += 1
        if idx >= ln:
            break
        obj, idx = dec.raw_decode(data, idx)
        out.append(json.dumps(solve(obj)))
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
