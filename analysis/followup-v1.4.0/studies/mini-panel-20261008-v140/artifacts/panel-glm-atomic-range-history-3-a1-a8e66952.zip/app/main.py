#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation, so a witness is a serial order of
the transactions such that

  * real time is respected (if A.end <= B.start then A precedes B), and
  * replaying the transactions in that order from `initial` reproduces every
    observed return value and ends exactly at `final`.

The checker either returns one such order or proves that none exists.

Method
------
Each transaction is first compiled into an exact, state independent summary:
the set of equality/inequality constraints its entry state must satisfy for it
to succeed, plus the exact write effects it then performs.  This is possible
because operations are deterministic, so whether a transaction succeeds depends
only on the map it starts from.

A depth first search over transaction subsets then builds the serial order.
Real time is enforced by only scheduling a transaction once all of its
predecessors are scheduled.  Failure memoisation on (scheduled set, state) makes
the search polynomial in the number of reachable states, and two sound
necessary-condition prunings (final map reachability and per transaction
precondition reachability) cut off doomed branches early.
"""

import sys
import json
from bisect import bisect_left

ABSENT = 0  # encoded token for "key not present"


def enc(v):
    """Encode an observed/stored value; absence (null) becomes ABSENT."""
    if v is None:
        return 0
    return v + 10


def analyze_tx(ops, kidx, universe):
    """Compile one transaction.

    Returns (eq, banned, effects) where
      eq      : {key index: value} the entry map must satisfy (reads),
      banned  : {key index: set(values)} the entry map must avoid (failed CAS),
      effects : {key index: value} written by the transaction,
    or None when the transaction can never succeed on any map (its own
    operations contradict each other, or an observation is malformed).
    """
    known = {}    # key index -> current value, when already determined
    eq = {}       # entry constraints (value must be equal)
    banned = {}    # entry constraints (value must differ)
    effects = {}  # writes performed by this transaction

    for op in ops:
        kind = op[0]
        if kind == "get":
            i = kidx.get(op[1])
            if i is None:
                return None
            want = enc(op[2])
            if i in known:
                if known[i] != want:
                    return None
            else:
                if i in eq:
                    if eq[i] != want:
                        return None
                elif want in banned.get(i, ()):
                    return None
                eq[i] = want
                known[i] = want
        elif kind == "put":
            i = kidx.get(op[1])
            if i is None:
                return None
            val = enc(op[2])
            known[i] = val
            effects[i] = val
        elif kind == "del":
            i = kidx.get(op[1])
            if i is None:
                return None
            known[i] = ABSENT
            effects[i] = ABSENT
        elif kind == "cas":
            i = kidx.get(op[1])
            if i is None:
                return None
            old = enc(op[2])
            new = enc(op[3])
            want = op[4]
            if type(want) is not bool:
                # `ok is not want` in the reference semantics: only real
                # booleans can ever match.
                return None
            if i in known:
                if known[i] == old:
                    if not want:
                        return None
                    known[i] = new
                    effects[i] = new
                else:
                    if want:
                        return None
            elif want:
                # must succeed, hence the entry value equals `old`
                if i in eq:
                    if eq[i] != old:
                        return None
                elif old in banned.get(i, ()):
                    return None
                eq[i] = old
                known[i] = new
                effects[i] = new
            else:
                # must fail, hence the entry value differs from `old`
                if i in eq:
                    if eq[i] == old:
                        return None
                else:
                    banned.setdefault(i, set()).add(old)
        elif kind == "scan":
            lo = bisect_left(universe, op[1])
            hi = bisect_left(universe, op[2])
            seen = {}
            prev_key = None
            for pair in op[3]:
                try:
                    k = pair[0]
                    val = pair[1]
                except (TypeError, IndexError):
                    return None
                i = kidx.get(k)
                if i is None or i in seen:
                    return None
                # A scan result is reported sorted by key, each key once, and
                # only present (integer valued) keys appear in it.
                if not (lo <= i < hi) or val is None or type(val) is bool:
                    return None
                if prev_key is not None and not (prev_key < k):
                    return None
                prev_key = k
                seen[i] = enc(val)
            for i in range(lo, hi):
                want = seen.get(i, ABSENT)
                if i in known:
                    if known[i] != want:
                        return None
                else:
                    if i in eq:
                        if eq[i] != want:
                            return None
                    elif want in banned.get(i, ()):
                        return None
                    eq[i] = want
                    known[i] = want
        else:
            return None
    return eq, banned, effects


def compile_tx(summary):
    """Turn a summary into a fast (state -> new state or None) callable."""
    eq, banned, effects = summary
    checks = tuple(eq.items())
    bans = tuple((i, b) for i, bs in banned.items() for b in bs
                 if i not in eq)
    writes = tuple(effects.items())

    def run(state):
        for i, v in checks:
            if state[i] != v:
                return None
        for i, b in bans:
            if state[i] == b:
                return None
        if not writes:
            return state
        s = list(state)
        for i, v in writes:
            s[i] = v
        return tuple(s)

    return run, checks, writes


def solve(request):
    initial = request["initial"]
    final = request["final"]
    raw_txs = request["transactions"]
    if not raw_txs:
        return [] if dict(initial) == dict(final) else None

    # The reference semantics compare every ordered pair of transactions,
    # including a transaction with itself: `A.end <= B.start` requires
    # rank(A) < rank(B).  Hence a transaction with end <= start invalidates
    # every order, a non string id can never be reported, and duplicated ids
    # collapse to a single (last) occurrence.
    txs = {}
    for t in raw_txs:
        if not (t["start"] < t["end"]) or not isinstance(t["id"], str):
            return None
        txs[t["id"]] = t
    txs = list(txs.values())
    n = len(txs)

    # --- key universe (sorted, so ranges are contiguous in index space) ----
    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "scan":
                keys.add(op[1])
                keys.add(op[2])
                for pair in op[3]:
                    keys.add(pair[0])
            else:
                keys.add(op[1])
    universe = sorted(keys)
    K = len(universe)
    kidx = {k: i for i, k in enumerate(universe)}
    init_state = tuple(enc(initial.get(k)) for k in universe)
    final_state = tuple(enc(final.get(k)) for k in universe)

    # --- compile transactions ----------------------------------------------
    runs = []
    eq_checks = []
    effects_of = []
    for t in txs:
        summary = analyze_tx(t["ops"], kidx, universe)
        if summary is None:
            return None
        run, checks, writes = compile_tx(summary)
        runs.append(run)
        eq_checks.append(checks)
        effects_of.append(writes)

    # --- real time precedence ----------------------------------------------
    pred = [0] * n
    for i in range(n):
        start_i = txs[i]["start"]
        for j in range(n):
            if j != i and txs[j]["end"] <= start_i:
                pred[i] |= 1 << j
    full = (1 << n) - 1

    # --- pruning tables -----------------------------------------------------
    writers = [0] * K            # txs writing each key
    to_final = [0] * K           # txs writing each key's final value
    val_writers = [dict() for _ in range(K)]  # value -> txs writing it
    for j in range(n):
        for i, v in effects_of[j]:
            writers[i] |= 1 << j
            val_writers[i].setdefault(v, 0)
            val_writers[i][v] |= 1 << j
            if v == final_state[i]:
                to_final[i] |= 1 << j

    cand_order = sorted(range(n),
                        key=lambda j: (txs[j]["end"], txs[j]["start"], j))
    failed = set()
    order_stack = []

    def prunable(state, remaining):
        # (a) the final map must still be reachable for every key
        for i in range(K):
            if not (to_final[i] & remaining):
                if (writers[i] & remaining) or state[i] != final_state[i]:
                    return True
        # (b) every pending transaction must still be able to run: each of
        #     its reads must be explainable by the current value or by a
        #     pending write
        for j in range(n):
            bit = 1 << j
            if not (remaining & bit):
                continue
            rest = remaining ^ bit
            for i, v in eq_checks[j]:
                if state[i] != v:
                    vw = val_writers[i]
                    if not (vw.get(v, 0) & rest):
                        return True
        return False

    def dfs(mask, state):
        if mask == full:
            return state == final_state
        key = (mask, state)
        if key in failed:
            return False
        remaining = full ^ mask
        if prunable(state, remaining):
            failed.add(key)
            return False
        for j in cand_order:
            bit = 1 << j
            if mask & bit:
                continue
            if pred[j] & ~mask:
                continue
            nxt = runs[j](state)
            if nxt is None:
                continue
            order_stack.append(j)
            if dfs(mask | bit, nxt):
                return True
            order_stack.pop()
        failed.add(key)
        return False

    if dfs(0, init_state):
        return [txs[j]["id"] for j in order_stack]
    return None


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        try:
            order = solve(request)
        except Exception:  # malformed semantics: no order can be valid
            order = None
        out.append(json.dumps({"order": order}))
    sys.stdout.write("".join(x + "\n" for x in out))


if __name__ == "__main__":
    main()
