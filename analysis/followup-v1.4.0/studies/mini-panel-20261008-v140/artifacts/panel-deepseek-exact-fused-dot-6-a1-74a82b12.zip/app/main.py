import json
import sys


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Fm1 = F - 1
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    sign_shift = ebits + fbits
    sign_pos = 1 << sign_shift
    topbit = 1 << (fbits - 1)
    exp_shift = fbits
    sub_k = emin - fbits

    invalid = False
    has_nan = False
    inf_mask = 0  # bit0: +inf product seen, bit1: -inf product seen
    terms = []    # (signed integer mantissa, power-of-two exponent)
    zero_signs = []  # signs of zero products
    min_k = None

    for pair in pairs:
        a = int(pair[0], 16)
        b = int(pair[1], 16)

        sa = (a >> sign_shift) & 1
        ea = (a >> exp_shift) & Eall
        fa = a & Fm1
        sb = (b >> sign_shift) & 1
        eb = (b >> exp_shift) & Eall
        fb = b & Fm1

        na = ea == Eall and fa != 0
        nb = eb == Eall and fb != 0
        if na:
            has_nan = True
            if not (fa & topbit):
                invalid = True
        if nb:
            has_nan = True
            if not (fb & topbit):
                invalid = True
        if na or nb:
            # no infinite product, cannot count as zero times infinity
            continue

        ia = ea == Eall
        ib = eb == Eall
        za = ea == 0 and fa == 0
        zb = eb == 0 and fb == 0

        if ia or ib:
            if (ia and zb) or (ib and za):
                invalid = True
                continue
            inf_mask |= 2 if (sa ^ sb) else 1
            continue

        # Both operands finite here.
        ps = sa ^ sb
        if za or zb:
            zero_signs.append(ps)
            continue

        if ea == 0:
            ma, ka = fa, sub_k
        else:
            ma, ka = F + fa, ea - bias - fbits
        if eb == 0:
            mb, kb = fb, sub_k
        else:
            mb, kb = F + fb, eb - bias - fbits

        m = ma * mb
        if ps:
            m = -m
        k = ka + kb
        terms.append((m, k))
        if min_k is None or k < min_k:
            min_k = k

    if inf_mask == 3:
        invalid = True

    if has_nan or invalid:
        bits = (Eall << fbits) | topbit
        return bits, (["invalid"] if invalid else [])

    if inf_mask:
        bits = (sign_pos if inf_mask == 2 else 0) | (Eall << fbits)
        return bits, []

    if not terms:
        # All products are signed zeros (or there are no products).
        neg = (mode == "RDN") or (len(zero_signs) > 0 and all(zero_signs))
        return (sign_pos if neg else 0), []

    acc = 0
    for m, k in terms:
        acc += m << (k - min_k)

    if acc == 0:
        # Cancellation of nonzero products.
        return (sign_pos if mode == "RDN" else 0), []

    sign = 1 if acc < 0 else 0
    t = -acc if sign else acc
    L = t.bit_length() - 1 + min_k
    q_exp = L - fbits
    if emin - fbits > q_exp:
        q_exp = emin - fbits

    shift = min_k - q_exp
    if shift >= 0:
        y_int = t << shift
        rem = 0
        den = 0
    else:
        den = 1 << (-shift)
        y_int, rem = divmod(t, den)

    if rem:
        if mode == "RNE":
            r2 = rem << 1
            if r2 > den or (r2 == den and (y_int & 1)):
                y_int += 1
        elif mode == "RNA":
            if (rem << 1) >= den:
                y_int += 1
        elif mode == "RUP":
            if not sign:
                y_int += 1
        elif mode == "RDN":
            if sign:
                y_int += 1

    thresh = emax + 1 - q_exp
    if y_int == 0:
        overflow = False
    elif thresh <= 0:
        overflow = True
    else:
        overflow = y_int >= (1 << thresh)

    if overflow:
        to_inf = (mode == "RNE" or mode == "RNA"
                  or (mode == "RUP" and not sign)
                  or (mode == "RDN" and sign))
        if to_inf:
            bits = (sign_pos if sign else 0) | (Eall << fbits)
        else:
            bits = (sign_pos if sign else 0) | ((Eall - 1) << fbits) | Fm1
        return bits, ["overflow", "inexact"]

    flags = []
    if rem:
        flags.append("inexact")
        if q_exp < emin and y_int < (1 << (emin - q_exp)):
            flags.append("underflow")

    if y_int == 0:
        bits = sign_pos if sign else 0
    else:
        n = y_int.bit_length()
        if n <= fbits:
            bits = (sign_pos if sign else 0) | y_int
        else:
            sh = n - (fbits + 1)
            s = y_int >> sh
            e = q_exp + sh + bias + fbits
            f = s - F
            bits = (sign_pos if sign else 0) | (e << fbits) | f
    return bits, flags


def main():
    out = sys.stdout
    try:
        out.reconfigure(line_buffering=True)
    except Exception:
        pass
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        bits, flags = solve(req)
        out.write(json.dumps({"bits": format(bits, "x"), "flags": flags}) + "\n")


if __name__ == "__main__":
    main()
