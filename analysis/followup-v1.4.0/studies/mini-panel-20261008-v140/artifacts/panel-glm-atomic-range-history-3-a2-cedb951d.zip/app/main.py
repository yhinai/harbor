#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Each request is a completed concurrent history of *whole* transactions.  A
transaction is one atomic operation, so a valid witness is a permutation of
the transactions that

  * respects real time (A.end <= B.start forces A before B), and
  * executed sequentially from `initial` reproduces every observed return
    value and ends exactly at `final`.

The checker returns one such witness, or null when none exists.

Algorithm
---------
Transactions are split into independent groups (disjoint key footprints and no
real-time constraint between them); each group is searched separately and the
group orders concatenated.  Inside a group we run a depth-first search over
"how much of the witness has been fixed", where a search node is the pair
(map state, set of still-unplaced transactions).  Because the set of legal
next moves depends only on that pair, failures can be memoised on it, which
collapses the search space.  Two extra necessary-condition filters prune
hopeless nodes early:

  * real-time: a transaction may only be appended once every transaction that
    must precede it is already placed;
  * final map: for every key, its final value must still be producible by the
    transactions that remain (the last writer of a key decides its value).
"""

import sys
import json


def compile_ops(ops):
    """Normalise an operation list into tuples with small type codes."""
    out = []
    for op in ops or []:
        kind = op[0]
        if kind == 'get':
            out.append(('g', op[1], op[2]))
        elif kind == 'put':
            if op[2] is None:                 # defensive: null put == delete
                out.append(('d', op[1]))
            else:
                out.append(('p', op[1], op[2]))
        elif kind == 'del':
            out.append(('d', op[1]))
        elif kind == 'cas':
            # key, expected_old, new_value (null = delete), expected_success
            out.append(('c', op[1], op[2], op[3], bool(op[4])))
        elif kind == 'scan':
            out.append(('s', op[1], op[2],
                        tuple((p[0], p[1]) for p in (op[3] or []))))
        else:
            raise ValueError('unknown operation %r' % (kind,))
    return tuple(out)


def apply_ops(ops, state):
    """Execute one transaction against `state`.

    Returns the resulting map, or None when an observation does not match.
    Operations inside a transaction run sequentially, so a transaction sees
    its own earlier writes.
    """
    st = dict(state)
    for op in ops:
        kind = op[0]
        if kind == 'p':
            st[op[1]] = op[2]
        elif kind == 'g':
            if st.get(op[1]) != op[2]:        # absent key reads as null
                return None
        elif kind == 'd':
            st.pop(op[1], None)
        elif kind == 'c':
            key = op[1]
            if st.get(key) == op[2]:          # CAS hits
                if not op[4]:
                    return None               # observed failure, expected hit
                if op[3] is None:
                    st.pop(key, None)
                else:
                    st[key] = op[3]
            elif op[4]:
                return None                   # observed hit, expected failure
        else:                                 # scan: half-open key range
            res = tuple((k, v) for k, v in sorted(st.items())
                        if op[1] <= k < op[2])
            if res != op[3]:
                return None
    return st


def solve_component(txs, init, fin):
    """Find a valid serial order for one independent group of transactions.

    Returns the ordered list of transaction ids, or None if the group has no
    valid witness.
    """
    n = len(txs)
    if n == 0:
        return [] if init == fin else None

    ids = [t['id'] for t in txs]
    starts = [t['start'] for t in txs]
    ends = [t['end'] for t in txs]
    opsx = [t['ops'] for t in txs]

    # pred[i]: bitmask of transactions that real time forces before tx i.
    pred = [0] * n
    for i in range(n):
        mask = 0
        for j in range(n):
            if j != i and ends[j] <= starts[i]:
                mask |= 1 << j
        pred[i] = mask

    # Final-map feasibility data.  writers[k][v] masks the transactions able
    # to store value v (None = delete) in key k; modifiers[k] masks the
    # transactions that may write key k at all.
    writers = {}
    modifiers = {}
    for i in range(n):
        for op in opsx[i]:
            kind = op[0]
            if kind == 'p':
                w = writers.setdefault(op[1], {})
                w[op[2]] = w.get(op[2], 0) | (1 << i)
                modifiers[op[1]] = modifiers.get(op[1], 0) | (1 << i)
            elif kind == 'd':
                w = writers.setdefault(op[1], {})
                w[None] = w.get(None, 0) | (1 << i)
                modifiers[op[1]] = modifiers.get(op[1], 0) | (1 << i)
            elif kind == 'c' and op[4]:       # failed CAS never writes
                w = writers.setdefault(op[1], {})
                w[op[3]] = w.get(op[3], 0) | (1 << i)
                modifiers[op[1]] = modifiers.get(op[1], 0) | (1 << i)

    pkeys = []
    for k in set(init) | set(fin) | set(writers):
        want = fin.get(k)
        w = writers.get(k, {})
        pkeys.append((k, want, w.get(want, 0), modifiers.get(k, 0)))

    memo = set()                              # (remaining, state) dead ends
    order = []
    by_end = sorted(range(n), key=lambda i: ends[i])
    cand_cache = {}                           # remaining mask -> candidates

    def feasible(state, remaining):
        # The last writer of a key decides its final value, so whatever is
        # still missing must be writable by a remaining transaction.
        for k, want, wmask, modmask in pkeys:
            if state.get(k) == want:
                if (modmask & remaining) and not (wmask & remaining):
                    return False
            elif not (wmask & remaining):
                return False
        return True

    def dfs(state, remaining):
        if not remaining:
            return state == fin
        key = (remaining, tuple(sorted(state.items())))
        if key in memo:
            return False
        if not feasible(state, remaining):
            memo.add(key)
            return False
        # Only transactions whose forced predecessors are all placed may go
        # next; prefer the one that finishes earliest.
        cands = cand_cache.get(remaining)
        if cands is None:
            cands = [i for i in by_end
                     if (remaining >> i) & 1 and not (pred[i] & remaining)]
            cand_cache[remaining] = cands
        for i in cands:
            ns = apply_ops(opsx[i], state)
            if ns is None:
                continue
            order.append(i)
            if dfs(ns, remaining & ~(1 << i)):
                return True
            order.pop()
        memo.add(key)
        return False

    if dfs(init, (1 << n) - 1):
        return [ids[i] for i in order]
    return None


def solve(request):
    init = {k: v for k, v in (request.get('initial') or {}).items()
            if v is not None}
    fin = {k: v for k, v in (request.get('final') or {}).items()
           if v is not None}
    txs = []
    for t in request.get('transactions') or []:
        txs.append({'id': t['id'], 'start': t['start'], 'end': t['end'],
                    'ops': compile_ops(t['ops'])})

    # Keys that can ever become present (initial keys or keys some
    # transaction may store).
    present = set(init)
    for t in txs:
        for op in t['ops']:
            if op[0] == 'p' or op[0] == 'c':
                present.add(op[1])

    # Key footprint of every transaction: the keys it names, plus every
    # possibly-present key inside its scan ranges.
    for t in txs:
        ks = set()
        for op in t['ops']:
            if op[0] == 's':
                lo, hi = op[1], op[2]
                ks.update(k for k in present if lo <= k < hi)
            else:
                ks.add(op[1])
        t['ref'] = ks

    # Split into independent groups: transactions sharing a key footprint or
    # related by real time belong to the same group.
    n = len(txs)
    parent = list(range(n))

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    for i in range(n):
        for j in range(i + 1, n):
            a, b = txs[i], txs[j]
            if ((a['ref'] & b['ref']) or a['end'] <= b['start']
                    or b['end'] <= a['start']):
                ra, rb = find(i), find(j)
                if ra != rb:
                    parent[ra] = rb

    groups = {}
    for i in range(n):
        groups.setdefault(find(i), []).append(i)

    order = []
    covered = set()
    for members in groups.values():
        keys = set()
        for i in members:
            keys |= txs[i]['ref']
        covered |= keys
        res = solve_component(
            [txs[i] for i in members],
            {k: v for k, v in init.items() if k in keys},
            {k: v for k, v in fin.items() if k in keys})
        if res is None:
            return None
        order.extend(res)

    # Keys no transaction touches keep their initial value.
    for k in set(init) | set(fin):
        if k not in covered and init.get(k) != fin.get(k):
            return None
    return order


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        try:
            answer = {'order': solve(request)}
        except Exception as exc:              # keep the line count intact
            sys.stderr.write('error: %r\n' % (exc,))
            answer = {'order': None}
        out.append(json.dumps(answer))
    if out:
        sys.stdout.write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
