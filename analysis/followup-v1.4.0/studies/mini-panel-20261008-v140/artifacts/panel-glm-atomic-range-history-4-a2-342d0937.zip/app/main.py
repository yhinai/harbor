"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation, so a witness is a linear order of
the transactions that respects real time (A.end <= B.start => A before B) and
whose sequential execution from `initial` reproduces every observed value and
ends exactly at `final`.

Approach
--------
1.  Every transaction is symbolically executed once ("compiled").  Because a
   transaction is atomic, its effect on an incoming state is fully determined
   by that state:

     * reads (`get`, the compare of `cas`, `scan`) of keys not written earlier
       inside the same transaction become *constraints* on the incoming state,
     * writes become a final overlay (last write per key wins),
     * a `cas` expected to fail on an incoming key becomes a *disequality*.

   A transaction that contradicts itself can never appear in any witness, so
   the answer is immediately `null`.

2.  States are packed into a single integer, one field per key.  Only values
   that can actually be stored in a key ever occur (`initial` plus overlay
   values), so a compiled transaction becomes three bit patterns: an equality
   test, some disequality tests and an overlay applied by masking.

3.  The search is a DFS over (set of placed transactions, current state).  That
   pair determines everything about the future, so dead ends are memoised and
   never re-explored.  Only transactions whose real-time predecessors are all
   placed are considered.

4.  Pruning: every unplaced transaction executes after every placed one, so the
   last writer of a key is an unplaced transaction whenever some unplaced
   transaction writes that key.  Hence, per set of placed transactions, the
   final value of such a key must still be written by one of the remaining
   writers, while a key no remaining transaction writes must already hold its
   final value.  Both tests are single bit comparisons.
"""

import json
import sys

KEY_OPS = ("get", "put", "del", "cas")  # operations that name one key


def compile_tx(tx, kidx, keys):
    """Symbolically execute one transaction.

    Returns (eqs, neqs, overlay) where
      eqs    -- tuple of (key_index, value) the incoming state must satisfy
      neqs   -- tuple of (key_index, value) the incoming state must NOT satisfy
      overlay-- tuple of (key_index, value_or_None) applied afterwards
    or None when the transaction can never succeed in any state.
    """
    env = {}      # key index -> value visible to reads inside this transaction
    eqs = {}      # key index -> required incoming value
    neqs = {}     # key index -> set of forbidden incoming values
    writes = []   # ordered (key index, value) writes

    for op in tx["ops"]:
        kind = op[0]
        if kind == "get":
            i = kidx[op[1]]
            want = op[2]
            if i in env:
                if env[i] != want:
                    return None
            else:
                if want in neqs.get(i, ()):  # contradicts an earlier failed CAS
                    return None
                eqs[i] = want
                env[i] = want
        elif kind == "put":
            i = kidx[op[1]]
            env[i] = op[2]
            writes.append((i, op[2]))
        elif kind == "del":
            i = kidx[op[1]]
            env[i] = None
            writes.append((i, None))
        elif kind == "cas":
            i = kidx[op[1]]
            old, new, want = op[2], op[3], op[4]
            if i in env:
                ok = env[i] == old
                if ok != bool(want):
                    return None
                if ok:
                    env[i] = new
                    writes.append((i, new))
            elif want:  # CAS must succeed => incoming value equals `old`
                if old in neqs.get(i, ()):
                    return None
                eqs[i] = old
                env[i] = new
                writes.append((i, new))
            else:       # CAS must fail => incoming value differs from `old`
                neqs.setdefault(i, set()).add(old)
        elif kind == "scan":
            low, high = op[1], op[2]
            # a scan returns the present keys of the range, sorted by key and
            # each exactly once, so the expected pairs must be strictly
            # increasing in key
            expected = {}
            prev = None
            for pair in op[3]:
                k, v = pair[0], pair[1]
                if prev is not None and not prev < k:
                    return None  # unsorted or repeated key: never reproducible
                if v is None:
                    return None  # a present key always holds an integer
                prev = k
                expected[k] = v
            for k in expected:
                if not (low <= k < high):
                    return None  # a reported key outside the range
            for i, k in enumerate(keys):
                if low <= k < high:
                    want = expected.get(k)  # None means the key is expected absent
                    if i in env:
                        if env[i] != want:
                            return None
                    else:
                        if want in neqs.get(i, ()):
                            return None
                        eqs[i] = want
                        env[i] = want
        else:  # unknown operation: can never be satisfied
            return None

    overlay = {}
    for i, v in writes:  # last write per key wins
        overlay[i] = v
    neq_flat = tuple((i, v) for i, vs in neqs.items() for v in vs)
    return (tuple(eqs.items()), neq_flat, tuple(overlay.items()))


def make_apply(eq_mask, eq_val, neq_tests, keep_mask, set_val):
    """Fast state transition for one compiled transaction.

    `keep_mask` selects the bits of the incoming state that survive, `set_val`
    carries the overlay values in the fields that are written.
    """
    if eq_mask == 0 and not neq_tests:
        if set_val == 0 and keep_mask == -1:    # pure observer
            return lambda s: s
        return lambda s: (s & keep_mask) | set_val
    if not neq_tests:
        if keep_mask == -1 and set_val == 0:    # reads only, writes nothing
            def apply(s):
                if (s & eq_mask) != eq_val:
                    return None
                return s
        else:
            def apply(s):
                if (s & eq_mask) != eq_val:
                    return None
                return (s & keep_mask) | set_val
    else:
        def apply(s):
            if (s & eq_mask) != eq_val:
                return None
            for m, v in neq_tests:
                if (s & m) == v:
                    return None
            return (s & keep_mask) | set_val
    return apply


def solve(request):
    txs = request.get("transactions") or []
    initial = request.get("initial") or {}
    final = request.get("final") or {}

    # --- key universe: every key that can ever hold a value ----------------
    keyset = set(initial)
    keyset.update(final)
    for tx in txs:
        for op in tx["ops"]:
            if op[0] in KEY_OPS:
                keyset.add(op[1])
            elif op[0] == "scan":
                for pair in op[3]:
                    keyset.add(pair[0])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}
    nkeys = len(keys)

    # --- compile transactions ---------------------------------------------
    compiled = []
    for tx in txs:
        comp = compile_tx(tx, kidx, keys)
        if comp is None:  # can never appear in any witness
            return {"order": None}
        compiled.append(comp)

    # --- pack states: one field per key ------------------------------------
    # A key can only ever hold its `initial` value or one of the overlay values
    # written to it, so those are the only codes that need to exist.
    poss = [set() for _ in range(nkeys)]
    for i, k in enumerate(keys):
        poss[i].add(initial.get(k))
    for _eqs, _neqs, overlay in compiled:
        for i, v in overlay:
            poss[i].add(v)

    codes = []    # per key: {value: code}
    offsets = []  # per key: bit offset of its field
    field = []    # per key: bit mask of its field
    off = 0
    for i in range(nkeys):
        # absent sorts first, so every key gets a stable {value: code} map
        vals = sorted(poss[i], key=lambda v: (v is not None, v if v is not None else 0))
        codes.append({v: j for j, v in enumerate(vals)})
        width = max(1, (len(vals) - 1).bit_length()) if len(vals) > 1 else 1
        offsets.append(off)
        field.append(((1 << width) - 1) << off)
        off += width
    width_total = off

    initial_state = sum(codes[i][initial.get(k)] << offsets[i] for i, k in enumerate(keys))
    final_code = []
    for i, k in enumerate(keys):
        c = codes[i].get(final.get(k))
        if c is None:
            return {"order": None}  # `final` holds a value no write can produce
        final_code.append(c)
    final_state = sum(c << offsets[i] for i, c in enumerate(final_code))

    # --- turn compiled transactions into bit patterns ---------------------
    applies = []
    overlays = []  # per transaction: {key index: value}
    for eqs, neqs, overlay in compiled:
        eq_mask = eq_val = 0
        for i, v in eqs:
            code = codes[i].get(v)
            if code is None:
                return {"order": None}  # expects a value that cannot be stored
            eq_val |= code << offsets[i]
            eq_mask |= field[i]
        neq_tests = []
        for i, v in neqs:
            code = codes[i].get(v)
            if code is not None:  # otherwise the disequality always holds
                neq_tests.append((field[i], code << offsets[i]))
        write_mask = set_val = 0
        for i, v in overlay:
            write_mask |= field[i]
            set_val |= codes[i][v] << offsets[i]
        applies.append(make_apply(eq_mask, eq_val, tuple(neq_tests),
                                  ~write_mask, set_val))
        overlays.append(dict(overlay))

    ntx = len(txs)
    full = (1 << ntx) - 1

    # --- real-time precedence --------------------------------------------
    prereq = [0] * ntx
    for i, a in enumerate(txs):
        for j, b in enumerate(txs):
            if i != j and a["end"] <= b["start"]:
                prereq[j] |= 1 << i

    # --- who can still write what ----------------------------------------
    # writers[k][code] = transactions whose overlay gives key k that code
    writers = [{code: 0 for code in codes[k].values()} for k in range(nkeys)]
    for t, ovl in enumerate(overlays):
        for i, v in ovl.items():
            writers[i][codes[i][v]] |= 1 << t
    any_writer = [sum(w.values()) for w in writers]

    # --- per-mask feasibility of the final map ----------------------------
    # For a key some unplaced transaction writes, the last write to that key
    # comes from one of them, so one of them must still write its final value.
    # For a key no unplaced transaction writes, the current value already has
    # to be the final one.
    mask_info = {}

    def mask_check(mask):
        """(feasible?, bit mask of keys that must already be final, pattern)."""
        info = mask_info.get(mask)
        if info is None:
            rem = mask ^ full
            ok = True
            must_mask = must_val = 0
            for i in range(nkeys):
                if any_writer[i] & rem:
                    if not writers[i][final_code[i]] & rem:
                        ok = False
                        break
                else:  # nothing will write this key any more
                    must_mask |= field[i]
                    must_val |= final_code[i] << offsets[i]
            info = (ok, must_mask, must_val)
            mask_info[mask] = info
        return info

    # Transactions that write nothing are pure observers: placing them changes
    # nothing but the mask, so try them last.
    order_hint = sorted(
        range(ntx),
        key=lambda t: (len(overlays[t]) == 0, -len(compiled[t][0]) - len(compiled[t][1])))

    candidates = {}  # per mask: transactions that may be placed next

    def eligible(mask):
        cands = candidates.get(mask)
        if cands is None:
            rem = mask ^ full
            cands = tuple(t for t in order_hint
                          if rem >> t & 1 and not prereq[t] & rem)
            candidates[mask] = cands
        return cands

    dead = set()
    path = []

    def dfs(mask, state):
        if mask == full:
            return state == final_state
        for t in eligible(mask):
            nxt = applies[t](state)
            if nxt is None:  # the transaction would not observe what it saw
                continue
            nmask = mask | (1 << t)
            ok, must_mask, must_val = mask_check(nmask)
            if not ok:
                continue
            if (nxt & must_mask) != must_val:
                continue  # a settled key no longer holds its final value
            key = (nmask << width_total) | nxt
            if key in dead:
                continue
            path.append(t)
            if dfs(nmask, nxt):
                return True
            path.pop()
            dead.add(key)
        return False

    ok, must_mask, must_val = mask_check(0)
    if not ok or (initial_state & must_mask) != must_val:
        return {"order": None}
    if dfs(0, initial_state):
        return {"order": [txs[t]["id"] for t in path]}
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            result = solve(json.loads(line))
        except Exception:  # keep answering the rest of the batch
            result = {"order": None}
        out.write(json.dumps(result))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
