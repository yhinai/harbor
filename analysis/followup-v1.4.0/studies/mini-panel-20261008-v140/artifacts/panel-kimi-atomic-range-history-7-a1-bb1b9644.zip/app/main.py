import json
import sys


def _run(st, ops):
    """Execute one transaction's compiled ops against state tuple st.
    Returns the new state tuple, or None if any observation fails."""
    for op in ops:
        t = op[0]
        if t == 0:  # get
            if st[op[1]] != op[2]:
                return None
        elif t == 1:  # put
            i = op[1]
            st = st[:i] + (op[2],) + st[i + 1:]
        elif t == 2:  # del
            i = op[1]
            if st[i]:
                st = st[:i] + (0,) + st[i + 1:]
        elif t == 3:  # cas
            i = op[1]
            ok = st[i] == op[2]
            if ok != op[4]:
                return None
            if ok:
                st = st[:i] + (op[3],) + st[i + 1:]
        else:  # scan
            got = tuple((i, st[i]) for i in op[1] if st[i])
            if got != op[2]:
                return None
    return st


def solve(request):
    initial = request['initial']
    final = request['final']
    txs = request['transactions']
    n = len(txs)
    if n == 0:
        return {'order': [] if initial == final else None}

    # Key universe: every key that can ever be present or observed.
    keyset = set(initial) | set(final)
    for t in txs:
        for op in t['ops']:
            if op[0] == 'scan':
                for pair in op[3]:
                    keyset.add(pair[0])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    nk = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    def enc(v):
        return 0 if v is None else v + 10

    init_st = tuple(enc(initial.get(k)) for k in keys)
    final_st = tuple(enc(final.get(k)) for k in keys)

    # Heuristic: try transactions in start-time order.
    perm = sorted(range(n), key=lambda i: (txs[i]['start'], txs[i]['end'], txs[i]['id']))
    txs = [txs[i] for i in perm]
    ids = [t['id'] for t in txs]

    # Compile ops: 0=get(i,code) 1=put(i,code) 2=del(i) 3=cas(i,old,new,want) 4=scan(inds,exp)
    comp = []
    for t in txs:
        c = []
        for op in t['ops']:
            k0 = op[0]
            if k0 == 'get':
                c.append((0, kidx[op[1]], enc(op[2])))
            elif k0 == 'put':
                c.append((1, kidx[op[1]], enc(op[2])))
            elif k0 == 'del':
                c.append((2, kidx[op[1]]))
            elif k0 == 'cas':
                c.append((3, kidx[op[1]], enc(op[2]), enc(op[3]), bool(op[4])))
            else:  # scan
                lo, hi = op[1], op[2]
                inds = tuple(i for i, k in enumerate(keys) if lo <= k < hi)
                exp = tuple(sorted((kidx[p[0]], enc(p[1])) for p in op[3]))
                c.append((4, inds, exp))
        comp.append(tuple(c))

    # Precedence from intervals: i.end <= j.start  =>  i before j.
    pred = [0] * n
    starts = [t['start'] for t in txs]
    ends = [t['end'] for t in txs]
    for i in range(n):
        ei = ends[i]
        for j in range(n):
            if ei <= starts[j]:
                pred[j] |= 1 << i

    # Static net write of each transaction on each key (last write wins in-txn;
    # a successful-observed cas always writes; put/del always write).
    writers = [dict() for _ in range(nk)]  # key -> {written_code: txn bitmask}
    for j, c in enumerate(comp):
        lastw = {}
        for op in c:
            t0 = op[0]
            if t0 == 1:
                lastw[op[1]] = op[2]
            elif t0 == 2:
                lastw[op[1]] = 0
            elif t0 == 3 and op[4]:
                lastw[op[1]] = op[3]
        for i, cd in lastw.items():
            writers[i][cd] = writers[i].get(cd, 0) | (1 << j)

    # Last-writer constraints derived from the final map.
    need = [0] * nk  # per key: bitmask of txns that can leave final value
    for i in range(nk):
        if not writers[i]:
            continue  # key never written: value is always the initial one
        w_all = 0
        for msk in writers[i].values():
            w_all |= msk
        R = writers[i].get(final_st[i], 0)
        if R == 0:
            # No transaction can leave the required final value on this key.
            return {'order': None}
        need[i] = R
        if R & (R - 1) == 0:
            # Single possible final writer: it must follow every other writer.
            a = R.bit_length() - 1
            pred[a] |= (w_all & ~R)

    # Transitive closure of precedence, then cycle check.
    while True:
        changed = False
        for j in range(n):
            add = 0
            mm = pred[j]
            while mm:
                lsb = mm & -mm
                add |= pred[lsb.bit_length() - 1]
                mm ^= lsb
            if add & ~pred[j]:
                pred[j] |= add
                changed = True
        if not changed:
            break
    for j in range(n):
        if (pred[j] >> j) & 1:
            return {'order': None}

    full = (1 << n) - 1
    failed = set()
    sol = []
    run = _run
    failed_add = failed.add
    failed_contains = failed.__contains__

    def dfs(mask, st):
        # Prune: any key not yet at its final value needs a remaining
        # transaction able to write that final value.
        for i in range(nk):
            if st[i] != final_st[i] and not (need[i] & ~mask):
                return False
        if mask == full:
            return True
        rem = full ^ mask
        for j in range(n):
            b = 1 << j
            if not (rem & b) or (pred[j] & rem):
                continue
            ns = run(st, comp[j])
            if ns is None:
                continue
            m2 = mask | b
            key = (m2, ns)
            if failed_contains(key):
                continue
            sol.append(ids[j])
            if dfs(m2, ns):
                return True
            sol.pop()
            failed_add(key)
        return False

    if dfs(0, init_st):
        return {'order': list(sol)}
    return {'order': None}


def main():
    write = sys.stdout.write
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps(solve(json.loads(line))))
    if out:
        write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
