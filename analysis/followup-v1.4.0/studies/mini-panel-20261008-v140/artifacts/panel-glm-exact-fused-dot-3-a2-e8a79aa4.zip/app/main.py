#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating-point format.

All multiplication and accumulation are performed exactly (integer arithmetic);
only the final sum is rounded, using the requested rounding mode.

Reads newline-delimited JSON requests from stdin, writes one JSON response per
request line to stdout.
"""

import json
import sys

# operand classes
FINITE, INF, QNAN, SNAN = 0, 1, 2, 3


def _to_int(text):
    """Parse a hex bit pattern (no 0x prefix, leading zeros immaterial)."""
    if isinstance(text, str):
        t = text.strip()
        if t[:2].lower() == '0x':
            t = t[2:]
        return int(t, 16)
    return int(text)


class Format(object):
    """Static description of a (ebits, fbits) binary format."""

    __slots__ = ('ebits', 'fbits', 'bias', 'F', 'Eall', 'emin', 'emax',
                 'width', 'mask', 'sign_shift', 'qmask', 'quiet_bit',
                 'max_finite', 'canonical_nan', 'pos_inf', 'neg_inf')

    def __init__(self, ebits, fbits):
        self.ebits = ebits
        self.fbits = fbits
        self.bias = (1 << (ebits - 1)) - 1
        self.F = 1 << fbits
        self.Eall = (1 << ebits) - 1
        self.emin = 1 - self.bias
        self.emax = self.Eall - 1 - self.bias
        self.width = 1 + ebits + fbits
        self.mask = (1 << self.width) - 1
        self.sign_shift = ebits + fbits
        self.qmask = self.F - 1
        self.quiet_bit = 1 << (fbits - 1)
        # frequently used bit patterns
        self.max_finite = ((self.Eall - 1) << fbits) | self.qmask
        self.canonical_nan = (self.Eall << fbits) | self.quiet_bit
        self.pos_inf = self.Eall << fbits
        self.neg_inf = self.pos_inf | (1 << self.sign_shift)

    def decode(self, v):
        """-> (class, sign, mantissa, exponent).

        For FINITE the value is (-1)**sign * mantissa * 2**exponent, exactly.
        """
        e = (v >> self.fbits) & self.Eall
        f = v & self.qmask
        s = v >> self.sign_shift
        if e == self.Eall:
            if f == 0:
                return INF, s, 0, 0
            return (QNAN if (f & self.quiet_bit) else SNAN), s, 0, 0
        if e == 0:
            return FINITE, s, f, self.emin - self.fbits
        return FINITE, s, self.F + f, e - self.bias - self.fbits


_FORMATS = {}


def get_format(ebits, fbits):
    key = (ebits, fbits)
    fmt = _FORMATS.get(key)
    if fmt is None:
        fmt = _FORMATS[key] = Format(ebits, fbits)
    return fmt


def _round_magnitude(num, den, mode, negative):
    """Round the non-negative rational num/den to an integer.

    RNE / RNA round to nearest (ties to even significand / away from zero);
    the directed modes use the sign of the exact result (`negative`).
    Returns (n, exact) where exact is True when no rounding was needed.
    """
    n, r = divmod(num, den)
    if r == 0:
        return n, True
    if mode == 'RTZ':
        return n, False
    if mode == 'RNE':
        twice = r << 1
        if twice > den or (twice == den and (n & 1)):
            return n + 1, False
        return n, False
    if mode == 'RNA':
        return ((n + 1) if (r << 1) >= den else n), False
    if mode == 'RUP':
        return (n if negative else n + 1), False
    if mode == 'RDN':
        return (n + 1 if negative else n), False
    raise ValueError('unknown rounding mode: %r' % (mode,))


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = req['mode']
    if isinstance(mode, str):
        mode = mode.strip().upper()
    pairs = req['pairs']
    fmt = get_format(ebits, fbits)
    decode = fmt.decode
    mask = fmt.mask

    has_nan = False
    invalid = False
    pos_inf = False
    neg_inf = False

    mants = []
    exps = []
    neg_zero = 0
    pos_zero = 0

    for a_text, b_text in pairs:
        ka, sa, ma, ea = decode(_to_int(a_text) & mask)
        kb, sb, mb, eb = decode(_to_int(b_text) & mask)

        # Inspect every operand, even when another is NaN.
        if ka >= QNAN or kb >= QNAN:
            if ka == SNAN or kb == SNAN:
                invalid = True
            has_nan = True
            continue  # a pair with a NaN operand contributes nothing
        if ka == INF or kb == INF:
            if (ka == INF and kb == FINITE and mb == 0) or \
               (kb == INF and ka == FINITE and ma == 0):
                invalid = True  # zero times infinity, in either order
                continue
            if sa ^ sb:
                neg_inf = True
            else:
                pos_inf = True
            continue

        # both operands finite: exact product
        m = ma * mb
        e = ea + eb
        if m == 0:
            if sa ^ sb:
                neg_zero += 1
            else:
                pos_zero += 1
            continue
        # strip trailing zero bits to keep the integers small
        t = m & -m
        if t != 1:
            s = t.bit_length() - 1
            m >>= s
            e += s
        mants.append(-m if (sa ^ sb) else m)
        exps.append(e)

    if pos_inf and neg_inf:
        invalid = True

    if has_nan or invalid:
        return {'bits': format(fmt.canonical_nan, 'x'),
                'flags': ['invalid'] if invalid else []}

    if pos_inf or neg_inf:
        return {'bits': format(fmt.neg_inf if neg_inf else fmt.pos_inf, 'x'),
                'flags': []}

    # ---- finite path: exact accumulation ----
    if mants:
        common = min(exps)
        total = 0
        for i, m in enumerate(mants):
            d = exps[i] - common
            total += (m << d) if d else m
    else:
        total = 0

    if total == 0:
        # Exact zero: negative only if every product is a negative zero
        # (with at least one product), or the mode is RDN.
        if mode == 'RDN':
            negative = True
        elif mants or pos_zero or neg_zero:
            negative = (pos_zero == 0 and not mants)
        else:
            negative = False
        return {'bits': format((1 << fmt.sign_shift) if negative else 0, 'x'),
                'flags': []}

    negative = total < 0
    m = -total if negative else total
    F = fmt.F
    emin = fmt.emin
    emax = fmt.emax

    # exact magnitude x = m * 2**common
    L = m.bit_length() - 1 + common
    p = (L if L > emin else emin) - fbits

    if common >= p:
        # the quantum is finer than the exact value: x/q is already an integer
        n = m << (common - p)
        exact = True
    else:
        n, exact = _round_magnitude(m, 1 << (p - common), mode, negative)

    if n == 0:
        # rounded to zero: keeps the sign of the exact value
        return {'bits': format((1 << fmt.sign_shift) if negative else 0, 'x'),
                'flags': ['inexact', 'underflow']}

    # overflow: rounded magnitude y = n * 2**p >= 2**(emax+1)
    k = emax + 1
    if p >= k or (n >> (k - p)) >= 1:
        # infinity for nearest modes and for the directed mode pointing
        # away from zero, otherwise the maximum finite magnitude
        if (mode == 'RNE' or mode == 'RNA'
                or (mode == 'RUP' and not negative)
                or (mode == 'RDN' and negative)):
            bits = fmt.neg_inf if negative else fmt.pos_inf
        else:
            bits = fmt.max_finite | ((1 << fmt.sign_shift) if negative else 0)
        return {'bits': format(bits, 'x'), 'flags': ['overflow', 'inexact']}

    flags = []
    if not exact:
        flags.append('inexact')
        # underflow: inexact and rounded magnitude below 2**emin
        if p < emin and (n >> (emin - p)) == 0:
            flags.append('underflow')

    # ---- encode the rounded magnitude y = n * 2**p ----
    t = (n & -n).bit_length() - 1  # trailing zero bits of n
    nodd = n >> t
    lr = nodd.bit_length() - 1 + p + t  # floor(log2(y))
    if lr >= emin:
        # significand = y / 2**(lr - fbits), in [F, 2*F)
        sig = nodd << (fbits - nodd.bit_length() + 1)
        frac = sig - F
        efield = lr + fmt.bias
    else:
        # y is below the minimum normal: p == emin - fbits, n < F
        frac = n
        efield = 0
    bits = ((1 << fmt.sign_shift) if negative else 0) | (efield << fbits) | frac
    return {'bits': format(bits, 'x'), 'flags': flags}


def _fallback(req):
    """Best-effort response, used only if a request raises unexpectedly."""
    try:
        if isinstance(req, dict):
            fmt = get_format(int(req['ebits']), int(req['fbits']))
            return {'bits': format(fmt.canonical_nan, 'x'), 'flags': ['invalid']}
    except Exception:
        pass
    return {'bits': '0', 'flags': []}


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        if not line.strip():
            continue
        req = None
        try:
            req = json.loads(line)
            resp = solve(req)
        except Exception as exc:            # keep the output lines aligned
            sys.stderr.write('request failed: %r\n' % (exc,))
            resp = _fallback(req)
        write(json.dumps(resp))
        write('\n')
        sys.stdout.flush()


if __name__ == '__main__':
    main()
