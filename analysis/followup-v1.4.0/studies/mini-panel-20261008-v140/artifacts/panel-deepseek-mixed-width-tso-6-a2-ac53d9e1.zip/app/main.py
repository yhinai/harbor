"""Exhaustive enumeration of terminal outcomes for the mixed-width TSO teaching model.

Each request is a JSON object with "memory" (initial byte values) and "threads"
(lists of store/load/fence/xchg instructions).  The machine is the store-buffering
model described in instruction.md: per-thread FIFO store buffers with per-byte
load forwarding, atomic fence/xchg gated on an empty own buffer, and atomic
whole-store drains.

Algorithm: memoized DFS over the control state (program counters, per-thread
drain counts, shared memory).  The remaining buffered stores are implied by the
program counters and drain counts, so this state determines every possible
future behavior.  The cache stores, for each state, the set of (suffix
observations, final memory) pairs reachable from it; a load/xchg prepends its
observed value to the appropriate thread's suffix.  The transition graph is
acyclic (program counters and drain counts only increase), so the recursion
terminates and the root result is exactly the set of distinct terminal outcomes.
"""
import json
import sys
from functools import lru_cache


def solve(request):
    mem0 = tuple(request["memory"])
    threads = request["threads"]
    T = len(threads)

    ins = []            # per-thread tuple of parsed instructions
    stores = []         # per-thread tuple of (addr, width, value), program order
    issued_prefix = []  # per-thread prefix counts of store instructions
    for t in threads:
        its = []
        st = []
        for x in t:
            op = x[0]
            if op == "store":
                its.append(("store", x[1], x[2], x[3]))
                st.append((x[1], x[2], x[3]))
            elif op == "load":
                its.append(("load", x[1], x[2]))
            elif op == "fence":
                its.append(("fence",))
            elif op == "xchg":
                its.append(("xchg", x[1], x[2], x[3]))
            else:
                raise ValueError("unknown instruction")
        ins.append(tuple(its))
        stores.append(tuple(st))
        pref = [0]
        c = 0
        for j in range(len(its)):
            if its[j][0] == "store":
                c += 1
            pref.append(c)
        issued_prefix.append(tuple(pref))

    L = tuple(len(x) for x in ins)
    empty_obs = tuple(() for _ in range(T))

    def write_bytes(mem, addr, width, value):
        m = list(mem)
        for b in range(width):
            m[addr + b] = (value >> (8 * b)) & 0xFF
        return tuple(m)

    def load_value(mem, addr, width, buf):
        out = 0
        for b in range(width):
            a = addr + b
            byte = None
            for s in reversed(buf):
                if s[0] <= a < s[0] + s[1]:
                    byte = (s[2] >> (8 * (a - s[0]))) & 0xFF
                    break
            if byte is None:
                byte = mem[a]
            out |= byte << (8 * b)
        return out

    def prepend(obs, i, val):
        return obs[:i] + ((val,) + obs[i],) + obs[i + 1:]

    @lru_cache(maxsize=None)
    def f(pcs, drains, mem):
        # Terminal iff every thread finished and every buffer empty.
        done = True
        for i in range(T):
            if pcs[i] != L[i] or drains[i] != issued_prefix[i][pcs[i]]:
                done = False
                break
        if done:
            return frozenset(((empty_obs, mem),))

        transitions = []  # (identity?, thread, value, successor-set)

        for i in range(T):
            pc = pcs[i]
            if pc >= L[i]:
                continue
            instr = ins[i][pc]
            op = instr[0]
            if op == "store":
                npcs = list(pcs)
                npcs[i] = pc + 1
                transitions.append((True, 0, 0, f(tuple(npcs), drains, mem)))
            elif op == "load":
                issued = issued_prefix[i][pc]
                buf = stores[i][drains[i]:issued]
                val = load_value(mem, instr[1], instr[2], buf)
                npcs = list(pcs)
                npcs[i] = pc + 1
                transitions.append((False, i, val, f(tuple(npcs), drains, mem)))
            elif op == "fence":
                if drains[i] == issued_prefix[i][pc]:
                    npcs = list(pcs)
                    npcs[i] = pc + 1
                    transitions.append((True, 0, 0, f(tuple(npcs), drains, mem)))
            elif op == "xchg":
                if drains[i] == issued_prefix[i][pc]:
                    val = load_value(mem, instr[1], instr[2], ())
                    nmem = write_bytes(mem, instr[1], instr[2], instr[3])
                    npcs = list(pcs)
                    npcs[i] = pc + 1
                    transitions.append((False, i, val, f(tuple(npcs), drains, nmem)))

        for i in range(T):
            issued = issued_prefix[i][pcs[i]]
            if drains[i] < issued:
                s = stores[i][drains[i]]
                nmem = write_bytes(mem, s[0], s[1], s[2])
                ndrains = list(drains)
                ndrains[i] += 1
                transitions.append((True, 0, 0, f(pcs, tuple(ndrains), nmem)))

        if len(transitions) == 1:
            identity, i, val, succ = transitions[0]
            if identity:
                return succ
            return frozenset((prepend(obs, i, val), fm) for obs, fm in succ)

        results = set()
        for identity, i, val, succ in transitions:
            if identity:
                results.update(succ)
            else:
                for obs, fm in succ:
                    results.add((prepend(obs, i, val), fm))
        return frozenset(results)

    outcomes = f((0,) * T, (0,) * T, mem0)
    f.cache_clear()
    return {
        "outcomes": [
            {"reads": [list(x) for x in obs], "memory": list(mem)}
            for obs, mem in outcomes
        ]
    }


if __name__ == "__main__":
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))), flush=True)
