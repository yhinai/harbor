"""Linearizability checker for atomic range transactions.

A transaction is one atomic step, so a witness is a permutation of the
transactions that respects real time (A.end <= B.start forces A before B)
and replays from `initial` to `final` with every observation matching.

Method
------
Search depth first over "which transaction runs next", carrying the current
state.  Whether the rest can be completed depends only on the set of still
unscheduled transactions and on the state, so failures are memoised.

Three observations make this fast and keep it exact:

* Every operation constrains/updates exactly one key, and a scan is
  equivalent to one "key must hold this value" test per key in its range
  (a malformed scan can never succeed at all).  So a transaction's effect
  and validity factorise per key, and can be precompiled into one
  transition table per (transaction, key): symbol -> symbol, or invalid.
  The state itself is a packed integer, one field per key.

* A transaction that cannot change any key and is runnable now can always
  be moved to the front of the rest of the schedule, so such transactions
  are scheduled greedily instead of being branched on.

* If no unscheduled transaction depends on a key (neither its validity nor
  its result) but some unscheduled one still writes it, the current value of
  that key cannot influence the rest of the run: the final value is decided
  by the last writer.  Such fields are masked out of the memo key, which
  collapses large parts of the search.

Sound (never over-pruning) tests cut off hopeless branches: a key whose
final value no remaining writer can produce, and a pending transaction
whose reads no reachable value can satisfy.

Finally, any witness that is returned is replayed straight from the request
with a plain dict, exactly as the contract specifies; and if the search
finds no witness, the same question is answered once more by a search with
none of the shortcuts above, so an answer is only reported when two
independent searches agree on it.
"""

import json
import sys


def _solve(req):
    txs = req.get('transactions')
    if not txs:
        txs = []
    initial = req.get('initial') or {}
    final = req.get('final') or {}

    # ---------------- keys, symbols, normalised operations ----------------
    # Symbol 0 means "absent".  Every distinct value a key may hold gets its
    # own symbol, so absent is always different from a key holding zero (and
    # a key holding null is different from both).
    symmap = {}

    def symval(v):
        s = symmap.get(v)
        if s is None:
            s = len(symmap) + 1
            symmap[v] = s
        return s

    def expmask(e):
        """Symbols a read may observe for expectation `e`."""
        if e is None:                       # absent, or present holding null
            return 1 | (1 << symval(None))
        return 1 << symval(e)

    for v in initial.values():
        symval(v)
    for v in final.values():
        symval(v)

    keys = set(initial)
    keys.update(final)
    raws = []
    for t in txs:
        raw = []
        for op in t['ops']:
            kind = op[0]
            if kind == 'get':
                keys.add(op[1])
                raw.append((0, op[1], expmask(op[2])))
            elif kind == 'put':
                keys.add(op[1])
                raw.append((1, op[1], symval(op[2])))
            elif kind == 'del':
                keys.add(op[1])
                raw.append((1, op[1], 0))
            elif kind == 'cas':
                keys.add(op[1])
                want = op[4]
                if want is not True and want is not False:
                    return {'order': None}      # `ok is not want` always holds
                # a null new value deletes the key, as the contract does
                raw.append((2, op[1], expmask(op[2]),
                            0 if op[3] is None else symval(op[3]), want))
            elif kind == 'scan':
                low, high, pairs = op[1], op[2], op[3]
                keys.add(low)
                keys.add(high)
                seen = []
                prev = None
                for p in pairs:
                    if not isinstance(p, (list, tuple)) or len(p) != 2:
                        return {'order': None}
                    kk, vv = p[0], p[1]
                    # the answer is always sorted, unique and in range
                    if not low <= kk < high or (prev is not None and prev >= kk):
                        return {'order': None}
                    keys.add(kk)
                    seen.append((kk, symval(vv)))
                    prev = kk
                raw.append((3, low, high, seen))
            else:
                return {'order': None}
        raws.append(raw)

    keys = sorted(keys)
    K = len(keys)
    kidx = {}
    for i, k in enumerate(keys):
        kidx[k] = i
    n = len(raws)

    # flat programs: (0, key, mask) test, (1, key, sym) assign,
    # (2, key, mask, sym, want) cas.  A scan becomes one test per key inside
    # its range: hold exactly the expected symbol, or be absent.
    progs = []
    for raw in raws:
        prog = []
        for o in raw:
            kd = o[0]
            if kd == 3:
                low, high, seen = o[1], o[2], o[3]
                want = dict(seen)
                for i, k in enumerate(keys):
                    if low <= k < high:
                        prog.append((0, i, 1 << want[k] if k in want else 1))
            else:
                prog.append((kd, kidx[o[1]]) + o[2:])
        progs.append(prog)

    # ---------------- per (transaction, key) transition tables -------------
    # every symbol a key can ever hold: its initial symbol plus every write
    keycodes = []
    for i in range(K):
        keycodes.append(set())
    for prog in progs:
        for o in prog:
            if o[0] == 1:
                keycodes[o[1]].add(o[2])
            elif o[0] == 2:
                keycodes[o[1]].add(o[3])
    init_int = 0
    fs_int = 0
    init_syms = [symval(initial[k]) if k in initial else 0 for k in keys]
    fin_syms = [symval(final[k]) if k in final else 0 for k in keys]
    for i in range(K):
        keycodes[i].add(init_syms[i])
    full_in = []
    for i in range(K):
        m = 0
        for c in keycodes[i]:
            m |= 1 << c
        full_in.append(m)

    W = max(1, len(symmap).bit_length())
    SM = (1 << W) - 1
    sh = [W * i for i in range(K)]
    vm = [SM << s for s in sh]
    for i in range(K):
        init_int |= init_syms[i] << sh[i]
        fs_int |= fin_syms[i] << sh[i]

    writers = [0] * K     # transactions that can change key i
    dep = [0] * K         # transactions whose run depends on the value of key i
    outm = [[0] * n for _ in range(K)]   # symbols key i may hold after tx t
    inm = [[0] * n for _ in range(K)]    # symbols key i may hold before tx t
    tabs_all = []
    inneed = []
    for t in range(n):
        prog = progs[t]
        touched = []
        seen = {}
        for o in prog:
            if o[1] not in seen:
                seen[o[1]] = None
                touched.append(o[1])
        tabs = []
        need = []
        for i in touched:
            ops_i = [o for o in prog if o[1] == i]
            tab = [-1] * (len(symmap) + 1)
            fin = 0
            fout = 0
            first = -1
            multi = False
            for c in keycodes[i]:
                v = c
                ok = True
                for o in ops_i:
                    kd = o[0]
                    if kd == 0:
                        if not (o[2] >> v) & 1:
                            ok = False
                            break
                    elif kd == 1:
                        v = o[2]
                    else:
                        hit = (o[2] >> v) & 1
                        if hit != o[4]:
                            ok = False
                            break
                        if hit:
                            v = o[3]
                if ok:
                    tab[c] = v
                    fin |= 1 << c
                    fout |= 1 << v
                    if first < 0:
                        first = v
                    elif v != first:
                        multi = True       # result depends on the value read
                    if v != c:
                        writers[i] |= 1 << t
            if fin == 0:
                return {'order': None}     # no value lets this tx run
            # either the validity or the result of this transaction depends
            # on the value key i holds when it starts
            if fin != full_in[i] or multi:
                dep[i] |= 1 << t
            inm[i][t] = fin
            outm[i][t] = fout
            tabs.append((sh[i], vm[i], tab))
            if fin != full_in[i]:
                need.append((i, fin))
        tabs_all.append(tuple(tabs))
        inneed.append(tuple(need))

    # ---------------- real time precedence ----------------
    pred = [0] * n
    for a in range(n):
        for b in range(n):
            if a != b and txs[a]['end'] <= txs[b]['start']:
                pred[b] |= 1 << a
    hint = sorted(range(n), key=lambda i: (txs[i]['start'], txs[i]['end'], i))
    full = (1 << n) - 1
    noop = full
    for i in range(K):
        noop &= ~writers[i]

    # static reachability of each final value
    for i in range(K):
        if init_syms[i] != fin_syms[i]:
            w = writers[i]
            m = 0
            while w:
                low = w & -w
                w ^= low
                m |= outm[i][low.bit_length() - 1]
            if not m & (1 << fin_syms[i]):
                return {'order': None}

    # ---------------- search ----------------
    def apply(tabs, state, SM=SM):
        new = state
        for s, v, tab in tabs:
            c = (state >> s) & SM
            r = tab[c]
            if r < 0:
                return None
            if r != c:
                new = (new & ~v) | (r << s)
        return new

    pmt = [dict() for _ in range(K)]    # (rem & writers[i]) -> symbol mask
    care = {}                           # rem -> mask of fields that matter
    wr = writers
    dp = dep
    risky = tuple(i for i in range(K) if wr[i])
    riskymask = 0
    for i in risky:
        riskymask |= vm[i]
    need_txs = tuple(t for t in range(n) if inneed[t])
    finbit = [1 << f for f in fin_syms]

    def make_search(abst, failed):
        """Depth first search over "which transaction runs next".

        `abst` turns on the field masking described at the top of the file;
        the second search is run without it, so an answer is only reported
        when two searches that do not share that shortcut agree.
        """

        def dfs(rem, state, tabs=tabs_all, pred=pred, hint=hint, wr=wr, dp=dp,
                pmt=pmt, outm=outm, inneed=inneed, failed=failed, fs=fs_int,
                K=K, noop=noop, apply=apply, care=care, risky=risky,
                riskymask=riskymask, need_txs=need_txs, finbit=finbit,
                vm=vm, sh=sh, SM=SM, full=full, abst=abst):
            if rem == 0:
                return [] if state == fs else None
            if abst:
                cm = care.get(rem)
                if cm is None:
                    cm = 0
                    for i in range(K):
                        # the value of key i cannot matter unless some
                        # unscheduled transaction depends on it, or none
                        # writes it any more
                        if not (rem & dp[i]) and (rem & wr[i]):
                            continue
                        cm |= vm[i]
                    care[rem] = cm
                key = (rem, state & cm)
            else:
                key = (rem, state)
            if key in failed:
                return None

            # ---- greedy: runnable transactions that never change a key ----
            sched = []
            cache = {}
            while True:
                found = False
                for t in hint:
                    if (rem >> t) & 1 and (noop >> t) & 1:
                        ns = cache.get(t, -1)
                        if ns == -1:
                            if pred[t] & rem:
                                continue       # not runnable yet
                            ns = apply(tabs[t], state)
                            cache[t] = ns
                        if ns is not None:
                            sched.append(t)
                            rem &= ~(1 << t)
                            found = True
                if not found:
                    break
            if rem == 0:
                if state == fs:
                    return sched
                failed.add(key)
                return None
            if abst:
                cm = care.get(rem)
                if cm is None:
                    cm = 0
                    for i in range(K):
                        if not (rem & dp[i]) and (rem & wr[i]):
                            continue
                        cm |= vm[i]
                    care[rem] = cm
                key2 = (rem, state & cm)
            else:
                key2 = (rem, state)
            if key2 in failed:
                failed.add(key)
                return None

            # ---- symbols each key can still take ----
            pv = []
            for i in range(K):
                sub = rem & wr[i]
                if sub:
                    tbl = pmt[i]
                    r = tbl.get(sub)
                    if r is None:
                        r = 0
                        mm = sub
                        oi = outm[i]
                        while mm:
                            low = mm & -mm
                            mm ^= low
                            r |= oi[low.bit_length() - 1]
                        tbl[sub] = r
                    pv.append(r)
                else:
                    pv.append(0)

            # ---- a key whose final symbol no remaining writer produces ----
            diff = state ^ fs
            if diff & riskymask:
                for i in risky:
                    if diff & vm[i] and not pv[i] & finbit[i]:
                        failed.add(key)
                        failed.add(key2)
                        return None

            # ---- a pending transaction whose reads cannot be satisfied ----
            for t in need_txs:
                if (rem >> t) & 1:
                    for i, m in inneed[t]:
                        if not m & ((1 << ((state >> sh[i]) & SM)) | pv[i]):
                            failed.add(key)
                            failed.add(key2)
                            return None

            # ---- branch on runnable transactions ----
            for t in hint:
                if (rem >> t) & 1 and not (pred[t] & rem) and not (noop >> t) & 1:
                    ns = apply(tabs[t], state)
                    if ns is not None:
                        sub = dfs(rem & ~(1 << t), ns)
                        if sub is not None:
                            return sched + [t] + sub

            failed.add(key)
            failed.add(key2)
            return None

        return dfs

    for search in (make_search(True, set()), make_search(False, set())):
        res = search(full, init_int)
        if res is not None:
            order = [txs[i]['id'] for i in res]
            if _valid_order(req, order):
                return {'order': order}
    return {'order': None}


def _valid_order(req, order):
    """Replay a candidate witness straight from the request, exactly the way
    the task's contract does, with no reliance on the compiled tables."""
    txs = req['transactions']
    tx = {}
    for t in txs:
        tx[t['id']] = t
    if not isinstance(order, list) or len(order) != len(txs):
        return False
    if any(not isinstance(x, str) for x in order) or set(order) != set(tx):
        return False
    ranks = {}
    for i, x in enumerate(order):
        ranks[x] = i
    for a in txs:
        for b in txs:
            if a['end'] <= b['start'] and ranks[a['id']] >= ranks[b['id']]:
                return False
    d = dict(req['initial'])
    for name in order:
        for op in tx[name]['ops']:
            kind = op[0]
            if kind == 'get':
                if d.get(op[1]) != op[2]:
                    return False
            elif kind == 'put':
                d[op[1]] = op[2]
            elif kind == 'del':
                d.pop(op[1], None)
            elif kind == 'cas':
                ok = d.get(op[1]) == op[2]
                if ok is not op[4]:
                    return False
                if ok:
                    if op[3] is None:
                        d.pop(op[1], None)
                    else:
                        d[op[1]] = op[3]
            else:
                if sorted([[k, v] for k, v in d.items()
                           if op[1] <= k < op[2]]) != op[3]:
                    return False
    return d == req['final']


def solve(req):
    try:
        return _solve(req)
    except Exception:                      # malformed input: no witness
        return {'order': None}


def main():
    out = []
    for line in sys.stdin.read().splitlines():
        if not line.strip():
            continue
        try:
            req = json.loads(line)
        except Exception:
            out.append(json.dumps({'order': None}))
            continue
        out.append(json.dumps(solve(req)))
    if out:
        sys.stdout.write('\n'.join(out) + '\n')


if __name__ == '__main__':
    main()
