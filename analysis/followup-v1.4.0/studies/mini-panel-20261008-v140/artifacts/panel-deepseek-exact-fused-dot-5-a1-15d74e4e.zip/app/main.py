import json
import sys


def _canonical_nan_bits(fbits, eall):
    return (eall << fbits) | (1 << (fbits - 1))


def _round_integer(num, den, mode, sign):
    """Round the positive rational num/den to an integer.

    ``sign`` is the sign of the exact result and only matters for the
    directed rounding modes.
    """
    q, r = divmod(num, den)
    if r == 0:
        return q
    if mode == "RNE":
        twice = r << 1
        if twice > den or (twice == den and (q & 1)):
            q += 1
    elif mode == "RNA":
        if (r << 1) >= den:
            q += 1
    elif mode == "RUP":
        if sign == 0:
            q += 1
    elif mode == "RDN":
        if sign == 1:
            q += 1
    # RTZ: truncate, i.e. keep q
    return q


def solve(request):
    ebits = int(request["ebits"])
    fbits = int(request["fbits"])
    mode = request["mode"]
    pairs = request["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    eall = (1 << ebits) - 1
    fmask = F - 1
    shift = ebits + fbits
    emin = 1 - bias
    emax = eall - 1 - bias
    top_frac = 1 << (fbits - 1)

    any_nan = False
    invalid = False
    has_pos_inf = False
    has_neg_inf = False
    # finite / zero products as (sign, integer mantissa, power-of-two exponent)
    prods = []

    for pair in pairs:
        va = int(pair[0], 16)
        vb = int(pair[1], 16)

        sa = (va >> shift) & 1
        ea = (va >> fbits) & eall
        fa = va & fmask
        sb = (vb >> shift) & 1
        eb = (vb >> fbits) & eall
        fb = vb & fmask

        a_nan = ea == eall and fa != 0
        b_nan = eb == eall and fb != 0
        if a_nan or b_nan:
            # A pair containing a NaN contributes no product at all.
            any_nan = True
            if (a_nan and not (fa & top_frac)) or (b_nan and not (fb & top_frac)):
                invalid = True
            continue

        a_inf = ea == eall
        b_inf = eb == eall
        a_zero = ea == 0 and fa == 0
        b_zero = eb == 0 and fb == 0

        if (a_inf and b_zero) or (b_inf and a_zero):
            invalid = True
            continue
        if a_inf or b_inf:
            if sa ^ sb:
                has_neg_inf = True
            else:
                has_pos_inf = True
            continue

        if ea == 0:
            ma, pa = fa, 1 - bias - fbits
        else:
            ma, pa = F + fa, ea - bias - fbits
        if eb == 0:
            mb, pb = fb, 1 - bias - fbits
        else:
            mb, pb = F + fb, eb - bias - fbits
        prods.append((sa ^ sb, ma * mb, pa + pb))

    if any_nan or invalid or (has_pos_inf and has_neg_inf):
        if has_pos_inf and has_neg_inf:
            invalid = True
        flags = ["invalid"] if invalid else []
        return {"bits": format(_canonical_nan_bits(fbits, eall), "x"), "flags": flags}
    if has_pos_inf or has_neg_inf:
        sign = 1 if has_neg_inf else 0
        return {"bits": format((sign << shift) | (eall << fbits), "x"), "flags": []}

    nonzero = [t for t in prods if t[1] != 0]
    if not nonzero:
        # Exact zero: negative only when every product is a negative zero,
        # or in round-down mode.
        if prods and all(t[0] == 1 for t in prods):
            sign = 1
        else:
            sign = 1 if mode == "RDN" else 0
        return {"bits": format(sign << shift, "x"), "flags": []}

    minp = min(t[2] for t in nonzero)
    total = 0
    for s, m, p in nonzero:
        term = m << (p - minp)
        total += -term if s else term

    if total == 0:
        # Cancellation of nonzero products (or of mixed-sign zeros).
        sign = 1 if mode == "RDN" else 0
        return {"bits": format(sign << shift, "x"), "flags": []}

    if total < 0:
        sign = 1
        mag = -total
    else:
        sign = 0
        mag = total

    L = mag.bit_length() - 1 + minp
    qexp = emin - fbits
    if L - fbits > qexp:
        qexp = L - fbits

    if minp >= qexp:
        num = mag << (minp - qexp)
        den = 1
    else:
        num = mag
        den = 1 << (qexp - minp)

    y = _round_integer(num, den, mode, sign)
    remainder = num % den

    if y == 0:
        # A nonzero exact result rounded to zero keeps its exact sign.
        return {"bits": format(sign << shift, "x"), "flags": ["underflow", "inexact"]}

    E = y.bit_length() - 1 + qexp
    if E >= emax + 1:
        flags = ["overflow", "inexact"]
        if (mode in ("RNE", "RNA")
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1)):
            bits = (sign << shift) | (eall << fbits)
        else:
            bits = (sign << shift) | ((eall - 1) << fbits) | fmask
        return {"bits": format(bits, "x"), "flags": flags}

    flags = []
    if remainder:
        flags.append("inexact")
        if E < emin:
            flags.append("underflow")

    if E >= emin:
        d = fbits - (y.bit_length() - 1)
        sig = (y << d) if d >= 0 else (y >> -d)
        bits = (sign << shift) | ((E + bias) << fbits) | (sig - F)
    else:
        d = qexp - emin + fbits
        frac = (y << d) if d >= 0 else (y >> -d)
        bits = (sign << shift) | frac
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        result = solve(json.loads(line))
        out.write(json.dumps(result) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
