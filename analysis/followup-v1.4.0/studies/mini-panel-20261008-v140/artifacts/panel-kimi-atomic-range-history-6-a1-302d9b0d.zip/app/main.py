"""Linearizability checker for atomic range transactions.

Each transaction is one atomic operation; find a serial order of all
transactions that respects real-time precedence (A.end <= B.start => A first),
reproduces every observed return value when executed from `initial`, and ends
in exactly `final`.  Backtracking over topological orders with memoized
failure nodes keyed by (placed-mask, state) is complete: future behavior
depends only on the remaining set and the current map.
"""
import json
import sys

GET, PUT, DEL, CAS, SCAN = range(5)


def solve(request):
    txns = request["transactions"]
    initial = request["initial"]
    final = request["final"]
    n = len(txns)

    # Universe of keys that may ever be present or observed.
    keyset = set(initial) | set(final)
    for t in txns:
        for op in t["ops"]:
            kind = op[0]
            if kind in ("get", "put", "del", "cas"):
                keyset.add(op[1])
            elif kind == "scan":
                for pair in op[3]:
                    keyset.add(pair[0])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}

    init_state = tuple(initial.get(k) for k in keys)
    final_state = tuple(final.get(k) for k in keys)

    # Encode operations over integer key indices; absent value is None.
    enc_ops = []
    for t in txns:
        lst = []
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                lst.append((GET, kidx[op[1]], op[2]))
            elif kind == "put":
                lst.append((PUT, kidx[op[1]], op[2]))
            elif kind == "del":
                lst.append((DEL, kidx[op[1]]))
            elif kind == "cas":
                lst.append((CAS, kidx[op[1]], op[2], op[3], op[4]))
            else:  # scan
                low, high, expected = op[1], op[2], op[3]
                rng = tuple(i for i, k in enumerate(keys) if low <= k < high)
                exp = tuple((kidx[p[0]], p[1]) for p in expected)
                lst.append((SCAN, rng, exp))
        enc_ops.append(lst)

    ids = [t["id"] for t in txns]
    preds = [0] * n  # bitmask of transactions that must precede i
    for i in range(n):
        ei = txns[i]["end"]
        for j in range(n):
            if i != j and ei <= txns[j]["start"]:
                preds[j] |= 1 << i

    full = (1 << n) - 1
    failed = set()
    order = []

    def run(ops, st):
        """Execute one transaction atomically; new state tuple or None."""
        s = list(st)
        for op in ops:
            t = op[0]
            if t == GET:
                if s[op[1]] != op[2]:
                    return None
            elif t == PUT:
                s[op[1]] = op[2]
            elif t == DEL:
                s[op[1]] = None
            elif t == CAS:
                cur = s[op[1]]
                if (cur == op[2]) != op[4]:
                    return None
                if cur == op[2]:
                    s[op[1]] = op[3]  # None means delete
            else:  # SCAN
                if tuple((i, s[i]) for i in op[1] if s[i] is not None) != op[2]:
                    return None
        return tuple(s)

    def dfs(mask, st):
        if mask == full:
            return st == final_state
        key = (mask, st)
        if key in failed:
            return False
        for i in range(n):
            b = 1 << i
            if mask & b or preds[i] & ~mask:
                continue
            nst = run(enc_ops[i], st)
            if nst is None:
                continue
            order.append(i)
            if dfs(mask | b, nst):
                return True
            order.pop()
        failed.add(key)
        return False

    if dfs(0, init_state):
        return {"order": [ids[i] for i in order]}
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
