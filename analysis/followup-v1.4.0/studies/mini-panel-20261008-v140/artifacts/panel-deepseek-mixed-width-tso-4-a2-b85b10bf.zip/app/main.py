"""Exhaustive enumerator for the mixed-width buffered (TSO-like) teaching machine.

A machine state (program counters, per-thread store buffers, shared memory) is
explored layer by layer.  Each layer advances a progress measure by exactly one
transition, so states never repeat across layers and no global visited set is
needed.  For every machine state we carry the set of observation prefixes that
can reach it; transitions are computed once per machine state and applied to the
whole observation set, which keeps the search compact.
"""

import json
import sys


def _norm_instr(ins):
    kind = ins[0]
    if kind == 'fence':
        return ('fence',)
    if kind == 'load':
        return ('load', int(ins[1]), int(ins[2]))
    return (kind, int(ins[1]), int(ins[2]), int(ins[3]))


def _store_bytes(width, value):
    return tuple((value >> (8 * k)) & 0xFF for k in range(width))


def solve(request):
    mem0 = tuple(int(x) for x in request['memory'])
    raw_threads = request['threads']
    instrs = [tuple(_norm_instr(x) for x in t) for t in raw_threads]
    n = len(instrs)
    if n == 0:
        return {"outcomes": [{"reads": [], "memory": list(mem0)}]}

    # machine state: (pcs, bufs, mem)
    #   bufs[t] is a tuple of (addr, width, bytes) pending stores, oldest first
    # observation set values: tuple with one tuple of read values per thread
    start_machine = ((0,) * n, tuple(() for _ in range(n)), mem0)
    start_obs = tuple(() for _ in range(n))
    frontier = {start_machine: {start_obs}}
    outcomes = set()

    while frontier:
        nxt = {}
        for (pcs, bufs, mem), obsset in frontier.items():
            finished = all(pcs[t] == len(instrs[t]) for t in range(n))
            if finished and all(not bufs[t] for t in range(n)):
                for obs in obsset:
                    outcomes.add((obs, mem))
                continue

            for t in range(n):
                if pcs[t] < len(instrs[t]):
                    ins = instrs[t][pcs[t]]
                    kind = ins[0]
                    if kind == 'store':
                        _, a, w, v = ins
                        nb = bufs[t] + ((a, w, _store_bytes(w, v)),)
                        tgt = (pcs[:t] + (pcs[t] + 1,) + pcs[t + 1:],
                               bufs[:t] + (nb,) + bufs[t + 1:], mem)
                        if tgt not in nxt:
                            nxt[tgt] = obsset
                        elif nxt[tgt] is not obsset:
                            nxt[tgt] = nxt[tgt] | obsset
                    elif kind == 'load':
                        _, a, w = ins
                        val = 0
                        bt = bufs[t]
                        for k in range(w):
                            ad = a + k
                            byte = None
                            for j in range(len(bt) - 1, -1, -1):
                                sa, sw, sb = bt[j]
                                if sa <= ad < sa + sw:
                                    byte = sb[ad - sa]
                                    break
                            if byte is None:
                                byte = mem[ad]
                            val |= byte << (8 * k)
                        tgt = (pcs[:t] + (pcs[t] + 1,) + pcs[t + 1:], bufs, mem)
                        newobs = {obs[:t] + (obs[t] + (val,),) + obs[t + 1:]
                                  for obs in obsset}
                        if tgt not in nxt:
                            nxt[tgt] = newobs
                        else:
                            nxt[tgt] = nxt[tgt] | newobs
                    elif kind == 'fence':
                        if not bufs[t]:
                            tgt = (pcs[:t] + (pcs[t] + 1,) + pcs[t + 1:], bufs, mem)
                            if tgt not in nxt:
                                nxt[tgt] = obsset
                            elif nxt[tgt] is not obsset:
                                nxt[tgt] = nxt[tgt] | obsset
                    else:  # xchg
                        if not bufs[t]:
                            _, a, w, v = ins
                            val = 0
                            for k in range(w):
                                val |= mem[a + k] << (8 * k)
                            nm = mem[:a] + _store_bytes(w, v) + mem[a + w:]
                            tgt = (pcs[:t] + (pcs[t] + 1,) + pcs[t + 1:], bufs, nm)
                            newobs = {obs[:t] + (obs[t] + (val,),) + obs[t + 1:]
                                      for obs in obsset}
                            if tgt not in nxt:
                                nxt[tgt] = newobs
                            else:
                                nxt[tgt] = nxt[tgt] | newobs
                if bufs[t]:
                    a, w, bs = bufs[t][0]
                    nm = mem[:a] + bs + mem[a + w:]
                    tgt = (pcs, bufs[:t] + (bufs[t][1:],) + bufs[t + 1:], nm)
                    if tgt not in nxt:
                        nxt[tgt] = obsset
                    elif nxt[tgt] is not obsset:
                        nxt[tgt] = nxt[tgt] | obsset
        frontier = nxt

    return {"outcomes": [{"reads": [list(r) for r in obs],
                          "memory": list(mem)}
                         for obs, mem in outcomes]}


def _canonical(request):
    return (tuple(int(x) for x in request['memory']),
            tuple(tuple(tuple(x) for x in t) for t in request['threads']))


_cache = {}


def solve_cached(request):
    key = _canonical(request)
    hit = _cache.get(key)
    if hit is None:
        hit = solve(request)
        _cache[key] = hit
    return hit


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve_cached(request)))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
