#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Each transaction is one atomic operation.  A witness is a permutation of the
transactions such that

  * real-time order is respected (A.end <= B.start  =>  A before B), and
  * replaying the transactions in that order from `initial` makes every
    observed return value match and ends exactly at `final`.

The search is a depth-first enumeration of topological orders with
memoisation on (set of already placed transactions, resulting state); a
failure of (mask, state) is a permanent failure because the future depends
on nothing else.  Several cheap necessary conditions prune the tree.
"""

import sys
import json
from bisect import bisect_left

# operation codes used by the compiled form of a transaction
GET_INT, PUT, DEL, CAS_INT, SCAN, GET_NULL, CAS_NULL = 0, 1, 2, 3, 4, 5, 6
# slot value 0 means "key absent"; slot value 1 means "key present holding null"
ABSENT = 0


def solve(req):
    """Return a list of transaction ids forming a valid witness, else None."""
    txns = req.get("transactions") or []
    n = len(txns)
    initial = req.get("initial") or {}
    final = req.get("final") or {}

    # ids are unique strings by specification; with anything else no
    # well-formed witness exists, so do not even search
    ids = [t.get("id") for t in txns]
    if len(set(ids)) != n or any(not isinstance(x, str) for x in ids):
        return None

    ops_lists = [t.get("ops") or [] for t in txns]

    # ---- universe of keys (state slots) -------------------------------
    keyset = set(initial)
    keyset.update(final)
    for ops in ops_lists:
        for op in ops:
            tag = op[0]
            if tag == "scan":
                keyset.add(op[1])
                keyset.add(op[2])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    K = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    # ---- interning of slot values -------------------------------------
    # ids >= 2 denote concrete integer values, so "reads as null" is
    # exactly "slot value <= 1".
    vid = {None: 1}

    def iv(x):
        r = vid.get(x)
        if r is None:
            r = len(vid) + 1   # ids of concrete values start at 2
            vid[x] = r
        return r

    # ---- compile transactions ----------------------------------------
    compiled = []      # per txn: list of op tuples
    wval = []          # per txn: {key index: value id left by its last write}
    readonly = []      # per txn: True if it performs no write at all
    for ops in ops_lists:
        cops = []
        wv = {}
        for op in ops:
            tag = op[0]
            if tag == "put":
                i = kidx[op[1]]
                w = iv(op[2])
                cops.append((PUT, i, w))
                wv[i] = w
            elif tag == "get":
                i = kidx[op[1]]
                if op[2] is None:
                    cops.append((GET_NULL, i))
                else:
                    cops.append((GET_INT, i, iv(op[2])))
            elif tag == "del":
                i = kidx[op[1]]
                cops.append((DEL, i))
                wv[i] = ABSENT
            elif tag == "cas":
                i = kidx[op[1]]
                old = op[2]
                new = op[3]
                want = bool(op[4])
                w = ABSENT if new is None else iv(new)
                if want:
                    wv[i] = w
                if old is None:
                    cops.append((CAS_NULL, i, w, want))
                else:
                    cops.append((CAS_INT, i, iv(old), w, want))
            else:  # scan
                lo_i = bisect_left(keys, op[1])
                hi_i = bisect_left(keys, op[2])
                exp = [(p[0], iv(p[1])) for p in op[3]]
                cops.append((SCAN, lo_i, hi_i, exp))
        compiled.append(cops)
        wval.append(wv)
        readonly.append(not wv)

    init_vals = [(iv(initial[k]) if k in initial else ABSENT) for k in keys]
    final_vals = [(iv(final[k]) if k in final else ABSENT) for k in keys]

    # per key: transactions writing it, split by whether their last write
    # leaves the value that `final` requires for that key
    writers_k = [0] * K
    need_k = [0] * K
    wrong_k = [0] * K
    for t, wv in enumerate(wval):
        bit = 1 << t
        for i, w in wv.items():
            writers_k[i] |= bit
            if w == final_vals[i]:
                need_k[i] |= bit
            else:
                wrong_k[i] |= bit

    # ---- real-time precedence ----------------------------------------
    starts = [t["start"] for t in txns]
    ends = [t["end"] for t in txns]
    pred = [0] * n
    reach = [0] * n
    for i in range(n):
        p = 0
        s = 0
        si = starts[i]
        ei = ends[i]
        for j in range(n):
            if ends[j] <= si:
                p |= 1 << j
            if ei <= starts[j]:
                s |= 1 << j
        pred[i] = p
        reach[i] = s
    for k in range(n):  # transitive closure of "must occur before"
        rk = reach[k]
        if rk:
            kb = 1 << k
            for i in range(n):
                if reach[i] & kb:
                    reach[i] |= rk

    full = (1 << n) - 1
    failed = set()    # (mask, state) pairs proven to have no completion
    chain = []         # witness, built back to front while unwinding

    keys_ref = keys
    compiled_ref = compiled
    readonly_ref = readonly

    def sim(ops, vals, ro):
        """Apply one transaction; return the new state list or None on a
        mismatch between an observed and an expected return value."""
        if ro:
            v = vals          # a read-only txn cannot modify the state
        else:
            v = vals[:]
        for op in ops:
            c = op[0]
            if c == GET_INT:
                if v[op[1]] != op[2]:
                    return None
            elif c == PUT:
                v[op[1]] = op[2]
            elif c == CAS_INT:
                i = op[1]
                if v[i] == op[2]:
                    if op[4]:
                        v[i] = op[3]
                    else:
                        return None
                elif op[4]:
                    return None
            elif c == GET_NULL:
                if v[op[1]] > 1:
                    return None
            elif c == CAS_NULL:
                i = op[1]
                if v[i] <= 1:
                    if op[3]:
                        v[i] = op[2]
                    else:
                        return None
                elif op[3]:
                    return None
            elif c == DEL:
                v[op[1]] = ABSENT
            else:  # SCAN
                obs = []
                ap = obs.append
                for i in range(op[1], op[2]):
                    x = v[i]
                    if x:
                        ap((keys_ref[i], x))
                if obs != op[3]:
                    return None
        return v

    def dfs(mask, vals):
        key = (mask, tuple(vals))
        if key in failed:
            return False
        if mask == full:
            if vals == final_vals:
                return True
            failed.add(key)
            return False
        rem = full ^ mask
        # ---- necessary conditions on the remaining schedule ----------
        for i in range(K):
            wrem = writers_k[i] & rem
            if wrem:
                cand = need_k[i] & rem
                if not cand:
                    # some remaining txn still writes key i, so the last
                    # writer of key i is among them and none of them can
                    # leave the value that `final` requires
                    failed.add(key)
                    return False
                bad = wrong_k[i] & rem
                if bad:
                    # a candidate c can only be the last writer of key i if
                    # no real-time path forces some wrong writer after c
                    feasible = False
                    c = cand
                    while c:
                        b = c & -c
                        c ^= b
                        if not (reach[b.bit_length() - 1] & bad):
                            feasible = True
                            break
                    if not feasible:
                        failed.add(key)
                        return False
            elif vals[i] != final_vals[i]:
                failed.add(key)
                return False
        # ---- try to extend the schedule ------------------------------
        c = rem
        while c:
            b = c & -c
            c ^= b
            t = b.bit_length() - 1
            if pred[t] & mask != pred[t]:
                continue
            v = sim(compiled_ref[t], vals, readonly_ref[t])
            if v is None:
                continue
            if dfs(mask | b, v):
                chain.append(t)
                return True
        failed.add(key)
        return False

    if dfs(0, init_vals):
        chain.reverse()
        return [txns[t]["id"] for t in chain]
    return None


def main():
    out = sys.stdout
    write = out.write
    # One JSON request per input line.  A line that does not parse on its own
    # is joined with the following ones, so pretty-printed input still works.
    pending = ""
    for line in sys.stdin:
        if not line.strip():
            continue
        cand = pending + line if pending else line
        try:
            req = json.loads(cand)
        except ValueError:
            pending = cand
            continue
        pending = ""
        try:
            order = solve(req)
        except Exception:  # pragma: no cover - keep the output aligned
            import traceback
            traceback.print_exc()
            order = None
        write(json.dumps({"order": order}))
        write("\n")
        out.flush()


if __name__ == "__main__":
    main()
