import json
import sys


def solve(request):
    memory = request["memory"]
    msize = len(memory)
    instrs = [list(t) for t in request["threads"]]
    nt = len(instrs)

    # Per-thread store lists and, for every pc, how many stores have been issued.
    stores = []
    issued = []
    for t in instrs:
        st = []
        pref = [0]
        for ins in t:
            if ins[0] == "store":
                st.append((ins[1], ins[2], ins[3]))
            pref.append(len(st))
        stores.append(tuple(st))
        issued.append(pref)
    n_i = [len(t) for t in instrs]
    nstore = [len(st) for st in stores]

    mem0 = 0
    for i, b in enumerate(memory):
        mem0 |= (b & 0xFF) << (8 * i)

    done_pcs = tuple(n_i)
    done_drained = tuple(nstore)
    start = ((0,) * nt, (0,) * nt, mem0, tuple(() for _ in range(nt)))
    seen = {start}
    stack = [start]
    outcomes = set()

    while stack:
        pcs, drained, mem, reads = stack.pop()

        # terminal: every thread finished and every store drained
        if pcs == done_pcs and drained == done_drained:
            outcomes.add((reads, mem))
            continue

        for i in range(nt):
            pc = pcs[i]
            if pc >= n_i[i]:
                continue
            ins = instrs[i][pc]
            op = ins[0]
            hi = issued[i][pc]
            lo = drained[i]

            if op == "store":
                st = (pcs[:i] + (pc + 1,) + pcs[i + 1:], drained, mem, reads)
                if st not in seen:
                    seen.add(st)
                    stack.append(st)
            elif op == "load":
                a, w = ins[1], ins[2]
                val = 0
                stlist = stores[i]
                for k in range(w):
                    addr = a + k
                    byte = None
                    for j in range(hi - 1, lo - 1, -1):
                        sa, sw, sv = stlist[j]
                        if sa <= addr < sa + sw:
                            byte = (sv >> (8 * (addr - sa))) & 0xFF
                            break
                    if byte is None:
                        byte = (mem >> (8 * addr)) & 0xFF
                    val |= byte << (8 * k)
                nr = reads[i] + (val,)
                st = (pcs[:i] + (pc + 1,) + pcs[i + 1:], drained, mem,
                      reads[:i] + (nr,) + reads[i + 1:])
                if st not in seen:
                    seen.add(st)
                    stack.append(st)
            elif op == "fence":
                if hi == lo:
                    st = (pcs[:i] + (pc + 1,) + pcs[i + 1:], drained, mem, reads)
                    if st not in seen:
                        seen.add(st)
                        stack.append(st)
            else:  # xchg
                if hi == lo:
                    a, w, v = ins[1], ins[2], ins[3]
                    mask = ((1 << (8 * w)) - 1) << (8 * a)
                    val = (mem & mask) >> (8 * a)
                    nm = (mem & ~mask) | (v << (8 * a))
                    nr = reads[i] + (val,)
                    st = (pcs[:i] + (pc + 1,) + pcs[i + 1:], drained, nm,
                          reads[:i] + (nr,) + reads[i + 1:])
                    if st not in seen:
                        seen.add(st)
                        stack.append(st)

        for i in range(nt):
            lo = drained[i]
            if lo < issued[i][pcs[i]]:
                sa, sw, sv = stores[i][lo]
                mask = ((1 << (8 * sw)) - 1) << (8 * sa)
                nm = (mem & ~mask) | (sv << (8 * sa))
                nd = drained[:i] + (lo + 1,) + drained[i + 1:]
                st = (pcs, nd, nm, reads)
                if st not in seen:
                    seen.add(st)
                    stack.append(st)

    out = []
    for reads, mem in outcomes:
        out.append({
            "reads": [list(r) for r in reads],
            "memory": [(mem >> (8 * i)) & 0xFF for i in range(msize)],
        })
    return {"outcomes": out}


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        write(json.dumps(solve(json.loads(line))) + "\n")


if __name__ == "__main__":
    main()
