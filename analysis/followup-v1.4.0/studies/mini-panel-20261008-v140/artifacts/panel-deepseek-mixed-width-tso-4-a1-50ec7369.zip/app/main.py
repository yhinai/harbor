import json
import sys


def solve(request):
    init_mem = tuple(request["memory"])
    threads = request["threads"]
    n = len(threads)
    instrs = tuple(tuple(tuple(ins) for ins in th) for th in threads)
    lengths = tuple(len(th) for th in instrs)
    empty_bufs = tuple(() for _ in range(n))
    init_state = (init_mem, tuple(0 for _ in range(n)), empty_bufs)

    memo = {}

    def successors(state):
        mem, pcs, bufs = state
        out = []
        for t in range(n):
            pc = pcs[t]
            if pc >= lengths[t]:
                continue
            ins = instrs[t][pc]
            op = ins[0]
            npcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
            if op == "store":
                addr, w, val = ins[1], ins[2], ins[3]
                nbufs = bufs[:t] + (bufs[t] + ((addr, w, val),),) + bufs[t + 1:]
                out.append(((mem, npcs, nbufs), None))
            elif op == "load":
                addr, w = ins[1], ins[2]
                v = 0
                buf = bufs[t]
                for i in range(w):
                    a = addr + i
                    b = mem[a]
                    for st in reversed(buf):
                        if st[0] <= a < st[0] + st[1]:
                            b = (st[2] >> (8 * (a - st[0]))) & 255
                            break
                    v |= b << (8 * i)
                out.append(((mem, npcs, bufs), (t, v)))
            elif op == "fence":
                if not bufs[t]:
                    out.append(((mem, npcs, bufs), None))
            else:  # xchg
                if not bufs[t]:
                    addr, w, val = ins[1], ins[2], ins[3]
                    mem_l = list(mem)
                    v = 0
                    for i in range(w):
                        a = addr + i
                        v |= mem[a] << (8 * i)
                        mem_l[a] = (val >> (8 * i)) & 255
                    out.append(((tuple(mem_l), npcs, bufs), (t, v)))
        for t in range(n):
            buf = bufs[t]
            if buf:
                addr, w, val = buf[0]
                mem_l = list(mem)
                for i in range(w):
                    mem_l[addr + i] = (val >> (8 * i)) & 255
                nbufs = bufs[:t] + (buf[1:],) + bufs[t + 1:]
                out.append(((tuple(mem_l), pcs, nbufs), None))
        return out

    def future(state):
        r = memo.get(state)
        if r is not None:
            return r
        mem, pcs, bufs = state
        if pcs == lengths and not any(bufs):
            r = frozenset({(tuple(() for _ in range(n)), mem)})
            memo[state] = r
            return r
        acc = set()
        for ns, read in successors(state):
            sub = future(ns)
            if read is None:
                acc.update(sub)
            else:
                t, v = read
                for reads, m in sub:
                    acc.add((reads[:t] + ((v,) + reads[t],) + reads[t + 1:], m))
        r = frozenset(acc)
        memo[state] = r
        return r

    outcomes = future(init_state)
    result = []
    for reads, mem in outcomes:
        result.append({"reads": [list(r) for r in reads], "memory": list(mem)})
    return {"outcomes": result}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
