import sys
import json

FLAG_ORDER = ("invalid", "overflow", "underflow", "inexact")


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req.get("pairs") or []

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    fmask = F - 1
    spos = ebits + fbits          # position of the sign bit
    top_frac = 1 << (fbits - 1)   # quiet/signaling distinguishing bit

    any_nan = False
    invalid = False
    pos_inf = False
    neg_inf = False
    terms = []                    # nonzero finite products: (sign, mantissa, scale2)
    all_neg_zero = len(pairs) > 0  # "all products are negative signed zeros"

    for pair in pairs:
        a, b = pair
        va = int(a or "0", 16)
        vb = int(b or "0", 16)
        sa = (va >> spos) & 1
        ea = (va >> fbits) & Eall
        fa = va & fmask
        sb = (vb >> spos) & 1
        eb = (vb >> fbits) & Eall
        fb = vb & fmask

        a_nan = ea == Eall and fa != 0
        b_nan = eb == Eall and fb != 0
        if a_nan:
            any_nan = True
            if not (fa & top_frac):
                invalid = True    # signaling NaN operand
        if b_nan:
            any_nan = True
            if not (fb & top_frac):
                invalid = True
        if a_nan or b_nan:
            # contributes no infinite product, cannot be zero*infinity
            continue

        ps = sa ^ sb
        a_inf = ea == Eall        # fa == 0 here
        b_inf = eb == Eall
        a_zero = ea == 0 and fa == 0
        b_zero = eb == 0 and fb == 0

        if a_inf or b_inf:
            if a_zero or b_zero:
                invalid = True
            elif ps:
                neg_inf = True
            else:
                pos_inf = True
            all_neg_zero = False
            continue

        if a_zero or b_zero:
            # exact zero product, sign = XOR of operand signs
            if ps == 0:
                all_neg_zero = False
            continue

        all_neg_zero = False
        if ea == 0:
            ma, sca = fa, 1 - bias - fbits
        else:
            ma, sca = F | fa, ea - bias - fbits
        if eb == 0:
            mb, scb = fb, 1 - bias - fbits
        else:
            mb, scb = F | fb, eb - bias - fbits
        terms.append((ps, ma * mb, sca + scb))

    if pos_inf and neg_inf:
        invalid = True

    def emit(bits, flags):
        return {"bits": format(bits, "x"), "flags": [f for f in FLAG_ORDER if f in flags]}

    if any_nan or invalid:
        return emit((Eall << fbits) | top_frac, {"invalid"} if invalid else set())

    inf_payload = Eall << fbits
    if pos_inf:
        return emit(inf_payload, set())
    if neg_inf:
        return emit((1 << spos) | inf_payload, set())

    # ---- finite exact accumulation: sum = T * 2^min_sc ----
    T = 0
    min_sc = 0
    if terms:
        min_sc = min(sc for _, _, sc in terms)
        for ps, m, sc in terms:
            v = m << (sc - min_sc)
            T = T - v if ps else T + v

    if T == 0:
        neg = all_neg_zero or mode == "RDN"
        return emit((1 << spos) if neg else 0, set())

    sign = 1 if T < 0 else 0
    Ta = -T if sign else T

    # ---- round |sum| to the format ----
    L = Ta.bit_length() - 1 + min_sc
    q_exp = L - fbits
    if q_exp < emin - fbits:
        q_exp = emin - fbits

    sh = min_sc - q_exp
    if sh >= 0:
        n = Ta << sh
        rem = 0
        half = 0
    else:
        k = -sh
        n = Ta >> k
        rem = Ta & ((1 << k) - 1)
        half = 1 << (k - 1)

    inexact = rem != 0
    if inexact:
        if mode == "RNE":
            if rem > half or (rem == half and (n & 1)):
                n += 1
        elif mode == "RNA":
            if rem >= half:
                n += 1
        elif mode == "RUP":
            if not sign:
                n += 1
        elif mode == "RDN":
            if sign:
                n += 1
        # RTZ: never increment

    # overflow: y = n * 2^q_exp >= 2^(emax+1)
    if q_exp > emax:
        overflow = True
    else:
        overflow = n >= (1 << (emax + 1 - q_exp))

    if overflow:
        if mode in ("RNE", "RNA") or (mode == "RUP" and not sign) or (mode == "RDN" and sign):
            bits = (sign << spos) | inf_payload
        else:
            bits = (sign << spos) | ((Eall - 1) << fbits) | fmask
        return emit(bits, {"overflow", "inexact"})

    if n == 0:
        # nonzero sum rounded to zero; keeps exact sign
        return emit(sign << spos, {"underflow", "inexact"})

    e_y = n.bit_length() - 1 + q_exp
    if e_y >= emin:
        e_field = e_y + bias
        shift = e_y - fbits - q_exp   # >= 0 because y is a multiple of 2^q_exp
        sig = n >> shift
        bits = (sign << spos) | (e_field << fbits) | (sig - F)
    else:
        bits = (sign << spos) | (n << (q_exp - (emin - fbits)))

    flags = set()
    if inexact:
        flags.add("inexact")
        if e_y < emin:
            flags.add("underflow")
    return emit(bits, flags)


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
