"""Enumerate every terminal observable outcome of the mixed-width buffered machine.

Machine (per the specification)
-------------------------------
Each thread owns a program counter, a FIFO store buffer and an observation
list.  A step is one enabled atomic transition:

  * execute the next instruction of a thread
      - store : the whole (address, width, value) store is appended to this
                thread's buffer; shared memory is untouched
      - load  : each byte is read independently; the youngest buffered store of
                *this* thread covering that byte wins, otherwise shared memory;
                the assembled integer is appended to the observations
                (loads never block on a non-empty buffer)
      - fence : enabled only when this thread's buffer is empty
      - xchg  : enabled only when this thread's buffer is empty; reads the
                shared-memory value, records it, then writes the new value
                atomically (it neither drains nor blocks on other buffers)
  * drain the oldest store of any non-empty buffer; all of its bytes become
    visible together (draining is possible after the issuing thread finished)

A state is terminal only when every thread is finished and every buffer is
empty; the answer is the set of distinct (observations, final memory) pairs.

Search
------
The explored "control state" is
    (memory bytes, per-thread pc, per-thread drained-store count)
because a thread's buffer is always the slice of its executed stores that has
not been drained yet, so (pc, drained) implies the buffer contents.

Every transition increases sum(pc) + sum(drained) by exactly one, so the
control-state graph is layered and breadth-first processing is a topological
order: when a state is expanded no further observations can be added to it.

Each control state carries the set of observation tuples with which it is
reachable.  All future behaviour depends only on the control state, hence paths
that reach the same control state are merged; only the recorded observations
differ.  Merging keeps the search small while the answer stays exact.

Input is guaranteed to obey the stated bounds; the decoding helpers merely
tolerate oddities instead of raising, so that one strange line can never take
down the rest of a batch.
"""

import json
import sys
from collections import deque

K_STORE, K_LOAD, K_XCHG, K_FENCE, K_NOP = 0, 1, 2, 3, 4
WIDTHS = (1, 2, 4)


def _int(x, default=0):
    try:
        if isinstance(x, bool):
            return default
        return int(x)
    except (TypeError, ValueError):
        return default


def _bytes_of(value, width):
    """Little-endian bytes of an unsigned value of the given width."""
    return tuple((value >> (8 * k)) & 0xFF for k in range(max(width, 0)))


def _instruction(op):
    """Decode one instruction into (kind, addr, width, data); None to skip."""
    if not isinstance(op, (list, tuple)) or not op:
        return None
    name = op[0] if isinstance(op[0], str) else None
    args = len(op)
    if name == "store" or name == "xchg":
        addr = _int(op[1]) if args > 1 else 0
        width = _int(op[2], 1) if args > 2 else 1
        value = _int(op[3]) if args > 3 else 0
        data = _bytes_of(value, width)
        kind = K_STORE if name == "store" else K_XCHG
        return (kind, addr, width, data)
    if name == "load":
        addr = _int(op[1]) if args > 1 else 0
        width = _int(op[2], 1) if args > 2 else 1
        return (K_LOAD, addr, width, None)
    if name == "fence":
        return (K_FENCE, 0, 0, None)
    return (K_NOP, 0, 0, None)          # unknown instruction: plain no-op


def _program(entry):
    """Decode one element of "threads" into a list of instructions."""
    if isinstance(entry, (list, tuple)):
        if entry and not any(isinstance(x, (list, tuple)) for x in entry):
            return _program([entry])    # a bare instruction was given, wrap it
        out = []
        for op in entry:
            dec = _instruction(op)
            if dec is not None:
                out.append(dec)
        return out
    dec = _instruction(entry)            # not a list at all
    return [] if dec is None else [dec]


def _decode(threads):
    """Return (programs, store_recs, store_before).

    programs[i][p]     = (kind, addr, width, data)
    store_recs[i]      = (addr, width, data) of thread i's stores, program order
    store_before[i][p] = number of stores among thread i's instructions[0:p]
    """
    programs, store_recs, store_before = [], [], []
    for entry in threads if isinstance(threads, (list, tuple)) else []:
        ins, recs, counts = [], [], [0]
        for kind, addr, width, data in _program(entry):
            ins.append((kind, addr, width, data))
            if kind == K_STORE:
                recs.append((addr, width, data))
            counts.append(len(recs))
        programs.append(ins)
        store_recs.append(recs)
        store_before.append(counts)
    return programs, store_recs, store_before


def _mem_get(mem, addr):
    return mem[addr] if 0 <= addr < len(mem) else 0


def solve(request):
    mem0 = tuple(_int(b, 0) & 0xFF for b in
                 (request["memory"] if isinstance(request.get("memory"),
                                                   (list, tuple)) else ()))
    nmem = len(mem0)
    nthreads_raw = request.get("threads")
    threads = nthreads_raw if isinstance(nthreads_raw, (list, tuple)) else []
    nthreads = len(threads)

    programs, store_recs, store_before = _decode(threads)
    lens = [len(p) for p in programs]
    total_stores = [len(r) for r in store_recs]

    off_pc = nmem                      # key layout: memory ++ pcs ++ drained
    off_dr = nmem + nthreads

    def make_key(mem, pcs, drs):
        return mem + tuple(pcs) + tuple(drs)

    start = make_key(mem0, (0,) * nthreads, (0,) * nthreads)
    states = {start: {((),) * nthreads}}   # control state -> reachable obs
    queue = deque([start])
    terminal = set()                       # (observations, memory) of final states

    while queue:
        key = queue.popleft()
        obs_set = states.pop(key)        # final: BFS runs in topological order
        mem = key[:off_pc]
        pcs = key[off_pc:off_dr]
        drs = key[off_dr:]

        done = True
        for i in range(nthreads):
            if pcs[i] != lens[i] or drs[i] != total_stores[i]:
                done = False
                break
        if done:
            for obs in obs_set:
                terminal.add((obs, mem))
            continue

        for i in range(nthreads):
            p = pcs[i]
            executed = store_before[i][p]      # p <= len(programs[i])
            drained = drs[i]
            buf = store_recs[i][drained:executed]

            if p < lens[i]:
                kind, addr, width, data = programs[i][p]
                npcs = pcs[:i] + (p + 1,) + pcs[i + 1:]
                if kind == K_STORE:
                    _push(states, queue, make_key(mem, npcs, drs),
                          obs_set, None, i)
                elif kind == K_LOAD:
                    val = 0
                    for j in range(max(width, 0)):
                        a = addr + j
                        b = None
                        for s in reversed(buf):          # youngest first
                            if s[0] <= a < s[0] + max(s[1], 0):
                                b = s[2][a - s[0]]
                                break
                        if b is None:
                            b = _mem_get(mem, a)
                        val |= b << (8 * j)
                    _push(states, queue, make_key(mem, npcs, drs),
                          obs_set, val, i)
                elif kind == K_FENCE:
                    if drained == executed:              # buffer empty
                        _push(states, queue, make_key(mem, npcs, drs),
                              obs_set, None, i)
                elif kind == K_XCHG:
                    if drained == executed:              # buffer empty
                        old = 0
                        for j in range(max(width, 0)):
                            old |= _mem_get(mem, addr + j) << (8 * j)
                        nm = _write(mem, addr, data)
                        _push(states, queue, make_key(nm, npcs, drs),
                              obs_set, old, i)
                else:                                     # K_NOP
                    _push(states, queue, make_key(mem, npcs, drs),
                          obs_set, None, i)

            if drained < executed:                       # drain oldest store
                addr, width, data = store_recs[i][drained]
                nm = _write(mem, addr, data)
                ndr = drs[:i] + (drained + 1,) + drs[i + 1:]
                _push(states, queue, make_key(nm, pcs, ndr),
                      obs_set, None, i)

    outcomes = [
        {"reads": [list(o) for o in obs], "memory": list(mem)}
        for obs, mem in sorted(terminal)
    ]
    return {"outcomes": outcomes}


def _write(mem, addr, data):
    """Write the bytes of one store/xchg into memory (atomically)."""
    nm = list(mem)
    for k, b in enumerate(data):
        a = addr + k
        if 0 <= a < len(nm):
            nm[a] = b & 0xFF
    return tuple(nm)


def _push(states, queue, nkey, obs_set, val, ti):
    """Merge (transformed) observations into a successor control state.

    A brand-new set is installed for a new state.  The source set must never be
    aliased: an in-place merge into one live successor would then silently
    mutate other states that share the object.
    """
    new_obs = set()
    if val is None:
        new_obs.update(obs_set)
    else:
        for obs in obs_set:
            new_obs.add(obs[:ti] + (obs[ti] + (val,),) + obs[ti + 1:])
    cur = states.get(nkey)
    if cur is None:
        states[nkey] = new_obs
        queue.append(nkey)
    else:
        cur |= new_obs


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            result = solve(json.loads(line))
        except Exception as exc:  # never lose the rest of the batch
            sys.stderr.write("request failed: %r\n" % (exc,))
            result = {"outcomes": []}
        out.write(json.dumps(result))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
