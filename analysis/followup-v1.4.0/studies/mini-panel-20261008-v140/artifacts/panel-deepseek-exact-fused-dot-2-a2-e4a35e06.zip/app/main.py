import json
import sys


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    F = 1 << fbits
    Eall = (1 << ebits) - 1
    bias = (1 << (ebits - 1)) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    signpos = ebits + fbits
    fracmask = F - 1
    qbit = 1 << (fbits - 1)

    def parse(h):
        v = int(h, 16) if h else 0
        return (v >> signpos) & 1, (v >> fbits) & Eall, v & fracmask

    invalid = False
    any_nan = False
    inf_signs = 0          # bit0: +inf product seen, bit1: -inf product seen
    prods = []             # (sign, mantissa, exponent) finite products
    all_neg_zero = True
    nprod = 0

    for pair in pairs:
        sa, ea, fa = parse(pair[0])
        sb, eb, fb = parse(pair[1])

        a_nan = ea == Eall and fa != 0
        b_nan = eb == Eall and fb != 0
        if a_nan or b_nan:
            any_nan = True
            if (a_nan and not (fa & qbit)) or (b_nan and not (fb & qbit)):
                invalid = True
            continue

        a_inf = ea == Eall
        b_inf = eb == Eall
        a_zero = ea == 0 and fa == 0
        b_zero = eb == 0 and fb == 0

        if (a_zero and b_inf) or (a_inf and b_zero):
            invalid = True
            continue

        if a_inf or b_inf:
            if sa ^ sb:
                inf_signs |= 2
            else:
                inf_signs |= 1
            continue

        nprod += 1
        if ea == 0:
            ma, xa = fa, 1 - bias - fbits
        else:
            ma, xa = F + fa, ea - bias - fbits
        if eb == 0:
            mb, xb = fb, 1 - bias - fbits
        else:
            mb, xb = F + fb, eb - bias - fbits

        s = sa ^ sb
        m = ma * mb
        if m == 0:
            if s == 0:
                all_neg_zero = False
        else:
            all_neg_zero = False
        prods.append((s, m, xa + xb))

    if inf_signs == 3:
        invalid = True

    if invalid or any_nan:
        bits = (Eall << fbits) | qbit
        return {"bits": format(bits, "x"), "flags": ["invalid"] if invalid else []}

    if inf_signs:
        s = 0 if inf_signs == 1 else 1
        bits = (s << signpos) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # All products finite.  Sum exactly.
    if prods:
        min_e = min(x for _, _, x in prods)
        total = 0
        for s, m, x in prods:
            if m:
                term = m << (x - min_e)
                total += -term if s else term
    else:
        min_e = 0
        total = 0

    if total == 0:
        neg = (mode == "RDN") or (nprod > 0 and all_neg_zero)
        bits = (1 << signpos) if neg else 0
        return {"bits": format(bits, "x"), "flags": []}

    t = -total if total < 0 else total
    sgn = 1 if total < 0 else 0
    L = t.bit_length() - 1 + min_e
    qe = emin - fbits
    ql = L - fbits
    if ql > qe:
        qe = ql

    d = min_e - qe
    if d >= 0:
        N = t << d
        D = 1
    else:
        N = t
        D = 1 << (-d)

    fl, r = divmod(N, D)
    if r == 0:
        n = fl
    elif mode == "RTZ":
        n = fl
    elif mode == "RUP":
        n = fl + (0 if sgn else 1)
    elif mode == "RDN":
        n = fl + (1 if sgn else 0)
    elif mode == "RNE":
        c = r << 1
        if c > D:
            n = fl + 1
        elif c < D:
            n = fl
        else:
            n = fl + (fl & 1)
    else:  # RNA
        n = fl + (1 if (r << 1) >= D else 0)

    inexact = r != 0
    Ey = (n.bit_length() - 1 + qe) if n else -10 ** 9

    if n and Ey >= emax + 1:
        inf_away = (mode in ("RNE", "RNA")) or \
                   (mode == "RUP" and sgn == 0) or \
                   (mode == "RDN" and sgn == 1)
        if inf_away:
            bits = (sgn << signpos) | (Eall << fbits)
        else:
            bits = (sgn << signpos) | ((Eall - 1) << fbits) | (F - 1)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
        if Ey < emin:
            flags.append("underflow")

    if n == 0:
        bits = sgn << signpos
    elif Ey < emin:
        # subnormal: qe == emin - fbits and n < F
        bits = (sgn << signpos) | n
    else:
        sh = Ey - fbits - qe
        if sh >= 0:
            m = n >> sh
        else:
            m = n << (-sh)
        if m == (F << 1):
            Ey += 1
            m = F
        e_field = Ey + bias
        bits = (sgn << signpos) | (e_field << fbits) | (m - F)
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
