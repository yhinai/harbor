import json, sys

def solve(request):
    mem0 = tuple(request['memory'])
    progs = request['threads']
    n = len(progs)
    # State: (memory tuple, tuple of (pc, buffer tuple, observations tuple))
    start = (mem0, tuple((0, (), ()) for _ in range(n)))
    visited = {start}
    stack = [start]
    outcomes = set()
    while stack:
        mem, ts = stack.pop()
        terminal = True
        for i in range(n):
            pc, buf, obs = ts[i]
            if pc < len(progs[i]):
                terminal = False
                ins = progs[i][pc]
                op = ins[0]
                if op == 'store':
                    nts = list(ts)
                    nts[i] = (pc + 1, buf + ((ins[1], ins[2], ins[3]),), obs)
                    s = (mem, tuple(nts))
                    if s not in visited:
                        visited.add(s); stack.append(s)
                elif op == 'load':
                    addr, width = ins[1], ins[2]
                    v = 0
                    for j in range(width):
                        b = addr + j
                        val = None
                        for k in range(len(buf) - 1, -1, -1):
                            sa, sw, sv = buf[k]
                            if sa <= b < sa + sw:
                                val = (sv >> (8 * (b - sa))) & 0xFF
                                break
                        if val is None:
                            val = mem[b]
                        v |= val << (8 * j)
                    nts = list(ts)
                    nts[i] = (pc + 1, buf, obs + (v,))
                    s = (mem, tuple(nts))
                    if s not in visited:
                        visited.add(s); stack.append(s)
                elif op == 'fence':
                    if not buf:
                        nts = list(ts)
                        nts[i] = (pc + 1, buf, obs)
                        s = (mem, tuple(nts))
                        if s not in visited:
                            visited.add(s); stack.append(s)
                else:  # xchg
                    if not buf:
                        addr, width, val = ins[1], ins[2], ins[3]
                        old = 0
                        m = list(mem)
                        for j in range(width):
                            old |= mem[addr + j] << (8 * j)
                            m[addr + j] = (val >> (8 * j)) & 0xFF
                        nts = list(ts)
                        nts[i] = (pc + 1, buf, obs + (old,))
                        s = (tuple(m), tuple(nts))
                        if s not in visited:
                            visited.add(s); stack.append(s)
        for i in range(n):
            pc, buf, obs = ts[i]
            if buf:
                terminal = False
                sa, sw, sv = buf[0]
                m = list(mem)
                for j in range(sw):
                    m[sa + j] = (sv >> (8 * j)) & 0xFF
                nts = list(ts)
                nts[i] = (pc, buf[1:], obs)
                s = (tuple(m), tuple(nts))
                if s not in visited:
                    visited.add(s); stack.append(s)
        if terminal:
            outcomes.add((tuple(t[2] for t in ts), mem))
    return {'outcomes': [{'reads': [list(o) for o in obs], 'memory': list(mem)}
                         for obs, mem in outcomes]}

if __name__ == '__main__':
    for line in sys.stdin:
        print(json.dumps(solve(json.loads(line))))
