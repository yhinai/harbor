import json
import sys


def solve(request):
    mem0 = tuple(request['memory'])
    programs = []
    for prog in request['threads']:
        p = []
        for ins in prog:
            op = ins[0]
            if op == 'store':
                p.append((0, ins[1], ins[2], ins[3]))
            elif op == 'load':
                p.append((1, ins[1], ins[2], 0))
            elif op == 'fence':
                p.append((2, 0, 0, 0))
            else:  # xchg
                p.append((3, ins[1], ins[2], ins[3]))
        programs.append(p)

    n = len(programs)
    # State: (mem, ths) where ths is a tuple of (pc, buf, obs);
    # buf is a tuple of (addr, width, value), obs a tuple of ints.
    init = (mem0, tuple((0, (), ()) for _ in range(n)))
    visited = {init}
    stack = [init]
    outcomes = set()

    while stack:
        mem, ths = stack.pop()
        terminal = True
        for t in range(n):
            pc, buf, obs = ths[t]
            prog = programs[t]
            if pc < len(prog):
                terminal = False
                op, a, w, v = prog[pc]
                if op == 0:  # store: enqueue into own FIFO buffer
                    ns = (mem, ths[:t] + ((pc + 1, buf + ((a, w, v),), obs),) + ths[t + 1:])
                    if ns not in visited:
                        visited.add(ns)
                        stack.append(ns)
                elif op == 1:  # load: per-byte forwarding, youngest store wins
                    val = 0
                    for i in range(w):
                        addr = a + i
                        b = mem[addr]
                        for sa, sw, sv in reversed(buf):
                            if sa <= addr < sa + sw:
                                b = (sv >> (8 * (addr - sa))) & 0xFF
                                break
                        val |= b << (8 * i)
                    ns = (mem, ths[:t] + ((pc + 1, buf, obs + (val,)),) + ths[t + 1:])
                    if ns not in visited:
                        visited.add(ns)
                        stack.append(ns)
                elif op == 2:  # fence: only with empty buffer
                    if not buf:
                        ns = (mem, ths[:t] + ((pc + 1, buf, obs),) + ths[t + 1:])
                        if ns not in visited:
                            visited.add(ns)
                            stack.append(ns)
                else:  # xchg: only with empty buffer; atomic read+write of memory
                    if not buf:
                        old = 0
                        for i in range(w):
                            old |= mem[a + i] << (8 * i)
                        nm = list(mem)
                        for i in range(w):
                            nm[a + i] = (v >> (8 * i)) & 0xFF
                        ns = (tuple(nm), ths[:t] + ((pc + 1, buf, obs + (old,)),) + ths[t + 1:])
                        if ns not in visited:
                            visited.add(ns)
                            stack.append(ns)
            if buf:
                terminal = False
                sa, sw, sv = buf[0]
                nm = list(mem)
                for i in range(sw):
                    nm[sa + i] = (sv >> (8 * i)) & 0xFF
                ns = (tuple(nm), ths[:t] + ((pc, buf[1:], obs),) + ths[t + 1:])
                if ns not in visited:
                    visited.add(ns)
                    stack.append(ns)
        if terminal:
            outcomes.add((tuple(o for (_, _, o) in ths), mem))

    return {
        "outcomes": [
            {"reads": [list(o) for o in obs], "memory": list(m)}
            for (obs, m) in outcomes
        ]
    }


if __name__ == '__main__':
    out = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out(json.dumps(solve(json.loads(line))))
        out('\n')
