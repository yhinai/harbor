#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

Reads newline-delimited JSON requests and writes one JSON response per line.
A request is a completed history; each transaction is one atomic operation.
We search for a serial witness order (respecting the real-time order of
non-overlapping intervals) in which every observation matches and the final
map equals the requested final map, or report that no such order exists.

The search is a memoized DFS over (set of already executed transactions,
current state).  Two sound pruning techniques keep it small:

* A read-free relaxation: ignoring all observations, remove remaining
  transactions from the end of the order.  A transaction can be last iff every
  key it is forced to write to a non-final value is already overwritten by the
  suffix.  All reachable suffix "need" masks are computed with a subset DP;
  if none is compatible with the current state, no completion exists.

* A producer check: if an unused transaction must read a value that is neither
  the current value nor writable by any unused transaction, it can never run.

The relaxation also supplies a candidate order which is verified first, so
satisfiable histories are usually solved in one pass.
"""
import sys
import json


def solve(req):
    initial = req.get("initial") or {}
    final = req.get("final") or {}
    txs = req.get("transactions") or []
    n = len(txs)

    # ---------------------------------------------------------------- keys
    keyset = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            if op[0] == "scan":
                for p in op[3]:
                    keyset.add(p[0])
            else:
                keyset.add(op[1])
    keys = sorted(keyset)
    kidx = {k: i for i, k in enumerate(keys)}
    K = len(keys)

    # state is a tuple over keys; None means "absent", other entries are ints
    init = tuple(initial.get(k) for k in keys)
    fin = tuple(final.get(k) for k in keys)

    if n == 0:
        return [] if init == fin else None

    full = (1 << n) - 1
    ALL = (1 << K) - 1

    # ------------------------------------------------------- value encoding
    # Map every value that can appear in a state to a small integer code.
    values = {None}
    values.update(initial.values())
    values.update(final.values())
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                values.add(op[2])
            elif kind == "put":
                values.add(op[2])
            elif kind == "cas":
                values.add(op[2])
                values.add(op[3])
            elif kind == "scan":
                for p in op[3]:
                    values.add(p[1])
    code_map = {v: i for i, v in enumerate(values)}
    base = len(code_map)
    SHIFT = K * base.bit_length()   # base**K < 2**SHIFT, so codes never collide

    # ------------------------------------------------------------- compile
    # compiled[ti]      low-level ops for forward simulation
    # reqs[ti]          positive observations (key, expected value)
    # poss_fin_mask[ti] keys this tx can leave at the final value
    # forced_nonfin[ti] keys this tx must leave at a non-final value
    #                   (no no-op possible and final value unreachable)
    compiled = [None] * n
    reqs = [None] * n
    poss_fin_mask = [0] * n
    forced_nonfin_mask = [0] * n
    producers = {}   # (key index, value) -> mask of txs that can write that value

    def add_producer(ki, c, ti):
        producers[(ki, c)] = producers.get((ki, c), 0) | (1 << ti)

    for ti, t in enumerate(txs):
        ops_c = []
        rq = []
        eff = {}  # key index -> (set of possible final values, has_noop)
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                ki = kidx[op[1]]
                ops_c.append((0, ki, op[2]))
                rq.append((ki, op[2]))
            elif kind == "put":
                ki = kidx[op[1]]
                v = op[2]
                ops_c.append((1, ki, v))
                eff[ki] = ({v}, False)
                add_producer(ki, v, ti)
            elif kind == "del":
                ki = kidx[op[1]]
                ops_c.append((2, ki))
                eff[ki] = ({None}, False)
                add_producer(ki, None, ti)
            elif kind == "cas":
                ki = kidx[op[1]]
                old = op[2]
                new = op[3]
                succ = bool(op[4])
                ops_c.append((3, ki, old, new, succ))
                if succ:
                    # observation: current value must equal old
                    rq.append((ki, old))
                    prev = eff.get(ki)
                    if prev is None:
                        eff[ki] = ({new}, True)
                    else:
                        vals, hn = prev
                        eff[ki] = (vals | {new}, hn)
                    add_producer(ki, new, ti)
                # failed CAS (succ False) never writes
            else:  # scan
                low = op[1]
                high = op[2]
                exp = {}
                for p in op[3]:
                    exp[kidx[p[0]]] = p[1]
                pairs = []
                for kk in keys:
                    if low <= kk < high:
                        ki = kidx[kk]
                        c = exp.get(ki, None)
                        pairs.append((ki, c))
                        rq.append((ki, c))
                ops_c.append((4, tuple(pairs)))
        compiled[ti] = tuple(ops_c)
        reqs[ti] = tuple(rq)
        pf = 0
        fnf = 0
        for ki, (vals, hn) in eff.items():
            if fin[ki] in vals:
                pf |= 1 << ki
            elif not hn:
                fnf |= 1 << ki
        poss_fin_mask[ti] = pf
        forced_nonfin_mask[ti] = fnf

    # -------------------------------------------------------- real-time DAG
    succ_mask = [0] * n   # j must occur after i
    pred_mask = [0] * n   # j must occur before i
    for i in range(n):
        si = txs[i]["start"]
        ei = txs[i]["end"]
        for j in range(n):
            if i != j and ei <= txs[j]["start"]:
                succ_mask[i] |= 1 << j
                pred_mask[j] |= 1 << i

    # ------------------------------------------------------------- helpers
    def apply_tx(ops, state):
        s = list(state)
        for op in ops:
            c = op[0]
            if c == 0:
                if s[op[1]] != op[2]:
                    return None
            elif c == 1:
                s[op[1]] = op[2]
            elif c == 2:
                s[op[1]] = None
            elif c == 3:
                ki = op[1]
                cur = s[ki]
                old = op[2]
                if cur == old:
                    if not op[4]:
                        return None
                    s[ki] = op[3]
                else:
                    if op[4]:
                        return None
            else:
                for ki, code in op[1]:
                    if s[ki] != code:
                        return None
        return tuple(s)

    def code_of(state):
        x = 0
        for v in state:
            x = x * base + code_map[v]
        return x

    def mismatch_of(state):
        m = 0
        for i in range(K):
            if state[i] != fin[i]:
                m |= 1 << i
        return m

    # ------------------------------------------------- relaxation (pruning)
    # Ignore observations.  Remove remaining transactions from the end of the
    # order; a transaction may be placed last iff each key it must write to a
    # non-final value is already guaranteed by the suffix (need bit clear).
    # reach(rem, n0) is the set (bitmask) of final need masks obtainable by
    # removing all of rem, starting from need mask n0.
    # need bit k set  <=>  the suffix contains no writer of key k.
    reach_memo = {}

    def reach(rem, n0):
        if rem == 0:
            return 1 << n0
        key = (rem << K) | n0
        v = reach_memo.get(key)
        if v is not None:
            return v
        res = 0
        r = rem
        while r:
            b = r & -r
            i = b.bit_length() - 1
            r ^= b
            if succ_mask[i] & rem:
                continue
            if forced_nonfin_mask[i] & n0:
                continue
            res |= reach(rem ^ b, n0 & ~poss_fin_mask[i])
        reach_memo[key] = res
        return res

    def compatible_need(res, m):
        """Return a need mask from bitset res that is compatible with m."""
        r = res
        while r:
            b = r & -r
            n0 = b.bit_length() - 1
            if n0 & m == 0:
                return n0
            r ^= b
        return -1

    def guided_order(rem, m):
        """One order of rem that the relaxation considers feasible."""
        n0 = ALL
        removal = []
        r = rem
        while r:
            bb = r
            found = -1
            while bb:
                b = bb & -bb
                i = b.bit_length() - 1
                bb ^= b
                if succ_mask[i] & r:
                    continue
                if forced_nonfin_mask[i] & n0:
                    continue
                n1 = n0 & ~poss_fin_mask[i]
                sub = reach(r ^ b, n1)
                if sub and compatible_need(sub, m) >= 0:
                    found = i
                    n0 = n1
                    r ^= b
                    removal.append(i)
                    break
            if found < 0:
                return None
        removal.reverse()
        return removal

    def dead_tx_prune(rem, state):
        """Every unused transaction must still be able to satisfy its reads."""
        r = rem
        while r:
            b = r & -r
            i = b.bit_length() - 1
            r ^= b
            for ki, c in reqs[i]:
                if state[ki] == c:
                    continue
                if producers.get((ki, c), 0) & rem:
                    continue
                return True
        return False

    # ---------------------------------------------------------------- search
    memo_fail = set()
    apply_cache = [dict() for _ in range(n)]

    def get_apply(i, state, scode):
        cache = apply_cache[i]
        v = cache.get(scode, -2)
        if v != -2:
            return v
        ns = apply_tx(compiled[i], state)
        cache[scode] = ns
        return ns

    def dfs(mask, state, scode):
        if mask == full:
            return [] if state == fin else None
        key = (mask << SHIFT) | scode
        if key in memo_fail:
            return None
        rem = full ^ mask
        m = mismatch_of(state)
        res = reach(rem, ALL)
        if res == 0 or compatible_need(res, m) < 0:
            memo_fail.add(key)
            return None
        go = guided_order(rem, m)
        if go is not None:
            st = state
            stc = scode
            ok = True
            for i in go:
                ns = get_apply(i, st, stc)
                if ns is None:
                    ok = False
                    break
                stc = code_of(ns)
                st = ns
            if ok and st == fin:
                return go
        if dead_tx_prune(rem, state):
            memo_fail.add(key)
            return None
        cand = []
        r = rem
        while r:
            b = r & -r
            i = b.bit_length() - 1
            r ^= b
            if pred_mask[i] & rem:
                continue
            cand.append(i)
        if go is not None:
            pos = {i: p for p, i in enumerate(go)}
            cand.sort(key=lambda i: pos.get(i, 99))
        else:
            cand.sort(key=lambda i: (txs[i]["start"], txs[i]["id"]))
        for i in cand:
            ns = get_apply(i, state, scode)
            if ns is None:
                continue
            sub = dfs(mask | (1 << i), ns, code_of(ns))
            if sub is not None:
                return [i] + sub
        memo_fail.add(key)
        return None

    sys.setrecursionlimit(10000)
    return dfs(0, init, code_of(init))


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        order = solve(req)
        if order is None:
            out.write('{"order":null}\n')
        else:
            ids = [req["transactions"][i]["id"] for i in order]
            out.write('{"order":' + json.dumps(ids) + '}\n')
    out.flush()


if __name__ == "__main__":
    main()
