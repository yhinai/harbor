"""
Exact fused dot product for a parameterized binary floating-point format.

Each operand is decoded from its hexadecimal bit pattern (sign | exponent |
fraction) into an exact value of the form (-1)**s * mant * 2**exp.  All
multiplications and the accumulation are performed exactly with Python
integers; only the final sum is rounded once to the destination format.

Per request:
  1. Every operand is inspected.  A signaling NaN, a zero-times-infinity pair
     (in either order, from a pair without a NaN operand) or both positive and
     negative infinite products raises `invalid`.  Any NaN operand or
     `invalid` produces the canonical NaN, with `invalid` as the only flag
     that may be set.
  2. Otherwise, an infinite product (necessarily of a single sign) produces
     that signed infinity, with no flags.
  3. Otherwise the exact sum of the finite products is rounded once:
         L = floor(log2(|x|)),  quantum q = 2**max(emin-fbits, L-fbits),
         y = |x|/q rounded to an integer in the request's mode (the original
         sign governs the directed modes),  rounded magnitude m = y*q.
     If m >= 2**(emax+1): overflow and inexact, delivering signed infinity for
     the nearest modes and for the directed mode pointing away from zero,
     otherwise the signed maximum finite.
     Otherwise inexact iff m != x, and underflow iff inexact and m < 2**emin
     (tininess after rounding).
     An exact zero is negative iff all products are negative signed zeros (and
     there is at least one product) or the mode is RDN; a nonzero result that
     rounds to zero keeps its exact sign.  Product zero signs are the XOR of
     the operand signs.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per input line to stdout.
"""

import sys, json

FIN, INF, SNAN, QNAN = 0, 1, 2, 3      # operand classes


def solve(req):
    ebits = req['ebits']
    fbits = req['fbits']
    mode = req['mode']
    pairs = req['pairs']

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits                 # 2**fbits
    Eall = (1 << ebits) - 1
    wshift = ebits + fbits         # bit position of the sign field
    vmask = (1 << (wshift + 1)) - 1
    fmask = F - 1
    top = F >> 1                   # top fraction bit (quiet/signaling)
    emin = 1 - bias
    emax = Eall - 1 - bias
    sub_exp = emin - fbits         # exponent of the subnormal quantum 2**sub_exp

    cache = {}

    def dec(h):
        """decode one hex pattern -> (cls, sign, mant, exp)

        value = (-1)**sign * mant * 2**exp; mant == 0 denotes a signed zero."""
        r = cache.get(h)
        if r is not None:
            return r
        v = int(h, 16) & vmask
        sign = (v >> wshift) & 1
        e = (v >> fbits) & Eall
        f = v & fmask
        if e == Eall:
            if f == 0:
                r = (INF, sign, 0, 0)
            else:
                r = (QNAN if (f & top) else SNAN, sign, 0, 0)
        elif e == 0:
            r = (FIN, sign, f, sub_exp)          # subnormal, or zero if f == 0
        else:
            r = (FIN, sign, F + f, e - bias - fbits)
        cache[h] = r
        return r

    # ---- inspect operands and form exact products ----
    nan_seen = False
    invalid = False
    inf_pos = False                 # some positive infinite product
    inf_neg = False                 # some negative infinite product
    prods = []                      # (sign, mant, exp) of finite products

    for pair in pairs:
        a = dec(pair[0])
        b = dec(pair[1])
        for op in (a, b):           # every operand is inspected
            c = op[0]
            if c == QNAN:
                nan_seen = True
            elif c == SNAN:
                nan_seen = True
                invalid = True
        ca = a[0]
        cb = b[0]
        if ca >= SNAN or cb >= SNAN:
            continue               # a NaN pair yields no product of any kind
        if ca == INF or cb == INF:
            if (ca == FIN and a[2] == 0) or (cb == FIN and b[2] == 0):
                invalid = True     # zero times infinity, either order
            elif a[1] ^ b[1]:
                inf_neg = True
            else:
                inf_pos = True
            continue
        prods.append((a[1] ^ b[1], a[2] * b[2], a[3] + b[3]))

    if inf_pos and inf_neg:         # both positive and negative infinite products
        invalid = True

    def pack(sign, n):
        """encode magnitude n (counted in subnormal quanta) as a bit pattern"""
        if n == 0:
            return sign << wshift
        if n < F:
            return (sign << wshift) | n                 # subnormal
        dd = n.bit_length() - fbits - 1                # exponent offset
        return (sign << wshift) | ((dd + 1) << fbits) | ((n >> dd) - F)

    if nan_seen or invalid:
        bits = (Eall << fbits) | top                    # canonical NaN
        return {'bits': format(bits, 'x'),
                'flags': ['invalid'] if invalid else []}

    if inf_pos or inf_neg:
        s = 1 if inf_neg else 0
        return {'bits': format((s << wshift) | (Eall << fbits), 'x'), 'flags': []}

    # ---- exact sum of the finite products ----
    nonzero = [p for p in prods if p[1]]
    if nonzero:
        minexp = min(p[2] for p in nonzero)
        total = 0
        for s, m, e in nonzero:
            t = m << (e - minexp)
            total = total - t if s else total + t
    else:
        total = 0

    if total == 0:
        # all products must be zeros when they are all negative and sum to 0
        neg = (mode == 'RDN') or (bool(prods) and all(p[0] == 1 for p in prods))
        return {'bits': format(1 << wshift if neg else 0, 'x'), 'flags': []}

    sign = 1 if total < 0 else 0
    num = -total if total < 0 else total          # |x| = num * 2**minexp

    # ---- round the exact magnitude once ----
    L = minexp + num.bit_length() - 1            # floor(log2(|x|))
    k = L - fbits
    if k < sub_exp:
        k = sub_exp                               # quantum q = 2**k
    d = k - minexp
    if d <= 0:
        y = num << (-d)                           # |x| is an exact multiple of q
    else:
        base = num >> d
        rem = num - (base << d)
        half = 1 << (d - 1)
        if mode == 'RTZ':
            y = base
        elif mode == 'RNE':
            if rem > half:
                y = base + 1
            elif rem < half:
                y = base
            else:
                y = base + 1 if (base & 1) else base    # tie to even significand
        elif mode == 'RNA':
            y = base + 1 if rem >= half else base        # tie away from zero
        elif mode == 'RUP':
            y = base + 1 if (sign == 0 and rem) else base
        else:                                            # RDN
            y = base + 1 if (sign == 1 and rem) else base

    # ---- overflow: rounded magnitude y*2**k >= 2**(emax+1) ----
    sh = emax + 1 - k
    ovf = y >= (1 << sh) if sh >= 0 else y >= 1
    if ovf:
        away = (mode == 'RNE' or mode == 'RNA' or
                (mode == 'RUP' and sign == 0) or (mode == 'RDN' and sign == 1))
        if away:
            bits = (sign << wshift) | (Eall << fbits)
        else:
            bits = pack(sign, ((F << 1) - 1) << (emax - emin))   # signed max finite
        return {'bits': format(bits, 'x'), 'flags': ['overflow', 'inexact']}

    # ---- inexact / underflow (tininess after rounding) ----
    if d <= 0:
        inexact = False
    else:
        inexact = (y << d) != num
    if inexact:
        if k < emin:
            under = y < (1 << (emin - k))
        else:
            under = y == 0
    else:
        under = False

    bits = pack(sign, y << (k - sub_exp))
    flags = []
    if inexact:
        flags.append('inexact')
    if under:
        flags.append('underflow')
    return {'bits': format(bits, 'x'), 'flags': flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        try:
            res = solve(json.loads(line))
        except Exception as exc:      # keep line alignment; input is specified valid
            print('error: %r' % (exc,), file=sys.stderr)
            res = {'bits': '0', 'flags': []}
        out.write(json.dumps(res))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
