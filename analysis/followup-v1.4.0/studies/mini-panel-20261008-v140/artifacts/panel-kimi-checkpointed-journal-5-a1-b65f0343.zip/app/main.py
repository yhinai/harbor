"""Deterministic recovery of a checkpointed transactional byte journal."""
import json
import sys
import zlib

MAX_PAYLOAD = 4096
HEADER_LEN = 13
CRC_LEN = 4

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    num_pages = len(pages)
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])
    n = len(log)

    pos = 0
    prev_seq = 0
    last_seq = 0
    # txid -> list of staged PATCH payload bytes for the active incarnation.
    active = {}

    while True:
        if n - pos < HEADER_LEN:
            break
        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")

        # Structural validation only; no semantic effect before a record
        # is fully validated.
        if payload_length > MAX_PAYLOAD:
            break
        rec_end = pos + HEADER_LEN + payload_length + CRC_LEN
        if rec_end > n:
            break  # incomplete / torn record
        payload = log[pos + HEADER_LEN:pos + HEADER_LEN + payload_length]
        stored_crc = int.from_bytes(
            log[pos + HEADER_LEN + payload_length:rec_end], "little")
        if (zlib.crc32(log[pos:pos + HEADER_LEN + payload_length]) & 0xffffffff
                ) != stored_crc:
            break
        if sequence == 0 or sequence <= prev_seq:
            break
        if txid == 0:
            break

        if kind == KIND_BEGIN:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            if (page_index >= num_pages
                    or byte_offset + byte_count > len(pages[page_index])):
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        elif kind == KIND_ABORT:
            if payload_length != 0:
                break
        else:
            break

        # The record is structurally valid: apply transaction semantics.
        if kind == KIND_BEGIN:
            # Fresh incarnation, discarding any unfinished one.
            active[txid] = []
        elif kind == KIND_PATCH:
            staged = active.get(txid)
            if staged is not None:
                staged.append(payload)
        elif kind == KIND_ABORT:
            active.pop(txid, None)
        else:  # KIND_COMMIT always closes the active incarnation, if any.
            staged = active.pop(txid, None)
            if staged is not None and sequence > checkpoint:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if patch_count == len(staged):
                    crc = 0
                    for p in staged:
                        crc = zlib.crc32(p, crc)
                    if (crc & 0xffffffff) == digest:
                        for p in staged:
                            page_index = int.from_bytes(p[0:2], "little")
                            byte_offset = int.from_bytes(p[2:4], "little")
                            pages[page_index][byte_offset:
                                              byte_offset + len(p) - 6] = p[6:]

        prev_seq = sequence
        last_seq = sequence
        pos = rec_end

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


if __name__ == "__main__":
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()
