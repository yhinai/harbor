#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation: the witness is a serial order of
the transactions (a linear extension of the "A.end <= B.start => A before B"
partial order) that, executed from the initial map, reproduces every
observation and the final map.  We must return such an order, or null when no
such order exists.

State model (identical to the reference semantics of a dict-backed store):
 * a key slot holds either ABSENT (key not present) or a value;
 * reading an absent key yields null, and a value may itself be null - the
   two cases read the same but are different slot contents, which matters
   for scans and for map equality;
 * "del" makes a slot ABSENT, a CAS whose new value is null deletes the key,
   a put stores its value verbatim.

Search strategy
---------------
* Bitmask DFS over "which transactions are already scheduled".  A search node
  is (mask, current map); nodes proven unsolvable are memoised, and so is the
  result of applying one transaction to a given map (the map, not the mask,
  decides the outcome).
* Cheap necessary-condition pruning:
    - a key whose slot still differs from its final slot needs a remaining
      transaction able to write exactly that slot value;
    - a pending read requirement of an unscheduled transaction needs a
      remaining possible producer (excluding a sole producer that needs the
      value itself).
* Transactions built only from puts and dels never read, so their
  applicability does not depend on the state and the problem reduces to
  choosing per-key last writers.  That case is solved by an exact backward
  greedy (see solve_write_only), which keeps write-only stress histories out
  of the subset search entirely.
"""

import json
import sys
from bisect import bisect_left

# operation codes of the compiled transaction programs
GET, PUT, DEL, CAS, SCAN = 0, 1, 2, 3, 4

MISS = object()   # "not in transition cache" sentinel
WILD = object()   # wildcard slot for the backward greedy
ABSENT = object()  # slot content: key not present (distinct from a null value)


# --------------------------------------------------------------------------
# compilation
# --------------------------------------------------------------------------
def collect_keys(req, txs):
    """Every key mentioned anywhere (map entries, ops, scan bounds, pairs)."""
    keys = set()
    for k in (req.get("initial") or {}):
        keys.add(k)
    for k in (req.get("final") or {}):
        keys.add(k)
    for t in txs:
        for op in t["ops"]:
            if op[0] == "scan":
                keys.add(op[1])
                keys.add(op[2])
                for pair in op[3]:
                    keys.add(pair[0])
            else:
                keys.add(op[1])
    return sorted(keys)


def compile_tx(t, kidx, keylist):
    """Translate one transaction into a compact tuple program."""
    prog = []
    for op in t["ops"]:
        tag = op[0]
        if tag == "get":
            prog.append((GET, kidx[op[1]], op[2]))
        elif tag == "put":
            prog.append((PUT, kidx[op[1]], op[2]))
        elif tag == "del":
            prog.append((DEL, kidx[op[1]]))
        elif tag == "cas":
            prog.append((CAS, kidx[op[1]], op[2], op[3], bool(op[4])))
        elif tag == "scan":
            lo = bisect_left(keylist, op[1])
            hi = bisect_left(keylist, op[2])
            exp = tuple((kidx[pair[0]], pair[1]) for pair in op[3])
            prog.append((SCAN, lo, hi, exp))
        else:
            raise ValueError("unknown operation %r" % (tag,))
    return tuple(prog)


def eff(slot):
    """Value observed when reading a slot (ABSENT reads as null)."""
    return None if slot is ABSENT else slot


def self_contradictory(prog):
    """True if no state whatsoever can make this transaction's ops match.

    Only an optimisation (a cheap sufficient condition for a transaction
    being inapplicable); correctness never depends on it.
    """
    known = {}                      # key index -> slot content
    for ins in prog:
        c = ins[0]
        if c == PUT:
            known[ins[1]] = ins[2]
        elif c == DEL:
            known[ins[1]] = ABSENT
        elif c == GET:
            k, v = ins[1], ins[2]
            if v is None:           # satisfied by ABSENT or a null value
                if k in known and known[k] is not ABSENT and known[k] is not None:
                    return True
                continue
            if k in known:
                if eff(known[k]) != v:
                    return True
            else:
                known[k] = v
        elif c == CAS:
            k, old, new, succ = ins[1], ins[2], ins[3], ins[4]
            if k in known:
                ok = eff(known[k]) == old
                if ok is not succ:
                    return True
            if succ:
                known[k] = ABSENT if new is None else new
        else:                       # SCAN
            lo, hi, exp = ins[1], ins[2], ins[3]
            prev = -1
            for i, _v in exp:
                if i <= prev or i < lo or i >= hi:
                    return True     # unsorted/duplicate/out-of-range pair
                prev = i
            em = dict(exp)
            for k in range(lo, hi):
                req = em.get(k, ABSENT)
                if k in known:
                    if known[k] != req:
                        return True
                else:
                    known[k] = req
    return False


def apply_tx(prog, state):
    """Run one transaction against a state tuple.

    Returns the resulting tuple, or None if some observation mismatches.
    """
    st = list(state)
    for ins in prog:
        c = ins[0]
        if c == PUT:
            st[ins[1]] = ins[2]
        elif c == GET:
            if eff(st[ins[1]]) != ins[2]:
                return None
        elif c == DEL:
            st[ins[1]] = ABSENT
        elif c == CAS:
            k = ins[1]
            if eff(st[k]) == ins[2]:
                st[k] = ABSENT if ins[3] is None else ins[3]
                if not ins[4]:
                    return None
            elif ins[4]:
                return None
        else:                       # SCAN
            lo, hi, exp = ins[1], ins[2], ins[3]
            act = tuple((i, st[i]) for i in range(lo, hi) if st[i] is not ABSENT)
            if act != exp:
                return None
    return tuple(st)


# --------------------------------------------------------------------------
# exact fast path: transactions that never read (put/del only)
# --------------------------------------------------------------------------
def solve_write_only(progs, preds, init_state, final_state):
    """Solve exactly when every transaction consists of puts and dels only.

    Backward greedy: take as *last* transaction any T such that
      (a) no remaining transaction is forced to run after T, and
      (b) for every key T writes, T's resulting slot equals the still
          required target slot (keys T writes are already wildcarded).
    Choosing such a T only relaxes the problem, so the greedy is complete:
    if it gets stuck the instance has no witness.  (Moving a valid T to the
    end of a solution preserves real-time order by (a) and the final map by
    (b); keys T does not write are untouched.)
    Returns the order as a list of transaction indices, or None.
    """
    n = len(progs)
    effect = []                     # per transaction: key index -> slot
    for prog in progs:
        tx_eff = {}
        for ins in prog:
            tx_eff[ins[1]] = ABSENT if ins[0] == DEL else ins[2]
        effect.append(tx_eff)
    target = list(final_state)
    remaining = set(range(n))
    suffix = []
    while remaining:
        chosen = -1
        for t in remaining:
            # (a) nobody remaining is forced to run after t
            bit = 1 << t
            ok = True
            for u in remaining:
                if u != t and (preds[u] & bit):
                    ok = False
                    break
            if not ok:
                continue
            # (b) t's writes must match the still-required target slots
            for k, v in effect[t].items():
                tk = target[k]
                if tk is not WILD and tk != v:
                    ok = False
                    break
            if ok:
                chosen = t
                break
        if chosen < 0:
            return None
        suffix.append(chosen)
        remaining.discard(chosen)
        for k in effect[chosen]:
            target[k] = WILD
    suffix.reverse()
    # the initial map must already supply every still-required slot
    for k, v in enumerate(target):
        if v is not WILD and init_state[k] != v:
            return None
    return suffix


# --------------------------------------------------------------------------
# general solver
# --------------------------------------------------------------------------
def solve(req):
    initial = req.get("initial") or {}
    final = req.get("final") or {}
    txs = req.get("transactions") or []
    n = len(txs)

    keylist = collect_keys(req, txs)
    kidx = {k: i for i, k in enumerate(keylist)}
    init_state = tuple(initial.get(k, ABSENT) for k in keylist)
    final_state = tuple(final.get(k, ABSENT) for k in keylist)
    progs = [compile_tx(t, kidx, keylist) for t in txs]

    if any(self_contradictory(p) for p in progs):
        return None
    if n == 0:
        return [] if init_state == final_state else None

    starts = [t["start"] for t in txs]
    ends = [t["end"] for t in txs]
    # preds[i]: transactions that must be scheduled before i
    preds = [0] * n
    for i in range(n):
        pi = 0
        si = starts[i]
        for j in range(n):
            if i != j and ends[j] <= si:
                pi |= 1 << j
        preds[i] = pi
    full = (1 << n) - 1

    # ---- exact fast path for histories whose transactions never read ----
    if all(ins[0] in (PUT, DEL) for p in progs for ins in p):
        order = solve_write_only(progs, preds, init_state, final_state)
        if order is not None:
            state = init_state
            for t in order:
                state = apply_tx(progs[t], state)
            if state == final_state:      # verify before trusting the greedy
                return [txs[t]["id"] for t in order]
        # the greedy is proven complete; the search below is kept as a
        # safety net and reaches the same (negative) conclusion
        return _search(txs, progs, preds, init_state, final_state, full)

    return _search(txs, progs, preds, init_state, final_state, full)


def _search(txs, progs, preds, init_state, final_state, full):
    n = len(progs)
    K = len(init_state)

    # enabled(mask): transactions not yet in mask whose predecessors all are
    # (built lazily, so only reachable masks are ever tabulated)
    enabled_cache = {}

    def enabled_of(mask):
        lst = enabled_cache.get(mask)
        if lst is None:
            lst = []
            for t in range(n):
                if not (mask >> t) & 1 and not (preds[t] & ~mask):
                    lst.append(t)
            lst = tuple(lst)
            enabled_cache[mask] = lst
        return lst

    bits = [1 << t for t in range(n)]

    # ---- pruning tables -------------------------------------------------
    # prov[(key, slot)] : transactions able to write exactly that slot value
    # need[(key, accepted slots)] : transactions that must observe one of
    #                      those slot values and cannot produce them first
    prov = {}
    need = {}

    def add_need(k, slots):
        key = (k, slots)
        need[key] = need.get(key, 0) | bit

    for ti, prog in enumerate(progs):
        bit = 1 << ti
        written = set()
        for ins in prog:
            c = ins[0]
            if c == PUT:
                key = (ins[1], ins[2])
                prov[key] = prov.get(key, 0) | bit
                written.add(ins[1])
            elif c == DEL:
                key = (ins[1], ABSENT)
                prov[key] = prov.get(key, 0) | bit
                written.add(ins[1])
            elif c == CAS:
                slot = ABSENT if ins[3] is None else ins[3]
                key = (ins[1], slot)
                prov[key] = prov.get(key, 0) | bit
                if ins[4] and ins[1] not in written:
                    # expects to succeed: must read ins[2]
                    add_need(ins[1], (ins[2],) if ins[2] is not None
                             else (ABSENT, None))
                written.add(ins[1])
            elif c == GET:
                if ins[1] not in written:
                    add_need(ins[1], (ins[2],) if ins[2] is not None
                             else (ABSENT, None))
            else:                   # SCAN: exact slots, pairs or absent
                lo, hi, exp = ins[1], ins[2], ins[3]
                em = dict(exp)
                for k in range(lo, hi):
                    if k not in written:
                        add_need(k, (em.get(k, ABSENT),))

    # final map requirements (key, wanted slot, producers of that slot)
    final_req = tuple(
        (k, final_state[k], prov.get((k, final_state[k]), 0))
        for k in range(K)
    )
    # pending read requirements (key, accepted slots, readers, producers)
    req3 = []
    for (k, slots), nm in need.items():
        if not nm:
            continue
        if len(slots) == 2:               # (ABSENT, None): either will do
            pm = prov.get((k, ABSENT), 0) | prov.get((k, None), 0)
        else:
            pm = prov.get((k, slots[0]), 0)
        req3.append((k, slots, nm, pm))
    req3 = tuple(req3)

    failed = {}                        # mask -> set of states proven unsolvable
    tcache = [dict() for _ in range(n)]  # txn -> state -> resulting state
    order = []

    def dfs(mask, state):
        if mask == full:
            return state == final_state
        fs = failed.get(mask)
        if fs is None:
            fs = failed[mask] = set()
        if state in fs:
            return False
        # every slot still differing from its final value needs a producer
        for k, fv, pm in final_req:
            if state[k] != fv and not (pm & ~mask):
                fs.add(state)
                return False
        # every pending read requirement needs a possible producer
        for k, slots, nm, pm in req3:
            if state[k] not in slots:
                rd = nm & ~mask
                if rd:
                    p = pm & ~mask
                    if not p or (
                        not (p & (p - 1)) and (p & rd) == p
                    ):                   # sole producer needs the value itself
                        fs.add(state)
                        return False
        for t in enabled_of(mask):
            tc = tcache[t]
            r = tc.get(state, MISS)
            if r is MISS:
                r = apply_tx(progs[t], state)
                tc[state] = r
            if r is not None:
                order.append(t)
                if dfs(mask | bits[t], r):
                    return True
                order.pop()
        fs.add(state)
        return False

    if dfs(0, init_state):
        return [txs[t]["id"] for t in order]
    return None


# --------------------------------------------------------------------------
def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        req = json.loads(line)
        try:
            order = solve(req)
        except Exception as exc:    # pragma: no cover - safety net
            sys.stderr.write("solver error: %r\n" % (exc,))
            order = None
        out.write(json.dumps({"order": order}))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
