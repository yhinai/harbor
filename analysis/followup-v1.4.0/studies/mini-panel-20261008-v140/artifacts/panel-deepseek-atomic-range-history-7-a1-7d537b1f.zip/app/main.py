import sys, json, os


def solve(request):
    initial = request.get("initial", {})
    final = request.get("final", {})
    txns = request.get("transactions", [])
    n = len(txns)

    # ---- collect key universe -------------------------------------------------
    keyset = set(initial) | set(final)
    for t in txns:
        for op in t["ops"]:
            kind = op[0]
            if kind in ("get", "put", "del", "cas"):
                keyset.add(op[1])
            elif kind == "scan":
                keyset.add(op[1])
                keyset.add(op[2])
                for p in op[3]:
                    keyset.add(p[0])
    keys = sorted(keyset)
    K = len(keys)
    idx = {k: i for i, k in enumerate(keys)}

    # dynamic value encoding: code(value) = value - minv + 1 ; 0 = absent
    vals = []
    for m in (initial, final):
        vals.extend(m.values())
    for t in txns:
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                if op[2] is not None:
                    vals.append(op[2])
            elif kind == "put":
                vals.append(op[2])
            elif kind == "cas":
                if op[2] is not None:
                    vals.append(op[2])
                if op[3] is not None:
                    vals.append(op[3])
            elif kind == "scan":
                for p in op[3]:
                    if p[1] is not None:
                        vals.append(p[1])
    if vals:
        minv = min(vals)
        maxv = max(vals)
    else:
        minv = maxv = 0
    OFF = 1 - minv
    span = maxv - minv + 1
    BITS = max(1, span.bit_length())
    KEYMASK = (1 << BITS) - 1
    shift = [BITS * i for i in range(K)]

    def encode(m):
        s = 0
        for k, v in m.items():
            s |= (v + OFF) << shift[idx[k]]
        return s

    initial_state = encode(initial)
    final_state = encode(final)
    final_codes = [((final[k] + OFF) if k in final else 0) for k in keys]

    # ---- compile transactions -------------------------------------------------
    compiled = []
    read_reqs_all = []
    for t in txns:
        ops_c = []
        written_before = set()
        read_reqs = []  # (key index, expected code) reads against start-of-tx state
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                ki = idx[op[1]]
                ec = (op[2] + OFF) if op[2] is not None else 0
                ops_c.append((0, shift[ki], ec))
                if ki not in written_before:
                    read_reqs.append((ki, ec, True))
            elif kind == "put":
                ki = idx[op[1]]
                ops_c.append((1, shift[ki], op[2] + OFF))
                written_before.add(ki)
            elif kind == "del":
                ki = idx[op[1]]
                ops_c.append((2, shift[ki]))
                written_before.add(ki)
            elif kind == "cas":
                ki = idx[op[1]]
                old = (op[2] + OFF) if op[2] is not None else 0
                new = (op[3] + OFF) if op[3] is not None else 0
                want = bool(op[4])
                ops_c.append((3, shift[ki], old, new, want))
                if ki not in written_before:
                    read_reqs.append((ki, old, want))
                if want:
                    written_before.add(ki)
            else:  # scan
                low, high, pairs = op[1], op[2], op[3]
                expd = {}
                bad = False
                for p in pairs:
                    k, v = p[0], p[1]
                    if k not in idx or not (low <= k < high) or v is None or k in expd:
                        bad = True
                        break
                    expd[k] = v + OFF
                if bad:
                    ops_c.append((5,))
                    continue
                cand = [i for i, k in enumerate(keys) if low <= k < high]
                shs = tuple(shift[i] for i in cand)
                exps = tuple(expd.get(keys[i], 0) for i in cand)
                ops_c.append((4, shs, exps))
                for i in cand:
                    if i not in written_before:
                        ec = expd.get(keys[i], 0)
                        read_reqs.append((i, ec, True))
                for k in expd:
                    written_before.add(idx[k])
        compiled.append(ops_c)
        read_reqs_all.append(read_reqs)

    # ---- precedence / masks ---------------------------------------------------
    full = (1 << n) - 1
    pred = [0] * n
    for u in range(n):
        eu = txns[u]["end"]
        for v in range(n):
            if u != v and eu <= txns[v]["start"]:
                pred[v] |= (1 << u)

    maywrite = [0] * K        # any op that could write (incl. cas)
    writemask = [0] * K       # unconditional writers: put / del only
    can_final = [0] * K       # any op that could write final value
    cap_putdel = [0] * K      # put / del that writes final value
    read_key_mask = [0] * K   # transactions that read this key (get/cas/scan)
    for t in range(n):
        for op in txns[t]["ops"]:
            kind = op[0]
            if kind == "put":
                ki = idx[op[1]]
                maywrite[ki] |= (1 << t)
                writemask[ki] |= (1 << t)
                if op[2] + OFF == final_codes[ki]:
                    can_final[ki] |= (1 << t)
                    cap_putdel[ki] |= (1 << t)
            elif kind == "del":
                ki = idx[op[1]]
                maywrite[ki] |= (1 << t)
                writemask[ki] |= (1 << t)
                if final_codes[ki] == 0:
                    can_final[ki] |= (1 << t)
                    cap_putdel[ki] |= (1 << t)
            elif kind == "cas":
                ki = idx[op[1]]
                read_key_mask[ki] |= (1 << t)
                if op[4]:
                    maywrite[ki] |= (1 << t)
                    nv = (op[3] + OFF) if op[3] is not None else 0
                    if nv == final_codes[ki]:
                        can_final[ki] |= (1 << t)
            elif kind == "get":
                read_key_mask[idx[op[1]]] |= (1 << t)
            else:  # scan
                low, high = op[1], op[2]
                for i, k in enumerate(keys):
                    if low <= k < high:
                        read_key_mask[i] |= (1 << t)

    read_masks = [0] * n
    read_list = [None] * n
    for t in range(n):
        m = 0
        for ki, ec, eq in read_reqs_all[t]:
            m |= (1 << ki)
        read_masks[t] = m
        read_list[t] = read_reqs_all[t]

    # ---- execution ------------------------------------------------------------
    def exec_tx(t, state):
        for op in compiled[t]:
            c = op[0]
            if c == 0:
                if ((state >> op[1]) & KEYMASK) != op[2]:
                    return -1
            elif c == 1:
                sh = op[1]
                state = (state & ~(KEYMASK << sh)) | (op[2] << sh)
            elif c == 2:
                state &= ~(KEYMASK << op[1])
            elif c == 3:
                sh = op[1]
                cur = (state >> sh) & KEYMASK
                if (cur == op[2]) != op[4]:
                    return -1
                if cur == op[2]:
                    state = (state & ~(KEYMASK << sh)) | (op[3] << sh)
            elif c == 4:
                st = state
                for sh, ec in zip(op[1], op[2]):
                    if ((st >> sh) & KEYMASK) != ec:
                        return -1
            else:
                return -1
        return state

    if n == 0:
        return {"order": []} if initial_state == final_state else {"order": None}

    memo = {}
    pick = {}
    DEBUG = os.environ.get('MAIN_DEBUG')
    NODES = [0]
    sys.setrecursionlimit(10000)

    # candidate heuristic: earlier end first, then more ops
    order_hint = sorted(range(n), key=lambda t: (txns[t]["end"], -len(compiled[t])))

    def dfs(mask, state):
        if mask == full:
            return state == final_state
        remaining = full ^ mask
        # ---- canonicalize / prune unread keys --------------------------------
        canon = state
        for i in range(K):
            sh = shift[i]
            if read_key_mask[i] & remaining:
                # key is read later: its value matters; capability prune
                cur = (state >> sh) & KEYMASK
                if cur != final_codes[i]:
                    if (can_final[i] & remaining) == 0:
                        return False
                elif (can_final[i] & remaining) == 0 and (writemask[i] & remaining):
                    return False
            else:
                W = writemask[i] & remaining
                if W == 0:
                    if ((state >> sh) & KEYMASK) != final_codes[i]:
                        return False
                else:
                    if (cap_putdel[i] & W) == 0:
                        return False
                    canon &= ~(KEYMASK << sh)
        state = canon
        key = (mask << (BITS * K)) | state
        v = memo.get(key)
        if v is not None:
            return v
        if DEBUG:
            NODES[0] += 1
        # reads against keys that can no longer change
        frozen = 0
        for i in range(K):
            if (maywrite[i] & remaining) == 0:
                frozen |= (1 << i)
        if frozen:
            for t in range(n):
                if (mask >> t) & 1:
                    continue
                if read_masks[t] & frozen:
                    for ki, ec, eq in read_list[t]:
                        if (frozen >> ki) & 1:
                            val = (state >> shift[ki]) & KEYMASK
                            if (val != ec) if eq else (val == ec):
                                memo[key] = 0
                                return False
        # candidates
        for t in order_hint:
            if (mask >> t) & 1:
                continue
            if pred[t] & mask != pred[t]:
                continue
            ns = exec_tx(t, state)
            if ns >= 0 and dfs(mask | (1 << t), ns):
                memo[key] = 1
                pick[key] = t
                return True
        memo[key] = 0
        return False

    if dfs(0, initial_state):
        out = []
        mask = 0
        state = initial_state
        while mask != full:
            # replicate canonicalization to find the memo key
            remaining = full ^ mask
            canon = state
            for i in range(K):
                if not (read_key_mask[i] & remaining):
                    if writemask[i] & remaining:
                        canon &= ~(KEYMASK << shift[i])
            state = canon
            key = (mask << (BITS * K)) | state
            t = pick[key]
            out.append(txns[t]["id"])
            state = exec_tx(t, state)
            mask |= (1 << t)
        if DEBUG: print('nodes', NODES[0], file=sys.stderr)
        return {"order": out}
    if DEBUG: print('nodes', NODES[0], file=sys.stderr)
    return {"order": None}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
            res = solve(req)
        except Exception as e:  # pragma: no cover
            print("error:", e, file=sys.stderr)
            res = {"order": None}
        out.write(json.dumps(res))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
