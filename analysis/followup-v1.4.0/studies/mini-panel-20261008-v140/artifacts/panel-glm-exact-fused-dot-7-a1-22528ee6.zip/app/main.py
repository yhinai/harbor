#!/usr/bin/env python3
"""Exact fused dot product for a parameterized binary floating-point format.

Reads newline delimited JSON requests from stdin and writes one JSON response
per request line to stdout.

All intermediate products and the accumulation are performed exactly (integer
arithmetic); only the final sum is rounded to the destination format.
"""

import json
import sys

NEAREST = ('RNE', 'RNA')


# ---------------------------------------------------------------------------
# format helpers
# ---------------------------------------------------------------------------

def encode(ebits, fbits, sign, exp, frac):
    """Pack (sign, exponent, fraction) into an integer bit pattern."""
    return (sign << (ebits + fbits)) | (exp << fbits) | frac


def hexbits(value):
    return format(value, 'x')


# ---------------------------------------------------------------------------
# core solver
# ---------------------------------------------------------------------------

def solve(request):
    ebits = request['ebits']
    fbits = request['fbits']
    mode = request['mode']
    pairs = request['pairs']

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits              # significand radix (2**fbits)
    Eall = (1 << ebits) - 1     # all-ones exponent
    fmask = F - 1
    emin = 1 - bias             # minimum (subnormal) exponent
    emax = Eall - 1 - bias      # maximum normal exponent
    top_frac_bit = 1 << (fbits - 1)

    # ---- pass 1: inspect every operand of every pair ---------------------
    any_nan = False             # some operand is a NaN (quiet or signaling)
    invalid = False             # sNaN, 0*inf, or +/-inf products mixed
    inf_negative = False         # an infinite product is negative
    inf_positive = False        # an infinite product is positive
    all_products_neg_zero = True  # every product is a negative zero
    terms = []                  # nonzero finite products: (sign, m, E)

    for left, right in pairs:
        v1 = int(left, 16)
        v2 = int(right, 16)
        s1 = (v1 >> (ebits + fbits)) & 1
        e1 = (v1 >> fbits) & Eall
        f1 = v1 & fmask
        s2 = (v2 >> (ebits + fbits)) & 1
        e2 = (v2 >> fbits) & Eall
        f2 = v2 & fmask

        nan1 = (e1 == Eall and f1 != 0)
        nan2 = (e2 == Eall and f2 != 0)
        if nan1 or nan2:
            # a NaN operand contributes no product of any kind
            any_nan = True
            if nan1 and not (f1 & top_frac_bit):
                invalid = True  # signaling NaN
            if nan2 and not (f2 & top_frac_bit):
                invalid = True  # signaling NaN
            continue

        # significand / exponent2 of each operand (infinites handled below)
        if e1 == 0:
            m1, E1 = f1, 1 - bias - fbits
        else:
            m1, E1 = F + f1, e1 - bias - fbits
        if e2 == 0:
            m2, E2 = f2, 1 - bias - fbits
        else:
            m2, E2 = F + f2, e2 - bias - fbits

        if e1 == Eall or e2 == Eall:
            # at least one infinity, neither operand NaN
            if (e1 == 0 and f1 == 0) or (e2 == 0 and f2 == 0):
                invalid = True  # zero times infinity (either order)
                continue
            if s1 ^ s2:
                inf_negative = True
            else:
                inf_positive = True
            continue

        # finite times finite: exact product
        m = m1 * m2
        sign = s1 ^ s2
        if m == 0:
            if sign != 1:
                all_products_neg_zero = False  # a positive (or unsigned) zero
            continue
        all_products_neg_zero = False
        terms.append((sign, m, E1 + E2))

    if inf_negative and inf_positive:
        invalid = True  # both positive and negative infinite products

    # ---- exceptional results ---------------------------------------------
    if any_nan or invalid:
        bits = encode(ebits, fbits, 0, Eall, top_frac_bit)  # canonical NaN
        return {'bits': hexbits(bits), 'flags': ['invalid'] if invalid else []}

    if inf_positive or inf_negative:
        # both signs together would have raised invalid above
        sign = 1 if inf_negative else 0
        bits = encode(ebits, fbits, sign, Eall, 0)
        return {'bits': hexbits(bits), 'flags': []}

    # ---- exact accumulation of finite products ---------------------------
    if not terms:
        # exact zero: negative iff all products are negative zeros (and there
        # is at least one), or the rounding mode is RDN.
        sign = 1 if (pairs and all_products_neg_zero) or mode == 'RDN' else 0
        bits = encode(ebits, fbits, sign, 0, 0)
        return {'bits': hexbits(bits), 'flags': []}

    common = min(t[2] for t in terms)
    total = 0
    for sign, m, E in terms:
        scaled = m << (E - common)
        total = total - scaled if sign else total + scaled

    if total == 0:
        # exact zero (e.g. a cancellation between nonzero products): negative
        # iff every product is a negative zero (with at least one product) or
        # the mode is RDN.
        sign = 1 if (pairs and all_products_neg_zero) or mode == 'RDN' else 0
        bits = encode(ebits, fbits, sign, 0, 0)
        return {'bits': hexbits(bits), 'flags': []}

    negative = total < 0
    mag = -total if negative else total       # exact magnitude = mag * 2**common

    L = (mag.bit_length() - 1) + common       # floor(log2(x))
    qexp = (emin if emin > L else L) - fbits  # quantum = 2**qexp
    shift = common - qexp                     # x/q = mag * 2**shift

    if shift >= 0:
        yint = mag << shift
        k = 0
        rem = 0
    else:
        k = -shift
        yint = mag >> k
        rem = mag & ((1 << k) - 1)

    # round the magnitude x/q to an integer in the requested mode
    if rem:
        half = 1 << (k - 1)
        if mode == 'RNE':
            if rem > half or (rem == half and (yint & 1)):
                yint += 1
        elif mode == 'RNA':
            if rem >= half:
                yint += 1
        elif mode == 'RTZ':
            pass
        elif mode == 'RUP':
            if not negative:
                yint += 1
        elif mode == 'RDN':
            if negative:
                yint += 1
        else:
            raise ValueError('unknown mode %r' % (mode,))

    inexact = rem != 0

    def at_least_pow2(n):
        """True iff y (= yint * 2**qexp) >= 2**n."""
        if yint == 0:
            return False
        d = n - qexp
        if d <= 0:
            return True
        return yint >= (1 << d)

    # ---- overflow --------------------------------------------------------
    if at_least_pow2(emax + 1):
        # round away from zero for nearest modes and for the directed mode
        # that points away from zero, otherwise keep the maximum finite.
        away = (mode in NEAREST
                or (mode == 'RUP' and not negative)
                or (mode == 'RDN' and negative))
        if away:
            bits = encode(ebits, fbits, 1 if negative else 0, Eall, 0)
        else:
            bits = encode(ebits, fbits, 1 if negative else 0, Eall - 1, fmask)
        return {'bits': hexbits(bits), 'flags': ['overflow', 'inexact']}

    flags = []
    if inexact:
        flags.append('inexact')
        if not at_least_pow2(emin):   # rounded magnitude below 2**emin
            flags.append('underflow')

    # ---- encode the rounded magnitude ------------------------------------
    sign = 1 if negative else 0
    # y is always a multiple of the subnormal quantum 2**(emin-fbits)
    units = yint << (qexp - (emin - fbits))   # y / 2**(emin-fbits)
    if units == 0:
        bits = encode(ebits, fbits, sign, 0, 0)
    elif units < F:
        bits = encode(ebits, fbits, sign, 0, units)          # subnormal
    else:
        e0 = units.bit_length() - 1
        significand = units >> (e0 - fbits)
        bits = encode(ebits, fbits, sign, e0 - fbits + 1, significand - F)
    return {'bits': hexbits(bits), 'flags': flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request)))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
