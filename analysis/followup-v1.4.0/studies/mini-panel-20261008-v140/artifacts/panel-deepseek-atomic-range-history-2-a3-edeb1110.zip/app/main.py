"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation.  For a completed concurrent
history we must either return a serial order of the transactions that
reproduces every observed result (starting from ``initial`` and ending at
``final``), or prove that no such order exists.

The search runs backwards from the final state.  Because every operation of a
transaction only ever touches one key (scans compare a per-key expectation)
and the effects on different keys are independent, the set of states from
which a suffix of transactions can validly run down to ``final`` is always a
product of per-key allowed-value sets.  Prepending a transaction to a suffix
therefore transforms each per-key set independently, which makes the backward
search very compact.  A forward DFS is kept as a fallback.
"""

import json
import sys


# ---------------------------------------------------------------------------
# value encoding: None (absent) -> 0, integer v in [-9, 9] -> v + 10
# ---------------------------------------------------------------------------

def _code(v):
    return 0 if v is None else v + 10


def _scan_is_satisfiable(op, keys):
    """A scan observation that cannot match any state kills the history."""
    lo, hi, pairs = op[1], op[2], op[3]
    prev = None
    for pr in pairs:
        if not isinstance(pr, list) or len(pr) != 2:
            return False
        k, v = pr
        if (not isinstance(k, str) or k not in keys or not (lo <= k < hi)
                or type(v) is not int or not (-9 <= v <= 9)):
            return False
        if prev is not None and k <= prev:
            return False
        prev = k
    return True


# ---------------------------------------------------------------------------
# backward (primary) solver
# ---------------------------------------------------------------------------

class _Budget(Exception):
    pass


def _solve_backward(request, node_budget, memo_budget=2000000):
    """Return (order_or_None, solved).  solved=False means budget exhausted."""
    txs = request["transactions"]
    n = len(txs)
    initial = request["initial"]
    final = request["final"]

    if n == 0:
        return ([] if initial == final else None), True

    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            keys.add(op[1])
    keys = sorted(keys)
    nk = len(keys)
    kid = {k: i for i, k in enumerate(keys)}

    for t in txs:
        for op in t["ops"]:
            if op[0] == "scan" and not _scan_is_satisfiable(op, keys):
                return None, True

    starts = [t["start"] for t in txs]
    ends = [t["end"] for t in txs]

    # Domains: any value that can ever be present in a state is an initial
    # value or a written constant (plus None for absence).
    dom = [set([None]) for _ in range(nk)]
    for k in keys:
        i = kid[k]
        if k in initial:
            dom[i].add(initial[k])
        if k in final:
            dom[i].add(final[k])
    for t in txs:
        for op in t["ops"]:
            i = kid[op[1]]
            if op[0] == "put":
                dom[i].add(op[2])
            elif op[0] == "del":
                dom[i].add(None)
            elif op[0] == "cas" and op[4]:
                dom[i].add(op[3])
    pos = []
    for i in range(nk):
        pos.append({_code(v): j for j, v in enumerate(sorted(dom[i], key=_code))})

    # trans[t][ki][position] = resulting position, or -1 if the ops of t on
    # that key fail (get mismatch, cas mismatch, scan mismatch).
    trans = []
    for t in txs:
        tt = []
        for i in range(nk):
            k = keys[i]
            res = []
            for v in sorted(dom[i], key=_code):
                val = v
                fail = False
                for op in t["ops"]:
                    kind = op[0]
                    if kind == "get":
                        if op[1] == k and val != op[2]:
                            fail = True
                            break
                    elif kind == "put":
                        if op[1] == k:
                            val = op[2]
                    elif kind == "del":
                        if op[1] == k:
                            val = None
                    elif kind == "cas":
                        if op[1] == k:
                            ok = (val == op[2])
                            if ok != op[4]:
                                fail = True
                                break
                            if ok:
                                val = op[3]
                    else:  # scan
                        if op[1] <= k < op[2]:
                            want = None
                            for kk, vv in op[3]:
                                if kk == k:
                                    want = vv
                                    break
                            if val != want:
                                fail = True
                                break
                res.append(pos[i][_code(val)] if not fail else -1)
            tt.append(res)
        trans.append(tt)

    # inv[t][ki][after_position] = bitmask of pre-positions
    inv = []
    for t in range(n):
        ti = []
        for i in range(nk):
            m = {}
            for x, r in enumerate(trans[t][i]):
                if r >= 0:
                    m[r] = m.get(r, 0) | (1 << x)
            ti.append(m)
        inv.append(ti)

    init_bit = [pos[i][_code(initial[k])] if k in initial else pos[i][_code(None)]
                for i, k in enumerate(keys)]
    final_box = tuple(1 << (pos[i][_code(final[k])] if k in final else pos[i][_code(None)])
                      for i, k in enumerate(keys))

    # must_precede[i][j]: i is forced before j by the real-time order.
    mp = [[False] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i != j and ends[i] <= starts[j]:
                mp[i][j] = True
    for k in range(n):
        for i in range(n):
            if mp[i][k]:
                rowi = mp[i]
                rowk = mp[k]
                for j in range(n):
                    if rowk[j]:
                        rowi[j] = True

    def pre(t, box):
        nb = []
        for i in range(nk):
            a = box[i]
            invi = inv[t][i]
            m = 0
            while a:
                low = a & -a
                m |= invi.get(low.bit_length() - 1, 0)
                a ^= low
            if m == 0:
                return None
            nb.append(m)
        return tuple(nb)

    memo = {}
    order = []
    nodes = [0]

    def bdfs(rem, box):
        nodes[0] += 1
        if nodes[0] > node_budget:
            raise _Budget
        if rem == 0:
            for i in range(nk):
                if not (box[i] >> init_bit[i]) & 1:
                    return False
            return True
        key = (rem, box)
        if key in memo:
            return False
        cands = []
        for t in range(n):
            if rem >> t & 1:
                bad = False
                for u in range(n):
                    if u != t and (rem >> u & 1) and mp[t][u]:
                        bad = True
                        break
                if not bad:
                    cands.append(t)
        precomputed = []
        for t in cands:
            nb = pre(t, box)
            if nb is not None:
                precomputed.append((t, nb))
        # Prefer choices that keep the boxes large (they tend to be feasible).
        precomputed.sort(key=lambda tb: sum(x.bit_count() for x in tb[1]),
                         reverse=True)
        for t, nb in precomputed:
            order.append(t)
            if bdfs(rem ^ (1 << t), nb):
                return True
            order.pop()
        memo[key] = True
        if len(memo) > memo_budget:
            raise _Budget
        return False

    try:
        ok = bdfs((1 << n) - 1, final_box)
    except _Budget:
        return None, False
    if not ok:
        return None, True
    order.reverse()
    return [txs[i]["id"] for i in order], True


# ---------------------------------------------------------------------------
# forward (fallback) solver
# ---------------------------------------------------------------------------

def _apply_tx(ops, state):
    d = dict(state)
    for op in ops:
        kind = op[0]
        if kind == "get":
            if d.get(op[1]) != op[2]:
                return None
        elif kind == "put":
            d[op[1]] = op[2]
        elif kind == "del":
            d.pop(op[1], None)
        elif kind == "cas":
            _, key, old, new, want = op
            cur = d.get(key)
            ok = (cur == old)
            if ok != want:
                return None
            if ok:
                if new is None:
                    d.pop(key, None)
                else:
                    d[key] = new
        else:
            _, low, high, pairs = op
            got = [[k, d[k]] for k in sorted(d) if low <= k < high]
            if got != pairs:
                return None
    return d


def _solve_forward(request, node_budget, memo_budget=2000000):
    txs = request["transactions"]
    n = len(txs)
    initial = request["initial"]
    final = request["final"]
    if n == 0:
        return ([] if initial == final else None), True

    ids = [t["id"] for t in txs]
    starts = [t["start"] for t in txs]
    ends = [t["end"] for t in txs]
    opsets = [t["ops"] for t in txs]

    keys_all = set(initial) | set(final)
    for ops in opsets:
        for op in ops:
            keys_all.add(op[1])
    for t in txs:
        for op in t["ops"]:
            if op[0] == "scan" and not _scan_is_satisfiable(op, keys_all):
                return None, True

    pred = [0] * n
    for i in range(n):
        for j in range(n):
            if i != j and ends[j] <= starts[i]:
                pred[i] |= 1 << j

    init_state = tuple(sorted(initial.items()))
    final_state = tuple(sorted(final.items()))
    final_map = dict(final)

    apply_cache = {}
    fail_memo = set()
    order = []
    nodes = [0]

    def dfs(rem, state):
        nodes[0] += 1
        if nodes[0] > node_budget:
            raise _Budget
        if rem == 0:
            return state == final_state
        key = (rem, state)
        if key in fail_memo:
            return False
        cands = []
        for i in range(n):
            if rem >> i & 1 and (pred[i] & rem) == 0:
                ck = (i, state)
                ns = apply_cache.get(ck)
                if ns is None:
                    r = _apply_tx(opsets[i], dict(state))
                    ns = tuple(sorted(r.items())) if r is not None else False
                    apply_cache[ck] = ns
                if ns is not False:
                    score = 0
                    nd = dict(ns)
                    for k, v in final_map.items():
                        if nd.get(k) == v:
                            score += 1
                    score -= abs(len(nd) - len(final_map))
                    cands.append((-score, i, ns))
        cands.sort()
        for _, i, ns in cands:
            order.append(ids[i])
            if dfs(rem & ~(1 << i), ns):
                return True
            order.pop()
        fail_memo.add(key)
        if len(fail_memo) > memo_budget:
            raise _Budget
        return False

    try:
        ok = dfs((1 << n) - 1, init_state)
    except _Budget:
        return None, False
    if not ok:
        return None, True
    return list(order), True


# ---------------------------------------------------------------------------

def solve(request):
    # The backward search is the primary engine; the forward DFS is a fallback
    # with different failure modes.  Budgets are far above anything observed
    # for the allowed input sizes.
    order, done = _solve_backward(request, 250000, 300000)
    if done:
        return {"order": order}
    order, done = _solve_forward(request, 1000000, 800000)
    if done:
        return {"order": order}
    order, done = _solve_backward(request, 5000000, 1500000)
    if done:
        return {"order": order}
    order, done = _solve_forward(request, 5000000, 1500000)
    if done:
        return {"order": order}
    # Last resort: run the complete backward search without a node budget.
    order, _ = _solve_backward(request, 1 << 62, 2000000)
    return {"order": order}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        try:
            result = solve(request)
        except Exception as exc:  # never lose the rest of the batch
            sys.stderr.write("solve error: %r\n" % (exc,))
            result = {"order": None}
        out.write(json.dumps(result))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
