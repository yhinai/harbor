#!/usr/bin/env python3
"""Enumerate every terminal observable outcome of a mixed-width buffered
(TSO-like teaching) machine.

Machine (all transitions are atomic, multi-byte accesses included)
------------------------------------------------------------------
Each thread has a program counter, a FIFO store buffer and an observation
list; shared memory is a flat array of bytes.  One step is one of:

  1. execute the next instruction of some thread, in program order
       * store : append the complete (addr,width,value) store to this
                 thread's buffer and advance.  Memory is unchanged.
       * load  : for every byte, the youngest buffered store *of this
                 thread* covering that byte wins, otherwise shared memory.
                 The assembled unsigned little-endian value is appended to
                 this thread's observations.  It never blocks on a non-empty
                 buffer.
       * fence : enabled only with an empty buffer, then advance.
       * xchg  : enabled only with an empty buffer; atomically read the
                 shared-memory value (appended to the observations), write
                 the supplied value, advance.  Other threads' buffers are
                 neither drained nor consulted.
  2. drain the oldest store of some non-empty buffer to shared memory, all
     of its bytes becoming visible together.  Also possible after the
     issuing thread has finished.

A state is terminal iff every thread finished and every buffer is empty.
The pair (remaining instructions, buffered stores) strictly decreases
lexicometrically with every step, so every execution is finite and ends in a
terminal state; no fairness assumption is needed and no execution can be
starved away from a terminal state.

Exploration
-----------
The buffer of a thread is always the contiguous slice store_list[k:j] of that
thread's stores, where j is the number of stores among its first pc
instructions and k is how many of them already drained.  Hence a state is
fully described by (pcs, drained counts, memory) - the store payloads are
implied.  Observations are append-only and never influence any transition,
so the set of (future observations, final memory) pairs is a pure function of
that state.  The machine's transition relation is therefore a DAG over these
states, which makes a memoised suffix recursion exact; since the initial
observation lists are empty, that suffix set for the initial state is the
complete answer.
"""

import json
import sys


def _le_bytes(value, width):
    """Little-endian byte tuple of an unsigned value of the given width."""
    return tuple((value >> (8 * k)) & 0xFF for k in range(width))


class Machine:
    """State explorer for one request."""

    __slots__ = ('n', 'progs', 'store_lists', 'store_covers', 'issued',
                 'lens', 'empty_obs', 'memo')

    def __init__(self, threads_raw):
        self.n = n = len(threads_raw)
        self.progs = []        # per thread: tuple of (kind, payload)
        self.store_lists = []  # per thread: tuple of (addr, width, bytes)
        self.store_covers = [] # per thread: tuple of covered offsets
        self.issued = []       # per thread: issued[pc] = stores in prog[:pc]
        self.lens = []
        for raw in threads_raw:
            prog = []
            stores = []
            covers = []
            issued = [0]
            for ins in raw:
                kind = ins[0]
                if kind == 'store':
                    addr, width, value = ins[1], ins[2], ins[3]
                    bts = _le_bytes(value, width)
                    stores.append((addr, width, bts))
                    covers.append(tuple(range(addr, addr + width)))
                    prog.append(('s', None))
                elif kind == 'load':
                    prog.append(('l', tuple(range(ins[1], ins[1] + ins[2]))))
                elif kind == 'fence':
                    prog.append(('f', None))
                elif kind == 'xchg':
                    addr, width, value = ins[1], ins[2], ins[3]
                    offs = tuple(range(addr, addr + width))
                    prog.append(('x', (addr, width, _le_bytes(value, width), offs)))
                else:
                    raise ValueError('unknown instruction %r' % (ins,))
                issued.append(len(stores))
            self.progs.append(tuple(prog))
            self.store_lists.append(tuple(stores))
            self.store_covers.append(tuple(covers))
            self.issued.append(tuple(issued))
            self.lens.append(len(prog))
        self.empty_obs = ((),) * n
        self.memo = {}

    # -- helpers ---------------------------------------------------------
    def _forwarded(self, i, pc, k):
        """Byte -> value map of thread i's own forwarding for a load at pc."""
        stores = self.store_lists[i]
        covers = self.store_covers[i]
        fwd = {}
        for si in range(self.issued[i][pc] - 1, k - 1, -1):   # youngest first
            addr, _, bts = stores[si]
            for off in covers[si]:
                if off not in fwd:
                    fwd[off] = bts[off - addr]
        return fwd

    @staticmethod
    def _assemble(offs, fwd, mem):
        val = 0
        shift = 0
        for off in offs:
            byte = fwd.get(off)
            val |= (mem[off] if byte is None else byte) << shift
            shift += 8
        return val

    # -- exploration ----------------------------------------------------
    def outcomes(self, pcs, ks, mem):
        """All ((observations per thread), final memory) pairs from a state."""
        key = (pcs, ks, mem)
        memo = self.memo
        hit = memo.get(key)
        if hit is not None:
            return hit

        results = set()
        progs = self.progs
        issued = self.issued
        stores = self.store_lists
        covers = self.store_covers
        lens = self.lens

        for i in range(self.n):
            pc = pcs[i]
            k = ks[i]
            iss = issued[i][pc]

            # ---- transition 1: execute thread i's next instruction ----
            if pc < lens[i]:
                kind, payload = progs[i][pc]
                npcs = pcs[:i] + (pc + 1,) + pcs[i + 1:]
                if kind == 's':
                    results |= self.outcomes(npcs, ks, mem)
                elif kind == 'f':
                    if k == iss:                      # fence: buffer empty
                        results |= self.outcomes(npcs, ks, mem)
                elif kind == 'l':
                    val = self._assemble(payload,
                                        self._forwarded(i, pc, k), mem)
                    for obs, m in self.outcomes(npcs, ks, mem):
                        row = list(obs)
                        row[i] = (val,) + row[i]
                        results.add((tuple(row), m))
                else:                                  # xchg: buffer empty
                    if k == iss:
                        addr, _, bts, offs = payload
                        val = self._assemble(offs, {}, mem)
                        nm = list(mem)
                        for off in offs:
                            nm[off] = bts[off - addr]
                        for obs, m in self.outcomes(npcs, ks, tuple(nm)):
                            row = list(obs)
                            row[i] = (val,) + row[i]
                            results.add((tuple(row), m))

            # ---- transition 2: drain thread i's oldest store ----
            if k < iss:
                addr, _, bts = stores[i][k]
                nm = list(mem)
                for off in covers[i][k]:
                    nm[off] = bts[off - addr]
                nks = ks[:i] + (k + 1,) + ks[i + 1:]
                results |= self.outcomes(pcs, nks, tuple(nm))

        if not results:
            # No enabled transition: every thread finished and all buffers
            # are empty (this machine cannot deadlock).
            results = {(self.empty_obs, mem)}

        memo[key] = results
        return results


def solve(request):
    """Return {'outcomes': [{'reads': [...], 'memory': [...]}, ...]}."""
    mem0 = tuple(request['memory'])
    machine = Machine(request['threads'])
    n = machine.n
    final = machine.outcomes((0,) * n, (0,) * n, mem0)
    return {
        'outcomes': [
            {'reads': [list(t) for t in obs], 'memory': list(mem)}
            for obs, mem in final
        ]
    }


def main():
    sys.setrecursionlimit(100000)
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            response = solve(json.loads(line))
        except Exception as exc:               # keep the batch alive
            print('error: %r' % (exc,), file=sys.stderr)
            response = {'outcomes': []}
        out.write(json.dumps(response))
        out.write('\n')
    out.flush()


if __name__ == '__main__':
    main()
