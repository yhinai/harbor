import json
import sys

# Instruction encodings (first element = kind):
#   store: (0, addr, value_bytes)
#   load:  (1, addr, width)
#   fence: (2,)
#   xchg:  (3, addr, width, value_bytes)
# Buffer entries: (addr, value_bytes)  -- FIFO, drain from the front.
# State: (memory_bytes, ((pc, buffer_tuple, obs_tuple), ... per thread))

def _compile(threads):
    progs = []
    for thread in threads:
        prog = []
        for ins in thread:
            op = ins[0]
            if op == 'store':
                a, w, v = ins[1], ins[2], ins[3]
                prog.append((0, a, v.to_bytes(w, 'little')))
            elif op == 'load':
                prog.append((1, ins[1], ins[2]))
            elif op == 'fence':
                prog.append((2,))
            else:  # xchg
                a, w, v = ins[1], ins[2], ins[3]
                prog.append((3, a, w, v.to_bytes(w, 'little')))
        progs.append(prog)
    return progs

def solve(request):
    mem0 = bytes(request['memory'])
    progs = _compile(request['threads'])
    n = len(progs)
    init = (mem0, tuple((0, (), ()) for _ in range(n)))
    visited = {init}
    stack = [init]
    outcomes = set()
    push = stack.append
    while stack:
        mem, threads = stack.pop()
        terminal = True
        for i in range(n):
            pc, buf, obs = threads[i]
            prog = progs[i]
            if pc < len(prog):
                terminal = False
                ins = prog[pc]
                kind = ins[0]
                if kind == 0:  # store: enqueue into own FIFO buffer
                    ns = (mem, threads[:i] + ((pc + 1, buf + ((ins[1], ins[2]),), obs),) + threads[i + 1:])
                    if ns not in visited:
                        visited.add(ns)
                        push(ns)
                elif kind == 1:  # load: per-byte forwarding from own buffer
                    a, w = ins[1], ins[2]
                    val = 0
                    for j in range(w):
                        x = a + j
                        b = mem[x]
                        for sa, sb in reversed(buf):
                            if sa <= x < sa + len(sb):
                                b = sb[x - sa]
                                break
                        val |= b << (8 * j)
                    ns = (mem, threads[:i] + ((pc + 1, buf, obs + (val,)),) + threads[i + 1:])
                    if ns not in visited:
                        visited.add(ns)
                        push(ns)
                elif kind == 2:  # fence: only when own buffer is empty
                    if not buf:
                        ns = (mem, threads[:i] + ((pc + 1, buf, obs),) + threads[i + 1:])
                        if ns not in visited:
                            visited.add(ns)
                            push(ns)
                else:  # xchg: only when own buffer empty; atomic read+write of memory
                    if not buf:
                        a, w, vb = ins[1], ins[2], ins[3]
                        old = int.from_bytes(mem[a:a + w], 'little')
                        nmem = mem[:a] + vb + mem[a + w:]
                        ns = (nmem, threads[:i] + ((pc + 1, buf, obs + (old,)),) + threads[i + 1:])
                        if ns not in visited:
                            visited.add(ns)
                            push(ns)
            if buf:
                terminal = False
                sa, sb = buf[0]  # drain oldest store of this thread
                nmem = mem[:sa] + sb + mem[sa + len(sb):]
                ns = (nmem, threads[:i] + ((pc, buf[1:], obs),) + threads[i + 1:])
                if ns not in visited:
                    visited.add(ns)
                    push(ns)
        if terminal:
            outcomes.add((tuple(t[2] for t in threads), mem))
    solve.last_states = len(visited)
    return {'outcomes': [{'reads': [list(o) for o in obss], 'memory': list(mem)}
                         for obss, mem in outcomes]}

def main():
    lines = []
    for line in sys.stdin:
        line = line.strip()
        if line:
            lines.append(json.dumps(solve(json.loads(line))))
    if lines:
        sys.stdout.write('\n'.join(lines) + '\n')

if __name__ == '__main__':
    main()
