"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests from stdin and writes one JSON
response per line to stdout.
"""

import json
import sys
import zlib

MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray.fromhex(h) for h in request["pages"]]
    n_pages = len(pages)
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])
    n = len(log)

    pos = 0            # bytes consumed so far == valid prefix length
    prev_seq = 0       # sequence of previous valid record
    last_seq = 0       # last valid record sequence
    active = {}        # txn_id -> [patches list, crc of concatenated payloads]

    while n - pos >= 13:
        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txn_id = int.from_bytes(log[pos + 9:pos + 13], "little")
        end = pos + 13 + payload_length + 4
        if end > n:
            break  # incomplete / torn record
        header = log[pos:pos + 13]
        payload = log[pos + 13:end - 4]
        crc_stored = int.from_bytes(log[end - 4:end], "little")
        if zlib.crc32(header + payload) & 0xFFFFFFFF != crc_stored:
            break  # invalid CRC
        if sequence == 0 or sequence <= prev_seq:
            break  # invalid sequence
        if txn_id == 0 or payload_length > MAX_PAYLOAD:
            break  # invalid header

        # kind / payload-shape validation (structural, applies to all records)
        if kind == KIND_BEGIN:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            if page_index >= n_pages or byte_offset + byte_count > len(pages[page_index]):
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        elif kind == KIND_ABORT:
            if payload_length != 0:
                break
        else:
            break  # unknown kind

        # The record is structurally valid: extend the prefix.
        pos = end
        prev_seq = sequence
        last_seq = sequence

        # Semantic effects.
        if kind == KIND_BEGIN:
            # Fresh incarnation, discarding any unfinished one.
            active[txn_id] = [[], 0]
        elif kind == KIND_PATCH:
            st = active.get(txn_id)
            if st is not None:
                st[0].append((page_index, byte_offset, bytes(payload[6:])))
                st[1] = zlib.crc32(payload, st[1]) & 0xFFFFFFFF
            # otherwise ignored (but still validated above)
        elif kind == KIND_COMMIT:
            st = active.pop(txn_id, None)  # always closes the incarnation
            if st is not None:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (patch_count == len(st[0]) and digest == st[1]
                        and sequence > checkpoint):
                    for pi, off, data in st[0]:
                        pages[pi][off:off + len(data)] = data
                # seal mismatch (or not newer than checkpoint): no apply
        else:  # KIND_ABORT
            active.pop(txn_id, None)

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def main():
    write = sys.stdout.write
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        write(json.dumps(solve(json.loads(line))) + "\n")


if __name__ == "__main__":
    main()
