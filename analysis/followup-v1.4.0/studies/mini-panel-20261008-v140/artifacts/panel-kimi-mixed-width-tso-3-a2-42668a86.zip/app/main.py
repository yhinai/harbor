import json
import sys

sys.setrecursionlimit(1000000)


def solve(request):
    mem0 = tuple(request["memory"])
    threads = [tuple(tuple(ins) for ins in t) for t in request["threads"]]
    n = len(threads)
    empty_reads = tuple(() for _ in range(n))

    # explore(mem, pcs, bufs) -> set of (reads_suffix, final_mem)
    # reads_suffix[i] = tuple of values observed by thread i from this state on.
    memo = {}

    def explore(mem, pcs, bufs):
        key = (mem, pcs, bufs)
        hit = memo.get(key)
        if hit is not None:
            return hit
        res = set()

        for i in range(n):
            # execute next instruction of thread i
            if pcs[i] < len(threads[i]):
                ins = threads[i][pcs[i]]
                op = ins[0]
                if op == "store":
                    _, addr, width, value = ins
                    npcs = list(pcs)
                    npcs[i] += 1
                    nb = list(bufs)
                    nb[i] = nb[i] + ((addr, width, value),)
                    for rs, fm in explore(mem, tuple(npcs), tuple(nb)):
                        res.add((rs, fm))
                elif op == "load":
                    _, addr, width = ins
                    buf = bufs[i]
                    val = 0
                    for k in range(width):
                        b = addr + k
                        byte = None
                        for a, w, v in reversed(buf):
                            if a <= b < a + w:
                                byte = (v >> (8 * (b - a))) & 0xFF
                                break
                        if byte is None:
                            byte = mem[b]
                        val |= byte << (8 * k)
                    npcs = list(pcs)
                    npcs[i] += 1
                    for rs, fm in explore(mem, tuple(npcs), bufs):
                        rs2 = list(rs)
                        rs2[i] = (val,) + rs2[i]
                        res.add((tuple(rs2), fm))
                elif op == "fence":
                    if not bufs[i]:  # enabled only when buffer empty
                        npcs = list(pcs)
                        npcs[i] += 1
                        for rs, fm in explore(mem, tuple(npcs), bufs):
                            res.add((rs, fm))
                else:  # xchg
                    if not bufs[i]:  # enabled only when buffer empty
                        _, addr, width, value = ins
                        old = 0
                        for k in range(width):
                            old |= mem[addr + k] << (8 * k)
                        nm = list(mem)
                        for k in range(width):
                            nm[addr + k] = (value >> (8 * k)) & 0xFF
                        npcs = list(pcs)
                        npcs[i] += 1
                        for rs, fm in explore(tuple(nm), tuple(npcs), bufs):
                            rs2 = list(rs)
                            rs2[i] = (old,) + rs2[i]
                            res.add((tuple(rs2), fm))

            # drain oldest store of thread i's buffer
            if bufs[i]:
                a, w, v = bufs[i][0]
                nm = list(mem)
                for k in range(w):
                    nm[a + k] = (v >> (8 * k)) & 0xFF
                nb = list(bufs)
                nb[i] = nb[i][1:]
                for rs, fm in explore(tuple(nm), pcs, tuple(nb)):
                    res.add((rs, fm))

        if not res:
            # terminal: every thread finished and every buffer empty
            res.add((empty_reads, mem))

        memo[key] = res
        return res

    init = (mem0, tuple(0 for _ in range(n)), tuple(() for _ in range(n)))
    outcomes = explore(*init)
    return {
        "outcomes": [
            {"reads": [list(r) for r in reads], "memory": list(fm)}
            for reads, fm in outcomes
        ]
    }


if __name__ == "__main__":
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if line:
            out.write(json.dumps(solve(json.loads(line))) + "\n")
