import json
import sys


def solve(request):
    mem0 = tuple(request["memory"])
    threads = [list(t) for t in request["threads"]]
    n = len(threads)
    lengths = [len(t) for t in threads]

    # state: (memory tuple, ((pc, buffer tuple, obs tuple), ...))
    start = (mem0, tuple((0, (), ()) for _ in range(n)))
    seen = {start}
    stack = [start]
    outcomes = set()

    while stack:
        mem, ts = stack.pop()

        # terminal check
        if all(ts[i][0] == lengths[i] and not ts[i][1] for i in range(n)):
            outcomes.add((tuple(ts[i][2] for i in range(n)), mem))
            continue

        for i in range(n):
            pc, buf, obs = ts[i]

            # ---- execute next instruction ----
            if pc < lengths[i]:
                ins = threads[i][pc]
                op = ins[0]
                if op == "store":
                    addr, width, val = ins[1], ins[2], ins[3]
                    nts = ts[:i] + ((pc + 1, buf + ((addr, width, val),), obs),) + ts[i + 1:]
                    st = (mem, nts)
                    if st not in seen:
                        seen.add(st)
                        stack.append(st)
                elif op == "load":
                    addr, width = ins[1], ins[2]
                    b = 0
                    for j in range(width):
                        a = addr + j
                        byte = mem[a]
                        for sa, sw, sv in reversed(buf):
                            if sa <= a < sa + sw:
                                byte = (sv >> (8 * (a - sa))) & 0xFF
                                break
                        b |= byte << (8 * j)
                    nts = ts[:i] + ((pc + 1, buf, obs + (b,)),) + ts[i + 1:]
                    st = (mem, nts)
                    if st not in seen:
                        seen.add(st)
                        stack.append(st)
                elif op == "fence":
                    if not buf:
                        nts = ts[:i] + ((pc + 1, buf, obs),) + ts[i + 1:]
                        st = (mem, nts)
                        if st not in seen:
                            seen.add(st)
                            stack.append(st)
                elif op == "xchg":
                    if not buf:
                        addr, width, val = ins[1], ins[2], ins[3]
                        b = 0
                        for j in range(width):
                            b |= mem[addr + j] << (8 * j)
                        nm = list(mem)
                        for j in range(width):
                            nm[addr + j] = (val >> (8 * j)) & 0xFF
                        nts = ts[:i] + ((pc + 1, buf, obs + (b,)),) + ts[i + 1:]
                        st = (tuple(nm), nts)
                        if st not in seen:
                            seen.add(st)
                            stack.append(st)

            # ---- drain oldest store ----
            if buf:
                sa, sw, sv = buf[0]
                nm = list(mem)
                for j in range(sw):
                    nm[sa + j] = (sv >> (8 * j)) & 0xFF
                nts = ts[:i] + ((pc, buf[1:], obs),) + ts[i + 1:]
                st = (tuple(nm), nts)
                if st not in seen:
                    seen.add(st)
                    stack.append(st)

    outs = []
    for reads, mem in sorted(outcomes):
        outs.append({"reads": [list(r) for r in reads], "memory": list(mem)})
    return {"outcomes": outs}


def main():
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        print(json.dumps(solve(json.loads(line))))


if __name__ == "__main__":
    main()
