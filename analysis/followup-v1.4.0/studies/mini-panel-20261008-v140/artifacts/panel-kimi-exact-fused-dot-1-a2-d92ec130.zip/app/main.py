import json
import sys


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    Eall = (1 << ebits) - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    sshift = ebits + fbits  # position of the sign bit

    def decode(v):
        s = (v >> sshift) & 1
        e = (v >> fbits) & Eall
        f = v & (F - 1)
        if e == Eall:
            if f == 0:
                return (s, 'inf', 0, 0)
            # NaN: quiet iff top fraction bit set
            return (s, 'snan' if ((f >> (fbits - 1)) & 1) == 0 else 'qnan', 0, 0)
        if e == 0:
            if f == 0:
                return (s, 'zero', 0, 0)
            return (s, 'fin', f, emin - fbits)
        return (s, 'fin', F + f, e - bias - fbits)

    has_nan = False
    has_snan = False
    zero_inf = False
    inf_pos = False
    inf_neg = False
    prods = []  # (sign, mant, exp) for finite*finite products

    for a_hex, b_hex in pairs:
        da = decode(int(a_hex, 16))
        db = decode(int(b_hex, 16))
        pair_nan = False
        for d in (da, db):
            k = d[1]
            if k == 'qnan':
                has_nan = True
                pair_nan = True
            elif k == 'snan':
                has_nan = True
                has_snan = True
                pair_nan = True
        if pair_nan:
            continue  # a NaN pair contributes no product of any kind
        psign = da[0] ^ db[0]
        ka, kb = da[1], db[1]
        if ka == 'inf' or kb == 'inf':
            if ka == 'zero' or kb == 'zero':
                zero_inf = True
            else:
                if psign:
                    inf_neg = True
                else:
                    inf_pos = True
        else:
            prods.append((psign, da[2] * db[2], da[3] + db[3]))

    invalid = has_snan or zero_inf or (inf_pos and inf_neg)

    if has_nan or invalid:
        canon = (Eall << fbits) | (1 << (fbits - 1))
        return {"bits": format(canon, "x"),
                "flags": ["invalid"] if invalid else []}

    if inf_pos or inf_neg:
        sign = 1 if inf_neg else 0
        bits = (sign << sshift) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # Exact sum of finite products.
    S = 0
    E0 = 0
    nonzero = [(s, m, e) for (s, m, e) in prods if m != 0]
    if nonzero:
        E0 = min(e for _, _, e in nonzero)
        acc = 0
        for s, m, e in nonzero:
            v = m << (e - E0)
            acc = acc - v if s else acc + v
        S = acc

    if S == 0:
        # Exact zero.
        if mode == 'RDN':
            sign = 1
        elif prods and all(m == 0 and s == 1 for s, m, e in prods):
            sign = 1  # all products are negative signed zeros
        else:
            sign = 0
        return {"bits": format(sign << sshift, "x"), "flags": []}

    sign = 1 if S < 0 else 0
    M = S if S > 0 else -S  # x = M * 2**E0 > 0

    L = M.bit_length() - 1 + E0
    q_exp = emin - fbits if emin > L else L - fbits
    shift = q_exp - E0

    if shift <= 0:
        n = M << (-shift)
        inexact = False
    else:
        n, rem = divmod(M, 1 << shift)
        inexact = rem != 0
        if inexact:
            half = 1 << (shift - 1)
            if mode == 'RNE':
                if rem > half or (rem == half and (n & 1)):
                    n += 1
            elif mode == 'RNA':
                if rem >= half:
                    n += 1
            elif mode == 'RUP':
                if sign == 0:
                    n += 1
            elif mode == 'RDN':
                if sign == 1:
                    n += 1
            # RTZ: truncate

    # y = n * 2**q_exp is the rounded magnitude.
    yexp = n.bit_length() - 1 + q_exp if n else None  # floor(log2(y))

    if n and yexp >= emax + 1:
        # Overflow: always overflow + inexact.
        if mode in ('RNE', 'RNA'):
            to_inf = True
        elif mode == 'RUP':
            to_inf = sign == 0
        elif mode == 'RDN':
            to_inf = sign == 1
        else:  # RTZ
            to_inf = False
        if to_inf:
            bits = (sign << sshift) | (Eall << fbits)
        else:
            bits = (sign << sshift) | ((Eall - 1) << fbits) | (F - 1)
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
        if n == 0 or yexp < emin:
            flags.append("underflow")

    if n == 0:
        e_field = 0
        f_field = 0
    elif yexp >= emin:
        e_field = yexp + bias
        sh = n.bit_length() - 1 - fbits
        sig = (n >> sh) if sh >= 0 else (n << (-sh))
        f_field = sig - F
    else:
        e_field = 0
        f_field = n << (q_exp - emin + fbits)

    bits = (sign << sshift) | (e_field << fbits) | f_field
    return {"bits": format(bits, "x"), "flags": flags}


if __name__ == '__main__':
    out = []
    for line in sys.stdin:
        line = line.strip()
        if line:
            out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))
