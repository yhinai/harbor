import sys
import json

# Sentinel used internally for an absent key.  Real values are integers in
# [-9, 9], so None is unambiguous.
ABS = None
# Class id standing for "some value that no observation distinguishes".
OTHER = 1000


def solve(req):
    initial = req.get("initial", {})
    final = req.get("final", {})
    txs = req.get("transactions", [])
    n = len(txs)

    def enc(v):
        return None if v is None else int(v)

    # ------------------------------------------------------------- keys
    keys = set(initial) | set(final)
    for t in txs:
        for op in t["ops"]:
            if op[0] == "scan":
                for p in op[3]:
                    keys.add(p[0])
            else:
                keys.add(op[1])
    keys = sorted(keys)
    m = len(keys)
    kidx = {k: i for i, k in enumerate(keys)}

    # ------------------------------------- possible concrete values per key
    # A key's value can only be its initial value or a value written by a
    # definitely executed write (put / del / CAS that must succeed).
    vals = [set() for _ in range(m)]
    for i, k in enumerate(keys):
        vals[i].add(enc(initial.get(k)))
        vals[i].add(ABS)
    for t in txs:
        for op in t["ops"]:
            if op[0] == "put":
                vals[kidx[op[1]]].add(op[2])
            elif op[0] == "del":
                vals[kidx[op[1]]].add(ABS)
            elif op[0] == "cas" and bool(op[4]):
                vals[kidx[op[1]]].add(enc(op[3]))

    # ------------------------------------------------ cheap impossibility
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                if enc(op[2]) not in vals[kidx[op[1]]]:
                    return {"order": None}
            elif kind == "scan":
                for p in op[3]:
                    if enc(p[1]) not in vals[kidx[p[0]]]:
                        return {"order": None}
            elif kind == "cas":
                if bool(op[4]) and enc(op[2]) not in vals[kidx[op[1]]]:
                    return {"order": None}
    for i, k in enumerate(keys):
        if enc(final.get(k)) not in vals[i]:
            return {"order": None}

    # ------------------------------------------------- value abstraction
    # Values that appear in some test (equality or inequality) must stay
    # distinguishable.  All other possible values are interchangeable and
    # are merged into one class.
    ref = [set() for _ in range(m)]
    for t in txs:
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                ref[kidx[op[1]]].add(enc(op[2]))
            elif kind == "scan":
                low, high, pairs = op[1], op[2], op[3]
                present = set()
                for p in pairs:
                    ref[kidx[p[0]]].add(enc(p[1]))
                    present.add(p[0])
                for k in keys:
                    if low <= k < high and k not in present:
                        ref[kidx[k]].add(ABS)
            elif kind == "cas":
                i = kidx[op[1]]
                old = enc(op[2])
                if bool(op[4]):
                    ref[i].add(old)
                elif old in vals[i]:
                    ref[i].add(old)
    for i, k in enumerate(keys):
        ref[i].add(enc(final.get(k)))

    class_lists = []
    class_of = []
    for i in range(m):
        sing = sorted(ref[i] - {ABS})
        lst = ([ABS] if ABS in ref[i] else []) + sing
        if vals[i] - ref[i]:
            lst.append(OTHER)
        class_lists.append(lst)
        mp = {}
        for d, v in enumerate(lst):
            if v is not OTHER:
                mp[v] = d
        oth = lst.index(OTHER) if OTHER in lst else None
        for v in vals[i]:
            if v not in mp:
                mp[v] = oth
        class_of.append(mp)

    # ------------------------------------------------ state space encoding
    strides = []
    prod = 1
    for i in range(m):
        strides.append(prod)
        prod *= len(class_lists[i])
    S = prod
    FULL = (1 << S) - 1

    # eq[i][d] : bitset of all states whose digit i equals d
    eq = []
    for i in range(m):
        stride = strides[i]
        r = len(class_lists[i])
        period = r * stride
        masks = []
        for d in range(r):
            block = ((1 << stride) - 1) << (d * stride)
            mask = block
            step = period
            while step < S:
                mask |= mask << step
                step <<= 1
            masks.append(mask & FULL)
        eq.append(masks)
    neq = [[FULL ^ e for e in eq[i]] for i in range(m)]

    # plan for "set digit i to d": (mask, shift) pairs
    set_plan = []
    for i in range(m):
        stride = strides[i]
        plans = []
        for d in range(len(class_lists[i])):
            plan = [(e, (d - d2) * stride) for d2, e in enumerate(eq[i])]
            plans.append(plan)
        set_plan.append(plans)

    # ------------------------------------------------------------- scans
    scan_cache = {}

    def build_scan_mask(low, high, pairs):
        ck = (low, high, tuple((p[0], p[1]) for p in pairs))
        got = scan_cache.get(ck)
        if got is not None:
            return got
        expected = {}
        bad = False
        prev = None
        for p in pairs:
            k = p[0]
            if k in expected or not (low <= k < high):
                bad = True
                break
            if prev is not None and k <= prev:
                bad = True
                break
            prev = k
            expected[k] = enc(p[1])
        if bad:
            scan_cache[ck] = 0
            return 0
        mask = FULL
        for i, k in enumerate(keys):
            if low <= k < high:
                v = expected.get(k, ABS)
                mask &= eq[i][class_of[i][v]]
        scan_cache[ck] = mask
        return mask

    # ------------------------------------------------- transaction actions
    acts = []
    for t in txs:
        A = []
        for op in t["ops"]:
            kind = op[0]
            if kind == "get":
                i = kidx[op[1]]
                A.append((0, eq[i][class_of[i][enc(op[2])]]))
            elif kind == "put":
                i = kidx[op[1]]
                A.append((1, i, class_of[i][op[2]]))
            elif kind == "del":
                i = kidx[op[1]]
                A.append((1, i, class_of[i][ABS]))
            elif kind == "cas":
                i = kidx[op[1]]
                old = enc(op[2])
                if bool(op[4]):
                    A.append((0, eq[i][class_of[i][old]]))
                    A.append((1, i, class_of[i][enc(op[3])]))
                elif old in vals[i]:
                    A.append((0, neq[i][class_of[i][old]]))
                # else: inequality is always true
            else:  # scan
                A.append((0, build_scan_mask(op[1], op[2], op[3])))
        acts.append(A)

    def image(A, R):
        for a in A:
            if a[0] == 0:
                R &= a[1]
            else:
                i = a[1]
                d = a[2]
                res = 0
                for e, sh in set_plan[i][d]:
                    if sh == 0:
                        res |= R & e
                    elif sh > 0:
                        res |= (R & e) << sh
                    else:
                        res |= (R & e) >> (-sh)
                R = res
            if not R:
                return 0
        return R

    def preimage(A, P):
        for a in reversed(A):
            if a[0] == 0:
                P &= a[1]
            else:
                i = a[1]
                d = a[2]
                # forward the digit was set to d: post-states have digit d,
                # pre-states could have had any digit there.
                P &= eq[i][d]
                if not P:
                    return 0
                stride = strides[i]
                r = len(class_lists[i])
                collapsed = 0
                for d2 in range(r):
                    collapsed |= (P & eq[i][d2]) >> (d2 * stride)
                P = 0
                for d2 in range(r):
                    P |= collapsed << (d2 * stride)
            if not P:
                return 0
        return P

    # ----------------------------------------------------------- intervals
    pred = [0] * n
    succ = [0] * n
    for a in range(n):
        for b in range(n):
            if a != b and txs[a]["end"] <= txs[b]["start"]:
                pred[b] |= 1 << a
                succ[a] |= 1 << b

    # ------------------------------------------------------------------ DP
    full = (1 << n) - 1
    reach = [0] * (1 << n)
    init_index = 0
    for i, k in enumerate(keys):
        init_index += class_of[i][enc(initial.get(k))] * strides[i]
    final_index = 0
    for i, k in enumerate(keys):
        final_index += class_of[i][enc(final.get(k))] * strides[i]
    reach[0] = 1 << init_index
    for mask in range(1 << n):
        R = reach[mask]
        if not R:
            continue
        rem = full ^ mask
        for t in range(n):
            bit = 1 << t
            if mask & bit:
                continue
            if pred[t] & rem:
                continue
            res = image(acts[t], R)
            if res:
                reach[mask | bit] |= res

    target = 1 << final_index
    if not (reach[full] & target):
        return {"order": None}

    # ----------------------------------------------------- reconstruct order
    mask = full
    order_rev = []
    while mask:
        placed = False
        for t in range(n):
            bit = 1 << t
            if not (mask & bit):
                continue
            if succ[t] & mask:
                continue
            if pred[t] & ~mask:
                continue
            P = preimage(acts[t], target)
            if P:
                inter = P & reach[mask ^ bit]
                if inter:
                    lsb = inter & -inter
                    pre_index = lsb.bit_length() - 1
                    order_rev.append(t)
                    target = 1 << pre_index
                    mask ^= bit
                    placed = True
                    break
        if not placed:
            return {"order": None}

    return {"order": [txs[t]["id"] for t in reversed(order_rev)]}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        try:
            resp = solve(req)
        except Exception as exc:  # defensive: never lose a response line
            sys.stderr.write("solve failed: %r\n" % (exc,))
            resp = {"order": None}
        out.write(json.dumps(resp))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
