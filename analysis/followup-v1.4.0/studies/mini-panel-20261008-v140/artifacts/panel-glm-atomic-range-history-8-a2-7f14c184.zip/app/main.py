#!/usr/bin/env python3
"""Linearizability checker for atomic range transactions.

A whole transaction is one atomic operation.  We must decide whether the
completed history admits a serial order ("witness") such that

  * every transaction appears exactly once,
  * real time is respected (A.end <= B.start  =>  A before B),
  * replaying the transactions from `initial` matches every observed return
    value and ends exactly at `final`.

Method: depth first search over the set of still unplaced transactions.  A
candidate B may be appended only if it is not forced to precede an already
placed transaction, i.e. B.end > max(start of placed).  Sound necessary
conditions prune the tree and failures are memoised on
(remaining set, canonical state), which bounds the work by the number of
reachable (set, state) pairs.

Details worth noting:
 * a CAS that is expected to fail never writes (a successful one would
   contradict the expected return value), and its comparison value only
   matters if that value can ever be observed for the key;
 * a CAS whose new value is null deletes the key.

Pruning rules (all of them necessary conditions of any witness, hence sound):
 1. per key: the last remaining writer of a key must be able to produce the
    final value of that key and must still be placeable (after the already
    placed transactions and after the remaining transactions that are bound
    to write the key); if nothing can write the key any more, its current
    value must already be the final one.
 2. every remaining transaction must still be able to observe what it
    expects: either the value is current, or somebody that can still be
    placed before it can write it (for a CAS expected to fail: somebody can
    write something else).
 3. memoisation: the exact value of a key is dropped from the memo key when
    no remaining transaction can tell the difference - either nobody
    observes it and it is bound to be overwritten, or its current value is
    not one of the values a remaining transaction observes (nor the final
    value it has to reach).
"""

import sys
import json

# A key that is absent is different from a key holding zero (or null).
ABSENT = object()
# Memoisation sentinels for values that cannot matter any more.
ANY = object()      # bound to be overwritten, and nobody observes it
OTHER = object()    # not a value any remaining transaction can observe
NEG = -(1 << 62)


def solve(req):
    initial = req.get("initial") or {}
    final = req.get("final") or {}
    txns = req.get("transactions") or []
    n = len(txns)

    ids = [t["id"] for t in txns]
    starts = [t["start"] for t in txns]
    ends = [t["end"] for t in txns]
    raw = [t.get("ops") or [] for t in txns]

    # ------------------------------------------------------------------ keys
    keyset = set(initial)
    keyset |= set(final)
    for ops in raw:
        for op in ops:
            kind = op[0]
            if kind == "scan":
                keyset.add(op[1])
                keyset.add(op[2])
                for pair in op[3]:
                    keyset.add(pair[0])
            else:
                keyset.add(op[1])
    universe = sorted(keyset)
    K = len(universe)
    kidx = {k: i for i, k in enumerate(universe)}
    init_state = tuple(initial[k] if k in initial else ABSENT for k in universe)
    final_state = tuple(final[k] if k in final else ABSENT for k in universe)
    init_obs = tuple(None if v is ABSENT else v for v in init_state)

    # ------------------------------------------------------ normalised ops
    norm = []
    for i in range(n):
        lst = []
        for op in raw[i]:
            kind = op[0]
            if kind == "get":
                lst.append(("g", kidx[op[1]], op[2]))
            elif kind == "put":
                lst.append(("p", kidx[op[1]], op[2]))
            elif kind == "del":
                lst.append(("d", kidx[op[1]]))
            elif kind == "cas":
                if op[4] is not True and op[4] is not False:
                    return None          # observed success is not a boolean
                lst.append(("c", kidx[op[1]], op[2], op[3], op[4]))
            elif kind == "scan":
                lo, hi = op[1], op[2]
                kis = tuple(j for j, k in enumerate(universe) if lo <= k < hi)
                exp = tuple((kidx[p[0]], p[1]) for p in op[3])
                lst.append(("s", kis, exp))
        norm.append(tuple(lst))

    # --------------------------------------------- static per-key facts
    # readers[k]  : transactions whose outcome depends on the value of k when
    #               they run (first access to k is an effective observation)
    # setters[k]  : transactions that overwrite k without observing its value
    #               (put/del, or a CAS expected to succeed on a key the same
    #               transaction has already determined itself)
    # bound[k]    : transactions that are bound to write k in any valid
    #               execution (put, or CAS expected to succeed)
    # writers[k]  : transactions that may write k (put / del / successful cas)
    # writable[k] : observed value -> mask of transactions that may write it
    # cand[k]     : transactions that may write the final value of k
    readers = [0] * K
    setters = [0] * K
    bound = [0] * K
    writers = [0] * K
    writable = [{} for _ in range(K)]
    cand = [0] * K
    # per transaction: (key index, expected observed value, positive?)
    #   positive : the value observed when the transaction runs must equal it
    #   negative : the value observed must differ from it (CAS expected to fail)
    rcons = []

    for i in range(n):
        bit = 1 << i
        rc = []
        written = set()
        for op in norm[i]:
            kind = op[0]
            if kind == "g":
                ki = op[1]
                if ki not in written:
                    rc.append((ki, op[2], True))
            elif kind == "p":
                ki, v = op[1], op[2]
                setters[ki] |= bit
                bound[ki] |= bit
                writers[ki] |= bit
                d = writable[ki]
                d[v] = d.get(v, 0) | bit
                if v == final_state[ki]:
                    cand[ki] |= bit
                written.add(ki)
            elif kind == "d":
                ki = op[1]
                setters[ki] |= bit
                writers[ki] |= bit
                d = writable[ki]
                d[None] = d.get(None, 0) | bit
                if final_state[ki] is ABSENT:
                    cand[ki] |= bit
                written.add(ki)
            elif kind == "c":
                ki, old, new, want = op[1], op[2], op[3], op[4]
                if want:
                    writers[ki] |= bit
                    bound[ki] |= bit     # a CAS expected to succeed writes
                    d = writable[ki]
                    obs = None if new is None else new
                    d[obs] = d.get(obs, 0) | bit
                    if (ABSENT if new is None else new) == final_state[ki]:
                        cand[ki] |= bit
                    if ki in written:
                        # the key is already self-determined here, so this
                        # CAS writes it without observing the earlier value
                        setters[ki] |= bit
                if ki not in written:
                    rc.append((ki, old, want))
                if want:
                    # it succeeds in every valid execution, so the key is
                    # self-determined from here on; a CAS expected to fail
                    # writes nothing, so the key still reflects the state
                    written.add(ki)
            else:  # scan
                emap = {}
                for (j, v) in op[2]:
                    emap[j] = v
                for j in op[1]:
                    if j not in written:
                        rc.append((j, emap.get(j), True))
        rcons.append(rc)

    # A CAS that is expected to fail only depends on the key if the value it
    # compares against can ever be observed; otherwise the constraint is void.
    possible = [set(d) for d in writable]
    for ki in range(K):
        possible[ki].add(init_obs[ki])
    for i in range(n):
        rc = []
        for (ki, e, positive) in rcons[i]:
            if not positive and e not in possible[ki]:
                continue
            readers[ki] |= 1 << i
            rc.append((ki, e, positive))
        rcons[i] = rc

    # Reads of one key before any write of that key inside one transaction all
    # observe the same value: the expectations must be consistent.
    for rc in rcons:
        pos = {}
        neg = set()
        for ki, e, positive in rc:
            if positive:
                if ki in pos:
                    if pos[ki] != e:
                        return None
                else:
                    pos[ki] = e
            else:
                neg.add((ki, e))
        for ki, e in neg:
            if ki in pos and pos[ki] == e:
                return None

    # Values that a remaining transaction can tell apart (it observes them
    # before its own first write of that key).
    dist = [{} for _ in range(K)]
    for i in range(n):
        for (ki, e, positive) in rcons[i]:
            d = dist[ki]
            d[e] = d.get(e, 0) | (1 << i)

    # feasibility masks -------------------------------------------------
    # feas[(k, v, i)] : transactions that may make i observe v on k and that
    #                   may still be placed before i
    # negm[(k, v, i)] : transactions that may make i observe something != v
    #                   and that may still be placed before i
    vals_by_w = [[set() for _ in range(n)] for _ in range(K)]
    for ki in range(K):
        for v, m in writable[ki].items():
            mm = m
            while mm:
                b = mm & -mm
                w = b.bit_length() - 1
                mm ^= b
                vals_by_w[ki][w].add(v)
    feas = {}
    negm = {}
    for i in range(n):
        for (ki, e, positive) in rcons[i]:
            if positive:
                m = writable[ki].get(e, 0) & ~(1 << i)
                res = 0
                mm = m
                while mm:
                    b = mm & -mm
                    w = b.bit_length() - 1
                    mm ^= b
                    if ends[i] > starts[w]:
                        res |= b
                feas[(ki, e, i)] = res
            else:
                allm = writers[ki] & ~(1 << i)
                neg = 0
                mm = allm
                while mm:
                    b = mm & -mm
                    w = b.bit_length() - 1
                    mm ^= b
                    if ends[i] > starts[w] and any(v != e for v in vals_by_w[ki][w]):
                        neg |= b
                negm[(ki, e, i)] = neg

    full = (1 << n) - 1

    # max start among already placed transactions (= complement of R)
    msc = {}

    def get_ms(R):
        v = msc.get(R)
        if v is None:
            m = NEG
            mm = full & ~R
            while mm:
                b = mm & -mm
                i = b.bit_length() - 1
                mm ^= b
                if starts[i] > m:
                    m = starts[i]
            msc[R] = m
            v = m
        return v

    # Per key: can the final value of the key still be produced?
    #   0 -> impossible, 1 -> requires state[k] == final[k], 3 -> always fine
    fokc = [dict() for _ in range(K)]

    def fok(ki, R):
        c = fokc[ki].get(R)
        if c is not None:
            return c
        W = writers[ki] & R
        if W == 0:
            c = 1
        else:
            M = bound[ki] & R
            C = cand[ki] & R
            msr = get_ms(R)
            ok = 0
            mm = C
            while mm:
                b = mm & -mm
                i = b.bit_length() - 1
                mm ^= b
                if ends[i] > msr:
                    good = 1
                    if M:
                        mm2 = M & ~b
                        while mm2:
                            b2 = mm2 & -mm2
                            w = b2.bit_length() - 1
                            mm2 ^= b2
                            if ends[i] <= starts[w]:
                                good = 0
                                break
                    if good:
                        ok = 1
                        break
            if M:
                c = 3 if ok else 0
            else:
                c = 3 if ok else 1
        fokc[ki][R] = c
        return c

    def exec_txn(ops, st):
        s = list(st)
        for op in ops:
            kind = op[0]
            if kind == "g":
                v = s[op[1]]
                if v is ABSENT:
                    v = None
                if v != op[2]:
                    return None
            elif kind == "p":
                s[op[1]] = op[2]
            elif kind == "d":
                s[op[1]] = ABSENT
            elif kind == "c":
                ki = op[1]
                v = s[ki]
                if v is ABSENT:
                    v = None
                if v == op[2]:
                    s[ki] = ABSENT if op[3] is None else op[3]
                    if op[4] is not True:
                        return None
                else:
                    if op[4] is not False:
                        return None
            else:  # scan
                got = tuple((j, s[j]) for j in op[1] if s[j] is not ABSENT)
                if got != op[2]:
                    return None
        return tuple(s)

    # try transactions that start earlier first
    cand_order = sorted(range(n), key=lambda i: (starts[i], ends[i], i))

    fail = set()
    rev = []

    def dfs(R, st, ms):
        if R == 0:
            return st == final_state

        # --- final-map reachability per key -----------------------------
        for ki in range(K):
            c = fok(ki, R)
            if c == 0:
                return False
            if c == 1 and st[ki] != final_state[ki]:
                return False

        # --- observations of the remaining transactions ------------------
        obs = tuple(None if v is ABSENT else v for v in st)
        mm = R
        while mm:
            b = mm & -mm
            i = b.bit_length() - 1
            mm ^= b
            for (ki, e, positive) in rcons[i]:
                if positive:
                    if obs[ki] != e and not (feas[(ki, e, i)] & R):
                        return False
                else:
                    if obs[ki] == e and not (negm[(ki, e, i)] & R):
                        return False

        # --- memoise on (remaining set, canonical state) ------------------
        # A key is canonised away when no remaining transaction can tell the
        # difference: either nobody observes it and it is bound to be
        # overwritten, or its current value is not one of the values some
        # remaining transaction observes (nor the final value it must reach).
        lst = list(st)
        for ki in range(K):
            if readers[ki] & R:
                v = lst[ki]
                if v != final_state[ki]:
                    ov = None if v is ABSENT else v
                    if not (dist[ki].get(ov, 0) & R):
                        lst[ki] = OTHER
            elif setters[ki] & R:
                lst[ki] = ANY
            # else: forced to equal final[k] by the pruning above
        key = (R, tuple(lst))
        if key in fail:
            return False

        for i in cand_order:
            if (R >> i) & 1 and ends[i] > ms:
                ns = exec_txn(norm[i], st)
                if ns is not None:
                    nms = starts[i] if starts[i] > ms else ms
                    if dfs(R & ~(1 << i), ns, nms):
                        rev.append(i)
                        return True
        fail.add(key)
        return False

    if dfs(full, init_state, NEG):
        return [ids[i] for i in reversed(rev)]
    return None


def main():
    out = []
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.append(json.dumps({"order": solve(json.loads(line))}))
    sys.stdout.write("\n".join(out) + ("\n" if out else ""))


if __name__ == "__main__":
    main()
