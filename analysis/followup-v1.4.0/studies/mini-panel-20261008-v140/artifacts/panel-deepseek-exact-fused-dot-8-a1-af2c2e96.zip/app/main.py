#!/usr/bin/env python3
"""Bit-exact fused dot product for a parameterized binary floating-point format.

Reads newline-delimited JSON requests from stdin and writes one JSON response
per line to stdout.  All products are formed and summed exactly (as integers
scaled by a power of two); only the final sum is rounded to the target format.
"""
import json
import sys


def decode(v, ebits, fbits, Eall, F, mask_f):
    """Return (sign, kind, snan, A).

    kind: 0 finite, 1 NaN, 2 infinity.  For finite values, A is an integer such
    that value = (-1)**sign * A * 2**(emin-fbits); A == 0 denotes a signed zero.
    snan is 1 for a signaling NaN, else 0.
    """
    s = (v >> (ebits + fbits)) & 1
    e = (v >> fbits) & Eall
    f = v & mask_f
    if e == Eall:
        if f == 0:
            return (s, 2, 0, 0)
        # top fraction bit set => quiet, clear => signaling
        return (s, 1, 0 if ((f >> (fbits - 1)) & 1) else 1, 0)
    if e == 0:
        A = f
    else:
        A = (F + f) << (e - 1)
    return (s, 0, 0, A)


def solve(req):
    ebits = req["ebits"]
    fbits = req["fbits"]
    mode = req["mode"]
    pairs = req["pairs"]

    Eall = (1 << ebits) - 1
    bias = (1 << (ebits - 1)) - 1
    F = 1 << fbits
    mask_f = F - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    unit = emin - fbits          # exponent of one unit of the scaled integers
    unit2 = unit + unit          # every finite product is a multiple of 2**unit2

    any_nan = False
    any_snan = False
    any_inf = False
    pos_inf = False
    neg_inf = False
    invalid = False
    total = 0                    # exact sum = total * 2**unit2
    # A zero result is negative iff every product is a negative signed zero
    # (and there is at least one product), or the mode is RDN.
    all_neg_zero = bool(pairs)

    for pa, pb in pairs:
        sa, ka, na, A = decode(int(pa, 16), ebits, fbits, Eall, F, mask_f)
        sb, kb, nb, B = decode(int(pb, 16), ebits, fbits, Eall, F, mask_f)

        if ka == 1 or kb == 1:
            # A pair with a NaN operand contributes no product at all.
            any_nan = True
            if na or nb:
                any_snan = True
            all_neg_zero = False
            continue

        if ka == 2 or kb == 2:
            if (ka == 2 and kb == 0 and B == 0) or (kb == 2 and ka == 0 and A == 0):
                # zero times infinity (either order)
                invalid = True
                all_neg_zero = False
                continue
            any_inf = True
            if sa ^ sb:
                neg_inf = True
            else:
                pos_inf = True
            all_neg_zero = False
            continue

        # Both operands finite.
        prod = A * B
        sp = sa ^ sb
        if prod == 0:
            if sp == 0:
                all_neg_zero = False
        else:
            all_neg_zero = False
            total += -prod if sp else prod

    if any_snan:
        invalid = True
    if pos_inf and neg_inf:
        invalid = True

    if any_nan or invalid:
        # canonical NaN: sign 0, exponent all ones, only top fraction bit set
        bits = (Eall << fbits) | (1 << (fbits - 1))
        return {"bits": format(bits, "x"), "flags": ["invalid"] if invalid else []}

    if any_inf:
        sign = 1 if neg_inf else 0
        bits = (sign << (ebits + fbits)) | (Eall << fbits)
        return {"bits": format(bits, "x"), "flags": []}

    # ---- finite case -----------------------------------------------------
    if total == 0:
        neg = all_neg_zero or mode == "RDN"
        bits = (1 << (ebits + fbits)) if neg else 0
        return {"bits": format(bits, "x"), "flags": []}

    sign = 1 if total < 0 else 0
    mag = -total if total < 0 else total

    # L = floor(log2(exact magnitude)); quantum exponent
    L = mag.bit_length() - 1 + unit2
    qexp = (emin if emin > L else L) - fbits
    d = qexp - unit2

    if d > 0:
        n = mag >> d
        rem = mag - (n << d)
        if rem:
            half = 1 << (d - 1)
            if mode == "RNE":
                if rem > half or (rem == half and (n & 1)):
                    n += 1
            elif mode == "RNA":
                if rem >= half:
                    n += 1
            elif mode == "RUP":
                if sign == 0:
                    n += 1
            elif mode == "RDN":
                if sign == 1:
                    n += 1
            # RTZ: truncate
        inexact = rem != 0
    else:
        n = mag << (-d)
        inexact = False

    if n == 0:
        # nonzero exact value rounded to zero: keeps its exact sign, tininess
        bits = sign << (ebits + fbits)
        return {"bits": format(bits, "x"), "flags": ["underflow", "inexact"]}

    Ly = n.bit_length() - 1 + qexp          # floor(log2(rounded magnitude))

    if Ly > emax:
        # overflow: result depends on mode and sign
        if (mode == "RNE" or mode == "RNA"
                or (mode == "RUP" and sign == 0)
                or (mode == "RDN" and sign == 1)):
            bits = (sign << (ebits + fbits)) | (Eall << fbits)
        else:
            bits = (sign << (ebits + fbits)) | ((Eall - 1) << fbits) | mask_f
        return {"bits": format(bits, "x"), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        flags.append("inexact")
    if Ly < emin:
        # tininess after rounding
        if inexact:
            flags.append("underflow")
        e_res = 0
        f_res = n
    else:
        nbits = n.bit_length()
        shift = fbits - (nbits - 1)
        if shift >= 0:
            sig = n << shift
        else:
            sig = n >> (-shift)
        f_res = sig - F
        e_res = Ly + bias

    bits = (sign << (ebits + fbits)) | (e_res << fbits) | f_res
    return {"bits": format(bits, "x"), "flags": flags}


def main():
    # A dedicated writer thread keeps the main thread from ever blocking on a
    # full stdout pipe (so batch harnesses cannot deadlock), while still
    # flushing every response promptly for interactive harnesses.
    import queue
    import threading

    out = sys.stdout
    q = queue.Queue()
    sentinel = object()

    def writer():
        while True:
            item = q.get()
            if item is sentinel:
                break
            out.write(item)
            out.flush()

    t = threading.Thread(target=writer, daemon=True)
    t.start()
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        q.put(json.dumps(solve(req), separators=(",", ":")) + "\n")
    q.put(sentinel)
    t.join()


if __name__ == "__main__":
    main()
