"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin and writes one JSON response
per request line to stdout.  See instruction.md for the format contract.
"""
import json
import sys
import zlib

HDR = 13                 # payload_len:u32 | seq:u32 | kind:u8 | txid:u32
MAX_PAYLOAD = 4096
BEGIN, PATCH, COMMIT, ABORT = 1, 2, 3, 4


def _from_hex(s):
    try:
        return bytes.fromhex(s)
    except (ValueError, TypeError):
        return b''


def solve(req):
    pages = req['pages']
    checkpoint = req['checkpoint']
    log = _from_hex(req['log'])

    out = [bytearray(_from_hex(p)) for p in pages]
    npages = len(out)
    plens = [len(p) for p in out]

    active = {}          # txid -> {'patches': [(page, off, cnt, data)], 'concat': bytes}
    prev_seq = 0
    last_seq = 0
    off = 0
    n = len(log)

    while off + HDR <= n:
        payload_len = int.from_bytes(log[off:off + 4], 'little')
        seq = int.from_bytes(log[off + 4:off + 8], 'little')
        kind = log[off + 8]
        txid = int.from_bytes(log[off + 9:off + 13], 'little')

        end = off + HDR + payload_len + 4
        # structural: bounded payload length and a complete record present
        if payload_len > MAX_PAYLOAD or end > n:
            break

        payload = log[off + HDR:off + HDR + payload_len]
        crc = int.from_bytes(log[end - 4:end], 'little')
        if zlib.crc32(log[off:off + HDR] + payload) & 0xffffffff != crc:
            break
        if seq <= 0 or seq <= prev_seq or txid <= 0:
            break

        # payload shape and bounds (checked before any semantic effect)
        page = boff = cnt = 0
        if kind == BEGIN or kind == ABORT:
            if payload_len != 0:
                break
        elif kind == PATCH:
            if payload_len < 6:
                break
            page = int.from_bytes(payload[0:2], 'little')
            boff = int.from_bytes(payload[2:4], 'little')
            cnt = int.from_bytes(payload[4:6], 'little')
            if cnt == 0 or payload_len != 6 + cnt:
                break
            if page >= npages or boff + cnt > plens[page]:
                break
        elif kind == COMMIT:
            if payload_len != 8:
                break
        else:
            break

        # semantics
        if kind == BEGIN:
            active[txid] = {'patches': [], 'concat': bytearray()}
        elif kind == PATCH:
            st = active.get(txid)
            if st is not None:
                st['patches'].append((page, boff, cnt, payload[6:6 + cnt]))
                st['concat'] += payload
        elif kind == ABORT:
            active.pop(txid, None)
        else:                                  # COMMIT
            st = active.pop(txid, None)
            if st is not None:
                count = int.from_bytes(payload[0:4], 'little')
                digest = int.from_bytes(payload[4:8], 'little')
                if (count == len(st['patches'])
                        and digest == (zlib.crc32(bytes(st['concat'])) & 0xffffffff)
                        and seq > checkpoint):
                    for p, o, c, data in st['patches']:
                        out[p][o:o + c] = data

        prev_seq = seq
        last_seq = seq
        off = end

    return {
        'pages': [bytes(p).hex() for p in out],
        'valid_bytes': off,
        'last_seq': last_seq,
    }


def main():
    for line in sys.stdin:
        if not line.strip():
            continue
        print(json.dumps(solve(json.loads(line))))


if __name__ == '__main__':
    main()
