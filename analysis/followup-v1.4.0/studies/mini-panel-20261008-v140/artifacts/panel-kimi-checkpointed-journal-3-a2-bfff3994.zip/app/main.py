"""Deterministic recovery of a checkpointed transactional byte journal.

Record layout (all integers unsigned, little-endian):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32

Only the structurally valid prefix of the log is replayed.  A structurally
valid COMMIT applies its staged patches atomically iff the seal (patch count
and digest) matches and its sequence is greater than the checkpoint.
"""

import json
import sys
import zlib

HEADER_LEN = 13          # payload_length(4) + sequence(4) + kind(1) + txid(4)
CRC_LEN = 4
MAX_PAYLOAD = 4096
MASK32 = 0xFFFFFFFF

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request["pages"]]
    checkpoint = request["checkpoint"]
    log = bytes.fromhex(request["log"])
    n = len(log)

    pos = 0
    prev_seq = 0
    valid_bytes = 0
    last_seq = 0
    active = {}  # txid -> list of staged PATCH payloads (bytes) for the open incarnation

    while pos + HEADER_LEN <= n:
        payload_length = int.from_bytes(log[pos:pos + 4], "little")
        sequence = int.from_bytes(log[pos + 4:pos + 8], "little")
        kind = log[pos + 8]
        txid = int.from_bytes(log[pos + 9:pos + 13], "little")

        # Header-level structural checks.
        if payload_length > MAX_PAYLOAD:
            break
        if kind < KIND_BEGIN or kind > KIND_ABORT:
            break
        if txid == 0:
            break
        if sequence <= prev_seq:  # must be positive and strictly increasing
            break

        payload_start = pos + HEADER_LEN
        payload_end = payload_start + payload_length
        record_end = payload_end + CRC_LEN
        if record_end > n:
            break  # incomplete / torn record

        payload = log[payload_start:payload_end]
        crc_stored = int.from_bytes(log[payload_end:record_end], "little")
        if (zlib.crc32(log[pos:payload_end]) & MASK32) != crc_stored:
            break  # invalid CRC

        # Kind-specific payload shape / bounds checks.
        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_length != 0:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            byte_count = int.from_bytes(payload[4:6], "little")
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            page_index = int.from_bytes(payload[0:2], "little")
            byte_offset = int.from_bytes(payload[2:4], "little")
            if page_index >= len(pages):
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break
        else:  # KIND_COMMIT
            if payload_length != 8:
                break

        # The record is structurally valid: advance the prefix.
        prev_seq = sequence
        valid_bytes = record_end
        last_seq = sequence
        pos = record_end

        # Semantics.
        if kind == KIND_BEGIN:
            active[txid] = []  # fresh incarnation, discarding any unfinished one
        elif kind == KIND_PATCH:
            incarnation = active.get(txid)
            if incarnation is not None:
                incarnation.append(payload)
        elif kind == KIND_ABORT:
            active.pop(txid, None)
        else:  # KIND_COMMIT: always closes the active incarnation, if any
            incarnation = active.pop(txid, None)
            if incarnation is not None and sequence > checkpoint:
                patch_count = int.from_bytes(payload[0:4], "little")
                digest = int.from_bytes(payload[4:8], "little")
                if (patch_count == len(incarnation)
                        and (zlib.crc32(b"".join(incarnation)) & MASK32) == digest):
                    for p in incarnation:
                        pi = int.from_bytes(p[0:2], "little")
                        off = int.from_bytes(p[2:4], "little")
                        cnt = int.from_bytes(p[4:6], "little")
                        pages[pi][off:off + cnt] = p[6:6 + cnt]

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))) + "\n")
    out.flush()


if __name__ == "__main__":
    main()
