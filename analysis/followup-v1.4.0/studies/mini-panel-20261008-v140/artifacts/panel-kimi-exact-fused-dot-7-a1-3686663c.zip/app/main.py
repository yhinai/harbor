import sys
import json


def solve(request):
    ebits = request["ebits"]
    fbits = request["fbits"]
    mode = request["mode"]
    pairs = request["pairs"]

    w = 1 + ebits + fbits
    bias = (1 << (ebits - 1)) - 1
    Eall = (1 << ebits) - 1
    F = 1 << fbits
    fmask = F - 1
    emin = 1 - bias
    emax = Eall - 1 - bias
    sign_bit = 1 << (ebits + fbits)
    hexd = (w + 3) // 4

    def enc(bits):
        return format(bits, "0{}x".format(hexd))

    canon_nan = (Eall << fbits) | (1 << (fbits - 1))

    def decode(v):
        s = 1 if (v & sign_bit) else 0
        e = (v >> fbits) & Eall
        f = v & fmask
        if e == Eall:
            if f == 0:
                return (2, s)          # infinity
            if f >> (fbits - 1):
                return (3, s)          # quiet NaN
            return (4, s)              # signaling NaN
        if e == 0:
            if f == 0:
                return (0, s)          # zero
            return (1, s, f, 1 - bias - fbits)   # subnormal
        return (1, s, F + f, e - bias - fbits)   # normal

    any_nan = False
    invalid = False
    inf_signs = 0          # bit0: positive infinite product seen, bit1: negative
    zero_prods_all_neg = True
    n_zero_prods = 0
    terms = []             # (sign, mantissa>0, exponent) of nonzero finite products

    for ah, bh in pairs:
        a = decode(int(ah, 16))
        b = decode(int(bh, 16))
        ka, kb = a[0], b[0]
        if ka >= 3 or kb >= 3:           # some NaN operand
            if ka >= 3:
                any_nan = True
                if ka == 4:
                    invalid = True
            if kb >= 3:
                any_nan = True
                if kb == 4:
                    invalid = True
            continue
        if ka == 2 or kb == 2:           # some infinity operand (no NaN)
            if ka == 0 or kb == 0:       # zero * infinity
                invalid = True
                continue
            inf_signs |= 1 << (a[1] ^ b[1])
            continue
        s = a[1] ^ b[1]
        if ka == 0 or kb == 0:           # zero product
            n_zero_prods += 1
            if s:
                pass
            else:
                zero_prods_all_neg = False
        else:
            terms.append((s, a[2] * b[2], a[3] + b[3]))

    if inf_signs == 3:                   # both +inf and -inf products
        invalid = True

    if invalid or any_nan:
        return {"bits": enc(canon_nan),
                "flags": ["invalid"] if invalid else []}

    if inf_signs:
        s = 1 if inf_signs == 2 else 0
        return {"bits": enc((s * sign_bit) | (Eall << fbits)), "flags": []}

    # ---- finite exact sum ----
    if not terms:
        neg = (mode == "RDN") or (n_zero_prods >= 1 and
                                  n_zero_prods == len(pairs) and
                                  zero_prods_all_neg)
        return {"bits": enc(sign_bit if neg else 0), "flags": []}

    E0 = terms[0][2]
    for t in terms:
        if t[2] < E0:
            E0 = t[2]
    S = 0
    for s, m, e in terms:
        v = m << (e - E0)
        S = S - v if s else S + v

    if S == 0:                           # cancellation -> exact zero
        return {"bits": enc(sign_bit if mode == "RDN" else 0), "flags": []}

    sign = 1 if S < 0 else 0
    A = -S if S < 0 else S
    L = A.bit_length() - 1 + E0          # floor(log2(x))
    q_exp = emin - fbits
    if L - fbits > q_exp:
        q_exp = L - fbits                # q = 2**q_exp
    sh = q_exp - E0                      # x / q = A / 2**sh

    if sh <= 0:
        n = A << (-sh)
        inexact = False
    else:
        n = A >> sh
        rem = A - (n << sh)
        inexact = bool(rem)
        if rem:
            inexact = True
            if mode == "RNE":
                half = 1 << (sh - 1)
                if rem > half or (rem == half and (n & 1)):
                    n += 1
            elif mode == "RNA":
                if rem >= (1 << (sh - 1)):
                    n += 1
            elif mode == "RUP":
                if sign == 0:
                    n += 1
            elif mode == "RDN":
                if sign == 1:
                    n += 1
            # RTZ: truncate

    Ly = n.bit_length() - 1 + q_exp if n else None

    if n and Ly >= emax + 1:             # overflow
        to_inf = (mode == "RNE" or mode == "RNA" or
                  (mode == "RUP" and sign == 0) or
                  (mode == "RDN" and sign == 1))
        if to_inf:
            bits = (sign * sign_bit) | (Eall << fbits)
        else:
            bits = (sign * sign_bit) | ((Eall - 1) << fbits) | fmask
        return {"bits": enc(bits), "flags": ["overflow", "inexact"]}

    flags = []
    if inexact:
        if n == 0 or Ly < emin:          # rounded magnitude below 2**emin
            flags.append("underflow")
        flags.append("inexact")

    if n == 0:
        bits = sign * sign_bit
    elif Ly < emin:                      # subnormal (q_exp == emin-fbits here)
        bits = (sign * sign_bit) | (n << (q_exp - (emin - fbits)))
    else:
        e_field = Ly + bias
        mant = n >> (Ly - fbits - q_exp)
        bits = (sign * sign_bit) | (e_field << fbits) | (mant - F)
    return {"bits": enc(bits), "flags": flags}


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        out.write(json.dumps(solve(json.loads(line))))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
