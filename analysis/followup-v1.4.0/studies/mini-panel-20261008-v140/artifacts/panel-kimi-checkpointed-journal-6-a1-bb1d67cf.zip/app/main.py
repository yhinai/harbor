"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin:
    {"pages": [hex, ...], "checkpoint": int, "log": hex}
Writes one JSON response per line:
    {"pages": [hex, ...], "valid_bytes": int, "last_seq": int}
"""

import json
import sys
import zlib

HEADER_LEN = 13          # payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32
CRC_LEN = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def _u16(b, i):
    return b[i] | (b[i + 1] << 8)


def _u32(b, i):
    return b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24)


def recover(page_hexes, checkpoint, log_hex):
    pages = [bytearray(bytes.fromhex(p)) for p in page_hexes]
    log = bytes.fromhex(log_hex) if log_hex else b""
    n = len(log)

    pos = 0
    last_seq = 0
    # transaction_id -> list of staged PATCH payload byte strings (this incarnation)
    active = {}

    while True:
        # --- structural validation of the next record ---
        if pos + HEADER_LEN > n:
            break  # incomplete header / torn record
        payload_length = _u32(log, pos)
        sequence = _u32(log, pos + 4)
        kind = log[pos + 8]
        tid = _u32(log, pos + 9)

        if payload_length > MAX_PAYLOAD:
            break  # invalid header
        end = pos + HEADER_LEN + payload_length + CRC_LEN
        if end > n:
            break  # incomplete record

        payload = log[pos + HEADER_LEN:pos + HEADER_LEN + payload_length]
        stored_crc = _u32(log, pos + HEADER_LEN + payload_length)
        if zlib.crc32(log[pos:end - CRC_LEN]) & 0xFFFFFFFF != stored_crc:
            break  # invalid CRC
        if sequence == 0 or sequence <= last_seq:
            break  # invalid sequence
        if tid == 0:
            break  # invalid transaction ID

        if kind == KIND_BEGIN or kind == KIND_ABORT:
            if payload_length != 0:
                break
        elif kind == KIND_COMMIT:
            if payload_length != 8:
                break
        elif kind == KIND_PATCH:
            if payload_length < 6:
                break
            byte_count = _u16(payload, 4)
            if byte_count == 0 or payload_length != 6 + byte_count:
                break
            page_index = _u16(payload, 0)
            byte_offset = _u16(payload, 2)
            if page_index >= len(pages):
                break
            if byte_offset + byte_count > len(pages[page_index]):
                break
        else:
            break  # invalid kind

        # --- record is structurally valid: extend the prefix ---
        pos = end
        last_seq = sequence

        # --- transactional semantics ---
        if kind == KIND_BEGIN:
            active[tid] = []  # fresh incarnation, discarding any unfinished one
        elif kind == KIND_ABORT:
            active.pop(tid, None)
        elif kind == KIND_PATCH:
            staged = active.get(tid)
            if staged is not None:
                staged.append(payload)
        else:  # KIND_COMMIT
            staged = active.pop(tid, None)
            if staged is None:
                continue  # orphan COMMIT: no effect
            want_count = _u32(payload, 0)
            want_digest = _u32(payload, 4)
            digest = 0
            for p in staged:
                digest = zlib.crc32(p, digest)
            digest &= 0xFFFFFFFF
            if want_count == len(staged) and want_digest == digest and sequence > checkpoint:
                for p in staged:
                    page_index = _u16(p, 0)
                    byte_offset = _u16(p, 2)
                    byte_count = _u16(p, 4)
                    pages[page_index][byte_offset:byte_offset + byte_count] = p[6:]

    return {
        "pages": [bytes(p).hex() for p in pages],
        "valid_bytes": pos,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        req = json.loads(line)
        out.write(json.dumps(recover(req["pages"], req["checkpoint"], req["log"])))
        out.write("\n")
    out.flush()


if __name__ == "__main__":
    main()
