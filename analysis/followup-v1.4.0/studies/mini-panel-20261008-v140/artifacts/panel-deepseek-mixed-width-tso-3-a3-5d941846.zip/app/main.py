"""Exhaustive outcome enumeration for a small TSO-like buffered machine.

Each thread has a FIFO store buffer.  Instructions execute in program order and
drains move the oldest buffered store of a thread to shared memory.  Loads read
each byte independently, forwarding from the youngest same-thread buffered store
covering that byte and otherwise reading shared memory.  xchg and fence are only
enabled when the issuing thread's buffer is empty.

The state of the machine is (program counters, buffers, memory).  Observations
do not influence any transition, so the set of possible observation suffixes
from a state depends only on that state.  We memoize that suffix set, which
keeps the search small while remaining exhaustive.
"""

import json
import sys


def solve(request):
    mem0 = tuple(request["memory"])
    threads = request["threads"]
    nthreads = len(threads)
    instrs = [tuple(tuple(ins) for ins in th) for th in threads]

    # Give every store instruction an index and precompute its byte writes.
    store_writes = []          # store id -> tuple of (address, byte)
    store_covers = []          # store id -> dict address -> byte
    store_id = {}              # (thread, pc) -> store id
    for t, th in enumerate(instrs):
        for pc, ins in enumerate(th):
            if ins[0] == "store":
                addr, width, value = ins[1], ins[2], ins[3]
                writes = tuple(
                    (addr + i, (value >> (8 * i)) & 0xFF) for i in range(width)
                )
                store_id[(t, pc)] = len(store_writes)
                store_writes.append(writes)
                store_covers.append(dict(writes))

    empty_reads = tuple(() for _ in range(nthreads))
    memo = {}

    def read_load(memory, buffer, addr, width):
        """Value of a load from ``memory`` with ``buffer`` forwarding."""
        value = 0
        for i in range(width):
            a = addr + i
            byte = None
            # Youngest buffered store covering this byte wins.
            for sid in reversed(buffer):
                b = store_covers[sid].get(a)
                if b is not None:
                    byte = b
                    break
            if byte is None:
                byte = memory[a]
            value |= byte << (8 * i)
        return value

    def explore(pcs, buffers, memory):
        key = (pcs, buffers, memory)
        cached = memo.get(key)
        if cached is not None:
            return cached

        # Terminal: every thread finished and every buffer empty.
        finished = True
        for t in range(nthreads):
            if pcs[t] != len(instrs[t]) or buffers[t]:
                finished = False
                break
        if finished:
            result = {(empty_reads, memory)}
            memo[key] = result
            return result

        result = set()

        # Option 1: execute the next instruction of a thread.
        for t in range(nthreads):
            pc = pcs[t]
            if pc >= len(instrs[t]):
                continue
            ins = instrs[t][pc]
            op = ins[0]
            new_pcs = pcs[:t] + (pc + 1,) + pcs[t + 1:]
            if op == "store":
                sid = store_id[(t, pc)]
                new_buffers = buffers[:t] + (buffers[t] + (sid,),) + buffers[t + 1:]
                result.update(explore(new_pcs, new_buffers, memory))
            elif op == "load":
                value = read_load(memory, buffers[t], ins[1], ins[2])
                for reads, mem in explore(new_pcs, buffers, memory):
                    new_reads = reads[:t] + ((value,) + reads[t],) + reads[t + 1:]
                    result.add((new_reads, mem))
            elif op == "fence":
                if not buffers[t]:
                    result.update(explore(new_pcs, buffers, memory))
            else:  # xchg
                if not buffers[t]:
                    addr, width, value = ins[1], ins[2], ins[3]
                    read_value = 0
                    for i in range(width):
                        read_value |= memory[addr + i] << (8 * i)
                    new_memory = list(memory)
                    for i in range(width):
                        new_memory[addr + i] = (value >> (8 * i)) & 0xFF
                    new_memory = tuple(new_memory)
                    for reads, mem in explore(new_pcs, buffers, new_memory):
                        new_reads = (
                            reads[:t] + ((read_value,) + reads[t],) + reads[t + 1:]
                        )
                        result.add((new_reads, mem))

        # Option 2: drain the oldest store of a nonempty buffer.
        for t in range(nthreads):
            buffer = buffers[t]
            if buffer:
                sid = buffer[0]
                new_memory = list(memory)
                for a, b in store_writes[sid]:
                    new_memory[a] = b
                new_buffers = buffers[:t] + (buffer[1:],) + buffers[t + 1:]
                result.update(explore(pcs, new_buffers, tuple(new_memory)))

        memo[key] = result
        return result

    start = (tuple(0 for _ in range(nthreads)), empty_reads, mem0)
    outcomes = explore(*start)
    return {
        "outcomes": [
            {"reads": [list(reads) for reads in reads_tuple], "memory": list(memory)}
            for reads_tuple, memory in outcomes
        ]
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request), separators=(",", ":")))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main()
