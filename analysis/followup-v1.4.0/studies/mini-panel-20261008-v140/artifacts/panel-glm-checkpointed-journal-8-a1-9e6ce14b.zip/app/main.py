#!/usr/bin/env python3
"""Deterministic recovery of a checkpointed transactional byte journal.

Journal record layout (all integers unsigned little-endian, no padding):

    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32

with ``crc = zlib.crc32(header + payload) & 0xffffffff`` and a 13 byte fixed
header.  Record kinds:

    1 BEGIN  empty payload
    2 PATCH  page_index:u16 | byte_offset:u16 | byte_count:u16 | data[count]
    3 COMMIT patch_count:u32 | digest:u32   (digest seals this incarnation's
                                             concatenated PATCH payloads)
    4 ABORT  empty payload

Recovery walks the log from the start and stops at the first structurally
invalid or torn record; everything from that record on is excluded from the
valid prefix.  Structurally valid records drive the transaction state machine,
and a COMMIT whose seal matches and whose sequence is newer than the checkpoint
atomically applies its incarnation's staged patches (in commit order).

Requests are newline-delimited JSON objects on stdin; exactly one JSON
response object is written per request line on stdout:

    {"pages": [...], "valid_bytes": int, "last_seq": int}
"""

import json
import struct
import sys
import zlib

HEADER = struct.Struct("<IIBI")     # payload_length, sequence, kind, transaction_id
PATCH_HEAD = struct.Struct("<HHH")   # page_index, byte_offset, byte_count
COMMIT_BODY = struct.Struct("<II")  # patch_count, digest

HEADER_SIZE = HEADER.size            # 13
CRC_SIZE = 4
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def recover(log, pages, checkpoint):
    """Replay the valid prefix of ``log`` onto ``pages`` (mutated in place).

    ``pages`` is a list of ``bytearray`` images.  Returns
    ``(valid_bytes, last_seq)``: the length in bytes of the structurally valid
    record prefix and the sequence number of its last record (0 if empty).
    """
    total = len(log)
    npages = len(pages)
    unpack_header = HEADER.unpack_from
    unpack_patch = PATCH_HEAD.unpack_from

    # Active incarnations: txid -> [running digest crc, [(page, offset, data)]]
    active = {}
    last_seq = 0
    off = 0

    while off + HEADER_SIZE <= total:
        plen, seq, kind, txid = unpack_header(log, off)

        # ---- header validation (any failure ends the valid prefix here) ----
        if plen > MAX_PAYLOAD or txid == 0 or seq <= last_seq or kind > 4 or kind < 1:
            break

        body_end = off + HEADER_SIZE + plen
        end = body_end + CRC_SIZE
        if end > total:
            break  # torn / truncated record

        payload = log[off + HEADER_SIZE:body_end]
        stored_crc = int.from_bytes(log[body_end:end], "little")
        # crc32(header) then crc32(payload, ...) == crc32(header + payload)
        if zlib.crc32(payload, zlib.crc32(log[off:off + HEADER_SIZE])) != stored_crc:
            break  # corrupted record

        # ---- payload shape validation, then the record's semantic effect ----
        if kind == KIND_BEGIN:
            if plen != 0:
                break
            # A fresh incarnation always discards an unfinished one.
            active[txid] = [0, []]

        elif kind == KIND_PATCH:
            if plen < PATCH_HEAD.size:
                break
            page_index, byte_offset, byte_count = unpack_patch(payload, 0)
            if byte_count == 0 or plen != PATCH_HEAD.size + byte_count:
                break
            if page_index >= npages or byte_offset + byte_count > len(pages[page_index]):
                break
            staged = active.get(txid)
            if staged is not None:  # patches for inactive ids are ignored
                staged[0] = zlib.crc32(payload, staged[0])
                staged[1].append((page_index, byte_offset, payload[PATCH_HEAD.size:]))

        elif kind == KIND_COMMIT:
            if plen != COMMIT_BODY.size:
                break
            patch_count, digest = COMMIT_BODY.unpack(payload)
            staged = active.pop(txid, None)  # orphan commits have no effect
            if (
                staged is not None
                and patch_count == len(staged[1])
                and staged[0] == digest
                and seq > checkpoint
            ):
                # Seal matches and the commit is newer than the checkpoint:
                # apply the incarnation's patches atomically, in patch order.
                for page_index, byte_offset, data in staged[1]:
                    page = pages[page_index]
                    stop = byte_offset + len(data)
                    if stop <= len(page):  # always true: validated when staged
                        page[byte_offset:stop] = data

        else:  # KIND_ABORT
            if plen != 0:
                break
            active.pop(txid, None)  # orphan aborts have no effect

        last_seq = seq
        off = end

    return off, last_seq


def solve(request):
    """Handle one request object and return the response object."""
    if not isinstance(request, dict):
        request = {}

    raw_pages = request.get("pages")
    if not isinstance(raw_pages, (list, tuple)):
        raw_pages = []
    pages = [bytearray(bytes.fromhex(p)) for p in raw_pages if isinstance(p, str)]

    checkpoint = request.get("checkpoint", 0)
    if isinstance(checkpoint, bool) or not isinstance(checkpoint, int):
        try:
            checkpoint = int(checkpoint)
        except (TypeError, ValueError):
            checkpoint = 0
    if checkpoint < 0:
        checkpoint = 0

    raw_log = request.get("log")
    if isinstance(raw_log, str):
        log = bytes.fromhex(raw_log)
    elif isinstance(raw_log, (bytes, bytearray)):
        log = bytes(raw_log)
    else:
        log = b""

    valid_bytes, last_seq = recover(log, pages, checkpoint)

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def fallback_response(request):
    """Best-effort response if an unexpected error occurs on one request."""
    pages = []
    if isinstance(request, dict):
        raw = request.get("pages")
        if isinstance(raw, (list, tuple)):
            pages = [p for p in raw if isinstance(p, str)]
    return {"pages": pages, "valid_bytes": 0, "last_seq": 0}


def main(stream, out):
    for line in stream:
        if not line.strip():
            continue  # tolerate stray blank lines
        try:
            response = solve(json.loads(line))
        except Exception as exc:  # pragma: no cover - defensive
            print("recovery error: %r" % (exc,), file=sys.stderr)
            response = fallback_response(json.loads(line))
        out.write(json.dumps(response))
        out.write("\n")
        out.flush()


if __name__ == "__main__":
    main(sys.stdin.buffer, sys.stdout)
