"""Deterministic recovery of a checkpointed transactional byte journal.

Record layout (all integers little-endian, no padding):
    payload_length:u32 | sequence:u32 | kind:u8 | transaction_id:u32 | payload | crc:u32
crc = zlib.crc32(header + payload) & 0xffffffff
"""
import json
import struct
import sys
import zlib

HEADER = struct.Struct('<IIBI')
U32 = struct.Struct('<I')
PATCH_HEAD = struct.Struct('<HHH')
COMMIT_BODY = struct.Struct('<II')
MAX_PAYLOAD = 4096

KIND_BEGIN = 1
KIND_PATCH = 2
KIND_COMMIT = 3
KIND_ABORT = 4


def solve(request):
    pages = [bytearray(bytes.fromhex(p)) for p in request['pages']]
    page_sizes = [len(p) for p in pages]
    log = bytes.fromhex(request['log'])
    checkpoint = request['checkpoint']

    n = len(log)
    # Active incarnations: transaction_id -> list of PATCH payload bytes.
    active = {}
    pos = 0
    last_seq = 0

    while pos + HEADER.size <= n:
        payload_len, seq, kind, tx_id = HEADER.unpack_from(log, pos)
        end = pos + HEADER.size + payload_len + U32.size

        # Structural validation. Any failure stops the replay; the record and
        # every following byte are excluded from the valid prefix.
        if payload_len > MAX_PAYLOAD:
            break                      # invalid header
        if end > n:
            break                      # incomplete (torn) record
        body_end = end - U32.size
        if U32.unpack_from(log, body_end)[0] != (zlib.crc32(
                memoryview(log)[pos:body_end]) & 0xffffffff):
            break                      # bad CRC
        if seq <= 0 or seq <= last_seq:
            break                      # invalid sequence watermark
        if tx_id <= 0:
            break                      # invalid transaction id

        payload = log[pos + HEADER.size:body_end]

        if kind == KIND_BEGIN:
            if payload_len != 0:
                break                  # invalid payload shape
            active[tx_id] = []
        elif kind == KIND_PATCH:
            if payload_len < PATCH_HEAD.size:
                break
            page_index, byte_offset, byte_count = PATCH_HEAD.unpack_from(payload, 0)
            if (byte_count <= 0 or payload_len != PATCH_HEAD.size + byte_count
                    or page_index >= len(pages)
                    or byte_offset + byte_count > page_sizes[page_index]):
                break                  # invalid payload shape / out of bounds
            staged = active.get(tx_id)
            if staged is not None:
                staged.append(payload)
        elif kind == KIND_COMMIT:
            if payload_len != COMMIT_BODY.size:
                break                  # invalid payload shape
            patch_count, digest = COMMIT_BODY.unpack_from(payload, 0)
            staged = active.pop(tx_id, None)
            if staged is not None:
                sealed = (patch_count == len(staged)
                          and digest == (zlib.crc32(b''.join(staged)) & 0xffffffff))
                if sealed and seq > checkpoint:
                    for patch_payload in staged:
                        page_index, byte_offset, byte_count = \
                            PATCH_HEAD.unpack_from(patch_payload, 0)
                        page = pages[page_index]
                        data = patch_payload[PATCH_HEAD.size:]
                        page[byte_offset:byte_offset + byte_count] = data
            # A seal mismatch or a commit at/below the checkpoint still closes
            # the incarnation; nothing is applied.
        elif kind == KIND_ABORT:
            if payload_len != 0:
                break                  # invalid payload shape
            active.pop(tx_id, None)
        else:
            break                      # unknown kind

        last_seq = seq
        pos = end

    return {
        'pages': [p.hex() for p in pages],
        'valid_bytes': pos,
        'last_seq': last_seq,
    }


def main():
    out = []
    for line in sys.stdin:
        if not line.strip():
            continue
        out.append(json.dumps(solve(json.loads(line))))
    sys.stdout.write('\n'.join(out) + ('\n' if out else ''))


if __name__ == '__main__':
    main()
