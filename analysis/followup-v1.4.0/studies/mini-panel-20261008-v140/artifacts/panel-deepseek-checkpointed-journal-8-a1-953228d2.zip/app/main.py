"""Deterministic recovery of a checkpointed transactional byte journal.

Reads newline-delimited JSON requests on stdin and writes one JSON response
per line on stdout.  See instruction.md / public_contract.py for the format.
"""

import json
import struct
import sys
import zlib

MAX_PAYLOAD = 4096          # payload_length upper bound (invalid header beyond)
FIXED_HEADER = 13           # payload_length:u32 | sequence:u32 | kind:u8 | txid:u32
CRC_SIZE = 4

BEGIN = 1
PATCH = 2
COMMIT = 3
ABORT = 4

_U32 = struct.Struct('<I')
_HDR = struct.Struct('<IIBI')
_PATCH_HDR = struct.Struct('<HHH')
_COMMIT = struct.Struct('<II')


def solve(request):
    pages = [bytearray(bytes.fromhex(h)) for h in request["pages"]]
    num_pages = len(pages)
    page_len = len(pages[0]) if num_pages else 0
    checkpoint = int(request["checkpoint"])
    data = bytes.fromhex(request["log"])
    total = len(data)

    pos = 0
    valid_bytes = 0
    last_seq = 0
    active = {}                 # txid -> list of (page_index, offset, data)

    while True:
        # A complete record needs the fixed header, the payload and the CRC.
        if pos + FIXED_HEADER > total:
            break
        payload_len, seq, kind, txid = _HDR.unpack_from(data, pos)
        if payload_len > MAX_PAYLOAD:
            break                       # invalid header
        end = pos + FIXED_HEADER + payload_len
        if end + CRC_SIZE > total:
            break                       # incomplete record
        header = data[pos:pos + FIXED_HEADER]
        payload = data[pos + FIXED_HEADER:end]
        crc = _U32.unpack_from(data, end)[0]
        if (zlib.crc32(header + payload) & 0xFFFFFFFF) != crc:
            break                       # invalid CRC
        if seq == 0 or seq <= last_seq:
            break                       # invalid sequence
        if kind < BEGIN or kind > ABORT or txid == 0:
            break                       # invalid kind / transaction id

        # Structural payload validation (before any semantic effect).
        if kind == BEGIN or kind == ABORT:
            if payload_len != 0:
                break
        elif kind == PATCH:
            if payload_len < 7:
                break
            page_idx, byte_off, byte_count = _PATCH_HDR.unpack_from(payload, 0)
            if byte_count == 0 or payload_len != 6 + byte_count:
                break
            if page_idx >= num_pages or byte_off + byte_count > page_len:
                break
        else:  # COMMIT
            if payload_len != 8:
                break

        # Record is structurally valid: it now participates in the prefix and
        # in transaction state processing.
        pos = end + CRC_SIZE
        valid_bytes = pos
        last_seq = seq

        if kind == BEGIN:
            active[txid] = []
        elif kind == PATCH:
            incarnation = active.get(txid)
            if incarnation is not None:
                page_idx, byte_off = _PATCH_HDR.unpack_from(payload, 0)[:2]
                incarnation.append((page_idx, byte_off, payload))
        elif kind == COMMIT:
            incarnation = active.pop(txid, None)
            if incarnation is not None:
                patch_count, digest = _COMMIT.unpack_from(payload, 0)
                concatenated = b''.join(entry[2] for entry in incarnation)
                if (patch_count == len(incarnation)
                        and (zlib.crc32(concatenated) & 0xFFFFFFFF) == digest
                        and seq > checkpoint):
                    for page_idx, byte_off, staged in incarnation:
                        blob = staged[6:]
                        pages[page_idx][byte_off:byte_off + len(blob)] = blob
        else:  # ABORT
            active.pop(txid, None)

    return {
        "pages": [p.hex() for p in pages],
        "valid_bytes": valid_bytes,
        "last_seq": last_seq,
    }


def main():
    out = sys.stdout
    for line in sys.stdin:
        if not line.strip():
            continue
        request = json.loads(line)
        out.write(json.dumps(solve(request)))
        out.write('\n')
        out.flush()
    out.flush()


if __name__ == '__main__':
    main()
