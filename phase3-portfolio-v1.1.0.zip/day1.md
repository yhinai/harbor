# Current task portfolio

**Verified — Phase 3 status.** The five selected CPU-only, offline packages pass
canonical, alternative, wrong-solution, isolation, and Harbor checks. Exact
package bytes and current evidence are frozen in
`evidence/day1-amendment-v1.1.0.json`. Historical registrations are preserved.
SQLite is removed; `alignment-relaxation` is retired; `atomic-range-history` is
retained again at the user's request.

**Inferred — provisional forecasts.** Ranked most to least likely to be hard.
Predictions are subjective prior means rounded to eight trials, conditional on
validity, before any valid paid proxy panel or frontier evaluation. The Phase 4
paid panel and evidence-based Day 1 update are pending human `go`. Older frontier
anchors are reference points and upper bounds on expected difficulty for newer
targets; their rates are not estimates for these tasks.

| Rank / task | Capability gap and concrete mechanism (inferred) | Predicted K / 8 (inferred) | Evidence and calibration reference | Workflow |
| --- | --- | ---: | --- | --- |
| 1 · typecheck-soundness-witness | Track returned-function effects across repeated loop analysis; a memo key omits nested write sets, so loop-carried function assignments can preserve an obsolete cell fact. | 4 | **Verified:** two distinct programs produce type errors at steps 26 and 48; a corrected key rejects both. The first design was found by random generation in about 1.8 seconds and discarded. The revised 900-second baseline tried 3,245,426 programs (1,581,430 accepted) and found zero qualifying counterexamples; `typecheck-baseline-hardened-v1.json` records the counts and hashes. **Reported:** `break-filter-js-from-html`, older GPT-5/Codex CLI, 0/5; later Opus 4.5/Terminus 80%, denominator unknown. **Inferred:** structural counterexample analogy only; transfer unmeasured. | **Verified:** W2; static checker, explicit-stack concrete interpreter, separate direct evaluator, random generation, negative controls and isolation probes. |
| 2 · exact-fused-dot | Preserve exact products through cancellation and combine rounding, exceptional values, signed zero and flags. A locally rounded intermediate can change the final answer. | 5 | **Verified:** 21,375 differential cases; four substantive arithmetic mutants rejected. **Reported:** `bn-fit-modify`, older GPT-5/Codex CLI, 3/4. **Inferred:** weak numerical reference; no task-specific calibration. | **Verified:** W1; integer canonical versus Fraction/encoding-search alternative. |
| 3 · mixed-width-tso | Enumerate complete outcomes across per-byte forwarding, FIFO drains, fences and exchanges; simplifying the represented state changes reachable outcomes. | 6 | **Verified:** 72 differential cases; five semantic mutants rejected. **Reported:** `fix-ocaml-gc` supplies a systems-state debugging analogy, with per-task rate unknown. **Inferred:** structural reference only; complete enumeration is feasible within the published bounds. | **Verified:** W1; immutable DFS versus per-byte dictionary BFS. |
| 4 · checkpointed-journal | Compose prefix validity, transaction incarnations, seals, commit order and checkpoint state; a locally plausible replay rule can apply the wrong bytes. | 6 | **Verified:** 377 differential cases; four recovery mutants rejected. **Reported:** `build-pmars`, older GPT-5/Codex CLI, 5/5. **Inferred:** low-relevance historical control anchor; it does not estimate recovery-task difficulty. | **Verified:** W1; streaming staging versus parse-and-bundle replay; malformed/truncated logs. |
| 5 · atomic-range-history | Find a whole-transaction order consistent with real-time and range observations. Incomplete search or incorrect absence semantics can reject a valid history or accept an invalid one. | 6 | **Verified:** 139 differential cases; four substantive mutants rejected; different valid orders accepted. **Reported:** `build-cython-ext`, older GPT-5/Codex CLI, 4/4. **Inferred:** low-relevance control reference; the 10-transaction bound makes exhaustive search plausible. | **Verified:** W1; memoized state search versus permutation/replay. |

**Verified — W1/W2:** One Codex assistant authored generation, implementation,
critique, tests and revision; no separate critic model or subagent was used.
Tools were Python, shell, Docker/Colima, Harbor's canonical oracle, and the
versioned scripts under `tools/`. Exact prompts and steering are recorded in
`PROMPTS.md`; the agent receives only its package instruction and environment.
The static and concrete execution mechanisms are different, but same-author
bias remains. Sources and historical rates: `../analysis/research-memo.md` and
`../analysis/benchmark-evidence.json`.

**Unknown:** frontier pass counts, official overnight results, and the strength
of transfer from the baseline to either target. No target frontier model has
been run. Paid calls remain on hold. Harness and transport failures are excluded
from difficulty evidence.

**Inferred — falsifier:** The type-checker task is currently the leading
candidate. A valid frontier result with K ≥ 3 falsifies the claim that it meets
the assignment's hard criterion. Successful proxy trajectories that identify
the omitted nested type information would weaken the proposed transfer
mechanism. A negative random search alone does not justify a strong hardness
claim. Final update rules and the completed Day 1 registration belong to Phase 4.
