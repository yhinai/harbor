# Frontier task portfolio

**Reported — selection.** The current set is `typecheck-soundness-witness`,
`exact-fused-dot`, `mixed-width-tso`, `checkpointed-journal`, and
`atomic-range-history`. `selected-tasks.json` is the authoritative list.
`alignment-relaxation` is historical and excluded from the current archive and
oracle command. SQLite has been removed from the plan.

**Inferred — status.** Phase 3 establishes reproducibility and validity evidence.
Local tests and non-LLM baselines do not establish frontier difficulty. Current
forecasts in `day1.md` are provisional judgments before the paid development
panel; Phase 4 must analyze real rewards and trajectories before the final Day 1
registration. Neither target model has been run.

| Task | Submission artifact | Main demand |
| --- | --- | --- |
| typecheck-soundness-witness | `witness.json` | Find a statically accepted program with a concrete runtime type error |
| exact-fused-dot | `main.py` | Exact accumulation and one final rounding |
| mixed-width-tso | `main.py` | Complete outcomes with byte forwarding |
| checkpointed-journal | `main.py` | Prefix validation and transaction recovery |
| atomic-range-history | `main.py` | Whole-transaction order consistent with observations |

Each package contains `task.toml`, `instruction.md`, `environment/Dockerfile`,
`tests/test.sh`, `solution/solve.sh`, and its canonical artifact. Correctness is
checked by behavior. Alternatives are differently structured programs by the
same author, rather than independent external reviews.

## Reproduce

Requires Docker, Compose/Buildx, Python 3.12, and Harbor 0.24.0. Environments use
a digest-pinned Python base image. It may need to be pulled during image build;
execution is CPU-only and offline, with no downloaded runtime dependencies.
From the parent workspace:

```sh
export PATH="/opt/homebrew/bin:$PATH"
export DOCKER_CONFIG="$PWD/tmp/docker-config"
export DOCKER_HOST="unix://$HOME/.colima/frontier-portfolio/docker.sock"
export PYTHONDONTWRITEBYTECODE=1
tmp/harbor-venv/bin/python portfolio/tools/validate.py
tmp/harbor-venv/bin/python portfolio/tools/docker_validate.py
tmp/harbor-venv/bin/python portfolio/tools/validate_typecheck.py
tmp/harbor-venv/bin/python portfolio/tools/crosscheck_typecheck.py
tmp/harbor-venv/bin/python portfolio/tools/audit_inputs.py
tmp/harbor-venv/bin/python portfolio/tools/instruction_audit.py
tmp/harbor-venv/bin/python portfolio/tools/isolation_audit.py
tmp/harbor-venv/bin/python portfolio/tools/run_oracles.py fresh-oracle-job
```

The four implementation-task scripts use the retained selection. The
checker-task validator runs its canonical and alternative programs, negative
controls, corrected-checker control, and isolation probes. The oracle runner
excludes the retired task and asserts all five rewards, exception status, and
unchanged package hashes. An unborn Git HEAD can cause a nonfatal Harbor
metadata warning; actual trial rewards and exceptions determine success.
`tools/build.py`, `finish.py`, and `make_cases.py` are historical generation
scripts, not commands for rebuilding the current selection.

The reproducible baseline is `tools/typecheck_baseline.py`. Its versioned records
contain seed, duration, program counts, coverage, source hashes, and saved
counterexamples. A negative random search is not evidence that no counterexample
can be found by a model or a stronger search method.

## Paid calls remain on hold

**Reported:** The maximum authorized spend is $185.30, from an initially reported
$385.30 credit. **Verified:** The client has a proxy allowlist, a $170 operational
limit, conservative reservations, per-trial limits, and no automatic refund for
unknown usage. The existing ledger remains halted. The host key is never
included in tasks or archives. These controls do not impose an account-wide
billing cap on other clients.

The freeze does not authorize Phase 4. The next human `go` is required. After
that authorization, the planned panel is five Kimi, three GLM, and three DeepSeek
trials per task, with tool-use smoke tests first. Compatible smoke trials are
admitted independently of reward. Transport, harness, budget, and protocol
failures are excluded from difficulty evidence. No target frontier model is
allowed through the client.

Historical registrations and validation records remain under `evidence/`.
Versioned amendments identify the exact current package bytes. The Phase 3
archive is a review artifact; the final Day 1 submission still requires the
Phase 4 evidence update. The evaluator's later results require a separate
one-page `report.md` and final `P(K=0..8)` distributions.
